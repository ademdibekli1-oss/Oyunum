
"use strict";
/* ================= SABİTLER ================= */
const $=id=>document.getElementById(id);
const MIN=60e3,HOUR=3600e3,DAY=86400e3;
const SPEED=Math.max(1,+(new URLSearchParams(location.search).get('hiz'))||1); // test: ?hiz=60
const SAVE='rrreal_v2', OFFLINE_CAP=3*DAY, PROTECT=36*HOUR;
const ELECT=24*HOUR, ELECT_LEN=2*HOUR, REVIEW=HOUR, WAR_PREP=20*MIN, WAR_LEN=3*HOUR;
const flr=Math.floor, clamp=(x,a,b)=>Math.max(a,Math.min(b,x)), rnd=(a,b)=>a+Math.random()*(b-a), pick=a=>a[flr(Math.random()*a.length)];
const fmt=n=>Math.round(n).toLocaleString('tr-TR');
const f1=n=>(Math.round(n*10)/10).toLocaleString('tr-TR');
const fmtT=t=>new Date(t).toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
function fmtDur(ms){ms=Math.max(0,ms);const s=flr(ms/1000),d=flr(s/86400),h=flr(s%86400/3600),m=flr(s%3600/60),sc=s%60;
  return d?`${d}g ${h}sa`:h?`${h}sa ${m}dk`:m?`${m}dk ${String(sc).padStart(2,'0')}sn`:`${sc}sn`;}

const RES=['gold','oil','ore','uranium','diamonds'];
const RES_N={gold:'Altın',oil:'Petrol',ore:'Maden',uranium:'Uranyum',diamonds:'Elmas'};
const RES_I={gold:'🥇',oil:'🛢️',ore:'⛏️',uranium:'☢️',diamonds:'💎'};
const PRICE0={gold:800,oil:28,ore:20,uranium:900,diamonds:1500};
const YIELD={gold:0.2,oil:1,ore:1.2};                 // kamu fabrikası verimi (uranyum/elmas yalnızca özel fabrikada)
const DRAIN={gold:1,oil:0.1,ore:0.08,uranium:3,diamonds:3}; // üretilen birim başına rezerv düşüşü
const PRIV_BASE={gold:0.6,oil:6,ore:7,uranium:0.15,diamonds:0.15};
const PERKS={str:'Güç',edu:'Eğitim',end:'Dayanıklılık'};
const PERK_D={str:'Savaş hasarı, kamu fabrikası verimi, üretim maliyeti −',edu:'Maksimum iş deneyimi, savaş hasarı, üretim maliyeti −',end:'İş enerji gideri −, depo +%1/puan, savaş alfa-hasarı'};

const BUILD={ // bölge binaları (kanunla, devlet bütçesiyle)
  hospital:{n:'Hastane',i:'🏥',idx:'h',d:'Sağlık indeksi +1'},
  school:{n:'Okul',i:'🏫',idx:'e',d:'Eğitim indeksi +1 (öğrenme hızlanır)'},
  base:{n:'Askeri Üs',i:'🎖️',idx:'m',d:'Askeri indeks +1 (savunma)'},
  house:{n:'Konut Fonu',i:'🏘️',idx:'d',d:'Gelişmişlik indeksi +1 (vergi geliri)'},
  power:{n:'Enerji Santrali',i:'⚡',d:'Uranyum/elmas fabrikası için gerekli'},
  airport:{n:'Havalimanı',i:'🛫',d:'Hava savaşı açar'},
  port:{n:'Liman',i:'⚓',d:'Deniz savaşı açar (kıyı bölgesi)'},
  missile:{n:'Füze Sistemi',i:'🚀',d:'Füze hasarı/savunma'},
  spaceport:{n:'Uzay Üssü',i:'🛰️',d:'Ay savaşı açar'},
  academy:{n:'Askeri Akademi',i:'🏛️',d:'Saldırı hasarı +%5/seviye'},
  library:{n:'Kütüphane',i:'📚',d:'Öğrenme süresi −%5/seviye'}
};
const IDX_B=['hospital','school','base','house'];
const ITEMS={ // üretilebilir eşyalar
  tank:{n:'Tank',i:'🚜',type:'land',money:5000,ore:60,oil:25,time:6*MIN,dmg:1.0},
  fighter:{n:'Savaş Uçağı',i:'✈️',type:'air',money:12000,ore:90,oil:60,time:10*MIN,dmg:1.4},
  bomber:{n:'Ağır Bombardıman',i:'🛩️',type:'air',money:25000,ore:140,oil:90,diamonds:3,time:15*MIN,dmg:2.5},
  ship:{n:'Savaş Gemisi',i:'🚢',type:'naval',money:20000,ore:160,oil:70,time:14*MIN,dmg:1.8},
  battleship:{n:'Zırhlı Gemi',i:'⛴️',type:'naval',money:45000,ore:250,oil:150,diamonds:6,time:25*MIN,dmg:3.5},
  missile:{n:'Balistik Füze',i:'🚀',type:'land',money:60000,oil:100,uranium:6,diamonds:2,time:30*MIN,dmg:6,needs:'missile'},
  moontank:{n:'Ay Tankı',i:'🛸',type:'space',money:50000,ore:200,uranium:5,time:20*MIN,dmg:4},
  station:{n:'Uzay İstasyonu',i:'🛰️',type:'space',money:120000,uranium:12,diamonds:6,time:40*MIN,dmg:8}
};
const WTYPE={land:'Kara',naval:'Deniz',air:'Hava',space:'Uzay'};
const GOVS={republic:'Başkanlık Cumhuriyeti',dictatorship:'Diktatörlük'};

/* ================= HARİTA ================= */
// [ad, devlet, kıyı, ay, idx(h,m,e,d), rezerv(gold,oil,ore,uranium,diamonds)]
const REG0=[
 ['Başkent Bölgesi','A',0,0,[5,4,5,6],[60,80,200,0,0]],
 ['Verimli Ova','A',0,0,[4,3,4,5],[0,60,160,0,0]],
 ['Dağlık Sınır','A',0,0,[3,5,3,3],[140,30,260,6,0]],
 ['Güney Kıyısı','A',1,0,[4,3,4,5],[0,120,90,0,8]],
 ['Doğu Madeni','A',0,0,[3,4,3,4],[90,40,320,10,0]],
 ['Kuzey Limanı','K',1,0,[4,5,4,5],[0,90,120,0,0]],
 ['Buzul Ovası','K',0,0,[3,4,3,3],[40,150,100,0,0]],
 ['Çelik Şehri','K',0,0,[4,6,4,6],[0,40,330,4,0]],
 ['Kutup Üssü','K',0,0,[2,8,2,2],[0,200,80,14,0]],
 ['Doğu Platosu','D',0,0,[3,5,3,4],[60,110,180,0,0]],
 ['Petrol Havzası','D',0,0,[4,5,4,6],[0,380,60,0,0]],
 ['Kervan Kenti','D',0,0,[4,4,5,7],[0,50,140,0,12]],
 ['Çöl Sınırı','D',0,0,[2,6,2,3],[20,160,100,8,0]],
 ['Güney Limanı','G',1,0,[4,6,4,6],[0,100,110,0,10]],
 ['Vaha','G',0,0,[4,3,4,5],[100,20,80,0,0]],
 ['Çöl Kapısı','G',0,0,[3,7,3,4],[30,130,150,5,0]],
 ['Altın Dağları','G',0,0,[3,5,3,3],[320,10,200,0,16]],
 ['Batı Ovası','B',0,0,[5,3,5,6],[0,70,130,0,0]],
 ['Liman Kenti','B',1,0,[5,4,5,7],[0,60,110,0,6]],
 ['Sanayi Havzası','B',0,0,[4,4,5,7],[0,50,300,8,0]],
 ['Elmas Vadisi','B',0,0,[3,3,3,4],[60,20,90,6,26]],
 ['Ay Üssü Alfa','O',0,1,[1,3,2,2],[0,0,300,18,10]],
 ['Ay Üssü Beta','O',0,1,[1,3,2,2],[160,0,420,12,30]]
 ,['Boğaz Kalesi','A',1,0,[5,4,5,7],[0,40,120,0,6]],
 ['Ege Limanı','A',1,0,[4,3,4,6],[0,50,90,0,10]],
 ['Karadeniz Yaylası','A',0,0,[3,4,3,3],[110,30,210,4,0]],
 ['Beyaz Deniz Limanı','K',1,0,[3,5,3,4],[0,120,90,0,0]],
 ['Taiga Karakolu','K',0,0,[2,7,2,2],[60,140,150,6,0]],
 ['Hazar Kıyısı','D',1,0,[4,4,4,5],[0,300,70,0,8]],
 ['Hint Kapısı','D',0,0,[4,4,5,7],[40,60,130,0,18]],
 ['Altay Geçidi','D',0,0,[3,6,3,3],[200,40,260,8,0]],
 ['Kızıldeniz Limanı','G',1,0,[4,5,4,6],[0,160,80,0,14]],
 ['Sahra Kapısı','G',0,0,[2,7,2,3],[50,220,90,10,0]],
 ['Habeş Yaylası','G',0,0,[3,4,3,4],[260,15,140,0,12]],
 ['Ren Vadisi','B',0,0,[5,3,5,6],[0,50,140,0,0]],
 ['Akdeniz Sahili','B',1,0,[5,3,5,6],[0,40,80,0,8]],
 ['Kuzey Denizi Limanı','B',1,0,[4,4,5,7],[0,140,100,4,0]]
];
const EDGES0=[[0,1],[0,2],[0,4],[0,5],[1,3],[1,17],[2,4],[2,9],[3,13],[4,10],[5,6],[5,7],[6,7],[6,8],[7,9],[9,10],[9,11],[10,11],[10,12],[11,15],[13,14],[13,15],[14,15],[14,16],[17,18],[17,19],[18,19],[19,20],[8,6]];
const EDGES_NEW=[[23,24],[23,0],[24,3],[23,3],[25,4],[25,2],[25,0],[26,5],[26,6],[27,6],[27,8],[27,12],[28,9],[28,2],[28,10],[28,25],[29,11],[29,12],[30,12],[30,27],[31,15],[31,10],[31,14],[32,14],[32,13],[32,35],[33,15],[33,31],[34,17],[34,36],[35,17],[35,34],[36,17]];
const EDGES=EDGES0.concat(EDGES_NEW);
const REG_N0=23; // eski kayıtlarda bölge sayısı
function mkReg(i){const r=REG0[i];return {id:i,n:r[0],state:r[1],coast:!!r[2],moon:!!r[3],adj:[],
    idx:{h:r[4][0],m:r[4][1],e:r[4][2],d:r[4][3]},
    res:Object.fromEntries(RES.map((k,j)=>[k,{c:r[5][j],m:r[5][j],dm:0,dmEnd:0}])),
    b:{},bq:[],auto:false,gov:null};}
/* eski kayıtlara yeni şehirleri ekle */
function migrateRegions(s){
  if(!s||!s.regions||s.regions.length>=REG0.length)return s;
  for(let i=s.regions.length;i<REG0.length;i++)s.regions.push(mkReg(i));
  EDGES_NEW.forEach(e=>{const a=s.regions[e[0]],b=s.regions[e[1]];if(a&&b){if(!a.adj.includes(e[1]))a.adj.push(e[1]);if(!b.adj.includes(e[0]))b.adj.push(e[0]);}});
  return s;
}
const STATE_N={A:'Anadolu Cumhuriyeti',K:'Kuzey Federasyonu',D:'Doğu Birliği',G:'Güney Emirliği',B:'Batı Cumhuriyeti',O:'Ay Kolonisi'};
const AI_S=['K','D','G','B','O'];
const AI_BASE={K:{rel:-15,aggr:0.9},D:{rel:-25,aggr:1.0},G:{rel:-35,aggr:1.2},B:{rel:5,aggr:0.7},O:{rel:0,aggr:0.2}};
const PARTY0=[
  {id:'halk',n:'Halk Partisi',supp:34,pref:{tax:0.6,build:0.5,explore:0.4,transfer:-0.6,war:-0.4,treaty:0.6,gov:-0.8,autonomy:0.2}},
  {id:'ulus',n:'Ulusal Birlik',supp:30,pref:{tax:-0.4,build:0.2,explore:0.5,transfer:-0.2,war:0.7,treaty:-0.3,gov:0.1,autonomy:-0.5}},
  {id:'ozgur',n:'Özgürlük ve Piyasa',supp:22,pref:{tax:-0.7,build:0.1,explore:0.6,transfer:-0.5,war:0.1,treaty:0.4,gov:-0.6,autonomy:0.6}},
  {id:'yesil',n:'Yeşil Gelecek',supp:14,pref:{tax:0.3,build:0.6,explore:-0.6,transfer:-0.4,war:-0.8,treaty:0.7,gov:-0.7,autonomy:0.4}}
];

/* ================= DURUM ================= */
let S=null;
function newState(){
  const t=Date.now();
  const regions=REG0.map((r,i)=>({id:i,n:r[0],state:r[1],coast:!!r[2],moon:!!r[3],adj:[],
    idx:{h:r[4][0],m:r[4][1],e:r[4][2],d:r[4][3]},
    res:Object.fromEntries(RES.map((k,j)=>[k,{c:r[5][j],m:r[5][j],dm:0,dmEnd:0}])),
    b:{},bq:[],auto:false,gov:null}));
  EDGES.forEach(e=>{regions[e[0]].adj.push(e[1]);regions[e[1]].adj.push(e[0]);});
  const rel={};['A'].concat(AI_S).forEach(a=>{rel[a]={};['A'].concat(AI_S).forEach(b=>{if(a!==b)rel[a][b]=0;});});
  AI_S.forEach(k=>{rel.A[k]=rel[k].A=AI_BASE[k].rel;});
  AI_S.forEach(a=>AI_S.forEach(b=>{if(a!==b)rel[a][b]=rnd(-30,10);}));
  const states={A:{n:STATE_N.A,gov:'republic',leader:'Başkan Koç',leaderMe:false,parlSize:100,
      parties:PARTY0.map(p=>Object.assign({members:0,leaderName:''},p,{pref:Object.assign({},p.pref)})),
      budget:{money:150000,gold:10,oil:200,ore:300,uranium:0,diamonds:0},
      tax:{inc:10,gold:10,oil:10,ore:10,uranium:10,diamonds:10},
      min:{econ:null,foreign:null},nextElection:t+ELECT,election:null,warScore:0,rulingParty:'halk',
      treaty:{mil:{},emb:{},mig:{}},truce:{}}};
  AI_S.forEach(k=>{states[k]={n:STATE_N[k],aggr:AI_BASE[k].aggr,next:t+rnd(6,14)*HOUR,truce:{},bonus:1};});
  return {v:2,startT:t,t:t,savedReal:t,live:false,dirty:true,seq:1,
    me:{name:'Sen',level:1,xp:0,str:30,edu:30,end:30,learn:null,boost:null,boostCd:0,
      energy:100,loc:0,res:0,resSince:t-DAY,travel:null,money:40000,
      stor:{gold:0,oil:100,ore:100,uranium:0,diamonds:0},items:Object.fromEntries(Object.keys(ITEMS).map(k=>[k,0])),
      craftQ:[],party:null,partyLead:false,paper:null,facs:[],hits:0,works:0,lastLobby:0,lastCamp:0,lastVote:0},
    regions:regions,states:states,rel:rel,laws:[],wars:[],
    prices:Object.assign({},PRICE0),nextPrice:t+10*MIN,mods:[],nextEvent:t+rnd(5,9)*HOUR,
    protectUntil:t+PROTECT,log:[],news:[]};
}
function load(){try{const d=localStorage.getItem(SAVE);if(!d)return null;const s=JSON.parse(d);return s&&s.v===2&&s.regions?migrateRegions(s):null;}catch(e){return null;}}
function save(){if(window.__noSave)return;try{S.savedReal=Date.now();const c=Object.assign({},S);delete c.dirty;delete c.live;localStorage.setItem(SAVE,JSON.stringify(c));}catch(e){}}
function L(m,c=''){S.log.unshift({t:S.t,m:m,c:c});if(S.log.length>200)S.log.pop();S.dirty=true;
  if(S.live&&typeof toast==='function')toast(m,c);}
function news(m){S.news.unshift({t:S.t,m:m});if(S.news.length>60)S.news.pop();S.dirty=true;}

/* ================= YARDIMCILAR ================= */
const ME=()=>S.me, A=()=>S.states.A;
const regOf=s=>S.regions.filter(r=>r.state===s);
const nameOf=s=>S.states[s]?S.states[s].n:s;
function perk(k){let v=S.me[k];if(S.me.boost&&S.me.boost.perk===k&&S.me.boost.end>S.t)v+=100;return v;}
const craftBonus=()=>Math.min(50,Math.sqrt(perk('str'))+Math.sqrt(perk('edu')));
function energyCost(){if(S.me.admin)return 0;const e=perk('end');return e>=50?5:Math.max(5,Math.round(10-(e-30)/4));}
const storCap=()=>S.me.admin?1e7:Math.floor(2000*(1+S.me.end/100)*(1+0.25*(((S.me.inv||{}).depo)||0)));
const myReg=()=>S.regions[S.me.loc];
const homeReg=()=>S.regions[S.me.res];
function levelB(r,b){return r.b[b]||0;}
function totalB(r,except){return Object.keys(r.b).reduce((a,k)=>a+(k===except?0:r.b[k]),0);}
function hasB(state,b){return regOf(state).some(r=>levelB(r,b)>0);}
function xpNeed(l){return 80+l*30;}
function addXP(n){const m=S.me;n*=(1+0.08*(((m.inv||{}).akad)||0))*(1+((typeof critBonus==='function')?critBonus('A','xp'):0));m.xp+=n;while(m.xp>=xpNeed(m.level)){m.xp-=xpNeed(m.level);m.level++;L(`⭐ Seviye ${m.level}!`,'ok');}}
function hopsTo(from,to){if(from===to)return 0;const seen={[from]:0},q=[from];
  while(q.length){const c=q.shift();for(const n of S.regions[c].adj){if(seen[n]===undefined){seen[n]=seen[c]+1;if(n===to)return seen[n];q.push(n);}}}return 99;}
function isMine(r){return r.state==='A';}
function powerOf(s){ // devletin askeri gücü (vatandaşlar/yapay zekâ)
  const days=(S.t-S.startT)/DAY;
  const base=regOf(s).reduce((a,r)=>a+r.idx.m*7+totalB(r,'house')*2,0);
  const g=s==='A'?1:(1+0.015*days)*(S.states[s].bonus||1);
  return base*g*(1+((typeof critBonus==='function')?critBonus(s,'power'):0))+((typeof BOTAGG!=='undefined'&&BOTAGG.st[s])?BOTAGG.st[s].str*0.0035:0);
}
function relTo(x,y){return S.rel[x]&&S.rel[x][y]!==undefined?S.rel[x][y]:0;}
function addRel(x,y,d){if(x===y)return;S.rel[x][y]=clamp(S.rel[x][y]+d,-100,100);S.rel[y][x]=S.rel[x][y];}
function atWar(s){return S.wars.filter(w=>w.state!=='done'&&(w.att===s||w.def===s));}
function adjacentStates(s){const o=new Set();regOf(s).forEach(r=>r.adj.forEach(a=>{const st=S.regions[a].state;if(st!==s)o.add(st);}));return Array.from(o);}
function modF(k){let f=1;S.mods.forEach(m=>{if(m.kind===k&&m.end>S.t)f*=m.f;});return f;}

/* ================= KARAKTER ================= */
function learnTimeMs(perkName,gold){
  const L=S.me[perkName]+1,E=homeReg().idx.e>=11?20:homeReg().idx.e;
  let T=(1-E/50)*L*L*(gold?0.72:9.6);
  if(L<=100)T*=0.5;if(L<=50)T*=0.5;
  T*=Math.max(0.5,1-0.05*levelB(homeReg(),'library'));
  if(typeof critBonus==='function')T*=Math.max(0.5,1-critBonus('A','learn'));
  if(typeof elBonus==='function')T*=Math.max(0.5,1-elBonus('learn'));
  return Math.max(30,T)*1000;
}
function learnCost(perkName,gold){const L=S.me[perkName]+1;return gold?Math.max(1,flr(L/8)):L*60;}
function addStor(res,amt){const cap=storCap(),cur=S.me.stor[res],ok=Math.min(amt,Math.max(0,cap-cur));S.me.stor[res]+=ok;return ok;}
function stateTax(state,res){return state==='A'?A().tax[res]/100:0.1;}
function regionAllows(r){ // çalışma izni
  if(r.state==='A')return true;
  if(relTo('A',r.state)<-50)return false;
  return true;
}
function workAmount(res,region){
  const m=S.me;
  return (3+m.level*0.05+perk('str')*0.12)*(YIELD[res]||0)*(1+region.idx.d*0.02)*(1+0.03*(region.dev||0))*(1+((typeof critBonus==='function')?critBonus('A','work'):0))*(1+((typeof allyBonus==='function')?allyBonus():0))*((typeof cityEvtF==='function')?cityEvtF(region.id):1)*(1+((typeof elBonus==='function')?elBonus('work'):0))*modF('work');
}
function doWork(res){
  if(S.me.jail>S.t)return 'Hapistesin ('+fmtDur(S.me.jail-S.t)+').';
  const m=S.me,r=myReg();
  if(m.travel)return 'Yoldasın.';
  if(!YIELD[res])return 'Bu kaynak yalnızca özel fabrikada üretilir.';
  if(!regionAllows(r))return 'Bu bölgede çalışma iznin yok.';
  if(r.res[res].c<=0)return `${r.n} bölgesinde ${RES_N[res]} rezervi bitti.`;
  const ec=energyCost();if(m.energy<ec)return 'Yetersiz enerji.';
  m.energy-=ec;
  let amt=workAmount(res,r)*((typeof evtMult==='function')?evtMult():1)*(1+0.05*(((m.inv||{}).fab)||0));const take=Math.min(amt,r.res[res].c/DRAIN[res]);amt=take;
  const tax=stateTax(r.state,res),t=amt*tax;let net=amt-t;
  if(!m.admin&&typeof prodTaxFor==='function'){const pr=prodTaxFor(res);if(pr>0){const pu=net*pr;net-=pu;m.taxPaid=(m.taxPaid||0)+pu*S.prices[res]*0.9;}}
  const ok=addStor(res,net);
  r.res[res].c=Math.max(0,r.res[res].c-amt*DRAIN[res]);
  if(r.state==='A')A().budget[res]+=t;
  m.works++;addXP(3+perk('edu')/25);
  return {amt:net,lost:net-ok,tax:t};
}
function drinkEnergy(){const m=S.me;if(m.stor.gold<2)return 'Yetersiz altın (2).';m.stor.gold-=2;m.energy=Math.min(200,m.energy+50);return true;}

/* ================= EKONOMİ ================= */
const TAXR=(r)=>(S.me.admin||typeof MP==='undefined')?0:((typeof taxFor==='function')?taxFor(r):MP.rate)/100;
function buyRes(res,n){const t=TAXR(res),p=S.prices[res]*1.1,c=Math.ceil(p*n*(1+t));if(S.me.money<c)return 'Yetersiz para.';
  const ok=Math.min(n,Math.max(0,storCap()-S.me.stor[res]));if(ok<=0)return 'Depo dolu.';
  const cc=Math.ceil(p*ok),tax=Math.ceil(cc*t);S.me.money-=cc+tax;S.me.taxPaid=(S.me.taxPaid||0)+tax;S.me.stor[res]+=ok;S.me.buys=(S.me.buys||0)+1;S.prices[res]*=1+ok*0.0003/Math.max(1,PRICE0[res]/100);return {n:ok,c:cc,tax:tax};}
function sellRes(res,n){n=Math.min(n,Math.floor(S.me.stor[res]*100)/100);if(n<=0)return 'Satacak kaynak yok.';
  const t=TAXR(res),g0=Math.floor(S.prices[res]*0.9*n),tax=Math.floor(g0*t),g=g0-tax;S.me.stor[res]-=n;S.me.money+=g;S.me.sells=(S.me.sells||0)+1;S.me.taxPaid=(S.me.taxPaid||0)+tax;S.prices[res]*=1-n*0.0003/Math.max(1,PRICE0[res]/100);S.prices[res]=Math.max(S.prices[res],PRICE0[res]*0.5);return {n:n,g:g,tax:tax};}
function itemCost(k,n){const b=1-craftBonus()/100,I=ITEMS[k],o={money:Math.ceil(I.money*b*n)};RES.forEach(r=>{if(I[r])o[r]=Math.ceil(I[r]*b*n);});return o;}
function facRate(f){return PRIV_BASE[f.res]*f.level*(1+perk('edu')/200)*(1+0.02*((S.regions[f.region]||{}).dev||0))*modF('work');}
function facCost(res,level){return {gold:10*level+(res==='uranium'||res==='diamonds'?10:0),money:30000*level};}

/* ================= ZAMAN / SİMÜLASYON ================= */
function integrate(ms){
  const h=ms/HOUR,m=S.me;
  if(typeof botsTick==='function')botsTick(ms);
  if(typeof powerTick==='function')powerTick(h);
  if(m.energy<100)m.energy=Math.min(100,m.energy+(30+4*(((m.inv||{}).house)||0)+Math.max(0,homeReg().idx.h-3)*1.5)*h); // içecekle 100 üstüne çıkan enerji korunur
  if(typeof autoRun==='function')autoRun();
  if(typeof bankTick==='function')bankTick(h);
  // özel fabrikalar
  m.facs.forEach(f=>{const r=S.regions[f.region];if(!r||r.res[f.res].c<=0||r.state!==f.owner)return;
    const prod=Math.min(facRate(f)*h,r.res[f.res].c/DRAIN[f.res]);
    const tax=stateTax(r.state,f.res);f.stock=Math.min(f.stock+prod*(1-tax),facRate(f)*24);
    r.res[f.res].c=Math.max(0,r.res[f.res].c-prod*DRAIN[f.res]);
    if(r.state==='A')A().budget[f.res]+=prod*tax;});
  // devlet geliri (vatandaşlar)
  const a=A();let inc=0;regOf('A').forEach(r=>{inc+=r.idx.d*3000*(a.tax.inc/100)*(1+0.1*levelB(r,'house'));
    // yapay zekâ işçileri kaynak çıkarır
    RES.forEach(k=>{if(r.res[k].c>0&&YIELD[k]!==undefined){const p=r.res[k].m*0.0015*h*(r.idx.d/5);a.budget[k]+=p*a.tax[k]/100*5;r.res[k].c=Math.max(0,r.res[k].c-p*DRAIN[k]*0.2);}});});
  a.budget.money+=inc*h;
  // savaş hasarı (yapay zekâ vatandaşlar)
  S.wars.forEach(w=>{if(w.state!=='on')return;
    const ra=rnd(0.8,1.2),rd=rnd(0.8,1.2);
    const rr=S.regions[w.region];
    const acad=regOf(w.att).reduce((x,r)=>x+levelB(r,'academy'),0);
    const pa=powerOf(w.att)*5*(1+0.05*acad);
    const pd=powerOf(w.def)*5*1.25*(1+0.03*totalB(rr,'house')); // savunan taraf avantajlı
    w.dA+=pa*ra*h;w.dD+=pd*rd*h;});
}
function nextEventTime(){
  let n=Infinity;const mm=x=>{if(x&&x<n)n=x;};
  const m=S.me;
  if(m.learn)mm(m.learn.end);if(m.boost)mm(m.boost.end);if(m.travel)mm(m.travel.arrive);m.craftQ.forEach(q=>mm(q.end));
  S.regions.forEach(r=>{if(r.bq.length)mm(r.bq[0].end);RES.forEach(k=>mm(r.res[k].dmEnd));});
  S.laws.forEach(l=>{if(l.status==='pending')mm(l.end);});
  S.wars.forEach(w=>{if(w.state==='prep')mm(w.start);else if(w.state==='on')mm(w.end);});
  if(A().gov!=='dictatorship'){if(A().election)mm(A().election.end);else mm(A().nextElection);}
  AI_S.forEach(k=>mm(S.states[k].next));
  mm(S.nextPrice);mm(S.nextEvent);S.mods.forEach(x=>mm(x.end));
  return n;
}
function processEvents(t){
  const m=S.me;
  if(m.learn&&m.learn.end<=t){m[m.learn.perk]++;L(`📈 ${PERKS[m.learn.perk]} ${m[m.learn.perk]} seviyesine ulaştı.`,'ok');m.learn=null;}
  if(m.boost&&m.boost.end<=t){L(`⏱️ ${PERKS[m.boost.perk]} güçlendiricisi bitti.`,'info');m.boost=null;}
  if(m.travel&&m.travel.arrive<=t){m.loc=m.travel.to;L(`🧳 ${S.regions[m.loc].n} bölgesine vardın.`,'ok');m.travel=null;}
  if(typeof craftFinish==='function')craftFinish(t);else while(m.craftQ.length&&m.craftQ[0].end<=t){const b=m.craftQ.shift();m.items[b.k]+=b.n;L(`🔧 ${b.n} ${ITEMS[b.k].n} üretildi.`,'ok');}
  S.regions.forEach(r=>{
    while(r.bq.length&&r.bq[0].end<=t){const b=r.bq.shift();completeBuilding(r,b.b);}
    RES.forEach(k=>{const x=r.res[k];if(x.dmEnd&&x.dmEnd<=t){x.dmEnd=0;x.m=Math.max(x.c,x.m-x.dm);x.dm=0;}});});
  S.laws.forEach(l=>{if(l.status==='pending'&&l.end<=t)resolveLaw(l);});
  S.wars.forEach(w=>{if(w.state==='prep'&&w.start<=t)startWar(w);else if(w.state==='on'&&w.end<=t)endWar(w);});
  S.wars=S.wars.filter(w=>w.state!=='done'||t-w.end<12*HOUR);
  electionTick(t);
  AI_S.forEach(k=>{if(S.states[k].next<=t)aiAct(k);});
  while(S.nextPrice<=t){for(const k of RES){const b=PRICE0[k];let p=S.prices[k];p+=(b-p)*0.05+p*rnd(-0.02,0.02);S.prices[k]=clamp(p,b*0.5,b*2.2);}S.nextPrice+=10*MIN;if(typeof phRec==='function')phRec(S.nextPrice-10*MIN);}
  if(S.nextEvent<=t){randomEvent();S.nextEvent=t+rnd(5,9)*HOUR;}
  S.mods=S.mods.filter(x=>x.end>t);
  // devlet bakımı: diktatör ayaklanması
  const a=A();if(a.gov==='dictatorship'&&a.leaderMe&&t-(a.lastUp||S.startT)>DAY){a.lastUp=t;
    if(Math.random()<0.18+Math.max(0,(a.tax.inc-10))*0.01){a.gov='republic';a.leaderMe=false;a.leader='Başkan Yılmaz';a.parlSize=100;L('🔥 Halk ayaklandı! Diktatörlük yıkıldı, cumhuriyet yeniden kuruldu.','bad');
      news('Halk ayaklanması rejimi devirdi.');}}
}
function randomEvent(){
  const e=pick(['boom','crash','quake','oil','strike','aid','scandal']);
  if(e==='boom'){const k=pick(RES);S.prices[k]=Math.min(PRICE0[k]*2.2,S.prices[k]*1.35);news(`${RES_N[k]} fiyatları yükseldi.`);}
  else if(e==='crash'){const k=pick(RES);S.prices[k]=Math.max(PRICE0[k]*0.5,S.prices[k]*0.7);news(`${RES_N[k]} fiyatları düştü.`);}
  else if(e==='quake'){const r=pick(S.regions.filter(x=>!x.moon));const k=pick(['h','m','e','d']);if(r.idx[k]>1){r.idx[k]--;news(`${r.n} bölgesinde deprem: bir indeks düştü.`);if(r.state==='A')L(`🌋 ${r.n} bölgesinde deprem! İndeks düştü.`,'bad');}}
  else if(e==='oil'){const r=pick(regOf('A'));r.res.oil.c+=40;r.res.oil.m+=40;L(`🛢️ ${r.n} bölgesinde yeni petrol damarı (+40 rezerv).`,'ok');}
  else if(e==='strike'){S.mods.push({kind:'work',f:0.7,end:S.t+3*HOUR});L('✊ Genel grev! 3 saat üretim %30 düştü.','bad');}
  else if(e==='aid'){const k=pick(AI_S.filter(x=>x!=='O'));addRel('A',k,8);A().budget.money+=15000;L(`🤝 ${nameOf(k)} bütçeye 15.000₺ yardım yaptı.`,'ok');}
  else{const a=A();a.parties.forEach(p=>{p.supp=Math.max(1,p.supp+rnd(-2,2));});L('📰 Siyasi skandal: partilerin desteği değişti.','info');}
}

/* ================= BİNALAR ================= */
function completeBuilding(r,b){
  r.b[b]=(r.b[b]||0)+1;
  const B=BUILD[b];if(B.idx)r.idx[B.idx]=Math.min(11,r.idx[B.idx]+1);
  if(r.state==='A')L(`🏗️ ${r.n}: ${B.n} tamamlandı.`,'ok');
  news(`${nameOf(r.state)} — ${r.n}: ${B.n} tamamlandı.`);
}
function buildCost(r,b){const lv=(r.b[b]||0)+r.bq.filter(x=>x.b===b).length;return 120000*(lv+1);}
function buildTime(r,b){const lv=(r.b[b]||0)+r.bq.filter(x=>x.b===b).length;return (lv+1)*HOUR;}

/* ================= KANUNLAR / PARLAMENTO ================= */
const LAW_K={tax:'Vergi',build:'Bina inşası',explore:'Kaynak keşfi',deep:'Derin arama',transfer:'Bütçe transferi',war:'Savaş ilanı',treaty:'Anlaşma',gov:'Hükümet şekli',autonomy:'Özerklik'};
const LAW_CAT={tax:'eco',build:'eco',explore:'eco',deep:'eco',transfer:'eco',war:'war',treaty:'foreign',gov:'gov',autonomy:'misc'};
function seatsOf(){
  const a=A(),o={};if(!a.parlSize){a.parties.forEach(p=>o[p.id]=0);return o;}
  const tot=a.parties.reduce((x,p)=>x+Math.max(0,p.supp),0)||1;let used=0;const rem=[];
  a.parties.forEach(p=>{const sh=p.supp/tot;if(sh<0.01){o[p.id]=0;return;}const q=a.parlSize*sh;o[p.id]=Math.floor(q);used+=o[p.id];rem.push([p.id,q-Math.floor(q)]);});
  rem.sort((x,y)=>y[1]-x[1]);for(let i=0;used<a.parlSize&&rem.length;i++,used++)o[rem[i%rem.length][0]]++;
  return o;
}
function lawText(k,g){
  if(k==='tax')return `Vergi: gelir %${g.inc}, altın %${g.gold}, petrol %${g.oil}, maden %${g.ore}, uranyum %${g.uranium}, elmas %${g.diamonds}`;
  if(k==='build')return `${S.regions[g.region].n}: ${BUILD[g.b].n} inşa edilsin`;
  if(k==='explore')return `${S.regions[g.region].n}: yeni ${RES_N[g.res]} keşfi`;
  if(k==='deep')return `${S.regions[g.region].n}: ${RES_N[g.res]} derin arama (24 saat)`;
  if(k==='transfer')return `Bütçeden ${fmt(g.amt)} ${g.res==='money'?'₺':RES_N[g.res]} oyuncuya aktarılsın`;
  if(k==='war')return `${S.regions[g.region].n} bölgesine ${WTYPE[g.type]} savaşı ilanı`;
  if(k==='treaty')return `${nameOf(g.state)} ile ${({mil:'askeri anlaşma',emb:'ambargo',mig:'göç anlaşması'})[g.kind]}`;
  if(k==='gov')return g.to==='dictatorship'?'Diktatörlük ilan edilsin':'Cumhuriyete dönülsün';
  if(k==='autonomy')return `${S.regions[g.region].n} özerk bölge olsun`;
  return k;
}
function proposeLaw(kind,args,by){
  const a=A();
  const id=S.seq++;const L0={id:id,kind:kind,args:args,by:by||'me',start:S.t,end:S.t+REVIEW,status:'pending',pro:0,txt:lawText(kind,args)};
  S.laws.unshift(L0);if(S.laws.length>40)S.laws.pop();
  const mine=by==='me';
  const dict=a.gov==='dictatorship'&&a.leaderMe&&mine&&kind!=='gov';
  const early=mine&&a.leaderMe&&a.gov==='republic'&&(LAW_CAT[kind]==='war'||false);
  const econ=mine&&(a.min.econ==='me'||a.leaderMe)&&LAW_CAT[kind]==='eco';
  const forn=mine&&(a.min.foreign==='me'||a.leaderMe)&&LAW_CAT[kind]==='foreign';
  if(dict||early||econ||forn){resolveLaw(L0,true);}
  else L(`🏛️ Kanun teklifi verildi: ${L0.txt}. Oylama ${fmtDur(REVIEW)} sonra.`,'info');
  return L0;
}
function lawSupport(l){
  const a=A(),seats=seatsOf();let pro=0,tot=0;
  a.parties.forEach(p=>{
    const s=seats[p.id]||0;tot+=s;
    let like=0.5+0.5*(p.pref[l.kind]||0);
    if(p.id==='me')like=l.by==='me'?1:0.5;
    if(l.by==='me'&&S.me.party===p.id)like=1;
    if(l.by==='leader'&&p.id===a.rulingParty)like=Math.min(1,like+0.3);
    like=clamp(like+(l.lobby||0),0,1);
    pro+=s*like;});
  return {pro:pro,tot:tot,pct:tot?pro/tot:0};
}
function resolveLaw(l,instant){
  if(l.status!=='pending')return;
  const a=A();
  let pass,pct=1;
  if(instant)pass=true;
  else{const s=lawSupport(l);pct=s.pct;l.pro=Math.round(pct*100);
    pass=pct>(l.kind==='gov'&&l.args.to==='dictatorship'?0.8:0.5);}
  l.status=pass?'passed':'failed';
  if(!pass){L(`🏛️ Kanun reddedildi (%${l.pro} evet): ${l.txt}`,'warn');return;}
  const err=execLaw(l);
  if(err){l.status='failed';L(`🏛️ Kanun uygulanamadı (${err}): ${l.txt}`,'warn');}
  else{L(`🏛️ Kanun kabul edildi${instant?'':' (%'+l.pro+' evet)'}: ${l.txt}`,'ok');news(`Yasa kabul edildi: ${l.txt}`);}
}
function execLaw(l){
  const a=A(),g=l.args;
  if(l.kind==='tax'){['inc','gold','oil','ore','uranium','diamonds'].forEach(k=>{a.tax[k]=clamp(+g[k],0,40);});return null;}
  if(l.kind==='build'){const r=S.regions[g.region];if(r.state!=='A')return 'bölge artık bizim değil';
    const c=buildCost(r,g.b);if(a.budget.money<c)return 'bütçe yetersiz';
    if((r.b[g.b]||0)+r.bq.filter(x=>x.b===g.b).length>=(BUILD[g.b].idx?(11-r.idx[BUILD[g.b].idx]):5))return 'en üst seviye';
    if(g.b==='port'&&!r.coast)return 'kıyı bölgesi değil';
    a.budget.money-=c;const st=r.bq.length?r.bq[r.bq.length-1].end:S.t;r.bq.push({b:g.b,start:st,end:st+buildTime(r,g.b)});return null;}
  if(l.kind==='explore'){const r=S.regions[g.region];if(r.state!=='A')return 'bölge bizim değil';if(r.res[g.res].m>0)return 'bu kaynak zaten var';
    if(a.budget.money<80000)return 'bütçe yetersiz';a.budget.money-=80000;r.res[g.res].m=30;r.res[g.res].c=30;return null;}
  if(l.kind==='deep'){const r=S.regions[g.region];if(r.state!=='A')return 'bölge bizim değil';
    if(a.budget.money<60000||a.budget.gold<5)return 'bütçe yetersiz (60.000₺ + 5 altın)';
    if(regOf('A').some(x=>RES.some(k=>x.res[k].dmEnd>S.t)))return 'zaten bir derin arama sürüyor';
    a.budget.money-=60000;a.budget.gold-=5;const x=r.res[g.res];const add=Math.round(Math.max(10,x.m*0.5));x.dm=add;x.m+=add;x.c+=add;x.dmEnd=S.t+24*HOUR;return null;}
  if(l.kind==='transfer'){const have=g.res==='money'?a.budget.money:a.budget[g.res];if(have<g.amt)return 'bütçe yetersiz';
    if(g.res==='money'){a.budget.money-=g.amt;S.me.money+=g.amt;}else{a.budget[g.res]-=g.amt;addStor(g.res,g.amt);}return null;}
  if(l.kind==='war'){return declareWar('A',g.region,g.type,true);}
  if(l.kind==='treaty'){const k=g.kind,s=g.state;
    if(k==='mil'){a.treaty.mil[s]=S.t+72*HOUR;addRel('A',s,25);}
    else if(k==='mig'){a.treaty.mig[s]=S.t+72*HOUR;addRel('A',s,10);}
    else{a.treaty.emb[s]=S.t+72*HOUR;addRel('A',s,-20);}return null;}
  if(l.kind==='gov'){
    if(g.to==='dictatorship'){if(!a.leaderMe)return 'diktatör olmak için başkan olmalısın';a.gov='dictatorship';a.parlSize=0;a.lastUp=S.t;L('👑 Diktatörlük ilan edildi: kanunlar anında çıkar, seçim yok.','warn');}
    else{a.gov='republic';a.parlSize=100;a.nextElection=S.t+ELECT;}
    return null;}
  if(l.kind==='autonomy'){const r=S.regions[g.region];if(r.state!=='A')return 'bölge bizim değil';r.auto=true;return null;}
  return 'bilinmeyen kanun';
}

/* ================= SEÇİM ================= */
function partyShare(){ // parti desteği (pp) + gazete
  const a=A(),m=S.me;
  return a.parties.map(p=>{let s=Math.max(0,p.supp);
    if(p.id==='me'&&m.paper)s+=m.paper.subs/200;
    if(typeof BOTAGG!=='undefined')s+=(BOTAGG.party[p.id]||0)*0.015;
    if(p.id===a.rulingParty){s-=Math.max(0,a.tax.inc-10)*0.5;s+=a.warScore*2;}
    return {id:p.id,s:Math.max(0.1,s+rnd(-1.5,1.5))};});
}
function electionTick(t){
  const a=A();
  if(a.gov==='dictatorship'){return;}
  if(!a.election&&a.nextElection<=t){a.election={start:t,end:t+ELECT_LEN};L('🗳️ Seçim başladı! Oy ver ya da kampanya yap. Sonuçlar 2 saat sonra.','info');news('Seçim başladı.');}
  else if(a.election&&a.election.end<=t){
    const sh=partyShare(),tot=sh.reduce((x,y)=>x+y.s,0);
    // oyuncunun oyu küçük bir ek
    if(S.me.votedFor){const x=sh.find(y=>y.id===S.me.votedFor);if(x)x.s+=S.me.level*0.05;}
    S.me.votedFor=null;
    const tot2=sh.reduce((x,y)=>x+y.s,0);
    a.parties.forEach(p=>{const x=sh.find(y=>y.id===p.id);p.supp=Math.max(0.5,x.s/tot2*100);});
    const win=sh.slice().sort((x,y)=>y.s-x.s)[0];const wp=a.parties.find(p=>p.id===win.id);
    a.rulingParty=win.id;a.warScore*=0.3;
    const mine=win.id==='me'&&S.me.partyLead;
    a.leaderMe=mine;a.leader=mine?S.me.name:('Başkan '+pick(['Aydın','Demir','Kaya','Şahin','Erdem','Polat']));
    a.min.econ=mine?'me':null;a.min.foreign=null;
    L(`🗳️ Seçim sonucu: ${wp.n} %${Math.round(win.s/tot2*100)} ile kazandı. Başkan: ${a.leader}.`,mine?'ok':'info');
    news(`Seçimi ${wp.n} kazandı; başkan ${a.leader}.`);
    a.election=null;a.nextElection=t+ELECT;
  }
}

/* ================= SAVAŞ ================= */
function warTypes(att,r){ // saldırgan devletin bu bölgeye açabileceği savaş türleri
  const o=[];
  if(r.moon){if(hasB(att,'spaceport'))o.push('space');return o;}
  const adj=r.adj.some(x=>S.regions[x].state===att);
  if(adj)o.push('land');
  if(hasB(att,'airport')&&(adj||true))o.push('air');
  if(r.coast&&hasB(att,'port'))o.push('naval');
  return o;
}
function declareWar(att,rid,type,pay){
  const r=S.regions[rid];if(!r)return 'bölge yok';
  if(r.state===att)return 'kendi bölgen';
  if(S.wars.some(w=>w.state!=='done'&&w.region===rid))return 'bu bölgede zaten savaş var';
  if(S.wars.some(w=>w.state!=='done'&&w.att===att))return 'zaten bir savaşın var';
  if(!warTypes(att,r).includes(type))return 'bu savaş türü açık değil';
  const def=r.state;
  if(S.states[att]&&S.states[att].truce&&S.states[att].truce[def]>S.t)return 'ateşkes sürüyor';
  if(att==='A'){const a=A();if(a.treaty.mil[def]>S.t)return 'askeri anlaşma var';
    if(pay){if(a.budget.money<50000||a.budget.gold<3)return 'bütçe yetersiz (50.000₺ + 3 altın)';a.budget.money-=50000;a.budget.gold-=3;}
    if(S.t<S.protectUntil)S.protectUntil=S.t;}
  const w={id:S.seq++,att:att,def:def,region:rid,type:type,start:S.t+WAR_PREP,end:S.t+WAR_PREP+WAR_LEN,dA:0,dD:0,state:'prep',mine:0};
  S.wars.push(w);addRel(att,def,-35);
  if(att==='A'){L(`⚔️ ${S.regions[rid].n} (${nameOf(def)}) için ${WTYPE[type]} savaşı ilan edildi! Başlangıç: ${fmtT(w.start)}`,'bad');}
  else if(def==='A'){L(`⚠️ ${nameOf(att)} ${S.regions[rid].n} bölgemize ${WTYPE[type]} savaşı ilan etti! Başlangıç: ${fmtT(w.start)}`,'bad');}
  news(`${nameOf(att)}, ${nameOf(def)}'e ${S.regions[rid].n} için ${WTYPE[type]} savaşı ilan etti.`);
  return null;
}
function startWar(w){w.state='on';if(w.att==='A'||w.def==='A')L(`⚔️ ${S.regions[w.region].n} savaşı başladı! Vur (enerji 10) ya da eşya kullan.`,'bad');}
function endWar(w){
  w.state='done';
  const r=S.regions[w.region],attWin=w.dA>w.dD;
  const involved=w.att==='A'||w.def==='A';
  const a=A();
  if(attWin){
    const others=regOf(w.def).length;
    if(others<=1){ // başkent düşmez
      if(involved)L(`🛡️ ${r.n} son bölge: savunma, başkenti kurtardı!`,'ok');
      news(`${nameOf(w.def)} son bölgesini savundu.`);
    }else{
      r.state=w.att;Object.keys(r.b).forEach(b=>{r.b[b]=Math.max(0,r.b[b]-1);});r.bq=[];r.auto=false;
      S.me.facs=S.me.facs.filter(f=>f.region!==r.id||r.state===f.owner);
      if(S.me.res===r.id&&r.state!=='A'){/* ikamet bölgesini kaybetti */}
      if(involved)L(`${w.att==='A'?'🏆':'💥'} ${r.n}: ${nameOf(w.att)} kazandı (${fmt(w.dA)} / ${fmt(w.dD)}).`,w.att==='A'?'ok':'bad');
      news(`${nameOf(w.att)}, ${r.n} bölgesini ${nameOf(w.def)}'den aldı.`);
    }
  }else{
    if(involved)L(`${w.def==='A'?'🛡️':'💀'} ${r.n}: ${nameOf(w.def)} savundu (${fmt(w.dA)} / ${fmt(w.dD)}).`,w.def==='A'?'ok':'bad');
    news(`${nameOf(w.def)}, ${r.n} bölgesini savundu.`);
  }
  if(involved){const ourWin=(w.att==='A')===attWin;a.warScore+=ourWin?1:-1;
    if(w.mine>0){addXP(40);L(`🎖️ Savaşa ${fmt(w.mine)} hasarla katkı yaptın (+40 XP).`,'ok');}}
  const sa=S.states[w.att],sd=S.states[w.def];
  if(sa&&sa.truce)sa.truce[w.def]=S.t+6*HOUR;if(sd&&sd.truce)sd.truce[w.att]=S.t+6*HOUR;
  if(w.att==='A'&&A().truce)A().truce[w.def]=S.t+6*HOUR;
  if(w.def==='A'&&sa)sa.truce.A=S.t+48*HOUR;
  if(sa)sa.cool=S.t+24*HOUR;if(sd)sd.cool=Math.max(sd.cool||0,S.t+12*HOUR);
}
const itemDmg=k=>ITEMS[k].dmg*40*(1+0.25*(((S.me.mk||{})[k]||1)-1));
function hitDamage(item){
  const m=S.me;
  let d=10+perk('str')*0.5+perk('edu')*0.25+perk('end')*0.15;
  if(item)d+=itemDmg(item);
  d*=(1+m.level/100);
  const e=perk('end'),cap=100+m.level*2+(e>=50?20:0)+(e>=75?20:0)+(e>=100?20:0)+(item?itemDmg(item):0);
  d=Math.min(d,cap);
  if(homeReg().state==='A'&&S.t-m.resSince>6*HOUR)d*=1.1;   // anavatan bonusu
  if(typeof elBonus==='function')d*=1+elBonus('war');
  return d;
}
function doHit(wid,item){
  const w=S.wars.find(x=>x.id===wid),m=S.me;
  if(!w||w.state!=='on')return 'Savaş aktif değil.';
  if(w.att!=='A'&&w.def!=='A')return 'Bu savaşta devletin yok.';
  if(m.travel)return 'Yoldasın.';
  if(m.jail>S.t)return 'Hapistesin.';
  if(item){if(ITEMS[item].type!==w.type)return 'Bu eşya bu savaş türünde kullanılamaz.';if(m.items[item]<1)return 'Eşyan yok.';
    if(ITEMS[item].needs&&!hasB('A',ITEMS[item].needs))return 'Füze Sistemi binası gerekli.';}
  if(m.energy<10)return 'Yetersiz enerji (10).';
  m.energy-=10;if(item)m.items[item]--;
  const d=hitDamage(item);
  if(w.att==='A')w.dA+=d;else w.dD+=d;
  w.mine+=d;m.dmg=(m.dmg||0)+d;m.hits++;addXP(6);
  return d;
}
function aiAct(k){
  const s=S.states[k];s.next=S.t+rnd(3,6)*HOUR;
  // yapay zekâ gelişimi ve ilişki sürüklenmesi
  s.bonus=(s.bonus||1)*(1+rnd(0,0.004));
  AI_S.concat(['A']).forEach(o=>{if(o===k)return;const base=o==='A'?AI_BASE[k].rel:(o==='O'?0:-24);S.rel[k][o]=clamp(S.rel[k][o]+(base-S.rel[k][o])*0.08+rnd(-3,3),-100,100);S.rel[o][k]=S.rel[k][o];});
  if(k==='O')return;
  if(atWar(k).length)return;
  if(s.cool>S.t)return;
  if(regOf(k).length===0)return;
  // hedef devlet
  const cand=adjacentStates(k).filter(x=>x!=='O');
  if(!cand.length)return;
  const tgt=cand.sort((x,y)=>S.rel[k][x]-S.rel[k][y])[0];
  if(S.rel[k][tgt]>-20)return;
  if(Math.random()>0.15*s.aggr)return;
  if(s.truce&&s.truce[tgt]>S.t)return;
  if(tgt==='A'){
    if(S.t<S.protectUntil)return;
    if(A().treaty.mil[k]>S.t)return;
    if(powerOf(k)<powerOf('A')*0.8)return;
  }else{if(atWar(tgt).length)return;if(powerOf(k)<powerOf(tgt)*0.9)return;}
  // hedef bölge: sınırdaki en zayıf bölge
  const regs=regOf(tgt).filter(r=>r.adj.some(x=>S.regions[x].state===k));
  if(!regs.length)return;
  const r=regs.sort((x,y)=>(x.idx.m+totalB(x))-(y.idx.m+totalB(y)))[0];
  const types=warTypes(k,r);if(!types.length)return;
  declareWar(k,r.id,types[0],false);
}

/* ================= SİMÜLASYON DÖNGÜSÜ ================= */
function advance(to){
  processEvents(S.t);
  let guard=0;
  while(S.t<to&&guard++<400000){
    const step=Math.min(to,S.t+MIN,Math.max(nextEventTime(),S.t+1));
    integrate(step-S.t);S.t=step;processEvents(S.t);
  }
}
/* ================= GENİŞLETİLMİŞ DÜNYA: yeni şehirler, devletler, komşuluklar =================
   Harita çizimi (kara/deniz/konumlar) harita.js dosyasındadır; burası oyun kuralları (bölge değerleri). */
(function(){
const NEWREG=[["Londra","B",1,0,[5,5,5,7],
[0,60,85,0,5]],
["Madrid","B",0,0,[6,5,6,7],
[30,50,170,0,0]],
["Lizbon","B",1,0,[3,3,3,5],
[0,65,95,0,5]],
["Roma","B",0,0,[6,5,6,7],
[30,55,170,0,0]],
["Berlin","B",0,0,[5,5,6,8],
[0,45,265,5,0]],
["Varşova","B",0,0,[5,4,5,6],
[0,50,145,0,0]],
["Viyana","B",0,0,[6,5,6,7],
[30,50,150,0,0]],
["Atina","B",1,0,[4,4,4,6],
[0,60,90,0,5]],
["Belgrad","B",0,0,[5,4,5,6],
[0,50,145,0,0]],
["Moskova","K",0,0,[6,5,6,7],
[30,50,160,0,0]],
["Kiev","K",0,0,[4,3,4,5],
[0,45,125,0,0]],
["Minsk","K",0,0,[3,2,3,4],
[0,55,150,0,0]],
["Volgograd","K",0,0,[4,4,5,7],
[0,45,285,10,0]],
["Novosibirsk","K",0,0,[4,4,5,7],
[0,55,320,10,0]],
["İrkutsk","K",0,0,[3,8,3,3],
[40,150,120,10,0]],
["Yakutsk","K",0,0,[3,8,3,3],
[35,130,105,5,0]],
["Vladivostok","K",1,0,[5,5,5,7],
[0,75,110,0,5]],
["Murmansk","K",1,0,[4,4,4,6],
[0,70,100,0,5]],
["Magadan","K",0,0,[4,6,4,4],
[300,10,180,0,15]],
["Kamçatka","K",0,0,[1,7,1,1],
[40,145,115,10,0]],
["Oslo","K",1,0,[4,4,4,6],
[0,75,110,0,5]],
["Stockholm","K",1,0,[4,4,4,6],
[0,80,115,0,5]],
["Norilsk","K",0,0,[2,4,2,2],
[135,35,295,5,10]],
["Bağdat","D",0,0,[4,5,4,6],
[0,335,55,0,0]],
["Kabil","D",0,0,[2,4,2,2],
[100,25,220,5,5]],
["Karaçi","D",1,0,[3,3,3,5],
[0,70,105,0,5]],
["Delhi","D",0,0,[4,3,4,5],
[25,45,140,0,0]],
["Mumbai","D",1,0,[4,4,4,6],
[0,80,115,0,5]],
["Kalküta","D",1,0,[4,4,4,6],
[0,75,105,0,5]],
["Chennai","D",1,0,[3,3,3,5],
[0,70,100,0,5]],
["Dakka","D",0,0,[5,4,5,6],
[0,55,155,0,0]],
["Taşkent","D",0,0,[4,3,4,5],
[0,50,145,0,0]],
["Aşkabat","D",0,0,[3,6,3,4],
[35,135,90,5,0]],
["Ulanbator","D",0,0,[3,7,3,3],
[45,165,130,10,0]],
["Bakü","D",0,0,[5,6,5,7],
[0,325,55,0,0]],
["Dubai","D",0,0,[5,6,5,7],
[0,410,70,0,0]],
["Riyad","D",0,0,[4,5,4,6],
[0,360,60,0,0]],
["Pekin","P",0,0,[6,5,6,7],
[30,45,150,0,0]],
["Şanghay","P",1,0,[3,3,3,5],
[0,70,100,0,5]],
["Guangzhou","P",0,0,[4,4,5,7],
[0,45,255,5,0]],
["Çengdu","P",0,0,[4,3,4,5],
[0,55,160,0,0]],
["Vuhan","P",0,0,[4,4,5,7],
[0,50,295,10,0]],
["Şian","P",0,0,[4,3,4,5],
[0,50,140,0,0]],
["Harbin","P",0,0,[3,8,3,3],
[40,150,120,10,0]],
["Seul","P",0,0,[4,4,5,7],
[0,55,340,10,0]],
["Tokyo","P",1,0,[4,4,4,6],
[0,65,90,0,5]],
["Osaka","P",1,0,[5,5,5,7],
[0,60,85,0,5]],
["Sapporo","P",0,0,[1,8,1,1],
[40,145,115,10,0]],
["Hong Kong","P",1,0,[3,3,3,5],
[0,65,90,0,5]],
["Hanoi","P",0,0,[4,3,4,5],
[0,55,150,0,0]],
["Saygon","P",1,0,[4,4,4,6],
[0,75,110,0,5]],
["Bangkok","P",1,0,[3,3,3,5],
[0,65,95,0,5]],
["Yangon","P",1,0,[4,4,4,6],
[0,75,105,0,5]],
["Kuala Lumpur","P",0,0,[4,4,5,7],
[0,55,325,10,0]],
["Singapur","P",1,0,[5,5,5,7],
[0,75,105,0,5]],
["Cakarta","P",1,0,[5,5,5,7],
[0,75,105,0,5]],
["Manila","P",1,0,[4,4,4,6],
[0,70,100,0,5]],
["Papua","P",0,0,[3,5,3,3],
[340,10,205,0,15]],
["Sidney","P",1,0,[3,3,3,5],
[0,70,95,0,5]],
["Melbourne","P",1,0,[4,4,4,6],
[0,80,110,0,5]],
["Perth","P",1,0,[3,3,3,5],
[0,70,100,0,5]],
["Darwin","P",1,0,[4,4,4,6],
[0,80,115,0,5]],
["Brisbane","P",1,0,[4,4,4,6],
[0,70,100,0,5]],
["Alis Springs","P",0,0,[2,7,2,3],
[45,160,110,5,0]],
["Auckland","P",1,0,[3,3,3,5],
[0,70,100,0,5]],
["Lhasa","P",0,0,[2,4,3,3],
[135,35,290,5,10]],
["Los Angeles","M",1,0,[3,3,3,5],
[0,75,105,0,5]],
["San Francisco","M",1,0,[4,4,4,6],
[0,80,110,0,5]],
["Seattle","M",1,0,[5,5,5,7],
[0,60,85,0,5]],
["Denver","M",0,0,[4,6,4,4],
[135,35,300,5,10]],
["Dallas","M",0,0,[5,6,5,7],
[0,325,55,0,0]],
["Houston","M",0,0,[4,5,4,6],
[0,330,55,0,0]],
["Miami","M",1,0,[5,5,5,7],
[0,65,90,0,5]],
["Atlanta","M",0,0,[4,4,5,7],
[0,55,325,10,0]],
["Washington","M",0,0,[6,5,6,7],
[30,50,165,0,0]],
["Boston","M",1,0,[3,3,3,5],
[0,80,110,0,5]],
["Toronto","M",0,0,[4,4,5,7],
[0,55,345,10,0]],
["Montreal","M",1,0,[3,3,3,5],
[0,60,85,0,5]],
["Winnipeg","M",0,0,[4,3,4,5],
[0,45,130,0,0]],
["Calgary","M",0,0,[5,6,5,7],
[0,375,65,0,0]],
["Anchorage","M",0,0,[1,6,1,1],
[35,130,105,5,0]],
["Meksiko","M",0,0,[5,4,5,6],
[35,55,175,0,0]],
["Havana","M",1,0,[4,4,4,6],
[0,70,100,0,5]],
["Panama","M",1,0,[3,3,4,5],
[0,70,100,0,5]],
["Yellowknife","M",0,0,[1,6,1,1],
[45,170,140,10,0]],
["Nuuk","M",0,0,[3,8,3,3],
[35,130,105,5,0]],
["São Paulo","L",0,0,[4,4,5,7],
[0,50,315,10,0]],
["Rio","L",1,0,[4,4,5,7],
[0,75,105,0,5]],
["Brasília","L",0,0,[4,3,4,5],
[35,55,180,0,0]],
["Manaus","L",0,0,[4,4,4,5],
[65,20,100,5,30]],
["Buenos Aires","L",1,0,[4,4,4,6],
[0,75,105,0,5]],
["Santiago","L",0,0,[3,5,3,3],
[115,30,250,5,10]],
["Lima","L",1,0,[4,4,4,6],
[0,70,100,0,5]],
["Bogota","L",0,0,[5,4,5,6],
[0,50,140,0,0]],
["Karakas","L",0,0,[4,5,4,6],
[0,375,65,0,0]],
["La Paz","L",0,0,[3,5,3,3],
[115,30,245,5,10]],
["Montevideo","L",1,0,[3,3,3,5],
[0,70,100,0,5]],
["Recife","L",1,0,[3,3,3,5],
[0,65,90,0,5]],
["Patagonya","L",0,0,[2,7,2,2],
[35,135,105,5,0]],
["Trablus","G",0,0,[4,5,4,6],
[0,330,55,0,0]],
["Tunus","G",1,0,[3,3,3,5],
[0,70,100,0,5]],
["Cezayir","G",1,0,[4,4,4,6],
[0,60,85,0,5]],
["Kazablanka","G",1,0,[4,4,4,6],
[0,70,100,0,5]],
["Dakar","G",1,0,[5,5,5,7],
[0,75,110,0,5]],
["Bamako","G",0,0,[3,5,3,3],
[285,10,170,0,15]],
["Lagos","G",0,0,[5,6,5,7],
[0,355,60,0,0]],
["Akra","G",0,0,[4,6,4,4],
[290,10,175,0,15]],
["Hartum","G",0,0,[4,3,4,5],
[0,55,150,0,0]],
["Nairobi","G",0,0,[3,2,3,4],
[0,55,160,0,0]],
["Dar es Salaam","G",1,0,[3,3,3,5],
[0,75,105,0,5]],
["Kinşasa","G",0,0,[2,2,2,3],
[60,20,95,5,25]],
["Luanda","G",0,0,[4,5,4,6],
[0,330,55,0,0]],
["Cape Town","G",1,0,[3,3,3,5],
[0,65,95,0,5]],
["Durban","G",1,0,[5,5,5,7],
[0,70,100,0,5]],
["Windhoek","G",0,0,[4,4,4,5],
[70,25,105,5,30]],
["Lusaka","G",0,0,[2,4,2,2],
[120,30,255,5,10]],
["Antananarivo","G",0,0,[4,3,4,5],
[0,50,140,0,0]],
["Mogadişu","G",1,0,[4,4,4,6],
[0,80,115,0,5]],
["Tamanrasset","G",0,0,[3,7,3,4],
[35,130,85,5,0]],
["Kampala","G",0,0,[4,3,4,5],
[0,50,145,0,0]],
["Harare","G",0,0,[4,6,4,4],
[260,10,155,0,10]]];
NEWREG.forEach(r=>REG0.push(r));
/* Amerika şehirleri yeni devletlere */
REG0[18][1]='M';REG0[19][1]='M';REG0[20][1]='L';
const NEWEDG=[[2,60],[2,71],[5,46],[5,48],[5,54],[5,58],[6,59],[7,49],[7,50],[7,68],[8,51],[8,59],[9,60],[9,69],[10,60],[10,72],[10,73],[11,61],[11,68],[11,69],[12,61],[12,63],[12,68],[12,102],[13,60],[14,136],[14,144],[15,144],[16,149],[16,150],[16,151],[16,157],[17,37],[18,111],[18,112],[18,113],[19,106],[19,110],[19,111],[19,113],[19,115],[20,125],[20,126],[20,132],[23,45],[23,47],[24,44],[25,49],[26,46],[26,54],[27,50],[27,59],[28,60],[28,71],[29,61],[29,62],[29,63],[30,50],[30,51],[31,60],[31,73],[31,144],[32,136],[32,138],[32,155],[33,144],[33,145],[33,154],[33,156],[34,40],[34,41],[35,38],[35,40],[35,137],[35,138],[36,37],[36,57],[38,39],[38,138],[39,139],[40,43],[40,44],[40,45],[40,137],[41,42],[41,43],[41,57],[41,58],[42,43],[42,48],[42,58],[43,45],[44,45],[44,136],[44,137],[45,47],[46,47],[46,48],[46,49],[47,48],[47,49],[49,71],[50,68],[51,52],[51,70],[52,55],[52,70],[52,80],[53,55],[53,80],[53,81],[53,84],[55,56],[55,80],[55,84],[56,84],[57,58],[61,72],[62,64],[62,72],[63,64],[63,65],[63,102],[64,65],[64,66],[65,66],[65,67],[65,89],[66,89],[67,77],[67,89],[67,102],[70,74],[70,79],[70,102],[74,78],[74,79],[74,80],[74,81],[75,76],[75,78],[75,81],[75,83],[76,78],[76,85],[76,86],[77,79],[77,86],[77,102],[78,79],[81,83],[82,83],[82,84],[83,84],[85,87],[85,93],[86,88],[86,89],[87,88],[87,90],[87,93],[88,89],[90,91],[91,92],[94,98],[95,96],[95,99],[95,100],[96,100],[97,100],[98,100],[99,100],[99,101],[103,104],[103,106],[103,118],[104,105],[105,106],[105,116],[105,117],[106,107],[106,115],[106,116],[107,108],[107,110],[108,109],[108,110],[108,118],[108,119],[109,110],[109,119],[110,111],[111,113],[112,114],[113,114],[115,116],[115,121],[116,121],[118,119],[118,120],[119,120],[119,131],[120,130],[123,124],[123,125],[123,133],[124,125],[125,134],[126,129],[126,130],[126,131],[126,132],[127,128],[127,133],[127,135],[128,132],[128,135],[129,130],[129,132],[130,131],[136,137],[137,138],[138,139],[139,140],[139,141],[139,155],[140,141],[141,143],[141,155],[142,143],[142,144],[142,147],[142,155],[145,146],[145,154],[145,156],[146,152],[146,153],[146,157],[147,148],[147,156],[148,151],[148,152],[149,150],[149,151],[151,152],[152,157],[153,157],[92,90],[94,100],[97,96],[101,95],[117,116],[122,114],[122,112],[134,124],[98,92]];
NEWEDG.forEach(e=>{EDGES_NEW.push(e);EDGES.push(e);});
})();

/* ---- yeni devletler ---- */
Object.assign(STATE_N,{M:'Yeni Dünya Birliği',L:'Güney Haç Cumhuriyeti',P:'Pasifik Konfederasyonu'});
Object.assign(AI_BASE,{M:{rel:-10,aggr:0.8},L:{rel:-5,aggr:0.6},P:{rel:-20,aggr:1.0}});
['M','L','P'].forEach(k=>{if(!AI_S.includes(k))AI_S.splice(AI_S.indexOf('O'),0,k);});
/* eski kayıtlar: yeni devletleri ve ilişkileri ekle, Amerika bölgelerini yeni devletlere ver */
const _mig0=migrateRegions;
migrateRegions=function(s){
  if(!s||!s.regions)return s;
  const grow=s.regions.length<REG0.length;
  s=_mig0(s);
  if(grow){[[18,'M'],[19,'M'],[20,'L']].forEach(a=>{const r=s.regions[a[0]];if(r&&r.state==='B')r.state=a[1];});}
  s.states=s.states||{};s.rel=s.rel||{};
  const all=['A'].concat(AI_S);
  ['M','L','P'].forEach(k=>{
    if(!s.states[k])s.states[k]={n:STATE_N[k],aggr:AI_BASE[k].aggr,next:(s.t||Date.now())+(6+Math.random()*8)*3600e3,truce:{},bonus:1};
    s.rel[k]=s.rel[k]||{};
  });
  all.forEach(a=>{s.rel[a]=s.rel[a]||{};all.forEach(b=>{if(a!==b&&typeof s.rel[a][b]!=='number')s.rel[a][b]=(a==='A'?AI_BASE[b]&&AI_BASE[b].rel:(b==='A'?AI_BASE[a]&&AI_BASE[a].rel:-12))||0;});});
  return s;
};
/* ================= EYLEMLER ================= */
const ACT={};
const UI={tab:'home',lawKind:'tax',lastWork:null};
function msg(m,c='bad'){toast(m,c);}
function res(r,okMsg){if(typeof r==='string'){msg(r);return false;}if(okMsg)msg(okMsg,'ok');return true;}
const isLeader=()=>A().leaderMe;
const myParty=()=>A().parties.find(p=>p.id===S.me.party);

ACT.tab=d=>{UI.tab=d.t;};
ACT.learn=d=>{
  const m=S.me;if(m.learn)return msg('Zaten bir şey öğreniyorsun.');
  const gold=d.g==='1',c=learnCost(d.p,gold);
  if(gold){if(m.stor.gold<c)return msg(`Yetersiz altın (${c}).`);m.stor.gold-=c;}else{if(m.money<c)return msg(`Yetersiz para (${fmt(c)}₺).`);m.money-=c;}
  const T=learnTimeMs(d.p,gold);m.learn={perk:d.p,start:S.t,end:S.t+T};
  L(`📚 ${PERKS[d.p]} ${m[d.p]+1} seviyesi için öğrenme başladı (${fmtDur(T)}).`,'info');
};
ACT.boost=d=>{
  const m=S.me;if(m.boost&&m.boost.end>S.t)return msg('Zaten aktif bir güçlendirici var.');
  if(S.t<m.boostCd)return msg(`Güçlendirici ${fmtDur(m.boostCd-S.t)} sonra kullanılabilir.`);
  const gold=d.g==='1';
  if(gold){if(m.stor.gold<25)return msg('Yetersiz altın (25).');m.stor.gold-=25;}else{if(m.money<30000)return msg('Yetersiz para (30.000₺).');m.money-=30000;}
  const dur=gold?20*HOUR:2*HOUR;m.boost={perk:d.p,end:S.t+dur};m.boostCd=S.t+12*HOUR;
  L(`💪 ${PERKS[d.p]} +100 güçlendirici ${fmtDur(dur)} aktif.`,'ok');
};
ACT.drink=()=>{const r=drinkEnergy();if(res(r,'⚡ +50 enerji'))L('⚡ Enerji içeceği içildi.','info');};
ACT.work=d=>{
  const n=+d.n||1;let tot=0,lost=0,err=null;
  for(let i=0;i<n;i++){const r=doWork(d.r);if(typeof r==='string'){err=r;break;}tot+=r.amt;lost+=r.lost;}
  if(tot>0){UI.lastWork=`${RES_I[d.r]} +${f1(tot)} ${RES_N[d.r]}${lost>0.001?` (depo dolu: ${f1(lost)} kayıp)`:''}`;msg(UI.lastWork,'ok');}
  if(err)msg(err);
};
ACT.workAll=d=>{let i=0;while(i<60){const r=doWork(d.r);if(typeof r==='string'){if(!i)msg(r);break;}i++;}if(i){UI.lastWork=`${i} kez çalıştın.`;msg(UI.lastWork,'ok');}};
ACT.buy=d=>{let n=+d.n;
  if(d.n==='fill'){const t=TAXR(d.r),p=S.prices[d.r]*1.1*(1+t),room=Math.max(0,storCap()-S.me.stor[d.r]);
    n=Math.floor(Math.min(room,S.me.money/p));
    if(room<=0)return msg('Depo zaten dolu.');if(n<1)return msg('Yetersiz para.');}
  const r=buyRes(d.r,n);res(r,'🛒 Alındı');};
ACT.sell=d=>{const r=sellRes(d.r,d.n==='all'?1e9:+d.n);res(r,'💰 Satıldı');};
ACT.craft=d=>{
  const k=d.k,n=+d.n,I=ITEMS[k],c=itemCost(k,n),m=S.me;
  if(I.needs&&!hasB('A',I.needs))return msg(`${BUILD[I.needs].n} binası gerekli (devlette).`);
  if(m.money<c.money)return msg('Yetersiz para.');
  for(const r of RES)if(c[r]&&m.stor[r]<c[r])return msg(`Yetersiz ${RES_N[r]}.`);
  m.money-=c.money;RES.forEach(r=>{if(c[r])m.stor[r]-=c[r];});
  m.crafts=(m.crafts||0)+1;
  const last=m.craftQ.length?m.craftQ[m.craftQ.length-1].end:S.t;m.craftQ.push({k:k,n:n,start:last,end:last+I.time*n});
  L(`🔧 ${n} ${I.n} üretime alındı (${fmtDur(I.time*n)}).`,'info');
};
ACT.facBuild=d=>{
  const r=myReg(),res0=d.r,m=S.me;
  if(r.res[res0].m<=0)return msg('Bu bölgede bu kaynak yok.');
  if((res0==='uranium'||res0==='diamonds')&&levelB(r,'power')<1)return msg('Bu bölgede Enerji Santrali olmalı.');
  if(m.facs.some(f=>f.region===r.id&&f.res===res0))return msg('Bu bölgede bu kaynak için zaten fabrikan var.');
  if(m.facs.length>=facSlots())return msg('Fabrika sınırına ulaştın.');
  const c0=facCost(res0,1),xm=facExtra(),c={gold:Math.ceil(c0.gold*xm),money:Math.ceil(c0.money*xm)};if(m.stor.gold<c.gold||m.money<c.money)return msg(`Gerekli: ${c.gold} altın + ${fmt(c.money)}₺${xm>1?' (6 fabrikadan sonra her yeni fabrika %15 daha pahalı)':''}`);
  m.stor.gold-=c.gold;m.money-=c.money;m.facs.push({id:S.seq++,res:res0,region:r.id,owner:r.state,level:1,stock:0});
  L(`🏭 ${r.n}: özel ${RES_N[res0]} fabrikası kuruldu.`,'ok');
};
ACT.facUp=d=>{
  const f=S.me.facs.find(x=>x.id===+d.id),m=S.me;if(!f||f.level>=10)return;
  const c=facCost(f.res,f.level+1);if(m.stor.gold<c.gold||m.money<c.money)return msg(`Gerekli: ${c.gold} altın + ${fmt(c.money)}₺`);
  m.stor.gold-=c.gold;m.money-=c.money;f.level++;msg('Fabrika yükseltildi.','ok');
};
ACT.facCollect=d=>{
  const f=S.me.facs.find(x=>x.id===+d.id);if(!f)return;
  let q=f.stock;if(!S.me.admin&&typeof prodTaxFor==='function'){const pr=prodTaxFor(f.res);if(pr>0){const pu=q*pr;q-=pu;S.me.taxPaid=(S.me.taxPaid||0)+pu*S.prices[f.res]*0.9;}}
  const ok=addStor(f.res,q);f.stock-=ok;msg(`+${f1(ok)} ${RES_N[f.res]} depoya alındı.`,'ok');
};
ACT.travel=d=>{
  const m=S.me,to=+d.to,r=S.regions[to];
  if(m.travel)return msg('Zaten yoldasın.');
  if(r.moon){if(!hasB('A','spaceport'))return msg('Ay için Uzay Üssü gerekli (devlet kanunuyla).');}
  const h=r.moon?3:hopsTo(m.loc,to);if(h>=99)return msg('Yol yok.');
  const cost=r.moon?20000:500*h;if(m.money<cost)return msg(`Yol ücreti ${fmt(cost)}₺.`);
  if(S.regions[to].state!=='A'&&relTo('A',r.state)<-70)return msg('Sınır kapalı (ilişkiler çok kötü).');
  m.money-=cost;m.travel={to:to,start:S.t,arrive:S.t+(r.moon?30*MIN:h*5*MIN)};
  L(`🧳 ${r.n} bölgesine yola çıktın (${fmtDur(m.travel.arrive-S.t)}).`,'info');
};
ACT.resid=()=>{
  const m=S.me,r=myReg();if(m.travel)return msg('Yoldasın.');if(m.res===r.id)return msg('Zaten buradasın.');
  if(r.moon)return msg('Ay üssünde ikamet edilemez.');
  if(r.state!=='A'&&relTo('A',r.state)<-30)return msg('Bu devletle ilişkiler kötü; ikamet verilmez.');
  m.res=r.id;m.resSince=S.t;L(`🏠 ${r.n} bölgesine yerleştin. (Anavatan bonusu için 6 saat beklemelisin.)`,'ok');
};
ACT.createParty=()=>{
  const m=S.me,n=($('partyName')||{}).value||'';
  if(m.party)return msg('Zaten bir partidesin.');if(m.level<10)return msg('Parti kurmak için seviye 10 gerekli.');
  if(n.trim().length<3)return msg('Parti adı yaz.');if(m.money<20000)return msg('Yetersiz para (20.000₺).');
  m.money-=20000;A().parties.push({id:'me',n:n.trim().slice(0,28),supp:1,pref:{},members:1});m.party='me';m.partyLead=true;
  L(`🗳️ "${n.trim()}" partisini kurdun.`,'ok');
};
ACT.joinParty=d=>{const m=S.me;if(m.party)return msg('Önce partinden ayrıl.');if(m.level<5)return msg('Seviye 5 gerekli.');m.party=d.p;m.partyLead=false;L('🗳️ Bir partiye katıldın.','ok');};
ACT.leaveParty=()=>{const m=S.me,a=A();if(m.party==='me'){a.parties=a.parties.filter(p=>p.id!=='me');}m.party=null;m.partyLead=false;L('Partiden ayrıldın.','info');};
ACT.campaign=()=>{
  const m=S.me,p=myParty();if(!p)return msg('Önce bir partiye gir.');if(S.t<m.lastCamp+HOUR)return msg(`Kampanya için ${fmtDur(m.lastCamp+HOUR-S.t)} bekle.`);
  if(m.money<10000)return msg('Yetersiz para (10.000₺).');m.money-=10000;m.lastCamp=S.t;
  p.supp+=0.4+m.level*0.01;L(`📣 Kampanya yaptın: ${p.n} desteği arttı (%${f1(p.supp)}).`,'ok');
};
ACT.vote=d=>{const a=A();if(!a.election)return msg('Şu an seçim yok.');if(S.me.level<5)return msg('Oy için seviye 5 gerekli.');S.me.votedFor=d.p;msg('Oyun kaydedildi.','ok');};
ACT.lawkind=d=>{};
ACT.propose=()=>{
  const k=UI.lawKind,g={},v=id=>{const e=$(id);return e?e.value:'';};
  if(S.me.level<5)return msg('Kanun teklifi için seviye 5 gerekli.');
  if(k==='tax'){['inc','gold','oil','ore','uranium','diamonds'].forEach(x=>g[x]=+v('lw_'+x));if(Object.values(g).some(x=>isNaN(x)||x<0||x>40))return msg('Oranlar 0–40 arasında olmalı.');}
  else if(k==='build'){g.region=+v('lw_region');g.b=v('lw_b');}
  else if(k==='explore'||k==='deep'){g.region=+v('lw_region');g.res=v('lw_res');}
  else if(k==='transfer'){g.res=v('lw_res');g.amt=+v('lw_amt');if(!(g.amt>0))return msg('Miktar gir.');}
  else if(k==='war'){g.region=+v('lw_region');g.type=v('lw_type');if(isNaN(g.region))return msg('Hedef seç.');}
  else if(k==='treaty'){g.state=v('lw_state');g.kind=v('lw_kind');}
  else if(k==='gov'){g.to=v('lw_to');if(g.to==='dictatorship'&&!isLeader())return msg('Diktatör olmak için önce seçimle başkan olmalısın.');}
  else if(k==='autonomy'){g.region=+v('lw_region');}
  if(S.laws.some(l=>l.status==='pending'&&l.kind===k&&JSON.stringify(l.args)===JSON.stringify(g)))return msg('Bu teklif zaten oylamada.');
  proposeLaw(k,g,'me');
};
ACT.lobby=d=>{
  const l=S.laws.find(x=>x.id===+d.id);if(!l||l.status!=='pending')return;
  if((l.lobbyN||0)>=3)return msg('En fazla 3 lobi yapılabilir.');if(S.me.money<20000)return msg('Yetersiz para (20.000₺).');
  S.me.money-=20000;l.lobby=(l.lobby||0)+0.08;l.lobbyN=(l.lobbyN||0)+1;msg('Lobi yapıldı: milletvekillerinin desteği arttı.','ok');
};
ACT.minister=d=>{if(!isLeader())return msg('Yalnızca başkan bakan atayabilir.');const a=A();a.min[d.m]=a.min[d.m]==='me'?null:'me';msg(a.min[d.m]==='me'?'Kendini atadın.':'Görevden alındın.','ok');};
ACT.hit=d=>{const r=doHit(+d.w,d.item||null);if(typeof r==='string')return msg(r);msg(`💥 ${fmt(r)} hasar!`,'ok');};
ACT.hitAll=d=>{let n=0,tot=0;while(n<30){const r=doHit(+d.w,d.item||null);if(typeof r==='string'){if(!n)msg(r);break;}tot+=r;n++;}if(n)msg(`💥 ${n} vuruş, toplam ${fmt(tot)} hasar.`,'ok');};
ACT.declare=()=>{
  const rid=+($('wRegion')||{}).value,type=($('wType')||{}).value;if(isNaN(rid))return msg('Hedef seç.');
  const a=A();
  if(S.t<S.protectUntil&&!confirm('Savaş ilan edersen acemilik korumasını kaybedersin. Devam?'))return;
  if(isLeader()){const l=proposeLaw('war',{region:rid,type:type},'me');if(l.status==='failed')msg('Savaş ilanı başarısız (bütçe/koşul).');}
  else proposeLaw('war',{region:rid,type:type},'me');
};
ACT.paperCreate=()=>{
  const m=S.me,n=($('paperName')||{}).value||'';if(m.paper)return msg('Zaten gazeten var.');if(n.trim().length<3)return msg('Gazete adı yaz.');
  if(m.stor.gold<10)return msg('Yetersiz altın (10).');m.stor.gold-=10;m.paper={name:n.trim().slice(0,28),subs:10,last:0,posts:0};L(`📰 "${n.trim()}" gazetesini kurdun.`,'ok');
};
ACT.paperPost=()=>{
  const m=S.me,p=m.paper;if(!p)return;if(S.t<p.last+HOUR)return msg(`Yeni makale için ${fmtDur(p.last+HOUR-S.t)} bekle.`);
  const add=Math.round(15+m.level*2+perk('edu')*0.3);p.subs+=add;p.last=S.t;p.posts++;addXP(5);
  msg(`📰 Makale yayınlandı: +${add} abone (toplam ${fmt(p.subs)}).`,'ok');
};
ACT.save=()=>{save();msg('Kaydedildi','ok');};
ACT.reset=()=>{if(!confirm('Tüm ilerleme silinecek. Emin misiniz?'))return;localStorage.removeItem(SAVE);S=newState();S.live=true;UI.tab='char';render();};

/* ================= ARAYÜZ ================= */
const TABS=[['char','👤 Karakter'],['work','⛏️ Çalış'],['store','🏦 Depo/Pazar'],['craft','🔧 Üretim'],['map','🗺️ Bölgeler'],['world','🌍 Dünya'],['state','🏛️ Devlet'],['party','🗳️ Parti'],['war','⚔️ Savaş'],['paper','📰 Gazete'],['mkt','🛒 Oyuncu Pazarı'],['lb','🏆 Sıralama'],['chat','💬 Sohbet'],['log','📜 Günlük'],['net','🌐 Online']];
function toast(m,c){const t=document.createElement('div');t.className='toast '+(c||'');t.textContent=m;$('toasts').appendChild(t);setTimeout(()=>t.remove(),4200);}
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const cd=end=>`<b data-cd="${end}">${fmtDur(end-S.t)}</b>`;
const pb=(a,b)=>`<div class="bar"><div data-pb="${a},${b}" style="width:${clamp((S.t-a)/(b-a)*100,0,100)}%"></div></div>`;
const card=(t,body,cls)=>`<div class="card ${cls||''}"><h3>${t}</h3>${body}</div>`;
const btn=(label,attrs,cls,dis)=>`<button class="act ${cls||''}" ${dis?'disabled':''} ${attrs}>${label}</button>`;
const sel=(id,opts,val)=>`<select id="${id}">${opts.map(o=>`<option value="${o[0]}" ${String(o[0])===String(val)?'selected':''}>${esc(o[1])}</option>`).join('')}</select>`;
const roleName=()=>isLeader()?(A().gov==='dictatorship'?'👑 Diktatör':'🎖️ Başkan'):(A().min.econ==='me'?'💼 Ekonomi Bakanı':(A().min.foreign==='me'?'🌐 Dışişleri Bakanı':'Vatandaş'));

const isAdminUI=()=>!!((typeof MP!=='undefined'&&MP.role==='admin')||(S&&S.me&&S.me.admin));
const TABX={};
const GROUPS=[
  ['home','🏠 Ana Sayfa',[['home','Ana Sayfa'],['quest','Görevler'],['log','Günlük']]],
  ['paper','📰 Makaleler',[['art','Makaleler'],['paper','Gazete'],['chat','Sohbet'],['ally','🛡️ İttifak'],['lb','Sıralama']]],
  ['map','🗺️ Harita',[['world','Harita'],['map','Şehirler'],['sw','Ortak'],['spy','Casus']]],
  ['store','📦 Depo',[['store','Depo'],['mkt','Pazar'],['craft','Üretim'],['bank','🏦 Banka']]],
  ['work','⛏️ Çalışma',[['work','Çalış'],['auto','⚙️ Otomatik']]],
  ['war','⚔️ Savaşlar',[['war','Savaş'],['state','Devlet'],['party','Parti']]],
  ['prof','👤 Profil',[['char','Profil'],['set','Ayarlar'],['guide','Rehber'],['net','Hesap']]]];
const groupOf=t=>GROUPS.find(g=>g[2].some(x=>x[0]===t))||GROUPS[0];
function renderNav(){
  const all=GROUPS;
  const qb=(typeof questBadge==='function')?questBadge():0;const cg=groupOf(UI.tab),unread=(typeof CHAT!=='undefined')?((CHAT.unread||0)+(CHAT.dmUnread||0)):0;
  let h=all.map(g=>`<button class="${g[0]===cg[0]?'active':''}" data-a="tab" data-t="${g[0]===cg[0]?UI.tab:g[2][0][0]}"><i>${g[1].split(' ')[0]}</i>${g[1].split(' ').slice(1).join(' ')}${g[0]==='home'&&qb?` <span class="owner" style="background:#da3633;color:#fff">${qb}</span>`:''}${g[0]==='paper'&&unread?` <span class="owner" style="background:#da3633;color:#fff">${unread}</span>`:''}</button>`).join('');
  const vis=cg[2].filter(t=>t[2]!=='adm'||isAdminUI());if(vis.length>1)h+=`<div class="subnav">${vis.map(t=>`<button class="${UI.tab===t[0]?'on':''}" data-a="tab" data-t="${t[0]}">${t[1]}${t[0]==='quest'&&qb?` <span class="owner" style="background:#da3633;color:#fff">${qb}</span>`:''}${t[0]==='chat'&&unread?` <span class="owner" style="background:#da3633;color:#fff">${unread}</span>`:''}</button>`).join('')}</div>`;
  $('nav').innerHTML=h;
  try{document.documentElement.style.setProperty('--navh',$('nav').offsetHeight+'px');}catch(e){}
}
function alerts(){
  const a=[],m=S.me;
  S.wars.filter(w=>w.state!=='done'&&(w.att==='A'||w.def==='A')).forEach(w=>{
    const t=w.state==='prep'?`başlamasına ${cd(w.start)}`:`bitmesine ${cd(w.end)}`;
    a.push(`<div class="al bad">⚔️ <a class="lk" data-a="goCity" data-id="${w.region}">${esc(S.regions[w.region].n)}</a> (${WTYPE[w.type]}): ${nameOf(w.att)} → ${nameOf(w.def)} — ${t} ${w.state==='on'?`<button class="act sm danger" data-a="hit" data-w="${w.id}">💥 Vur</button> <button class="act sm" data-a="tab" data-t="war">Savaşa git</button>`:''}</div>`);});
  if(A().election)a.push(`<div class="al info">🗳️ Seçim sürüyor! Bitişine ${cd(A().election.end)} — <button class="act sm blue" data-a="tab" data-t="party">Oy ver</button></div>`);
  const homeTab=['home','char','work','craft','quest'].includes(UI.tab);
  if(homeTab&&S.t<S.protectUntil)a.push(`<div class="al info">🛡️ Acemilik koruması: ${cd(S.protectUntil)} (kimse devletine saldıramaz)</div>`);
  if(S.ann&&S.ann.m)a.push(`<div class="al info">📣 <b>Duyuru:</b> ${esc(S.ann.m)}</div>`);
  if(S.evt&&S.evt.until>S.t)a.push(`<div class="al warn">🎉 ${EVT[S.evt.k].n}: bitişine ${cd(S.evt.until)}</div>`);
  if(homeTab&&UI.tab!=='home'&&!m.learn)a.push(`<div class="al warn">📚 Öğrenme boşta! Profil sekmesinden bir yetenek geliştir.</div>`);
  if(m.travel)a.push(`<div class="al info">🧳 Yoldasın: ${S.regions[m.travel.to].n}, varışa ${cd(m.travel.arrive)} ${m.travel.back?'(geri dönüyorsun)':`<button class="act sm" data-a="travelBack">↩ Geri dön</button>`}</div>`);
  if(typeof swAlerts==='function')swAlerts().forEach(x=>a.push(x));
  $('alerts').innerHTML=a.join('');
}
function bar(v,max,color){return `<div class="bar"><div style="width:${clamp(v/max*100,0,100)}%;background:${color||'#f0c040'}"></div></div>`;}

ACT.tutOff=()=>{S.tut=1;};
function tabChar(){
  const m=S.me,hr=homeReg();
  let h=tutCard()+`<div class="panel"><h2>👤 Karakter</h2><div class="grid">
  ${card('Seviye <span data-live="level"></span>',bar(m.xp,xpNeed(m.level))+`<p>XP ${fmt(m.xp)} / ${fmt(xpNeed(m.level))}</p><p>${roleName()}${m.party?` · ${esc(myParty()?myParty().n:'')}`:''}</p>`)}
  ${card('⚡ Enerji','<div class="big"><span data-live="energy"></span></div><p>Saatte +30 (100\'e kadar). İçecekle üstü korunur.</p>'+btn('Enerji içeceği (2 altın) +50','data-a="drink"','gold')) }
  ${card('📍 Konum',`<p>Bulunduğun: <b>${esc(myReg().n)}</b> (${nameOf(myReg().state)})</p><p>İkamet: <b>${esc(hr.n)}</b> · ${fmtDur(S.t-m.resSince)}</p><p class="dim">Eğitim indeksi ${hr.idx.e} (öğrenme hızı)${levelB(hr,'library')?` · Kütüphane ${levelB(hr,'library')}`:''}</p>`)}
  </div></div>
  <div class="panel"><h2>📈 Yetenekler (aynı anda biri öğrenilir)</h2><div class="grid">`;
  for(const k in PERKS){
    const v=perk(k),boosted=v!==m[k],lr=m.learn&&m.learn.perk===k;
    const tm=learnTimeMs(k,false),tg=learnTimeMs(k,true);
    h+=card(`${PERKS[k]}: <b>${v}</b>${boosted?` <small class="ok">(+100 güçlendirici)</small>`:''}`,
      `<p class="dim">${PERK_D[k]}</p>`+(lr?`<p>Öğreniliyor → ${m[k]+1}: ${cd(m.learn.end)}</p>${pb(m.learn.start,m.learn.end)}`:
      `<div class="btns">${btn(`Para: ${fmt(learnCost(k,false))}₺<br><small>${fmtDur(tm)}</small>`,`data-a="learn" data-p="${k}" data-g="0"`,'',m.learn||m.money<learnCost(k,false))}
      ${btn(`Altın: ${learnCost(k,true)}<br><small>${fmtDur(tg)}</small>`,`data-a="learn" data-p="${k}" data-g="1"`,'gold',m.learn||m.stor.gold<learnCost(k,true))}</div>`));
  }
  h+=`</div></div><div class="panel"><h2>💪 Güçlendirici (+100 puan)</h2><div class="card">`;
  if(m.boost&&m.boost.end>S.t)h+=`<p>Aktif: ${PERKS[m.boost.perk]} +100 — ${cd(m.boost.end)}</p>`;
  else if(S.t<m.boostCd)h+=`<p class="dim">Yeniden kullanılabilir: ${cd(m.boostCd)}</p>`;
  else h+=Object.keys(PERKS).map(k=>`<div class="btns"><b style="min-width:110px">${PERKS[k]}</b>${btn('2 saat · 30.000₺',`data-a="boost" data-p="${k}" data-g="0"`,'',m.money<30000)}${btn('20 saat · 25 altın',`data-a="boost" data-p="${k}" data-g="1"`,'gold',m.stor.gold<25)}</div>`).join('');
  h+=`</div></div><div class="panel"><h2>📊 Değerler</h2><div class="card"><table>
  <tr><td>Üretim bonusu</td><td class="num">%${f1(craftBonus())} maliyet indirimi</td></tr>
  <tr><td>İş başına enerji</td><td class="num">${energyCost()}</td></tr>
  <tr><td>Depo kapasitesi</td><td class="num">${fmt(storCap())} (kaynak başına)</td></tr>
  <tr><td>Savaş vuruşu (eşyasız)</td><td class="num">${fmt(hitDamage(null))} hasar</td></tr>
  <tr><td>Rütbe</td><td class="num">${rankName()} <small class="dim">(${fmt(m.dmg||0)} hasar)</small></td></tr>
  <tr><td>Toplam vuruş / iş</td><td class="num">${m.hits} / ${m.works}</td></tr></table></div></div>`;
  return h;
}

function tabWork(){
  const m=S.me,r=myReg();
  let h=`<div class="panel"><h2>⛏️ Çalış — <a class="lk" data-a="goCity" data-id="${r.id}">${esc(r.n)}</a></h2><p class="hint">Kamu fabrikalarında altın, petrol ve maden çıkarırsın. Uranyum ve elmas yalnızca <b>özel fabrikada</b> üretilir (Üretim sekmesi). Her iş ${energyCost()} enerji harcar. Üretim vergisi devlet bütçesine gider.</p>`;
  if(m.travel)h+='<div class="al info">Yoldasın; çalışamazsın.</div>';
  if(r.moon)h+='<div class="al warn">Ay üssünde kamu fabrikası yok.</div>';
  h+='<div class="grid">';
  ['gold','oil','ore'].forEach(k=>{
    const x=r.res[k],amt=workAmount(k,r),tax=stateTax(r.state,k);
    const dis=m.travel||r.moon||x.c<=0||m.energy<energyCost()||!regionAllows(r);
    h+=card(`${RES_I[k]} ${RES_N[k]}`,`<p>İş başına ≈ <b>${f1(amt*(1-tax))}</b> (vergi %${Math.round(tax*100)})</p><p>Rezerv: <b>${f1(x.c)}</b> / ${f1(x.m)}${x.dm?` <small class="ok">(derin arama +${x.dm})</small>`:''}</p>${bar(x.c,Math.max(1,x.m),'#3fb950')}<p class="dim">Piyasa: ${fmt(S.prices[k])}₺</p>
      <div class="btns">${btn('Çalış',`data-a="work" data-r="${k}" data-n="1"`,'',dis)}${btn('×5',`data-a="work" data-r="${k}" data-n="5"`,'',dis)}${btn('Tüm enerji',`data-a="workAll" data-r="${k}"`,'gold',dis)}</div>`);
  });
  h+=`</div>${UI.lastWork?`<p class="ok" style="margin-top:8px">${esc(UI.lastWork)}</p>`:''}`;
  h+=`<div class="card" style="margin-top:10px"><h3>Bu bölgedeki özel kaynaklar</h3><p>${['uranium','diamonds'].map(k=>`${RES_I[k]} ${RES_N[k]}: ${f1(r.res[k].c)}/${f1(r.res[k].m)}`).join(' · ')}</p></div></div>`;
  return h;
}

function tabStore(){
  const m=S.me;
  let h=`<div class="panel"><h2>🏦 Depo</h2><div class="card"><p>Para: <b><span data-live="money"></span></b> · Kaynak başına kapasite: ${fmt(storCap())}</p><table>`;
  RES.forEach(k=>{const p=S.prices[k];
    h+=`<tr><td>${RES_I[k]} ${RES_N[k]}<br><small class="dim">${fmt(p)}₺ <span class="${p>=PRICE0[k]?'bad':'ok'}">(${p>=PRICE0[k]?'▲':'▼'}${Math.abs(Math.round((p/PRICE0[k]-1)*100))}%)</span></small></td>
    <td class="num"><b data-live="st_${k}"></b></td><td>${btn('Al 10',`data-a="buy" data-r="${k}" data-n="10"`)} ${btn('Al 100',`data-a="buy" data-r="${k}" data-n="100"`)} ${btn('Doldur',`data-a="buy" data-r="${k}" data-n="fill"`,'gold')}
    ${btn('Sat 10',`data-a="sell" data-r="${k}" data-n="10"`,'gold')} ${btn('Hepsi',`data-a="sell" data-r="${k}" data-n="all"`,'gold')}</td></tr>`;});
  h+=`</table><p class="hint">Alış: piyasa +%10, satış: piyasa −%10. Fiyatlar 10 dakikada bir değişir; büyük işlemler fiyatı oynatır.</p></div></div>
  <div class="panel"><h2>🎒 Eşyalar</h2><div class="card"><p>${Object.keys(ITEMS).map(k=>`${ITEMS[k].i} ${ITEMS[k].n}: <b>${m.items[k]}</b>`).join(' · ')}</p></div></div>`;
  if(typeof invPanel==='function')h+=invPanel();
  return h;
}

function tabCraft(){
  const m=S.me;
  let h=`<div class="panel"><h2>🔧 Eşya üretimi</h2><p class="hint">Üretim maliyeti güç ve eğitim ile %${f1(craftBonus())} düşer. Eşyalar savaşta vuruşlara ek hasar verir (her vuruşta 1 adet harcanır).</p><div class="grid">`;
  Object.keys(ITEMS).forEach(k=>{
    const I=ITEMS[k],c=itemCost(k,1);
    const need=I.needs&&!hasB('A',I.needs);
    const can=!need&&m.money>=c.money&&RES.every(r=>!c[r]||m.stor[r]>=c[r]);
    h+=card(`${I.i} ${I.n} <span class="owner">${WTYPE[I.type]}</span>`,`<p>Hasar +${I.dmg*40} · Stok: <b>${m.items[k]}</b></p><p class="dim">${fmt(c.money)}₺${RES.filter(r=>c[r]).map(r=>` · ${c[r]} ${RES_N[r]}`).join('')} · ${fmtDur(I.time)}</p>${need?`<p class="bad">${BUILD[I.needs].n} gerekli</p>`:''}
      <div class="btns">${btn('×1',`data-a="craft" data-k="${k}" data-n="1"`,'',!can)}${btn('×5',`data-a="craft" data-k="${k}" data-n="5"`,'',!can||m.money<c.money*5)}</div>`);
  });
  h+='</div>';
  if(m.craftQ.length){h+='<h2 style="margin-top:12px">⏳ Üretim sırası</h2>';m.craftQ.forEach(b=>{h+=`<div class="q">${b.n} ${(itDef(b.k)||{n:b.k}).n} — ${cd(b.end)}${pb(b.start,b.end)}</div>`;});}
  h+=`</div><div class="panel"><h2>🏭 Özel fabrikalar</h2><p class="hint">Altınla kurulur; saatte kaynak üretir (uranyum/elmas için bölgede Enerji Santrali gerekir). Üretimin %10'u (veya yasadaki oran) bölge devletine vergi gider. Depoya el ile toplarsın.</p>`;
  const r=myReg();
  h+=`<div class="card"><h3>Yeni fabrika — ${esc(r.n)}</h3><div class="btns">${RES.map(k=>{const c=facCost(k,1);return btn(`${RES_I[k]} ${RES_N[k]}<br><small>${c.gold} altın + ${fmt(c.money)}₺</small>`,`data-a="facBuild" data-r="${k}"`,'',r.res[k].m<=0||r.moon);}).join('')}</div></div>`;
  m.facs.forEach(f=>{const rg=S.regions[f.region],c=facCost(f.res,f.level+1),rate=facRate(f);
    h+=`<div class="card"><h3>${RES_I[f.res]} ${RES_N[f.res]} fabrikası — ${esc(rg.n)} <span class="owner">sv ${f.level}</span></h3><p>Hız ≈ ${f1(rate)}/sa · Stok: <b>${f1(f.stock)}</b> (en çok ${f1(rate*24)})${rg.state!==f.owner?' <b class="bad">bölge el değiştirdi</b>':''}</p>
      <div class="btns">${btn('Depoya al',`data-a="facCollect" data-id="${f.id}"`,'',f.stock<=0)}${btn(`Yükselt (${c.gold} altın + ${fmt(c.money)}₺)`,`data-a="facUp" data-id="${f.id}"`,'gold',f.level>=10)}</div></div>`;});
  return h+'</div>';
}

function lawFormFields(){
  const k=UI.lawKind,a=A();
  const regs=(sts)=>S.regions.filter(r=>sts.includes(r.state)).map(r=>[r.id,`${r.n} (${nameOf(r.state)})`]);
  const own=regs(['A']);
  if(k==='tax')return ['inc','gold','oil','ore','uranium','diamonds'].map(x=>`<label>${x==='inc'?'Gelir':RES_N[x]} %<input type="number" id="lw_${x}" min="0" max="40" value="${a.tax[x]}"></label>`).join(' ');
  if(k==='build')return sel('lw_region',own)+sel('lw_b',Object.keys(BUILD).map(b=>[b,`${BUILD[b].i} ${BUILD[b].n} — ${BUILD[b].d}`]));
  if(k==='explore'||k==='deep')return sel('lw_region',own)+sel('lw_res',RES.map(r=>[r,RES_N[r]]));
  if(k==='transfer')return sel('lw_res',[['money','Para'],...RES.map(r=>[r,RES_N[r]])])+`<input type="number" id="lw_amt" min="1" placeholder="Miktar">`;
  if(k==='war'){const t=[];S.regions.forEach(r=>{if(r.state!=='A')warTypes('A',r).forEach(ty=>t.push([r.id+'|'+ty,r]));});
    return `<p class="hint">Hedef ve tür aşağıdaki Savaş sekmesinde seçilir.</p>`;}
  if(k==='treaty')return sel('lw_state',AI_S.filter(s=>s!=='O').map(s=>[s,nameOf(s)]))+sel('lw_kind',[['mil','Askeri anlaşma (+ilişki, saldırmazlık)'],['mig','Göç anlaşması'],['emb','Ambargo']]);
  if(k==='gov')return sel('lw_to',[['dictatorship','Diktatörlük (%80 oy gerekir)'],['republic','Cumhuriyet']]);
  if(k==='autonomy')return sel('lw_region',own);
  return '';
}
function tabState(){
  const a=A(),m=S.me,seats=seatsOf();
  let h=`<div class="panel"><h2>🏛️ ${nameOf('A')}</h2><div class="grid">
  ${card('Yönetim',`<p>${GOVS[a.gov]}</p><p>Başkan: <b>${esc(a.leader)}</b>${a.rulingParty?` <span class="owner">${esc((a.parties.find(p=>p.id===a.rulingParty)||{n:''}).n)}</span>`:''}</p><p>Sen: <b>${roleName()}</b></p><p class="dim">${a.gov==='dictatorship'?'Kanunlar anında çıkar. Seçim yok; halk ayaklanabilir.':`Sonraki seçim: ${a.election?'şimdi':cd(a.nextElection)}`}</p>`)}
  ${card('💰 Bütçe',`<p>${fmt(a.budget.money)}₺</p><p class="dim">${RES.map(k=>`${RES_I[k]} ${f1(a.budget[k])}`).join(' · ')}</p>`)}
  ${card('📊 Vergiler',`<p>Gelir %${a.tax.inc}</p><p class="dim">${RES.map(k=>`${RES_I[k]} %${a.tax[k]}`).join(' ')}</p>`)}
  ${card('👥 Bakanlar',`<p>Ekonomi: ${a.min.econ==='me'?'<b>Sen</b>':'Yapay zekâ'}<br>Dışişleri: ${a.min.foreign==='me'?'<b>Sen</b>':'Yapay zekâ'}</p>${isLeader()?`<div class="btns">${btn(a.min.econ==='me'?'Ekonomiden ayrıl':'Ekonomi bakanı ol','data-a="minister" data-m="econ"')}${btn(a.min.foreign==='me'?'Dışişlerinden ayrıl':'Dışişleri bakanı ol','data-a="minister" data-m="foreign"')}</div>`:'<p class="dim">Başkan atar.</p>'}`)}
  </div></div>
  <div class="panel"><h2>📜 Kanun teklifi</h2><div class="card"><p class="hint">Kanunlar 1 saat incelenir; meclis oyuyla (>%50) kabul edilir. Diktatörlük %80 ister. Başkan/bakan kendi alanındaki kanunları anında geçirir. Lobi (20.000₺) oyları artırır.</p>
  ${sel('lawKind',Object.keys(LAW_K).map(k=>[k,LAW_K[k]]),UI.lawKind).replace('<select','<select data-chg="lawKind"')}
  <div class="row">${lawFormFields()}</div>${UI.lawKind==='war'?'':btn('Teklif ver','data-a="propose"','blue')}</div>`;
  const pend=S.laws.filter(l=>l.status==='pending'),done=S.laws.filter(l=>l.status!=='pending').slice(0,8);
  h+=`<h2 style="margin-top:12px">Oylamadaki kanunlar</h2>`;
  if(!pend.length)h+='<p class="dim">Yok.</p>';
  pend.forEach(l=>{const s=lawSupport(l);h+=`<div class="q">${esc(l.txt)}<br><small>${l.by==='me'?'Senin teklifin':'Meclis'} · tahmini destek %${Math.round(s.pct*100)} · oylama ${cd(l.end)}</small> ${btn('Lobi (20.000₺)',`data-a="lobby" data-id="${l.id}"`,'gold sm')}</div>`;});
  h+=`<h2 style="margin-top:12px">Son kanunlar</h2>`;
  done.forEach(l=>{h+=`<div class="q ${l.status==='failed'?'bad':''}">${l.status==='passed'?'✅':'❌'} ${esc(l.txt)}${l.pro?` (%${l.pro})`:''}</div>`;});
  h+=`</div><div class="panel"><h2>🌐 Dış ilişkiler</h2><div class="grid">`;
  AI_S.filter(s=>regOf(s).length).forEach(s=>{
    h+=card(nameOf(s),`<p>İlişki: <b class="${relTo('A',s)>=0?'ok':'bad'}">${Math.round(relTo('A',s))}</b> · Güç ${fmt(powerOf(s))}</p><p class="dim">${a.treaty.mil[s]>S.t?'🤝 Askeri anlaşma '+fmtDur(a.treaty.mil[s]-S.t)+' · ':''}${a.treaty.mig[s]>S.t?'🧳 Göç anlaşması · ':''}${a.treaty.emb[s]>S.t?'⛔ Ambargo':''}</p>`);});
  return h+'</div></div>';
}

function tabParty(){
  const a=A(),m=S.me,seats=seatsOf();
  let h=`<div class="panel"><h2>🗳️ Meclis (${a.gov==='dictatorship'?'feshedildi':a.parlSize+' sandalye'})</h2>`;
  if(a.election)h+=`<div class="al info">Seçim sürüyor — bitişine ${cd(a.election.end)}. ${m.votedFor?'Oyun: '+esc((a.parties.find(p=>p.id===m.votedFor)||{n:''}).n):'Oy vermedin.'}</div>`;
  else if(a.gov!=='dictatorship')h+=`<p class="hint">Sonraki seçim: ${cd(a.nextElection)} (her 24 saatte bir; 2 saat sürer).</p>`;
  h+='<div class="grid">';
  a.parties.slice().sort((x,y)=>y.supp-x.supp).forEach(p=>{
    const tot=a.parties.reduce((x,y)=>x+y.supp,0);
    h+=card(`${esc(p.n)} ${p.id===a.rulingParty?'<span class="owner">iktidar</span>':''}${p.id===m.party?' <span class="owner">partin</span>':''}`,
     `<p>Destek %${f1(p.supp/tot*100)} · Sandalye <b>${seats[p.id]||0}</b></p>${bar(p.supp,tot,p.id==='me'?'#58a6ff':'#f0c040')}
      <div class="btns">${a.election?btn('🗳️ Oy ver',`data-a="vote" data-p="${p.id}"`,'blue',m.level<5):''}${!m.party&&p.id!=='me'?btn('Katıl',`data-a="joinParty" data-p="${p.id}"`,'',m.level<5):''}</div>`);
  });
  h+='</div></div><div class="panel"><h2>🚩 Partin</h2><div class="card">';
  if(m.party){const p=myParty();h+=`<p><b>${esc(p?p.n:'')}</b> ${m.partyLead?'(lideri sensin)':''}</p><p class="dim">Kampanya (10.000₺, saatte bir) desteği artırır. Gazete aboneleri seçimde ek destek sağlar. Partin birinci olur ve lideri sensen <b>başkan</b> olursun.</p>
    <div class="btns">${btn('📣 Kampanya yap',`data-a="campaign"`,'blue')}${btn('Partiden ayrıl',`data-a="leaveParty"`,'danger')}</div>`;}
  else h+=`<p class="hint">Parti kurmak için seviye 10 ve 20.000₺ gerekir; mevcut partiye katılmak için seviye 5.</p><div class="row"><input type="text" id="partyName" placeholder="Parti adı" maxlength="28" style="flex:1;padding:8px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px">${btn('Parti kur (20.000₺)','data-a="createParty"','gold',m.level<10)}</div>`;
  return h+'</div></div>';
}

function warDeclPanel(){
  /* Önce hedef DEVLET seçilir; bölge listesi yalnızca o devletin saldırılabilir bölgelerini gösterir. */
  const m=S.me,a=A();let h='';
  const byState={},stOrder=[];
  S.regions.forEach(r=>{if(r.state==='A'&&!r.moon)return;const t=warTypes('A',r);if(!t.length)return;
    const k=r.moon?'__moon':r.state;if(!byState[k]){byState[k]=[];stOrder.push(k);}byState[k].push([r.id,`${r.n} — ${t.map(x=>WTYPE[x]).join('/')}`]);});
  const stName=k=>k==='__moon'?'🌙 Ay':nameOf(k);
  const stOpts=stOrder.map(k=>[k,`${stName(k)} (${byState[k].length} bölge)`]);
  let selS=UI.wState;if(!byState[selS])selS=stOrder[0];
  const cand=selS?byState[selS]:[];
  let selR=UI.wRegion;if(!cand.some(c=>c[0]===selR))selR=cand[0]&&cand[0][0];
  const reg=S.regions[selR],types=reg?warTypes('A',reg):[];
  h+=`<div class="panel"><h2>📣 Savaş ilanı</h2><div class="card">`;
  if(!stOrder.length)h+='<p class="dim">Saldırılabilir bölge yok. Komşu bölge gerekir (kara); havalimanı/liman/uzay üssü yapılırsa yeni türler açılır.</p>';
  else{h+=`<p class="dim" style="margin:0 0 4px">1) Hedef devlet  2) o devletin bölgesi  3) savaş türü</p>
    <div class="row">${sel('wState',stOpts,selS).replace('<select','<select data-chg="wState"')}</div>
    <div class="row">${sel('wRegion',cand,selR).replace('<select','<select data-chg="wRegion"')}${sel('wType',types.map(t=>[t,WTYPE[t]]))}</div>
    <p class="dim">Maliyet: 50.000₺ + 3 altın (devlet bütçesi). ${isLeader()?'Başkan olduğun için anında ilan edilir.':'Başkan değilsen meclis oylar (Devlet sekmesi).'} Saldırgan olursan acemilik korumasını kaybedersin.</p>${btn('⚔️ Savaş ilan et','data-a="declare"','danger')}`;}
  h+='</div></div>';
  return h;
}
function tabWar(){
  const m=S.me,a=A();
  let h=`<div class="panel"><h2>⚔️ Savaşlar</h2><p class="hint">Savaş 20 dk hazırlıkla başlar, 3 saat sürer. Her vuruş 10 enerji harcar; eşya vuruşa ek hasar katar. Süre bitince daha çok hasar veren taraf kazanır; kazanan saldırgan bölgeyi alır. Savunan taraf %25 avantajlıdır; son bölge asla düşmez.</p>`;
  const mine=S.wars.filter(w=>w.state!=='done'&&(w.att==='A'||w.def==='A')),others=S.wars.filter(w=>w.state!=='done'&&w.att!=='A'&&w.def!=='A');
  if(!mine.length)h+='<p class="dim">Devletin şu an savaşta değil. Aşağıdaki antrenman savaşıyla pratik yapabilirsin.</p>';
  const warCard=(w,fight)=>{
    const r=S.regions[w.region],tot=w.dA+w.dD||1;
    let c=`<p>${nameOf(w.att)} → ${nameOf(w.def)} · ${WTYPE[w.type]} · ${w.state==='prep'?'başlamasına '+cd(w.start):'bitişine '+cd(w.end)}</p>
      <div class="bar2"><div data-war="${w.id}" style="width:${w.dA/tot*100}%"></div></div><p class="dim"><span data-wl="${w.id}">${fmt(w.dA)} / ${fmt(w.dD)}</span> (saldırgan / savunan)${w.mine?` · senin katkın ${fmt(w.mine)}`:''}</p>`;
    if(fight&&w.state==='on'){
      const items=Object.keys(ITEMS).filter(k=>ITEMS[k].type===w.type&&m.items[k]>0);
      c+=`<div class="btns">${btn(`💥 Vur (${fmt(hitDamage(null))})`,`data-a="hit" data-w="${w.id}"`,'danger')}${btn('Tüm enerji',`data-a="hitAll" data-w="${w.id}"`,'danger')}
      ${items.map(k=>btn(`${ITEMS[k].i} ${ITEMS[k].n} ×${m.items[k]} (${fmt(hitDamage(k))})`,`data-a="hit" data-w="${w.id}" data-item="${k}"`,'purple')).join('')}</div>`;}
    return card(`<a class="lk" data-a="goCity" data-id="${r.id}">${esc(r.n)}</a> ${w.att==='A'?'<span class="owner">saldırıyoruz</span>':w.def==='A'?'<span class="owner">savunuyoruz</span>':''}`,c,w.state==='on'&&(w.att==='A'||w.def==='A')?'glow':'');};
  h+='<div class="grid">'+mine.map(w=>warCard(w,true)).join('')+'</div>';
  if(others.length){h+='<h2 style="margin-top:12px">🌍 Dünyadaki savaşlar</h2><div class="grid">'+others.map(w=>warCard(w,false)).join('')+'</div>';}
  if(typeof trPanel==='function')h+=trPanel();
  return h+'</div>';
}

function tabPaper(){
  const m=S.me,p=m.paper;
  let h=`<div class="panel"><h2>📰 Gazete</h2>`;
  if(!p)h+=`<div class="card"><p class="hint">Gazete kur (10 altın); makale yayınla, abone kazan. Aboneler seçimde partine destek olur (200 abone ≈ %1).</p><div class="row"><input type="text" id="paperName" placeholder="Gazete adı" maxlength="28" style="flex:1;padding:8px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px">${btn('Kur (10 altın)','data-a="paperCreate"','gold')}</div></div>`;
  else h+=`<div class="card"><h3>${esc(p.name)}</h3><p>Abone: <b>${fmt(p.subs)}</b> · Makale: ${p.posts}</p><p class="dim">${S.t<p.last+HOUR?'Yeni makale: '+cd(p.last+HOUR):'Makale yazabilirsin.'}</p>${btn('✍️ Makale yayınla','data-a="paperPost"','',S.t<p.last+HOUR)}</div>`;
  h+=`<h2 style="margin-top:12px">🗞️ Dünya haberleri</h2><div class="log tall">${S.news.map(n=>`<div>[${fmtT(n.t)}] ${esc(n.m)}</div>`).join('')||'<div class="dim">Haber yok.</div>'}</div></div>`;
  return h;
}
function tabLog(){
  return `<div class="panel"><h2>📜 Günlük</h2><div class="log tall">${S.log.map(l=>`<div class="${l.c}">[${fmtT(l.t)}] ${esc(l.m)}</div>`).join('')||'<div class="dim">Boş.</div>'}</div>
  <div class="btns" style="margin-top:10px">${btn('💾 Kaydet','data-a="save"')}${btn('🗑️ Sıfırla','data-a="reset"','danger')}</div>
  <p class="hint">Oyun gerçek zamanlıdır ve sayfa kapalıyken de ilerler (en fazla 3 gün). Otomatik kaydedilir. Cihaza özeldir.</p></div>`;
}

function render(){
  renderNav();alerts();
  const fn={elect:(typeof tabElect==='function'?tabElect:null),char:tabChar,work:tabWork,store:tabStore,craft:tabCraft,map:tabMap,home:tabHome,art:tabArt,bank:tabBank,state:tabState,party:tabParty,war:tabWar,paper:tabPaper,log:tabLog,net:tabNet,adm:tabAdm,world:tabWorld,chat:tabChat,mkt:tabMkt,lb:tabLb,quest:tabQuest,sw:tabSW,guide:tabGuide,bots:tabBots,ally:tabAlly,auto:tabAuto,spy:tabSpy,set:tabSettings}[UI.tab]||TABX[UI.tab];
  const keep={},act=document.activeElement&&document.activeElement.id;
  $('main').querySelectorAll('input[id]:not([type=file]),select[id],textarea[id]').forEach(e=>{keep[e.id]=e.value;});
  $('main').innerHTML=(typeof isBanned==='function'&&isBanned())?banScreen():fn();
  for(const id in keep){const e=$(id);if(e&&$('main').contains(e)&&e.tagName!=='SELECT'||(e&&e.tagName==='SELECT'&&[...e.options].some(o=>o.value===keep[id])))e.value=keep[id];}
  if(act&&$(act)&&$('main').contains($(act)))$(act).focus();
  if(typeof afterRender==='function')afterRender();
  tickUI();
}
function bgRender(){S.dirty=false;render();}
function liveVals(){
  const m=S.me,o={energy:fmt(m.energy)+'/100',money:fmt(m.money)+'₺',level:m.level};
  RES.forEach(k=>o['st_'+k]=f1(m.stor[k]));return o;
}
function tickUI(){
  if(typeof lbTimer==='function')lbTimer();
  if(typeof questTick==='function')questTick();
  if(typeof socialTick==='function')socialTick();
  if(UI.tab==='world'&&typeof wmDraw==='function')wmDraw();
  const v=liveVals(),m=S.me;
  $('hMoney').textContent=v.money;$('hEn').textContent=fmt(m.energy);$('hLvl').textContent=m.level;
  $('hGold').textContent=f1(m.stor.gold);$('hLoc').textContent=myReg().n;$('hDay').textContent=(window.Takvim?Takvim.gunMetni():'Gün '+(flr((S.t-S.startT)/DAY)+1));
  document.querySelectorAll('[data-live]').forEach(e=>{const k=e.dataset.live;if(v[k]!==undefined)e.textContent=v[k];});
  document.querySelectorAll('[data-cd]').forEach(e=>{e.textContent=fmtDur(+e.dataset.cd-S.t);});
  document.querySelectorAll('[data-pb]').forEach(e=>{const[a,b]=e.dataset.pb.split(',').map(Number);e.style.width=clamp((S.t-a)/(b-a)*100,0,100)+'%';});
  document.querySelectorAll('[data-war]').forEach(e=>{const w=S.wars.find(x=>x.id===+e.dataset.war);if(w){const t=w.dA+w.dD||1;e.style.width=(w.dA/t*100)+'%';
    const l=document.querySelector(`[data-wl="${w.id}"]`);if(l)l.textContent=fmt(w.dA)+' / '+fmt(w.dD);}});
}
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-a]');if(!b||b.disabled)return;
  const f=ACT[b.dataset.a];if(!f)return;
  f(b.dataset);S.dirty=true;
  if(!['save','reset'].includes(b.dataset.a))save();
  if(S.dirty){S.dirty=false;render();}
});
document.addEventListener('change',e=>{
  const c=e.target.dataset&&e.target.dataset.chg;if(!c)return;
  if(c==='bp'&&typeof bpChange==='function')bpChange(e.target);if(c==='lawKind')UI.lawKind=e.target.value;if(c==='wState'){UI.wState=e.target.value;UI.wRegion=undefined;}if(c==='wRegion')UI.wRegion=+e.target.value;
  render();
});

