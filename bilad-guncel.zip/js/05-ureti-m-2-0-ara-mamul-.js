/* ================= ÜRETİM 2.0: ara mamul zinciri, atölyeler, paralel hatlar, hız, hızlandırma, Mk geliştirme ================= */
const MATS={
  steel:{n:'Çelik',i:'🔩',ore:2.5,oil:0.5,money:200,time:12*1000},
  fuel:{n:'Yakıt',i:'🛢️',oil:2,money:150,time:9*1000},
  warhead:{n:'Harp Başlığı',i:'☢️',uranium:2,steel:3,money:3000,time:40*1000}
};
const COSTK=RES.concat(['steel','fuel','warhead']);
const WK={
  arms:{n:'Silah Atölyesi',i:'🏭',d:'Tank ve füze üretir'},
  yard:{n:'Tersane',i:'⚓',d:'Savaş gemileri (kıyı bölgesinde yaşamak gerekir)'},
  air:{n:'Havacılık Üssü',i:'🛫',d:'Uçak, bombardıman ve SİHA'},
  mill:{n:'Çelikhane & Rafineri',i:'🔩',d:'Çelik, yakıt ve harp başlığı'},
  lab:{n:'Araştırma Laboratuvarı',i:'🔬',d:'Ay/uzay eşyaları ve Mk geliştirme'}
};
const ITEM_WK={tank:'arms',missile:'arms',fighter:'air',bomber:'air',siha:'air',ship:'yard',battleship:'yard',moontank:'lab',station:'lab'};
(function(){ // eşya tarifleri: ham madde yerine ara mamul; süreler kısaldı
  const cv={tank:{steel:24,fuel:12},fighter:{steel:36,fuel:30},bomber:{steel:56,fuel:45},ship:{steel:64,fuel:35},battleship:{steel:100,fuel:75},missile:{warhead:3,fuel:50},moontank:{steel:80},siha:{steel:20,fuel:20}};
  for(const k in ITEMS){const I=ITEMS[k];I.time=Math.round(I.time*0.4);if(cv[k]){delete I.ore;delete I.oil;if(k==='missile')delete I.uranium;Object.assign(I,cv[k]);}}
})();
const kindOf=k=>MATS[k]?'mill':(ITEM_WK[k]||'arms');
const itDef=k=>ITEMS[k]||MATS[k];
function prodS(){const m=S.me;if(!m.wk){const r=S.regions[m.res]||{};m.wk={arms:1,air:1,mill:1,yard:r.coast?1:0,lab:0};}
  m.mats=m.mats||{steel:0,fuel:0,warhead:0};m.mk=m.mk||{};m.lineX=m.lineX||0;m.made=m.made||0;return m;}
const pStk=k=>RES.includes(k)?S.me.stor[k]:((S.me.mats||{})[k]||0);
const pAdd=(k,n)=>{if(RES.includes(k))S.me.stor[k]+=n;else S.me.mats[k]=(S.me.mats[k]||0)+n;};
const wkSum=()=>Object.values(prodS().wk).reduce((a,b)=>a+b,0);
const lineCount=()=>Math.min(12,2+Math.floor(wkSum()/4)+(prodS().lineX||0));
function prodSpeed(kind){const m=prodS();return (1+perk('edu')*0.010+perk('str')*0.006+perk('end')*0.004)*(1+0.12*Math.max(0,(m.wk[kind]||0)-1));}
const prodDur=(k,n)=>Math.max(1000,Math.ceil(itDef(k).time*n/prodSpeed(kindOf(k))));
/* maliyet: güç/eğitim indirimi + (varsa) atölye envanter indirimi; ara mamul dahil */
itemCost=function(k,n){
  const I=itDef(k),f=(1-craftBonus()/100)*(1-0.02*(typeof invL==='function'?invL('ws'):0)),o={money:Math.ceil(I.money*f*n)};
  COSTK.forEach(r=>{if(I[r])o[r]=Math.ceil(I[r]*f*n);});return o;
};
function maxMake(k){
  const m=prodS(),I=itDef(k);if(!I||!(m.wk[kindOf(k)]>=1))return 0;
  if(I.needs&&!hasB('A',I.needs))return 0;
  const c=itemCost(k,1);let n=c.money>0?Math.floor(m.money/c.money):1e9;
  COSTK.forEach(r=>{if(c[r]>0)n=Math.min(n,Math.floor(pStk(r)/c[r]));});
  return Math.max(0,Math.min(n,5000));
}
function craftAdd(k,n){
  const m=prodS(),I=itDef(k);if(!I)return 'Bilinmeyen eşya.';n=Math.floor(n);if(!(n>=1))return 'Miktar en az 1 olmalı.';if(m.craftQ.length>=200)return 'Üretim kuyruğu dolu (en çok 200 iş).';
  const kind=kindOf(k);if(!(m.wk[kind]>=1))return WK[kind].n+' gerekli (Üretim › Atölyeler).';
  if(I.needs&&!hasB('A',I.needs))return BUILD[I.needs].n+' binası gerekli (devlette).';
  const c=itemCost(k,n);if(m.money<c.money)return 'Yetersiz para ('+fmt(c.money)+'₺).';
  for(const r of COSTK)if(c[r]&&pStk(r)<c[r])return 'Yetersiz '+(RES_N[r]||MATS[r].n)+'.';
  m.money-=c.money;COSTK.forEach(r=>{if(c[r])pAdd(r,-c[r]);});
  const L=lineCount(),ends=[];for(let i=0;i<L;i++)ends[i]=S.t;
  m.craftQ.forEach(q=>{if(q.rs)return;const i=Math.min(L-1,q.ln||0);if(q.end>ends[i])ends[i]=q.end;});
  let li=0;ends.forEach((e,i)=>{if(e<ends[li])li=i;});
  const e={id:S.seq++,k:k,n:n,start:ends[li],end:ends[li]+prodDur(k,n),ln:li};m.craftQ.push(e);
  if(!MATS[k])m.crafts=(m.crafts||0)+1;
  return e;
}
function craftFinish(t){
  const m=S.me;prodS();
  const done=m.craftQ.filter(b=>b.end<=t);if(!done.length)return;
  m.craftQ=m.craftQ.filter(b=>b.end>t);
  const sum={};
  done.sort((a,b)=>a.end-b.end).forEach(b=>{
    if(b.rs){m.mk[b.k]=(m.mk[b.k]||1)+1;L(`🔬 ${ITEMS[b.k].n} Mk${m.mk[b.k]} geliştirmesi tamam (hasar +%25).`,'ok');}
    else if(MATS[b.k]){m.mats[b.k]=(m.mats[b.k]||0)+b.n;}
    else{m.items[b.k]=(m.items[b.k]||0)+b.n;m.made+=b.n;sum[b.k]=(sum[b.k]||0)+b.n;}});
  for(const k in sum)L(`🔧 ${sum[k]} ${ITEMS[k].n} üretildi.`,'ok');
}
/* eksik ara mamul (kuyruktakiler düşülür) */
function matMissing(k,n){
  const c=itemCost(k,n),o=[];
  ['steel','fuel','warhead'].forEach(r=>{if(!c[r])return;
    const q=S.me.craftQ.filter(x=>x.k===r&&!x.rs).reduce((a,x)=>a+x.n,0),need=c[r]-pStk(r)-q;
    if(need>0)o.push([r,need]);});
  return o;
}
function matChain(k,n){ // eksik ara mamulü (para/ham madde yettiği kadar) kuyruğa al
  let made=0;
  matMissing(k,n).forEach(x=>{
    // harp başlığı çelik ister; önce çeliği üret
    let q=Math.min(Math.ceil(x[1]),maxMake(x[0]));
    if(q>=1&&typeof craftAdd(x[0],q)!=='string')made++;});
  return made;
}
/* otomatik üretim: hatlar boşta kalmasın, sınır yok */
function prodAuto(k,batch){
  const m=prodS();if(!itDef(k))return 0;let did=0;const lim=lineCount()*3;
  for(let g=0;g<lim&&m.craftQ.filter(q=>!q.rs).length<lim;g++){
    const mx=maxMake(k),want=batch>0?batch:5000;
    if(mx>=1){const r=craftAdd(k,Math.min(mx,want));if(typeof r==='string')break;did++;continue;}
    const need=matMissing(k,Math.max(1,Math.min(want,50)));if(!need.length)break;
    let ok=0;need.forEach(x=>{const q=Math.min(x[1],maxMake(x[0]));if(q>=1&&typeof craftAdd(x[0],q)!=='string'){ok++;did++;}});
    if(!ok)break;
  }
  return did;
}
/* ---- hızlandırma ---- */
const RUSH_MIN=2000,rushMoney=ms=>Math.ceil(ms/60000*RUSH_MIN),rushGold=ms=>Math.max(1,Math.ceil(ms/(20*MIN)));
const workLeft=b=>Math.max(0,b.end-Math.max(b.start,S.t));
function rushPay(ms,gold){const m=S.me;
  if(gold){const c=rushGold(ms);if(m.stor.gold<c)return 'Yetersiz altın ('+c+').';m.stor.gold-=c;}
  else{const c=rushMoney(ms);if(m.money<c)return 'Yetersiz para ('+fmt(c)+'₺).';m.money-=c;}
  return null;
}
function rushOne(b,gold){
  const m=S.me,w=workLeft(b),e=rushPay(w,gold);if(e)return e;
  const old=b.end,ln=b.ln||0;
  m.craftQ.forEach(q=>{if(q!==b&&!q.rs&&!b.rs&&(q.ln||0)===ln&&q.start>=old){q.start-=w;q.end-=w;}});
  b.end=S.t;craftFinish(S.t);return null;
}
ACT.rush=d=>{const b=S.me.craftQ.find(x=>x.id==d.id);if(!b)return;const e=rushOne(b,d.g==='1');if(e)return msg(e);msg('⚡ Üretim hızlandırıldı.','ok');};
ACT.rushAll=d=>{const m=S.me,tot=m.craftQ.reduce((a,b)=>a+workLeft(b),0);if(!tot)return;
  const e=rushPay(tot,d.g==='1');if(e)return msg(e);m.craftQ.forEach(b=>b.end=S.t);craftFinish(S.t);msg('⚡ Tüm üretim hızlandırıldı.','ok');};
/* ---- eylemler ---- */
ACT.craft=d=>{
  const k=d.k,mx=maxMake(k);let n=d.n==='max'?mx:Math.floor(+d.n);
  if(d.n==='max'&&n<1)return msg(maxMake(k)===0&&matMissing(k,1).length?'Ara mamul yetmiyor: aşağıdaki "Zinciri tamamla" düğmesini kullan.':'Maksimum üretilemiyor (kaynak/para/atölye).');
  const r=craftAdd(k,n);if(typeof r==='string')return msg(r);
  L(`🔧 ${n} ${itDef(k).n} üretime alındı (${fmtDur(r.end-r.start)}).`,'info');msg(`🔧 ${n} ${itDef(k).n} sıraya alındı.`,'ok');
};
ACT.craftChain=d=>{const n=Math.max(1,Math.floor(+d.n)||1),made=matChain(d.k,n);msg(made?'🔗 Ara mamuller üretime alındı.':'Ara mamul zaten yeterli ya da üretilemiyor.',made?'ok':'bad');};
ACT.wkUp=d=>{
  const m=prodS(),k=d.k,w=WK[k];if(!w)return;const L0=m.wk[k]||0;if(L0>=10)return msg('Zaten en üst seviyede.');
  if(k==='yard'&&!(S.regions[m.res]||{}).coast)return msg('Tersane için kıyı bölgesinde yaşamalısın.');
  const c=wkCost(k);if(m.money<c.money)return msg('Yetersiz para ('+fmt(c.money)+'₺).');if(m.stor.gold<c.gold)return msg('Yetersiz altın ('+c.gold+').');
  m.money-=c.money;m.stor.gold-=c.gold;m.wk[k]=L0+1;L(`${w.i} ${w.n} seviye ${L0+1} oldu.`,'ok');msg(`${w.i} ${w.n}: seviye ${L0+1}`,'ok');
};
const wkCost=k=>{const L0=prodS().wk[k]||0;return {money:15000*(L0+1)*(L0+1),gold:Math.max(0,L0-1)};};
ACT.lineBuy=()=>{const m=prodS(),x=m.lineX||0;if(x>=6)return msg('En fazla 6 ek hat.');const g=5*(x+1),mo=50000*(x+1);
  if(m.stor.gold<g||m.money<mo)return msg(`Gerekli: ${g} altın + ${fmt(mo)}₺`);m.stor.gold-=g;m.money-=mo;m.lineX=x+1;msg('➕ Yeni üretim hattı açıldı.','ok');};
ACT.mkUp=d=>{
  const m=prodS(),k=d.k,I=ITEMS[k];if(!I)return;const c0=m.mk[k]||1;
  if(c0>=5)return msg('Zaten Mk5.');if((m.wk.lab||0)<c0)return msg(`Mk${c0+1} için Araştırma Laboratuvarı seviye ${c0} gerekli.`);
  if(m.craftQ.some(q=>q.rs))return msg('Zaten bir araştırma sürüyor.');
  const c=mkCost(k);if(m.money<c.money||m.stor.gold<c.gold)return msg(`Gerekli: ${c.gold} altın + ${fmt(c.money)}₺`);
  m.money-=c.money;m.stor.gold-=c.gold;const dur=Math.ceil(8*MIN*c0/prodSpeed('lab'));
  m.craftQ.push({id:S.seq++,k:k,n:1,rs:1,start:S.t,end:S.t+dur,ln:-1});msg(`🔬 ${I.n} Mk${c0+1} araştırması başladı (${fmtDur(dur)}).`,'ok');
};
const mkCost=k=>{const c0=prodS().mk[k]||1;return {money:ITEMS[k].money*15*c0,gold:c0};};
/* ---- öğrenmeyi hızlandır ---- */
const learnRushCost=()=>{const m=S.me;if(!m.learn)return null;const rem=Math.max(0,m.learn.end-S.t);return {money:Math.ceil(rem/60000*1500),gold:Math.max(1,Math.ceil(rem/(30*MIN))),rem:rem};};
function learnRush(gold){const m=S.me,c=learnRushCost();if(!c)return 'Öğrenme yok.';
  if(gold){if(m.stor.gold<c.gold)return 'Yetersiz altın ('+c.gold+').';m.stor.gold-=c.gold;}
  else{if(m.money<c.money)return 'Yetersiz para ('+fmt(c.money)+'₺).';m.money-=c.money;}
  m.learn.end=S.t;processEvents(S.t);return null;}
ACT.learnRush=d=>{const r=learnRush(d.g==='1');if(r)return msg(r);msg('⚡ Yetenek hemen yükseldi.','ok');};
/* ---- arayüz ---- */
function costHtml(k,n){
  const c=itemCost(k,n);let h=`${fmt(c.money)}₺`;
  COSTK.forEach(r=>{if(!c[r])return;const nm=RES_N[r]||MATS[r].n,ic=RES_I[r]||MATS[r].i,ok=pStk(r)>=c[r];h+=` · <span class="${ok?'':'bad'}">${ic} ${f1(c[r])} ${nm}</span>`;});
  return h;
}
const _tc0=tabCraft;
tabCraft=function(){
  const m=prodS(),L0=lineCount(),sp=prodSpeed('arms');
  const busy=new Set(m.craftQ.filter(q=>!q.rs&&q.start<=S.t).map(q=>q.ln||0)).size;
  let h=`<div class="panel"><h2>🔧 Üretim</h2>
  <div class="grid">${card('⚙️ Hız',`<div class="big">×${f1(sp)}</div><p class="dim">Eğitim, güç ve dayanıklılığa göre. Atölye seviyesi her seviye +%12 ekler.</p>`)}
  ${card('🧵 Hatlar',`<div class="big">${busy}/${L0}</div><p class="dim">Aynı anda ${L0} iş paralel yürür.</p>${btn(`➕ Hat aç (${5*((m.lineX||0)+1)} altın + ${fmt(50000*((m.lineX||0)+1))}₺)`,'data-a="lineBuy"','gold sm',(m.lineX||0)>=6)}`)}
  ${card('📦 Toplam',`<div class="big">${fmt(m.made||0)}</div><p class="dim">üretilen eşya · ${m.craftQ.length} iş sırada</p>`)}</div></div>`;
  // atölyeler
  h+=`<div class="panel"><h2>🏗️ Atölyeler</h2><p class="hint">Her eşya kendi atölyesinde üretilir. Seviye hızı artırır; yeni hat açmak için toplam seviyeyi yükselt.</p><div class="grid">`;
  Object.keys(WK).forEach(k=>{const w=WK[k],l=m.wk[k]||0,c=wkCost(k),noc=k==='yard'&&!(S.regions[m.res]||{}).coast;
    h+=card(`${w.i} ${w.n} <span class="owner">sv ${l}</span>`,`<p class="dim">${w.d}</p>${noc?'<p class="bad">Kıyı bölgesinde yaşaman gerekir</p>':''}<p class="dim">Hız ×${f1(prodSpeed(k))}</p>${btn(l>=10?'Maksimum':`${l?'Yükselt':'Kur'} (${c.gold?c.gold+' altın + ':''}${fmt(c.money)}₺)`,`data-a="wkUp" data-k="${k}"`,'gold sm',l>=10||noc)}`);});
  h+='</div></div>';
  // ara mamul
  h+=`<div class="panel"><h2>🔩 Ara mamuller</h2><p class="hint">Çelik ve yakıt, ham maddeden üretilir. Tank, uçak, gemi ve füze bunlardan yapılır.</p><div class="grid">`;
  Object.keys(MATS).forEach(k=>{const I=MATS[k],mx=maxMake(k);
    h+=card(`${I.i} ${I.n} <span class="owner">stok ${f1(pStk(k))}</span>`,`<p class="dim">${costHtml(k,1)} · ${fmtDur(prodDur(k,1))}/adet</p><div class="btns">${[10,100,1000].map(n=>btn('×'+n,`data-a="craft" data-k="${k}" data-n="${n}"`,'sm',mx<n)).join('')}${btn('Maks','data-a="craft" data-k="'+k+'" data-n="max"','gold sm',mx<1)}</div>`);});
  h+='</div></div>';
  // eşyalar
  h+=`<div class="panel"><h2>⚔️ Eşyalar</h2><p class="hint">Üretim maliyeti güç ve eğitim ile %${f1(craftBonus())} düşer. Eşyalar savaşta vuruşlara ek hasar verir (her vuruşta 1 adet harcanır). Fazlasını Pazar sekmesinde satabilirsin.</p><div class="grid">`;
  Object.keys(ITEMS).forEach(k=>{
    const I=ITEMS[k],mx=maxMake(k),mk=m.mk[k]||1,kind=kindOf(k),locked=!(m.wk[kind]>=1),need=I.needs&&!hasB('A',I.needs),miss=matMissing(k,5).length>0&&mx<5;
    h+=card(`${I.i} ${I.n} <span class="owner">${WTYPE[I.type]} · Mk${mk}</span>`,`<p>Hasar +${f1(itemDmg(k))} · Stok: <b>${m.items[k]||0}</b></p><p class="dim">${costHtml(k,1)} · ${fmtDur(prodDur(k,1))}/adet</p>
      ${locked?`<p class="bad">${WK[kind].n} gerekli</p>`:''}${need?`<p class="bad">${BUILD[I.needs].n} gerekli (devlette)</p>`:''}
      <div class="btns">${[1,5,10,50].map(n=>btn('×'+n,`data-a="craft" data-k="${k}" data-n="${n}"`,'sm',mx<n)).join('')}${btn('Maks'+(mx>0?' ('+mx+')':''),`data-a="craft" data-k="${k}" data-n="max"`,'gold sm',mx<1)}</div>
      <div class="btns">${miss?btn('🔗 Ara mamul zinciri (×5)',`data-a="craftChain" data-k="${k}" data-n="5"`,'sm'):''}${btn(`🔬 Mk${mk+1} (${mkCost(k).gold} altın + ${fmt(mkCost(k).money)}₺)`,`data-a="mkUp" data-k="${k}"`,'sm purple',mk>=5)}${btn('🛒 Pazara koy',`data-a="craftSell" data-k="${k}"`,'sm',!(m.items[k]>0))}</div>`);
  });
  h+='</div></div>';
  // kuyruk
  h+=`<div class="panel"><h2>⏳ Üretim hatları</h2>`;
  if(!m.craftQ.length)h+='<p class="dim">Sırada iş yok.</p>';
  else{
    const tot=m.craftQ.reduce((a,b)=>a+workLeft(b),0);
    h+=`<div class="btns">${btn(`⚡ Hepsini hızlandır (${fmt(rushMoney(tot))}₺)`,'data-a="rushAll"','gold sm')}${btn(`⚡ Altınla (${rushGold(tot)})`,'data-a="rushAll" data-g="1"','sm')}</div>`;
    m.craftQ.slice().sort((a,b)=>a.end-b.end).slice(0,40).forEach(b=>{const w=workLeft(b),I=itDef(b.k),run=b.start<=S.t;
      h+=`<div class="q">${b.rs?'🔬':(I.i)} ${b.rs?`${I.n} Mk${(m.mk[b.k]||1)+1} araştırması`:`${b.n} ${I.n}`} <small class="dim">${b.rs?'Lab':'Hat '+((b.ln||0)+1)}${run?'':' · bekliyor'}</small> — ${cd(b.end)}${pb(Math.min(b.start,b.end-1),b.end)}
      <div class="btns">${btn(`⚡ ${fmt(rushMoney(w))}₺`,`data-a="rush" data-id="${b.id}"`,'sm gold',!b.id)}${btn(`⚡ ${rushGold(w)} altın`,`data-a="rush" data-id="${b.id}" data-g="1"`,'sm',!b.id)}</div></div>`;});
    if(m.craftQ.length>40)h+=`<p class="dim">… ve ${m.craftQ.length-40} iş daha</p>`;
  }
  h+='</div>';
  const old=_tc0(),i=old.indexOf('<div class="panel"><h2>🏭');
  return h+(i>=0?old.slice(i):'');
};
ACT.craftSell=d=>{UI.mkPre=d.k;UI.tab='mkt';};
if(typeof afterRender==='function'){const _ar9=afterRender;afterRender=function(){const r=_ar9.apply(this,arguments);try{if(UI.mkPre&&UI.tab==='mkt'){const e=$('mkRes');if(e){e.value=UI.mkPre;UI.mkPre=null;}}}catch(e){}return r;};}
/* karakter sekmesi: yetenek öğrenmeyi hızlandır */
if(typeof tabChar==='function'){const _tch=tabChar;tabChar=function(){
  const c=learnRushCost();let p='';
  if(c&&c.rem>0)p=`<div class="panel"><h2>⚡ Öğrenmeyi hızlandır</h2><p>${PERKS[S.me.learn.perk]} yükseliyor · kalan <b>${fmtDur(c.rem)}</b></p><div class="btns">${btn(`Parayla hemen bitir (${fmt(c.money)}₺)`,'data-a="learnRush"','gold sm')}${btn(`Altınla (${c.gold})`,'data-a="learnRush" data-g="1"','sm')}</div></div>`;
  return p+_tch.apply(this,arguments);};}
/* ================= HER İŞE OTOMASYON: öğrenme, üretim, fabrika, pazar, görev, günlük, içecek, güçlendirici, şehir bağışı, eve dönüş (ücretsiz anahtarlar) ================= */
const AU2_JOBS=[
  ['learn','📚','Otomatik öğrenme','Bir şey öğrenmiyorsan en düşük yeteneği para ile öğrenmeye başlar.'],
  ['craft','🔧','Otomatik üretim','Seçili eşyayı sınırsız, hatlar boş kalmasın diye sürekli üretir; eksik çelik/yakıtı da kendisi üretir.'],
  ['rush','⚡','Otomatik üretim hızlandırma','Para payını (ayardaki) aşan kısmıyla üretimi hemen bitirir.'],
  ['wk','🏗️','Otomatik atölye yükseltme','En düşük atölyeyi, para payını aşınca yükseltir.'],
  ['lrush','🚀','Hızlı yetenek yükseltme','Yeteneği otomatik öğrenir ve parayla (ayardaki payı bırakarak) hemen bitirir; seviye seviye tırmanır.'],
  ['fac','🏭','Otomatik fabrika toplama','Özel fabrikalarındaki stoğu depona alır.'],
  ['sell','💰','Otomatik pazar satışı','Petrol ve cevher deponun %70\'ini aşınca %30\'a kadar satar.'],
  ['daily','🎁','Otomatik günlük ödül','Giriş ödülünü her gün kendisi alır.'],
  ['quest','🎯','Otomatik görev ödülü','Biten günlük ve özel görev ödüllerini toplar.'],
  ['drink','⚡','Otomatik enerji içeceği','Çalışma/savaş otomatiği açıkken enerji bitince altınla içer (altın payı bırakır).'],
  ['boost','💪','Otomatik güçlendirici','Süresi bitince 30.000₺\'lik güçlendiriciyi kendisi kullanır.'],
  ['fund','🏙️','Otomatik şehir bağışı','Yaşadığın şehre saatte bir paranın %10\'unu bağışlar (en az 100.000₺ varken).'],
  ['home','🏠','Otomatik eve dönüş','Bir bölgede 20 dakikadan fazla kalırsan yurduna geri döner.']
];
function au2(){const m=S.me;if(!m.au2)m.au2={on:{},cfg:{perk:'low',item:'tank',boost:'str',keepGold:5,keepMoney:50000,batch:0},st:{},at:0};const a=m.au2;a.on=a.on||{};a.cfg=a.cfg||{};a.st=a.st||{};return a;}
const au2On=k=>{try{return !!au2().on[k];}catch(e){return false;}};
function au2Quiet(f){const m0=msg,t0=toast;msg=function(){};toast=function(){};try{return f();}finally{msg=m0;toast=t0;}}
const keep0=cfg=>Math.max(0,+cfg.keepMoney||0);
function au2Run(){
  if(!S||!S.me)return;const m=S.me,a=au2();
  if(S.t-(a.at||0)<30e3)return;a.at=S.t;
  const on=a.on,cfg=a.cfg,st=a.st,n=(k,t)=>{st[k]=(st[k]||0)+1;a.last=a.last||{};a.last[k]=S.t;a.log=a.log||[];a.log.unshift({t:S.t,k:k,x:t||''});if(a.log.length>30)a.log.pop();};
  if(m.loc!==a.lastLoc){a.lastLoc=m.loc;a.locSince=S.t;}
  if(m.travel)return;
  const q=f=>au2Quiet(f);
  if(on.daily&&typeof streakInfo==='function'&&streakInfo().can){q(()=>ACT.dailyClaim());n('daily');L('🎁 Otomatik: günlük ödül alındı.','ok');}
  if(on.quest&&typeof qState==='function'){
    try{qProg(qState()).filter(p=>p.ok&&!p.done).forEach(p=>{q(()=>ACT.qClaim({id:p.id}));n('quest');});}catch(e){}
    try{const r=rqS();
      if(!r.evl.done&&r.evl.ms>=RQ_TRAVEL_NEED){q(()=>ACT.rqClaim({k:'evl'}));n('quest');}
      if(r.tour&&!r.tour.done&&Object.keys(r.tour.seen).length>=RQ_TOUR_N){q(()=>ACT.rqClaim({k:'tour'}));n('quest');}
      if(r.visit&&r.visit.ok){q(()=>ACT.rqClaim({k:'visit'}));n('quest');}
      if(r.emek.claimed!==rqDay()&&rqStreak()>=5){q(()=>ACT.rqClaim({k:'emek'}));n('quest');}
    }catch(e){}
  }
  if(on.fac){m.facs.forEach(f=>{if(f.stock>=1){q(()=>ACT.facCollect({id:f.id}));n('fac');}});}
  if(on.sell){const cap=storCap();['oil','ore'].forEach(k=>{if(m.stor[k]>cap*0.7){q(()=>sellRes(k,m.stor[k]-cap*0.3));n('sell');}});}
  if((on.learn||on.lrush)&&!m.learn){
    let p=cfg.perk;if(!PERKS[p]){p=['str','edu','end'].sort((x,y)=>m[x]-m[y])[0];}
    const c=learnCost(p,false);if(m.money-(on.lrush?0:0)>=c){q(()=>ACT.learn({p:p,g:'0'}));if(m.learn)n('learn',PERKS[p]+' öğrenmeye başlandı');}
  }
  if(on.lrush&&m.learn){const lc=learnRushCost();if(lc&&lc.rem>0&&m.money-lc.money>=keep0(cfg)){q(()=>learnRush(false));n('lrush','yetenek hemen bitirildi');}}
  if(on.craft&&ITEMS[cfg.item]){const d=prodAuto(cfg.item,+cfg.batch||0);if(d)n('craft',ITEMS[cfg.item].n+' hattı dolduruldu');}
  const keep=Math.max(0,+cfg.keepMoney||0);
  if(on.rush&&m.craftQ.length){const ord=m.craftQ.filter(b=>!b.rs).sort((x,y)=>x.end-y.end);
    for(const b of ord){const w=workLeft(b);if(w<=0)continue;if(m.money-rushMoney(w)<keep)break;if(q(()=>rushOne(b,false))===null){n('rush','üretim hızlandırıldı');}else break;}}
  if(on.wk){const ks=Object.keys(WK).filter(k=>!(k==='yard'&&!(S.regions[m.res]||{}).coast)&&(prodS().wk[k]||0)<10).sort((x,y)=>m.wk[x]-m.wk[y]);
    if(ks.length){const k=ks[0],c=wkCost(k);if(m.money-c.money>=keep&&m.stor.gold-c.gold>=(+cfg.keepGold||0)){q(()=>ACT.wkUp({k:k}));n('wk',WK[k].n+' yükseltildi');}}}
  if(on.boost&&!(m.boost&&m.boost.end>S.t)&&S.t>=m.boostCd&&m.money>=30000+50000){q(()=>ACT.boost({p:PERKS[cfg.boost]?cfg.boost:'str',g:'0'}));n('boost');}
  if(on.drink&&!m.admin&&(auOn('work')||auOn('war'))&&m.energy<energyCost()&&m.stor.gold>=(+cfg.keepGold||0)+2){q(()=>ACT.drink());n('drink');}
  if(on.fund&&S.t-(a.fundAt||0)>=HOUR&&m.money>=100000&&m.res!=null){
    const r=S.regions[m.res];if(r&&typeof devOf==='function'&&devOf(r)<10){a.fundAt=S.t;const u0=UI.city;UI.city=m.res;q(()=>ACT.cityFund({v:Math.floor(m.money*0.1)}));UI.city=u0;n('fund','şehre bağış yapıldı');}
  }
  if(on.home&&m.res!=null&&m.loc!==m.res&&S.t-(a.locSince||S.t)>=20*MIN&&!S.regions[m.res].moon){q(()=>ACT.travel({to:m.res}));if(m.travel)n('home','eve dönüş yoluna çıkıldı');}
}
if(typeof autoRun==='function'){const _ar2=autoRun;autoRun=function(){const r=_ar2.apply(this,arguments);try{au2Run();}catch(e){}return r;};}
ACT.au2=d=>{const a=au2();if(d.k==='all'){const v=!AU2_JOBS.every(j=>a.on[j[0]]);AU2_JOBS.forEach(j=>a.on[j[0]]=v);return;}a.on[d.k]=!a.on[d.k];};
ACT.au2Cfg=()=>{const a=au2(),g=i=>($(i)||{}).value;
  if(g('au2perk')!==undefined)a.cfg.perk=g('au2perk');if(g('au2item'))a.cfg.item=g('au2item');
  if(g('au2boost'))a.cfg.boost=g('au2boost');if(g('au2batch')!==undefined)a.cfg.batch=+g('au2batch');if(g('au2keep')!==undefined)a.cfg.keepMoney=+g('au2keep');if(g('au2gold')!==undefined)a.cfg.keepGold=Math.max(0,+g('au2gold')||0);
  msg('✅ Otomasyon ayarları kaydedildi.','ok');};
/* sekme içi küçük anahtar şeridi */
function au2Strip(keys){
  const a=au2(),n=keys.filter(k=>a.on[k]).length;
  return `<details class="au2s" style="margin:0 0 8px;padding:6px 10px;border:1px solid #2a3542;border-radius:8px"><summary class="dim" style="cursor:pointer">⚙️ Otomatik anahtarlar · ${n}/${keys.length} açık</summary><div class="btns" style="margin-top:6px">${keys.map(k=>{const j=AU2_JOBS.find(x=>x[0]===k);return j?btn(j[1]+' '+j[2].replace('Otomatik ','')+': '+(a.on[k]?'AÇIK':'kapalı'),`data-a="au2" data-k="${k}"`,'sm '+(a.on[k]?'gold':'')):'';}).join('')}<button class="act sm" data-a="tab" data-t="ctl">🎛️ Kontrol</button></div></details>`;
}
function au2Panel(){
  const a=au2(),all=AU2_JOBS.every(j=>a.on[j[0]]);
  let h=`<div class="panel"><h2>🤖 Her işe otomasyon</h2><p class="dim">Her iş için ücretsiz bir anahtar. Oyun açıkken (ve çevrimdışı geçen sürede) seçtiğin işler kendiliğinden yapılır. Otomatik çalışma ve savaş yukarıdaki ücretli paketlerdir.</p>
  <div class="btns">${btn(all?'Hepsini kapat':'Hepsini aç','data-a="au2" data-k="all"','gold sm')}</div><div class="grid" style="margin-top:8px">`;
  AU2_JOBS.forEach(j=>{const on=!!a.on[j[0]],c=a.st[j[0]]||0;
    h+=card(j[1]+' '+j[2],`<p class="dim">${j[3]}</p><p>${on?'<b class="ok">AÇIK</b>':'<span class="dim">kapalı</span>'} · ${c} kez</p>${btn(on?'Kapat':'Aç',`data-a="au2" data-k="${j[0]}"`,on?'danger sm':'gold sm')}`);});
  h+=`</div><div class="card" style="margin-top:8px"><h3>Otomasyon ayarları</h3>
  <div class="row" style="margin:4px 0">Öğrenme: ${sel('au2perk',[['low','En düşük yetenek']].concat(Object.keys(PERKS).map(p=>[p,PERKS[p]])),a.cfg.perk||'low')}</div>
  <div class="row" style="margin:4px 0">Üretim: ${sel('au2item',Object.keys(ITEMS).map(k=>[k,ITEMS[k].i+' '+ITEMS[k].n]),a.cfg.item||'tank')}</div>
  <div class="row" style="margin:4px 0">Üretim parti: ${sel('au2batch',[[0,'Sınırsız (maks)'],[5,'5'],[10,'10'],[20,'20'],[50,'50'],[100,'100'],[500,'500']],a.cfg.batch||0)}</div>
  <div class="row" style="margin:4px 0">Hızlandırmada bırakılacak para: ${sel('au2keep',[[0,'0₺'],[50000,'50.000₺'],[250000,'250.000₺'],[1000000,'1.000.000₺']],a.cfg.keepMoney==null?50000:a.cfg.keepMoney)}</div>
  <div class="row" style="margin:4px 0">Güçlendirici: ${sel('au2boost',Object.keys(PERKS).map(p=>[p,PERKS[p]]),a.cfg.boost||'str')}</div>
  <div class="row" style="margin:4px 0">İçecek için bırakılacak altın: <input id="au2gold" type="number" min="0" value="${a.cfg.keepGold==null?5:a.cfg.keepGold}" style="width:80px"></div>
  <div class="btns">${btn('Ayarları kaydet','data-a="au2Cfg"','sm')}</div></div></div>`;
  return h;
}
function auStatus(){
  const m=S.me,a=auOf(),o=[],ec=energyCost();
  const pend=(m.apend||[]).length;
  if(pend)o.push('⏳ '+pend+' paket yönetici onayı bekliyor; onaylanana kadar mod çalışmaz.');
  if(m.jail>S.t)o.push('⛓️ Hapistesin: modlar durdu.');
  if(m.travel)o.push('🧳 Yoldasın: modlar varınca devam eder.');
  const warOn=S.wars.some(x=>x.state==='on'&&(x.att==='A'||x.def==='A'));
  if(a.work>S.t){const r=myReg();
    if(m.energy<ec)o.push(`⚡ Çalışma: enerji bekleniyor (${f1(m.energy)}/${ec}). Enerji saatte yaklaşık 30 artar; hızlandırmak için "Otomatik enerji içeceği" anahtarını aç.`);
    else if(!regionAllows(r))o.push('⛔ Çalışma: bu bölgede çalışma iznin yok.');
    else if(!RES.some(k=>YIELD[k]&&r.res[k].c>0))o.push('⛔ Çalışma: bu bölgede rezerv bitti, başka bölgeye git.');
    else o.push('✅ Çalışma: aktif.');}
  if(a.war>S.t){
    if(!warOn)o.push('⚔️ Savaş: devletin şu an aktif bir savaşta değil (savaş başlayınca vurur).');
    else if(m.energy<10)o.push(`⚡ Savaş: enerji bekleniyor (${f1(m.energy)}/10).`);
    else o.push('✅ Savaş: aktif.');}
  if(!(a.work>S.t)&&!(a.war>S.t))o.push('Otomatik çalışma/savaş paketi yok ya da süresi bitti.');
  return '<div class="card"><h3>📡 Durum</h3>'+o.map(x=>'<p>'+x+'</p>').join('')+'</div>';
}
if(typeof tabAuto==='function'){const _ta2=tabAuto;tabAuto=function(){const h=_ta2(),i=h.indexOf('<div class="card" style="margin-top:8px"><h3>Ayarlar</h3>');return (i>0?h.slice(0,i)+auStatus()+h.slice(i):auStatus()+h)+au2Panel();};}
/* Otomatik anahtar şeridi kaldırıldı: anahtarlar yalnızca Ekonomi › Otomatik sayfasında */
/* ================= YÖNETİM 2.0: bağışlar (devlet/şehir/yabancı devlet), Şehirlerim (vali), Kontrol paneli, yeni menü düzeni ================= */
const MAT_VAL={steel:210,fuel:180,warhead:4000};
const DN_VAL={tank:14000,fighter:35000,bomber:80000,ship:60000,battleship:150000,missile:200000,moontank:100000,siha:22000,station:300000};
function gvS(){const a=A();a.budget.mats=a.budget.mats||{steel:0,fuel:0,warhead:0};a.arsenal=a.arsenal||{};a.donors=a.donors||{};a.dfeed=a.dfeed||[];return a;}
function dnValue(kind,key,n){if(kind==='money')return n;if(kind==='res')return n*(S.prices[key]||0);if(kind==='mat')return n*(MAT_VAL[key]||100);return n*(DN_VAL[key]||20000);}
function dnLabel(kind,key){
  if(kind==='money')return '💰 Para';
  if(kind==='res')return RES_I[key]+' '+RES_N[key];
  if(kind==='mat')return MATS[key].i+' '+MATS[key].n;
  return ITEMS[key].i+' '+ITEMS[key].n;
}
function dnStock(kind,key){const m=S.me;if(kind==='money')return Math.floor(m.money);if(kind==='res')return Math.floor((m.stor[key]||0));if(kind==='mat')return Math.floor((prodS().mats[key]||0));return (m.items[key]||0);}
function dnTake(kind,key,n){const m=S.me;if(kind==='money')m.money-=n;else if(kind==='res')m.stor[key]-=n;else if(kind==='mat')m.mats[key]-=n;else m.items[key]-=n;}
function dnFeed(who,text,v,bot){
  const a=gvS();a.dfeed.unshift({t:S.t,n:who,w:text,v:Math.round(v),b:bot?1:0});if(a.dfeed.length>25)a.dfeed.pop();
  const d=a.donors[who]||(a.donors[who]={v:0,b:bot?1:0});d.v+=v;
  const ks=Object.keys(a.donors);if(ks.length>60){ks.sort((x,y)=>a.donors[x].v-a.donors[y].v);delete a.donors[ks[0]];}
}
const arsenalPower=()=>Object.keys(gvS().arsenal).reduce((t,k)=>t+(ITEMS[k]?ITEMS[k].dmg*gvS().arsenal[k]:0),0);
{const _p0=powerOf;powerOf=function(s){const v=_p0.apply(this,arguments);return s==='A'?v+arsenalPower()*0.4:v;};}
function dnApply(to,kind,key,n){ // hedefe teslim; sonuç metni
  const a=gvS(),v=dnValue(kind,key,n);
  if(to==='A'){
    if(kind==='money')a.budget.money+=n;else if(kind==='res')a.budget[key]+=n;else if(kind==='mat')a.budget.mats[key]=(a.budget.mats[key]||0)+n;else a.arsenal[key]=(a.arsenal[key]||0)+n;
    return 'devlet bütçesine';
  }
  if(to[0]==='c'){const r=S.regions[+to.slice(1)];r.treas=(r.treas||0)+Math.round(v*(kind==='money'?1:0.85));return r.n+' hazinesine';}
  addRel('A',to,Math.min(25,v/300000));S.states[to].gifts=(S.states[to].gifts||0)+v;return nameOf(to)+' devletine';
}
ACT.donate=d=>{
  const m=S.me,to=($('dnTo')||{}).value||'A',wh=($('dnWhat')||{}).value||'money',p=wh.split(':'),kind=p[0],key=p[1];
  let n=d.all==='1'?dnStock(kind,key):Math.floor(+(($('dnAmt')||{}).value)||0);
  if(!(n>=1))return msg('Bağış miktarı gir.');
  if(dnStock(kind,key)<n)return msg('Yeterli stok yok.');
  if(to[0]==='c'){const r=S.regions[+to.slice(1)];if(!r||r.state!=='A')return msg('Bu şehir devletin değil.');}
  else if(to!=='A'&&!S.states[to])return msg('Hedef geçersiz.');
  const v=dnValue(kind,key,n),where=dnApply(to,kind,key,n);dnTake(kind,key,n);
  m.dnTot=(m.dnTot||0)+v;
  if(to==='A'||to[0]==='c')dnFeed(m.name,`${fmt(n)} ${dnLabel(kind,key)}`,v,false);
  L(`🎁 ${where} ${fmt(n)} ${dnLabel(kind,key)} bağışladın (≈${fmt(v)}₺).`,'ok');msg('🎁 Bağış yapıldı, teşekkürler!','ok');
};
/* yapay zekâ oyuncular ve yabancı devletler de bağış yapar */
function gvTick(){
  if(!S||!S.me)return;const a=gvS(),rnd=Math.random;
  if(!a.dnAt)a.dnAt=S.t;
  const k=Math.min(12,Math.floor((S.t-a.dnAt)/(20*MIN)));if(k<1)return;a.dnAt+=k*20*MIN;
  const nb=(typeof BOTAGG!=='undefined'&&BOTAGG.st&&BOTAGG.st.A)?BOTAGG.st.A.n:0,gov=myGovs();
  for(let j=0;j<k;j++){
    const cnt=Math.min(6,Math.round(0.4+nb/150));
    for(let i=0;i<cnt;i++){
      const nm=(typeof botName==='function'?botName(Math.floor(rnd()*Math.max(60,nb))):'Vatandaş')+' 🤖',x=rnd();
      let kind,key,n;
      if(x<0.55){kind='money';key='';n=Math.round(8000+rnd()*112000);}
      else if(x<0.8){kind='res';key=['oil','ore','gold'][Math.floor(rnd()*3)];n=key==='gold'?1+Math.floor(rnd()*3):20+Math.floor(rnd()*130);}
      else if(x<0.92){kind='mat';key=['steel','fuel'][Math.floor(rnd()*2)];n=30+Math.floor(rnd()*170);}
      else{kind='item';key=['tank','siha','fighter'][Math.floor(rnd()*3)];n=1+Math.floor(rnd()*4);}
      const to=(gov.length&&rnd()<0.25)?'c'+gov[Math.floor(rnd()*gov.length)].id:'A';
      const v=dnValue(kind,key,n);dnApply(to,kind,key,n);dnFeed(nm,`${fmt(n)} ${dnLabel(kind,key)}`,v,true);
    }
  }
  // dost devletler
  if(S.t-(a.aidAt||0)>8*HOUR){a.aidAt=S.t;
    AI_S.filter(s=>s!=='O'&&regOf(s).length&&relTo('A',s)>35&&rnd()<0.5).forEach(s=>{
      const mo=Math.round(100000+rnd()*200000),g=3+Math.floor(rnd()*10);a.budget.money+=mo;a.budget.gold+=g;
      dnFeed(nameOf(s)+' 🌐',`${fmt(mo)}₺ + ${g} altın yardım`,mo+g*S.prices.gold,true);news(`${nameOf(s)} dost devlet olarak bütçemize yardım gönderdi.`);});}
  S.dirty=true;
}
{const _q9=questTick;questTick=function(){_q9.apply(this,arguments);try{gvTick();}catch(e){}};}
/* ---- bağış sekmesi ---- */
function tabGive(){
  const m=S.me,a=gvS(),own=regOf('A');
  const to=[['A','🏛️ '+nameOf('A')+' bütçesi']].concat(own.filter(r=>!r.moon).map(r=>['c'+r.id,'🏙️ '+r.n+(r.gov==='me'?' (valisin)':'')+' hazinesi'])).concat(AI_S.filter(s=>s!=='O'&&regOf(s).length).map(s=>[s,'🌐 '+nameOf(s)+' (ilişki '+Math.round(relTo('A',s))+')']));
  const wh=[['money:','💰 Para ('+fmt(m.money)+'₺)']].concat(RES.map(r=>['res:'+r,RES_I[r]+' '+RES_N[r]+' ('+f1(m.stor[r])+')'])).concat(Object.keys(MATS).map(k=>['mat:'+k,MATS[k].i+' '+MATS[k].n+' ('+f1(prodS().mats[k]||0)+')'])).concat(Object.keys(ITEMS).map(k=>['item:'+k,ITEMS[k].i+' '+ITEMS[k].n+' ('+(m.items[k]||0)+')']));
  let h=`<div class="panel"><h2>🎁 Bağış</h2><p class="hint">Devlet bütçesine, vali olduğun şehrin hazinesine ya da yabancı devletlere para, ham madde, ara mamul ve eşya bağışla. Yabancı devlete bağış ilişkiyi düzeltir; eşyalar devletin askeri gücüne eklenir. Yapay zekâ oyuncular ve dost devletler de bağış yapar.</p>
  <div class="card"><div class="row" style="margin:4px 0">Nereye: ${sel('dnTo',to,UI.dnTo||'A')}</div><div class="row" style="margin:4px 0">Ne: ${sel('dnWhat',wh,UI.dnWhat||'money:')}</div>
  <div class="row" style="margin:4px 0"><input id="dnAmt" type="number" min="1" placeholder="Miktar" style="width:140px"></div>
  <div class="btns">${btn('🎁 Bağışla','data-a="donate"','gold')}${btn('Hepsini bağışla','data-a="donate" data-all="1"','sm')}</div>
  <p class="dim">Toplam bağışın: <b>${fmt(m.dnTot||0)}₺</b> değerinde.</p></div></div>`;
  h+=`<div class="panel"><h2>🏛️ ${esc(nameOf('A'))} hazinesi</h2><div class="grid">
  ${card('💰 Para ve kaynak',`<p>${fmt(a.budget.money)}₺</p><p class="dim">${RES.map(k=>`${RES_I[k]} ${f1(a.budget[k])}`).join(' · ')}</p>`)}
  ${card('🔩 Ara mamul',`<p class="dim">${Object.keys(MATS).map(k=>`${MATS[k].i} ${f1(a.budget.mats[k]||0)}`).join(' · ')}</p>`)}
  ${card('⚔️ Cephanelik',`<p class="dim">${Object.keys(a.arsenal).filter(k=>a.arsenal[k]>0&&ITEMS[k]).map(k=>`${ITEMS[k].i} ${a.arsenal[k]}`).join(' · ')||'Boş'}</p><p class="dim">Askeri güce +${f1(arsenalPower()*0.4)}</p>`)}</div></div>`;
  const top=Object.keys(a.donors).sort((x,y)=>a.donors[y].v-a.donors[x].v).slice(0,10);
  h+=`<div class="panel"><h2>🏆 En çok bağış yapanlar</h2>${top.length?top.map((k,i)=>`<div class="q">${i+1}. ${esc(k)} — <b>${fmt(a.donors[k].v)}₺</b></div>`).join(''):'<p class="dim">Henüz bağış yok.</p>'}</div>`;
  h+=`<div class="panel"><h2>🕘 Son bağışlar</h2>${a.dfeed.length?a.dfeed.slice(0,12).map(x=>`<div class="q"><b>${esc(x.n)}</b>: ${esc(x.w)} <small class="dim">${fmtDur(S.t-x.t)} önce</small></div>`).join(''):'<p class="dim">Henüz bağış yok.</p>'}</div>`;
  return h;
}
TABX.give=tabGive;
/* ---- Şehirlerim (vali) ---- */
ACT.govDev=d=>{
  const r=S.regions[+d.id];if(!r||r.gov!=='me')return;if(devOf(r)>=10)return msg('Şehir zaten en üst seviyede.');
  const v=Math.floor(Math.min(r.treas||0,Math.max(1,devCost(devOf(r))-(r.devP||0))));if(v<1)return msg('Şehir hazinesi boş.');
  r.treas-=v;r.devP=(r.devP||0)+v;let up=0;
  while(devOf(r)<10&&r.devP>=devCost(devOf(r))){r.devP-=devCost(devOf(r));r.dev=devOf(r)+1;up++;}
  if(devOf(r)>=10)r.devP=0;
  if(up){L(`🏙️ ${r.n} hazineden geliştirildi: seviye ${r.dev}!`,'ok');news(`${r.n} şehri geliştirme seviyesi ${r.dev}'e yükseldi.`);}
  msg(up?`🏙️ ${r.n} seviye ${r.dev}!`:'Hazine geliştirmeye aktarıldı.','ok');
};
ACT.cityFund2=d=>{const u=UI.city;UI.city=+d.id;try{ACT.cityFund({v:d.v});}finally{UI.city=u;}};
function tabCities(){
  const m=S.me,mine=myGovs(),own=regOf('A').filter(r=>!r.moon);
  let h=`<div class="panel"><h2>🏙️ Şehirlerim</h2><p class="hint">Vali olduğun şehirlerin hazinesi, gelişimi ve inşaatları. Başkan vali atar (en çok 3 şehir). Hazine, şehrin gelirinin %40'ıyla dolar; bağış da kabul eder. <a class="lk" data-a="tab" data-t="give">Bağış sekmesi</a></p>`;
  if(!mine.length)h+=`<div class="card"><p>Şu an hiçbir şehrin valisi değilsin.</p>${isLeader()?`<div class="btns">${own.slice(0,6).map(r=>btn('Vali ol: '+esc(r.n),`data-a="govAppoint" data-id="${r.id}"`,'gold sm')).join('')}</div>`:'<p class="dim">Başkan seni vali atayabilir ya da Başkanlık sekmesinden seçime girebilirsin.</p>'}</div>`;
  h+='<div class="grid">';
  mine.forEach(r=>{
    const l=devOf(r),cost=l<10?devCost(l):0,inc=r.idx.d*3000*(A().tax.inc/100)*(1+0.1*levelB(r,'house'))*0.4;
    h+=card(`${esc(r.n)} <span class="owner">valisin</span>`,`<p>🏙️ Seviye <b>${l}</b>/10 · 👥 ${fmt(cityPop(r))}</p>${l<10?bar(r.devP||0,cost)+`<p class="dim">${fmt(r.devP||0)} / ${fmt(cost)}₺</p>`:'<p class="ok">En üst seviye</p>'}
      <p>🏦 Hazine: <b>${fmt(r.treas||0)}₺</b> <span class="dim">(≈ +${fmt(inc)}₺/sa)</span></p><p class="dim">❤️${r.idx.h} 🎖️${r.idx.m} 🎓${r.idx.e} 🏘️${r.idx.d}</p>
      <p class="dim">${RES.filter(k=>r.res[k].m>0).map(k=>`${RES_I[k]} ${f1(r.res[k].c)}/${f1(r.res[k].m)}`).join(' · ')}</p>
      <p class="dim">Binalar: ${Object.keys(BUILD).filter(k=>(r.b[k]||0)>0).map(k=>BUILD[k].i+r.b[k]).join(' ')||'yok'}</p>
      ${r.bq.length?r.bq.map(b=>`<div class="q">${BUILD[b.b].i} ${BUILD[b.b].n} — ${cd(b.end)}${pb(b.start,b.end)}</div>`).join(''):''}
      <div class="row" style="margin:4px 0">${sel('govB_'+r.id,Object.keys(BUILD).map(b=>[b,`${BUILD[b].i} ${BUILD[b].n} (${fmt(Math.floor(buildCost(r,b)*0.6))}₺)`]))}</div>
      <div class="btns">${btn('🏗️ İnşa ettir',`data-a="govBuild" data-id="${r.id}"`,'blue sm')}${btn('🏙️ Hazineden geliştir',`data-a="govDev" data-id="${r.id}"`,'gold sm',l>=10)}${btn('+100.000₺ hazine',`data-a="govFund" data-id="${r.id}"`,'sm')}${btn('Valilikten ayrıl',`data-a="govDismiss" data-id="${r.id}"`,'sm danger')}</div>`,'glow');});
  h+='</div></div><div class="panel"><h2>🏠 Devletin şehirleri</h2><p class="hint">Her şehre kendi paranla geliştirme bağışı yapabilirsin (gelişme: çalışma verimi ve tesis üretimi artar).</p><div class="grid">';
  own.forEach(r=>{const l=devOf(r);
    h+=card(`${esc(r.n)} ${r.gov==='me'?'🎖️':''}`,`<p>🏙️ sv <b>${l}</b>/10 · 👥 ${fmt(cityPop(r))}</p>${l<10?bar(r.devP||0,devCost(l)):''}
      <div class="btns">${btn('+100.000₺',`data-a="cityFund2" data-id="${r.id}" data-v="100000"`,'sm',l>=10||m.money<100000)}${btn('+1.000.000₺',`data-a="cityFund2" data-id="${r.id}" data-v="1000000"`,'sm',l>=10||m.money<1e6)}${btn('📋 Bilgi',`data-a="ent" data-k="city" data-id="${r.id}"`,'sm')}</div>`);});
  return h+'</div></div>';
}
TABX.cities=tabCities;
/* ---- Kontrol paneli ---- */
function tabCtl(){
  const m=prodS(),a=au2(),L0=lineCount();
  const ago=k=>a.last&&a.last[k]?fmtDur(S.t-a.last[k])+' önce':'—';
  let h=`<div class="panel"><h2>🎛️ Otomasyon kontrol</h2><p class="hint">Otomatik işlerin tamamı tek ekranda: ne üretiliyor, ne yapılıyor, en son ne zaman çalıştı. Anahtarları buradan açıp kapatabilirsin.</p>
  <div class="grid">${card('⚡ Enerji',`<div class="big">${f1(m.energy)}</div><p class="dim">Saatte ~30 artar.</p>`)}
  ${card('💰 Para',`<div class="big">${fmt(m.money)}₺</div><p class="dim">Altın ${f1(m.stor.gold)}</p>`)}
  ${card('📚 Öğrenme',m.learn?`<p>${PERKS[m.learn.perk]} → ${m[m.learn.perk]+1}</p>${cd(m.learn.end)}${pb(m.learn.start,m.learn.end)}${btn('⚡ Hemen bitir','data-a="learnRush"','gold sm')}`:'<p class="dim">Şu an bir şey öğrenmiyor.</p>')}
  ${card('💪 Güçlendirici',m.boost&&m.boost.end>S.t?`<p>${PERKS[m.boost.perk]} +100</p>${cd(m.boost.end)}`:'<p class="dim">Aktif değil.</p>')}</div></div>`;
  h+=auStatusPanel();
  h+=`<div class="panel"><h2>🤖 Otomatik işler</h2><div class="btns">${btn('Hepsini aç/kapat','data-a="au2" data-k="all"','sm gold')}${btn('Ayarlar','data-a="tab" data-t="auto"','sm')}</div>`;
  AU2_JOBS.forEach(j=>{const on=!!a.on[j[0]];
    h+=`<div class="q">${j[1]} <b>${j[2]}</b> — ${on?'<b class="ok">AÇIK</b>':'<span class="dim">kapalı</span>'} · ${a.st[j[0]]||0} kez · son: ${ago(j[0])} ${btn(on?'Kapat':'Aç',`data-a="au2" data-k="${j[0]}"`,on?'sm danger':'sm gold')}</div>`;});
  h+='</div>';
  // üretim
  h+=`<div class="panel"><h2>🔧 Üretim hatları (${L0})</h2>`;
  const run=m.craftQ.filter(q=>!q.rs),tot=m.craftQ.reduce((x,b)=>x+workLeft(b),0);
  for(let i=0;i<L0;i++){
    const qs=run.filter(q=>Math.min(L0-1,q.ln||0)===i).sort((x,y)=>x.start-y.start),cur=qs.find(q=>q.start<=S.t),nx=qs.filter(q=>q!==cur);
    h+=`<div class="q"><b>Hat ${i+1}</b>: ${cur?`${itDef(cur.k).i} ${cur.n} ${itDef(cur.k).n} — ${cd(cur.end)}${pb(cur.start,cur.end)}`:'<span class="dim">boşta</span>'}${nx.length?`<br><small class="dim">sırada: ${nx.map(q=>itDef(q.k).i+q.n).join(' ')}</small>`:''}</div>`;}
  const rs=m.craftQ.find(q=>q.rs);if(rs)h+=`<div class="q">🔬 ${ITEMS[rs.k].n} Mk${(m.mk[rs.k]||1)+1} araştırması — ${cd(rs.end)}</div>`;
  h+=`<p class="dim">Ara mamul: ${Object.keys(MATS).map(k=>`${MATS[k].i} ${f1(m.mats[k]||0)}`).join(' · ')}</p><p class="dim">Eşya stoğu: ${Object.keys(ITEMS).filter(k=>(m.items[k]||0)>0).map(k=>`${ITEMS[k].i} ${m.items[k]}`).join(' · ')||'yok'}</p>
  ${tot>0?`<div class="btns">${btn(`⚡ Hepsini bitir (${fmt(rushMoney(tot))}₺)`,'data-a="rushAll"','gold sm')}${btn(`Altınla (${rushGold(tot)})`,'data-a="rushAll" data-g="1"','sm')}</div>`:''}</div>`;
  if(m.facs.length){h+=`<div class="panel"><h2>🏭 Fabrikalar</h2>`;m.facs.forEach(f=>{const rate=facRate(f);h+=`<div class="q">${RES_I[f.res]} ${S.regions[f.region].n} sv${f.level} — stok <b>${f1(f.stock)}</b>/${f1(rate*24)} ${bar(f.stock,Math.max(1,rate*24))}</div>`;});h+='</div>';}
  h+=`<div class="panel"><h2>📜 Son otomatik işlemler</h2>${(a.log||[]).length?a.log.slice(0,15).map(x=>{const j=AU2_JOBS.find(y=>y[0]===x.k);return `<div class="q">${j?j[1]:'•'} ${esc(x.x||(j?j[2]:x.k))} <small class="dim">${fmtDur(S.t-x.t)} önce</small></div>`;}).join(''):'<p class="dim">Henüz otomatik işlem yok.</p>'}</div>`;
  return h;
}
function auStatusPanel(){return typeof auStatus==='function'?`<div class="panel"><h2>📡 Çalışma / savaş modu</h2>${auStatus()}<p class="dim">Çalışma ${auOf().st.w} · Savaş vuruşu ${auOf().st.h}</p></div>`:'';}
TABX.ctl=tabCtl;
/* ---- Başkan paneli (devlet başkanının araçları) ---- */
function tabLeader(){
  const a=A(),m=S.me,lead=isLeader(),regs=regOf('A').filter(r=>!r.moon);
  let h=`<div class="panel"><h2>👑 Başkan paneli</h2>`;
  if(!lead){
    h+=`<div class="card"><p>Şu an devletin başkanı <b>${esc(a.leader)}</b>.</p><p class="dim">Başkan olmak için seçime girebilir ${m.party?'ya da darbe girişiminde bulunabilirsin':'(bir partiye üye ol)'}.</p><div class="btns">${btn('🗳️ Başkanlık seçimi','data-a="tab" data-t="elect"','blue sm')}${btn('🎗️ Parti','data-a="tab" data-t="party"','sm')}</div></div></div>`;
    return h+(typeof coupPanel==='function'?coupPanel():'');
  }
  h+=`<p class="hint">Devletin başındasın: bakanları sen belirlersin, bölgelere vali atarsın, ekonomi ve dış ilişki kararlarını anında geçirirsin.</p><div class="grid">
  ${card('👥 Bakanlıklar',`<p>Ekonomi: ${a.min.econ==='me'?'<b>Sen</b>':'Yapay zekâ'}<br>Dışişleri: ${a.min.foreign==='me'?'<b>Sen</b>':'Yapay zekâ'}</p><div class="btns">${btn(a.min.econ==='me'?'Ekonomiden ayrıl':'Ekonomi bakanı ol','data-a="minister" data-m="econ"','sm')}${btn(a.min.foreign==='me'?'Dışişlerinden ayrıl':'Dışişleri bakanı ol','data-a="minister" data-m="foreign"','sm')}</div>`)}
  ${card('💰 Bütçe',`<p>${fmt(a.budget.money)}₺</p><p class="dim">${RES.map(k=>`${RES_I[k]} ${f1(a.budget[k])}`).join(' · ')}</p><div class="btns">${btn('🎁 Bağış sekmesi','data-a="tab" data-t="give"','sm')}</div>`)}
  ${card('📊 Vergiler',`<p>Gelir %${a.tax.inc}</p><p class="dim">${RES.map(k=>`${RES_I[k]} %${a.tax[k]}`).join(' ')}</p><div class="btns">${btn('Kanun teklifi (Devlet)','data-a="tab" data-t="state"','sm')}</div>`)}</div></div>`;
  return h+(typeof govPanel==='function'?govPanel():'');
}
TABX.leader=tabLeader;
/* ---- Rollerim kartı (Devlet sekmesinin başında) ---- */
function rolesCard(){
  const m=S.me,a=A(),gv=myGovs().length,pl=!!m.partyLead;
  const row=(ic,t,on,sub,tab)=>`<div class="q">${ic} <b>${t}</b> — ${on?'<b class="ok">aktif</b>':'<span class="dim">yok</span>'} <small class="dim">${sub}</small> ${btn('Aç',`data-a="tab" data-t="${tab}"`,'sm')}</div>`;
  return `<div class="panel"><h2>🎭 Rollerim</h2>${row('👑','Başkan',isLeader(),isLeader()?'devletin başındasın':'Başkan: '+esc(a.leader),'leader')}${row('🏙️','Vali',gv>0,gv?gv+' şehir':'şehir atanmadı','cities')}${row('🎗️','Parti lideri',pl,m.party?'partin: '+esc((myParty()||{n:''}).n):'partisiz','party')}${row('🎁','Bağışçı',(m.dnTot||0)>0,'toplam '+fmt(m.dnTot||0)+'₺','give')}</div>`;
}
{const _ts8=tabState;tabState=function(){return rolesCard()+_ts8.apply(this,arguments);};}
/* ---- Sınırsız para (yalnızca yönetici) ---- */
ACT.infMoney=()=>{if(!isAdminUI())return msg('Yalnızca yönetici açabilir.');const m=S.me;m.inf=!m.inf;if(m.inf){m.money=Math.max(m.money,1e13);m.stor.gold=storCap();}msg(m.inf?'💎 Sınırsız para açıldı.':'Sınırsız para kapatıldı.','ok');};
function infCard(){const on=!!S.me.inf;return `<div class="panel"><h2>💎 Sınırsız para</h2><div class="card"><p>${on?'<b class="ok">AÇIK</b> — paran ve altının azalmaz.':'Kapalı.'}</p><p class="dim">Yalnızca yönetici (game master) hesabında çalışır.</p><div class="btns">${btn(on?'Kapat':'Aç','data-a="infMoney"',on?'danger sm':'gold sm')}</div></div></div>`;}
{const _qi=questTick;questTick=function(){_qi.apply(this,arguments);try{const m=S.me;if(m.inf&&isAdminUI()){if(m.money<1e12)m.money=1e13;if(m.stor.gold<storCap())m.stor.gold=storCap();}}catch(e){}};}
{const _tu=tickUI;tickUI=function(){const r=_tu.apply(this,arguments);try{if(S.me.inf&&isAdminUI()){const e=$('hMoney');if(e)e.textContent='∞₺';const g=$('hGold');if(g)g.textContent='∞';}}catch(e){}return r;};}
if(typeof tabAdm==='function'){const _tad=tabAdm;tabAdm=function(){return infCard()+_tad.apply(this,arguments);};}
/* ---- yeni menü düzeni: mantıklı gruplar, her rol için ayrı sekme ---- */
(function(){
  const G=GROUPS;G.length=0;
  G.push(['home','🏠 Ana Sayfa',[['home','Ana Sayfa'],['quest','Görevler'],['log','Günlük'],['world','Harita'],['map','Şehirler']]]);
  G.push(['eco','💼 Ekonomi',[['work','Çalış'],['craft','Üretim'],['store','Depo'],['mkt','Pazar'],['bank','🏦 Banka']]]);
  G.push(['auto','⚙️ Otomasyon',[['auto','Otomatik'],['ctl','🎛️ Kontrol']]]);
  G.push(['war','⚔️ Savaş',[['war','Savaş'],['sw','Ortak'],['spy','Casus']]]);
  G.push(['gov','🏛️ Yönetim',[['state','Devlet'],['leader','👑 Başkan'],['cities','🏙️ Vali'],['party','🎗️ Parti'],['elect','🗳️ Seçim'],['give','🎁 Bağış']]]);
  G.push(['paper','📰 Sosyal',[['art','Makaleler'],['paper','Gazete'],['chat','Sohbet'],['ally','🛡️ İttifak'],['lb','Sıralama']]]);
  G.push(['prof','👤 Profil',[['char','Profil'],['set','Ayarlar'],['guide','Rehber'],['net','Hesap'],['adm','👑 Panel','adm'],['bots','🤖 Yapay Zekâ','adm']]]);
})();
/* savaş ilanı Devlet sekmesine taşındı */
{const _ts9=tabState;tabState=function(){return _ts9.apply(this,arguments)+(typeof warDeclPanel==='function'?warDeclPanel():'');};}
/* Kontrol şeridi: Üretim ve Çalış sekmelerinde kısayol */
/* ================= OTOMATİK BULUT KAYDI + ORTAK AÇILIŞ =================
   Aynı hesabı iki telefonda açınca oyun tek bir ortak kayıttan devam eder:
   - Oynarken kayıt kendiliğinden buluta gider (yalnızca sen bir şey yaptıysan).
   - Başka telefonda daha yeni kayıt varsa, oyun açılırken / ekrana dönünce otomatik yüklenir.
   - Yeni kaydı ezmemek için gönderme öncesi bulut kontrol edilir. */
const DEV=(()=>{try{let d=localStorage.getItem('rr-dev');if(!d){d='d'+Math.random().toString(36).slice(2,8);localStorage.setItem('rr-dev',d);}return d;}catch(e){return 'd0';}})();
const CLK='rr-cloudT';
const cloudT=()=>{try{return +localStorage.getItem(CLK)||0;}catch(e){return 0;}};
const setCloudT=t=>{try{localStorage.setItem(CLK,String(t));}catch(e){}};
const cloudOk=()=>!!(MP.ok&&MP.auth&&MP.uid()&&S&&S.mpUid===MP.uid());
MP.cloudInfo={last:0,err:'',checked:0,loaded:0};
MP.actAt=0;
['pointerdown','keydown','touchstart'].forEach(e=>document.addEventListener(e,()=>{MP.actAt=Date.now();},{passive:true,capture:true}));
async function cloudHead(){
  const uid=MP.uid(),t=await MP.fb('GET','saves/'+uid+'/t'),dv=t?await MP.fb('GET','saves/'+uid+'/dv'):null;
  return {t:+t||0,dv:dv||''};
}
function cloudApply(c){ // bulut kaydını bu telefona yükle ve yeniden başlat
  const o=JSON.parse(c.d);o.mpUid=MP.uid();
  MP.noPush=true;window.__noSave=true;
  localStorage.setItem(SAVE,JSON.stringify(o));setCloudT(+c.t||Date.now());
  location.reload();
}
MP.cloudSave=async(force,hard)=>{
  if(!cloudOk()||MP.noPush||MP.cs)return;
  const gap=(S.me&&S.me.admin)?120000:45000;
  if(!hard){
    if(!force&&(document.hidden||Date.now()-(MP.lastCloud||0)<gap))return;
    if(MP.actAt<=cloudT())return; // son eşitlemeden beri bu telefonda işlem yok: gönderme
  }
  MP.cs=1;MP.lastCloud=Date.now();
  try{
    if(!hard){const h=await cloudHead();
      if(h.t&&h.dv&&h.dv!==DEV&&h.t>cloudT()){MP.cloudInfo.err='Başka telefonda daha yeni kayıt var';if(!document.hidden)setTimeout(()=>MP.cloudCheck('push'),0);return;}}
    const t=Date.now();
    await MP.fb('PUT','saves/'+MP.uid(),{t:t,dv:DEV,d:MP.cloudSnap()});
    setCloudT(t);MP.cloudInfo.last=t;MP.cloudInfo.err='';
  }catch(e){MP.cloudInfo.err=String(e.message||e).slice(0,80);}
  finally{MP.cs=0;}
};
MP.cloudCheck=async(why)=>{
  if(!cloudOk()||MP.cc||MP.noPush)return;
  MP.cc=1;
  try{
    const h=await cloudHead();MP.cloudInfo.checked=Date.now();
    if(h.t&&h.dv&&h.dv!==DEV&&h.t>cloudT()){
      if(why==='tick'&&Date.now()-MP.actAt<15000)return; // şu an oynuyorsun; birazdan
      const c=await MP.fb('GET','saves/'+MP.uid());
      if(c&&c.d){toast('☁️ Başka telefondaki daha yeni kayıt yükleniyor…','info');MP.cloudInfo.loaded=Date.now();cloudApply(c);return 'reload';}
    }
  }catch(e){MP.cloudInfo.err=String(e.message||e).slice(0,80);}
  finally{MP.cc=0;}
};
MP.cloudPull=async()=>{ // girişte: ortak kayda göre aç
  const uid=MP.uid();if(!uid)return;
  let c=null;try{c=await MP.fb('GET','saves/'+uid);}catch(e){}
  if(S.mpUid===uid){
    const newer=c&&c.d&&(c.dv?(c.dv!==DEV&&+c.t>cloudT()):(+c.t>(S.savedReal||0)+5000)); // eski biçimli kayıtta yerel zamana bak
    if(newer){try{cloudApply(c);return 'reload';}catch(e){MP.err='Bulut kaydı okunamadı.';}}
    if(!c||!c.d||!c.dv)setTimeout(()=>MP.cloudSave(true,true),2500);
    return;
  }
  // bu telefondaki oyun hesaba bağlı değil
  const fresh=S.me.level<=1&&!(S.me.works>0)&&!(S.me.hits>0)&&S.me.money<=60000;
  if(c&&c.d){
    if(fresh||confirm('Bu hesabın bulutta kayıtlı oyunu var. Yüklensin mi?\n\nTamam: bulut kaydını yükle (bu telefondaki oyun silinir)\nİptal: bu telefondaki oyunu bu hesaba bağla ve buluttakinin yerine yaz')){
      try{cloudApply(c);return 'reload';}catch(e){MP.err='Bulut kaydı okunamadı.';}
    }
  }
  S.mpUid=uid;save();setTimeout(()=>MP.cloudSave(true,true),2500);
};
document.addEventListener('visibilitychange',()=>{if(document.hidden)MP.cloudSave(true);else MP.cloudCheck('vis');});
window.addEventListener('pagehide',()=>{MP.cloudSave(true);});
setInterval(()=>{if(!document.hidden)MP.cloudCheck('tick');},40000);
ACT.cloudPush=async()=>{
  if(!cloudOk())return msg('Önce hesaba giriş yapıp bağlan.');
  try{const h=await cloudHead();
    if(h.t&&h.dv&&h.dv!==DEV&&h.t>cloudT()&&!confirm('Başka telefonda daha yeni bir kayıt var. Yine de bu telefondakini buluta yazayım mı? (diğer telefondaki ilerleme silinir)'))return;}catch(e){}
  await MP.cloudSave(true,true);msg(MP.cloudInfo.err?('Kaydedilemedi: '+MP.cloudInfo.err):'☁️ Buluta kaydedildi.',MP.cloudInfo.err?'bad':'ok');S.dirty=true;render();
};
ACT.cloudLoad=async()=>{
  if(!cloudOk())return msg('Önce hesaba giriş yapıp bağlan.');
  if(!confirm('Buluttaki kayıt yüklensin mi? Bu telefondaki kaydedilmemiş ilerleme silinir.'))return;
  try{const c=await MP.fb('GET','saves/'+MP.uid());if(c&&c.d)cloudApply(c);else msg('Bulutta kayıt yok.');}catch(e){msg('Bulut okunamadı.');}
};
function cloudCard(){
  const i=MP.cloudInfo,lt=cloudT();
  return `<div class="panel"><h2>☁️ Ortak bulut kaydı</h2><div class="card"><p>${cloudOk()?'<b class="ok">Açık</b> · oynarken kendiliğinden kaydedilir; diğer telefonda açınca en yeni kayıttan devam eder.':'<span class="dim">Hesaba giriş yapıp bağlanınca açılır.</span>'}</p>
  <p class="dim">Son eşitleme: ${lt?fmtDur(Date.now()-lt)+' önce':'—'} · bu telefonun kodu: <b>${DEV}</b>${i.err?` · <span class="bad">${esc(i.err)}</span>`:''}</p>
  <div class="btns">${btn('☁️ Şimdi buluta kaydet','data-a="cloudPush"','gold sm')}${btn('⬇️ Buluttan yükle','data-a="cloudLoad"','sm')}</div>
  <p class="hint">İpucu: aynı hesabı iki telefonda aynı anda oynama; en son oynadığın telefondaki ilerleme ortak kayıt olur.</p></div></div>`;
}
if(typeof tabNet==='function'){const _tn9=tabNet;tabNet=function(){return _tn9.apply(this,arguments)+cloudCard();};}
/* ================= BİLDİRİM ZİLİ + HAFTALIK GÖREVLER ================= */
const NF={open:false,prev:0,only:false,sig:''};
const nfWars=()=>S.wars.filter(w=>w.state==='on'&&(w.att==='A'||w.def==='A'));
const nfImp=x=>/savaş ilan|savaşa|savaş başl|savaş bitt|barış|seçim|darbe|bağımsız|ittifak|ambargo|abluka|fethed|işgal|ele geçir|düştü|başkan|yasa|kabul edil|reddedil|vergi|gazete|devlet|sınır|vize|hazine|maaş|saldır/i.test(x.m||'')&&!/üretime alındı|üretildi|sıraya|çalıştın|vurdun|vuruş|eğitim|enerji|üretim/i.test(x.m||'');
const nfUnread=()=>{const m=S.me,s=m.nfSeen||0;return (S.log||[]).filter(x=>x.t>s&&nfImp(x)).length;};
function nfBadge(){const e=document.getElementById('hBellN');if(!e)return;const u=nfUnread(),w=nfWars().length,n=u+w;e.textContent=n?(n>99?'99+':n):'';e.style.display=n?'inline':'none';const b=document.getElementById('hBell');if(b)b.style.borderColor=w?'#da3633':'';}
function nfDraw(){
  const root=document.getElementById('modal-root');if(!root)return;
  if(!NF.open){if(root.dataset.nf){root.innerHTML='';delete root.dataset.nf;}return;}
  const ws=nfWars(),lg=(S.log||[]).filter(x=>nfImp(x)&&(!NF.only||x.c==='bad'||x.c==='warn')).slice(0,40);
  let h=`<div class="modal" data-a="bellClose"><div class="box" data-a="entNop" style="max-height:86vh;overflow:auto"><div class="btns" style="justify-content:space-between;margin-bottom:6px"><b>🔔 Bildirimler</b>${btn('✕ Kapat','data-a="bellClose"','sm')}</div>`;
  h+=`<h3 class="nolk">⚔️ Aktif savaşlar (${ws.length})</h3>`;
  if(!ws.length)h+='<p class="dim">Seni ilgilendiren aktif savaş yok.</p>';
  ws.forEach(w=>{h+=`<div class="card"><p><b>${esc(S.regions[w.region].n)}</b> (${WTYPE[w.type]}) — ${nameOf(w.att)} → ${nameOf(w.def)}<br><span class="dim">bitmesine ${cd(w.end)}</span></p><div class="btns">${btn('💥 Vur',`data-a="bellHit" data-w="${w.id}"`,'danger sm')}${btn('Vur ×5',`data-a="bellHit" data-w="${w.id}" data-n="5"`,'sm')}${btn('Savaşa git','data-a="bellGo"','sm')}</div></div>`;});
  h+=`<div class="btns" style="justify-content:space-between;margin:10px 0 4px"><b>📜 Son olaylar</b><span>${btn(NF.only?'Hepsi':'Sadece uyarılar','data-a="bellOnly"','sm')}${btn('Okundu say','data-a="bellRead"','sm')}</span></div>`;
  if(!lg.length)h+='<p class="dim">Kayıt yok.</p>';
  lg.forEach(x=>{const nw=x.t>NF.prev;h+=`<div class="card" style="padding:6px 8px;margin:4px 0;${nw?'border-color:#d4a72c':''}"><span class="dim">${new Date(x.t).toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'})}</span> ${nw?'🆕 ':''}<span class="${x.c==='bad'?'bad':x.c==='ok'?'ok':''}">${esc(x.m)}</span></div>`;});
  root.innerHTML=h+`</div></div>`;root.dataset.nf=1;
}
ACT.bell=()=>{const m=S.me;NF.prev=m.nfSeen||0;m.nfSeen=S.t;NF.open=true;nfDraw();nfBadge();S.dirty=false;};
ACT.bellClose=()=>{NF.open=false;nfDraw();S.dirty=false;};
ACT.bellOnly=()=>{NF.only=!NF.only;nfDraw();S.dirty=false;};
ACT.bellRead=()=>{NF.prev=S.t;S.me.nfSeen=S.t;nfDraw();nfBadge();S.dirty=false;};
ACT.bellGo=()=>{NF.open=false;nfDraw();UI.tab='war';window.scrollTo(0,0);};
ACT.bellHit=d=>{const n=Math.max(1,Math.min(10,+d.n||1));let tot=0,k=0,err='';for(let i=0;i<n;i++){const r=doHit(+d.w);if(typeof r==='string'){err=r;break;}tot+=r;k++;}
  if(k)msg(`💥 ${k} vuruş, toplam ${fmt(tot)} hasar.`,'ok');else msg(err||'Vurulamadı.');nfDraw();nfBadge();};
(function(){const st=document.querySelector('header .stats');if(st&&!document.getElementById('hBell')){const s=document.createElement('span');s.id='hBell';s.setAttribute('data-a','bell');s.style.cursor='pointer';s.innerHTML='🔔<b id="hBellN" style="display:none;background:#da3633;color:#fff;border-radius:9px;padding:0 5px;margin-left:3px;font-size:11px"></b>';st.insertBefore(s,st.firstChild);}})();
setInterval(()=>{try{nfBadge();}catch(e){}},1500);

/* ----- Haftalık görevler ----- */
const WPOOL=[{id:'work',t:'Çalış',k:'works',n:100,i:'⛏️'},{id:'sell',t:'Kaynak sat',k:'sells',n:30,i:'💰'},{id:'buy',t:'Kaynak satın al',k:'buys',n:20,i:'🛒'},{id:'hit',t:'Savaşta vur',k:'hits',n:25,i:'⚔️'},{id:'craft',t:'Eşya üret',k:'crafts',n:10,i:'🔧'},{id:'chat',t:'Sohbette mesaj yaz',k:'msgs',n:5,i:'💬'}];
const weekKey=()=>Math.floor((dayNum()+3)/7);
function wqState(){const m=S.me,k=weekKey();
  if(!m.wq||m.wq.wk!==k){const pool=WPOOL.slice(),pick=[];for(let i=0;i<3;i++){const x=pool.splice((k*5+i*2+i*i)%pool.length,1)[0];pick.push(x.id);}
    m.wq={wk:k,ids:pick,base:{works:m.works||0,sells:m.sells||0,buys:m.buys||0,hits:m.hits||0,crafts:m.crafts||0,msgs:m.msgs||0},done:{}};}
  return m.wq;}
const wqProg=q=>q.ids.map(id=>{const d=WPOOL.find(x=>x.id===id),cur=(S.me[d.k]||0)-(q.base[d.k]||0);return Object.assign({cur:Math.min(d.n,Math.max(0,cur)),done:!!q.done[id],ok:cur>=d.n},d);});
const wqReward=()=>({money:20000+S.me.level*3000,gold:5,xp:60+S.me.level*3});
ACT.wqClaim=d=>{const q=wqState(),p=wqProg(q).find(x=>x.id===d.id);if(!p||!p.ok||p.done)return;const r=wqReward(),m=S.me;q.done[p.id]=1;m.money+=r.money;m.stor.gold=Math.min(storCap(),m.stor.gold+r.gold);addXP(r.xp);
  msg(`✅ Haftalık görev: +${fmt(r.money)}₺, +${r.gold} altın`,'ok');
  if(q.ids.every(i=>q.done[i])){m.stor.gold=Math.min(storCap(),m.stor.gold+10);L('🏅 Haftanın tüm görevleri tamam: +10 altın bonus.','ok');}};
{const _qb=questBadge;questBadge=function(){let n=_qb();try{n+=wqProg(wqState()).filter(p=>p.ok&&!p.done).length;}catch(e){}return n;};}
{const _tq=tabQuest;tabQuest=function(){const q=wqState(),ps=wqProg(q),r=wqReward();
  let h=`<div class="panel"><h2>🗓️ Haftalık görevler</h2>`;
  ps.forEach(p=>{h+=`<div class="card"><h3>${p.i} ${p.t}: ${fmt(p.cur)}/${fmt(p.n)}</h3>${bar(p.cur,p.n,p.done?'#3fb950':undefined)}<p class="dim">Ödül: ${fmt(r.money)}₺ + ${r.gold} altın</p>${btn(p.done?'Alındı ✓':'Ödülü al',`data-a="wqClaim" data-id="${p.id}"`,'gold',!p.ok||p.done)}</div>`;});
  h+=`<p class="hint">Haftalık görevler pazartesi yenilenir. Üçünü de bitirirsen +10 altın bonus.</p></div>`;return _tq()+h;};}
/* ================= YARALANMA, ŞEHİR OLAYLARI, İSTATİSTİK ================= */
/* ----- Yaralanma: art arda vuruş yorar, hasarı düşürür; dinlenmek veya revir ile geçer ----- */
const WND_HIT=4,WND_MAX=100;
const woundMul=()=>1-Math.min(40,(S.me.wound||0)*0.4)/100;   // en çok −%40 hasar
const healCost=()=>Math.ceil(S.me.wound||0)*(500+S.me.level*50);
function woundTick(){const m=S.me;if(!m)return;const t=S.t;if(m.woundT==null)m.woundT=t;
  const dt=Math.max(0,t-m.woundT);m.woundT=t;if(!(m.wound>0))return;
  m.wound=Math.max(0,m.wound-dt/60000*(1+(homeReg().idx.m||0)*0.12));      // dakikada ~1 puan (tıp endeksiyle hızlanır)
  if(m.autoHeal&&m.wound>=60&&m.money>=healCost()*3)ACT.heal();}
{const _hd=hitDamage;hitDamage=function(item){return _hd(item)*woundMul();};}
{const _dh=doHit;doHit=function(wid,item){const r=_dh(wid,item);if(typeof r==='number'){const m=S.me;m.wound=Math.min(WND_MAX,(m.wound||0)+WND_HIT+(item?2:0));if(m.wound>=80&&!m._wnWarn){m._wnWarn=1;L('🩹 Ağır yorgunsun: hasarın %32 düştü. Revire git veya dinlen.','bad');}if(m.wound<50)m._wnWarn=0;}return r;};}
ACT.heal=()=>{const m=S.me,w=Math.ceil(m.wound||0);if(w<1)return msg('Yaralı değilsin.');const c=healCost();if(m.money<c)return msg('Revir ücreti '+fmt(c)+'₺.');m.money-=c;m.wound=0;msg('🩺 Tedavi edildin (−'+fmt(c)+'₺).','ok');};
ACT.autoHeal=()=>{S.me.autoHeal=!S.me.autoHeal;};
function woundCard(){const m=S.me,w=Math.round(m.wound||0),pen=Math.round((1-woundMul())*100);
  return `<div class="panel"><div class="card ${w>=60?'glow':''}"><h3>🩹 Yorgunluk / yara: ${w}/100</h3>${bar(w,100,w>=60?'#da3633':w>=30?'#d4a72c':'#3fb950')}<p class="dim">${pen?`Hasarın <b>−%${pen}</b>. `:'Hasar cezası yok. '}Her vuruş +${WND_HIT} yara ekler; dakikada ≈1 puan kendiliğinden geçer${(homeReg().idx.m||0)?` (tıp endeksi ${homeReg().idx.m} hızlandırır)`:''}.</p>
  <div class="btns">${btn(w?`🩺 Revir (${fmt(healCost())}₺)`:'Sağlıklısın','data-a="heal"','gold',!w)}${btn('Oto-revir: '+(m.autoHeal?'açık':'kapalı'),'data-a="autoHeal"','sm')}</div></div></div>`;}
{const _tw=tabWar;tabWar=function(){return woundCard()+_tw();};}

/* ----- Şehir olayları: karar isteyen rastgele olaylar ----- */
const EVS=[
 {id:'famine',i:'🌾',t:'Kıtlık haberi',d:'Bölgende kıtlık var. Halk senden yardım bekliyor.',o:[
   {l:'Petrol/maden dağıt (stoğun %5\'i)',f:m=>{const r=m.stor.ore>=20?'ore':'oil';const n=Math.floor(m.stor[r]*0.05);if(n<1)return 'Dağıtacak stok yok.';m.stor[r]-=n;addXP(40+m.level);m.karma=(m.karma||0)+1;return `${fmt(n)} ${RES_N[r]} dağıttın, itibarın arttı (+XP).`;}},
   {l:'Görmezden gel',f:()=>'Hiçbir şey yapmadın.'}]},
 {id:'merchant',i:'🧳',t:'Gezgin tüccar',d:'Bir tüccar 500 petrolü piyasanın %60\'ına satmak istiyor.',o:[
   {l:'Satın al',f:m=>{const c=Math.ceil(S.prices.oil*500*0.6);if(m.money<c)return 'Paran yetmedi ('+fmt(c)+'₺).';if(m.stor.oil+500>storCap())return 'Depon dolu.';m.money-=c;m.stor.oil+=500;return `500 petrol aldın (−${fmt(c)}₺).`;}},
   {l:'Reddet',f:()=>'Tüccar yoluna devam etti.'}]},
 {id:'strike',i:'✊',t:'İşçi grevi',d:'Fabrika işçileri zam istiyor.',o:[
   {l:()=>`Zam ver (${fmt(3000+S.me.level*400)}₺)`,f:m=>{const c=3000+m.level*400;if(m.money<c)return 'Paran yetmedi.';m.money-=c;addXP(30);return 'Anlaşıldı, işçiler memnun.';}},
   {l:'Diren (−20 enerji)',f:m=>{m.energy=Math.max(0,m.energy-20);return 'Grev yorucu geçti: −20 enerji.';}}]},
 {id:'treasure',i:'💰',t:'Gömülü hazine',d:'Arazide eski bir sandık bulundu.',o:[
   {l:'Aç',f:m=>{const g=1+Math.floor(Math.random()*3),mo=2000+m.level*500;m.stor.gold=Math.min(storCap(),m.stor.gold+g);m.money+=mo;return `+${fmt(mo)}₺ ve +${g} altın!`;}},
   {l:'Devlete teslim et',f:m=>{if(typeof A==='function'&&A().budget){A().budget.money+=5000+m.level*500;}addXP(60+m.level);return 'Hazine devlete bağışlandı (+XP).';}}]},
 {id:'quake',i:'🌋',t:'Deprem',d:'Küçük bir deprem oldu; depoda hasar var.',o:[
   {l:()=>`Onarım yaptır (${fmt(4000+S.me.level*600)}₺)`,f:m=>{const c=4000+m.level*600;if(m.money<c)return 'Paran yetmedi.';m.money-=c;return 'Hasar giderildi.';}},
   {l:'Kendi hâline bırak',f:m=>{const r=pk(['oil','ore']);const n=Math.floor(m.stor[r]*0.08);m.stor[r]-=n;return `${fmt(n)} ${RES_N[r]} kayboldu.`;}}]},
 {id:'spy',i:'🕵️',t:'Casus yakalandı',d:'Yabancı bir casus fabrikanı gözlerken yakalandı.',o:[
   {l:'Sorgula',f:m=>{const mo=3000+m.level*400;m.money+=mo;addXP(50);return `Bilgi karşılığı +${fmt(mo)}₺ ve XP.`;}},
   {l:'Serbest bırak',f:m=>{m.karma=(m.karma||0)+1;return 'Casus serbest bırakıldı.';}}]}];
function pk(a){return a[Math.floor(Math.random()*a.length)];}
const EV_GAP=75*60000,EV_TTL=3*3600000;
function evGen(){const m=S.me;if(!m||m.cev||S.t<S.protectUntil)return;if(!m.cevNext)m.cevNext=S.t+EV_GAP/3;if(S.t<m.cevNext)return;
  const e=EVS[Math.floor(Math.random()*EVS.length)];m.cev={k:e.id,end:S.t+EV_TTL};m.cevNext=S.t+EV_GAP+Math.random()*EV_GAP;L(`${e.i} Olay: ${e.t} — karar ver!`,'warn');S.dirty=true;}
ACT.cevPick=d=>{const m=S.me,c=m.cev;if(!c)return;const e=EVS.find(x=>x.id===c.k),o=e&&e.o[+d.i];if(!o)return;const r=o.f(m);m.cev=null;m.cevDone=(m.cevDone||0)+1;msg(r,/yetmedi|yok|dolu/.test(r)?'bad':'ok');L(`${e.i} ${e.t}: ${r}`,'ok');};
function cevHtml(){const m=S.me,c=m.cev;if(!c)return '';if(S.t>c.end){m.cev=null;return '';}const e=EVS.find(x=>x.id===c.k);if(!e)return '';
  return `<div class="al warn" style="display:block">${e.i} <b>${e.t}</b> — ${e.d} <span class="dim">(${cd(c.end)})</span><div class="btns" style="margin-top:6px">${e.o.map((o,i)=>btn(typeof o.l==='function'?o.l():o.l,`data-a="cevPick" data-i="${i}"`,i?'sm':'gold sm')).join('')}</div></div>`;}
{const _al=alerts;alerts=function(){_al();try{const h=cevHtml();if(h)$('alerts').insertAdjacentHTML('afterbegin',h);}catch(e){}};}
{const _nd=nfDraw;nfDraw=function(){_nd();try{const r=document.getElementById('modal-root'),h=cevHtml();if(NF.open&&h){const b=r.querySelector('.box');if(b)b.insertAdjacentHTML('beforeend','<h3 class="nolk">🎲 Karar bekleyen olay</h3>'+h);}}catch(e){}};}

/* ----- İstatistik ----- */
const HIST_GAP=10*60000,HIST_MAX=144;
function histTick(){const m=S.me;if(!m)return;m.hist=m.hist||[];const l=m.hist[m.hist.length-1];if(l&&S.t-l.t<HIST_GAP)return;
  m.hist.push({t:S.t,mo:Math.round(m.money),g:Math.round(m.stor.gold),lv:m.level,h:m.hits||0,w:m.works||0,c:m.made||0});if(m.hist.length>HIST_MAX)m.hist.shift();}
function spark2(vals,col){if(vals.length<2)return '<p class="dim">Grafik için birkaç ölçüm bekleniyor (10 dakikada bir).</p>';const mn=Math.min(...vals),mx=Math.max(...vals),r=(mx-mn)||1,W=300,H=60;
  const pts=vals.map((v,i)=>`${(i/(vals.length-1)*W).toFixed(1)},${(H-4-(v-mn)/r*(H-8)).toFixed(1)}`).join(' ');
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:64px;background:#0d1117;border-radius:6px"><polyline fill="none" stroke="${col}" stroke-width="2" points="${pts}"/></svg><div class="dim" style="display:flex;justify-content:space-between"><span>${fmt(mn)}</span><span>${fmt(mx)}</span></div>`;}
function tabStats(){const m=S.me,hs=m.hist||[],d=k=>hs.length>1?hs[hs.length-1][k]-hs[0][k]:0;
  const span=hs.length>1?fmtDur(hs[hs.length-1].t-hs[0].t):'—';
  let h=`<div class="panel"><h2>📊 İstatistikler</h2><div class="grid">
  ${card('Toplam',`<p>⛏️ Çalışma: <b>${fmt(m.works||0)}</b></p><p>⚔️ Vuruş: <b>${fmt(m.hits||0)}</b></p><p>💰 Satış: <b>${fmt(m.sells||0)}</b> · 🛒 Alış: <b>${fmt(m.buys||0)}</b></p><p>🔧 Üretilen eşya: <b>${fmt(m.made||0)}</b></p><p>🎲 Karara bağlanan olay: <b>${fmt(m.cevDone||0)}</b></p><p>💸 Ödenen vergi: <b>${fmt(m.taxPaid||0)}₺</b></p>`)}
  ${card('Şimdi',`<p>💰 Para: <b>${fmt(m.money)}₺</b></p><p>🥇 Altın: <b>${fmt(m.stor.gold)}</b></p><p>⭐ Seviye: <b>${m.level}</b></p><p>🩹 Yara: <b>${Math.round(m.wound||0)}/100</b></p>`)}</div></div>
  <div class="panel"><h2>📈 Son ${span}</h2>
  ${card('💰 Para',spark2(hs.map(x=>x.mo),'#d4a72c')+`<p class="dim">Değişim: ${d('mo')>=0?'+':''}${fmt(d('mo'))}₺</p>`)}
  ${card('🥇 Altın',spark2(hs.map(x=>x.g),'#f0c040'))}
  ${card('⚔️ Vuruş (toplam)',spark2(hs.map(x=>x.h),'#da3633')+`<p class="dim">Bu dönemde: +${fmt(d('h'))} vuruş</p>`)}
  ${card('⛏️ Çalışma (toplam)',spark2(hs.map(x=>x.w),'#3fb950')+`<p class="dim">Bu dönemde: +${fmt(d('w'))} iş</p>`)}</div>`;
  return h;}
TABX.stats=tabStats;
{const g=GROUPS.find(x=>x[0]==='prof');if(g&&!g[2].some(t=>t[0]==='stats'))g[2].splice(1,0,['stats','📊 İstatistik']);}
{const _q=questTick;questTick=function(){_q.apply(this,arguments);try{woundTick();evGen();histTick();}catch(e){}};}
/* ================= SADELEŞTİRME + PROFİL FOTOĞRAFI ================= */
const FOLD={};
(function(){const st=document.createElement('style');st.textContent=`
#subnavBar{position:sticky;top:0;z-index:25;background:var(--bg0);padding:4px 0 2px;margin:0 0 4px}
#subnavBar .subnav{display:flex;gap:4px;margin:0;order:0;overflow-x:auto}
#subnavBar .subnav button{flex:1 0 auto;min-width:64px;white-space:nowrap}
details.fold{margin:8px 0}
details.fold>summary{font-size:15px;color:var(--gold);font-weight:700;cursor:pointer;padding:10px 12px;background:var(--bg2);border:1px solid var(--line);border-radius:8px;list-style:none;display:flex;justify-content:space-between;align-items:center}
details.fold>summary::after{content:'▾';color:var(--tx3)}details.fold[open]>summary::after{content:'▴'}
details.fold>summary::-webkit-details-marker{display:none}
details.fold>div{padding-top:6px}
.al.more{cursor:pointer;text-align:center;color:var(--tx2);font-size:12px}
.qh{display:grid;grid-template-columns:1fr 1fr;gap:8px}.qh .qb{background:var(--bg2);border:1px solid var(--line);border-radius:10px;padding:10px;text-align:left;color:var(--tx);cursor:pointer}
.qh .qb b{display:block;font-size:15px}.qh .qb span{font-size:12px;color:var(--tx2)}.qh .qb.hot{border-color:var(--gold)}
#hAv img{width:22px;height:22px;border-radius:50%;object-fit:cover;vertical-align:middle;border:1px solid var(--gold)}
`;document.head.appendChild(st);
if(!document.getElementById('avFile')){const i=document.createElement('input');i.type='file';i.id='avFile';i.accept='image/*';i.style.display='none';document.body.appendChild(i);}
if(!document.getElementById('subnavBar')){const b=document.createElement('div');b.id='subnavBar';const mn=document.getElementById('main');mn.parentNode.insertBefore(b,mn);}
const stt=document.querySelector('header .stats');if(stt&&!document.getElementById('hAv')){const s=document.createElement('span');s.id='hAv';s.style.display='none';s.setAttribute('data-a','tab');s.setAttribute('data-t','char');stt.insertBefore(s,stt.firstChild);}})();

/* alt menü tek sıra: alt sekmeler üste (yapışkan şerit) */
function moveSub(){const sn=document.querySelector('#nav .subnav'),bar=document.getElementById('subnavBar');if(!bar)return;bar.innerHTML='';if(sn)bar.appendChild(sn);bar.style.display=sn?'':'none';
  try{document.documentElement.style.setProperty('--navh',$('nav').offsetHeight+'px');}catch(e){}
  const on=bar.querySelector('.on');if(on&&on.scrollIntoView&&bar.scrollWidth>bar.clientWidth)try{on.scrollIntoView({block:'nearest',inline:'center'});}catch(e){}}
{const _rn=renderNav;renderNav=function(){_rn.apply(this,arguments);try{moveSub();}catch(e){}};}

/* uzun sayfalar: başlıklı bölümler açılır-kapanır */
function foldPanels(){const main=$('main');if(!main||!['home','craft','store','quest','state'].includes(UI.tab))return;
  const ps=[...main.children].filter(e=>e.classList&&e.classList.contains('panel')&&e.firstElementChild&&e.firstElementChild.tagName==='H2');if(ps.length<3&&UI.tab!=='home')return;
  ps.forEach((p,i)=>{const h2=p.firstElementChild,title=h2.textContent.trim(),key=UI.tab+'|'+title;
    const d=document.createElement('details');d.className='fold';d.open=(key in FOLD)?FOLD[key]:(i===0&&UI.tab!=='home');
    const s=document.createElement('summary');s.textContent=title;d.appendChild(s);h2.remove();const body=document.createElement('div');while(p.firstChild)body.appendChild(p.firstChild);d.appendChild(body);p.appendChild(d);
    d.addEventListener('toggle',()=>{FOLD[key]=d.open;});});}
{const _ar=afterRender;afterRender=function(){const r=_ar.apply(this,arguments);try{foldPanels();avHead();}catch(e){}return r;};}

/* uyarılar: en çok 2 satır, gerisi "+N daha" */
{const _al=alerts;alerts=function(){_al.apply(this,arguments);try{const box=$('alerts'),k=[...box.children];if(k.length>2){if(!UI.alAll){k.slice(2).forEach(e=>e.style.display='none');box.insertAdjacentHTML('beforeend',`<div class="al more" data-a="alToggle">▾ ${k.length-2} uyarı daha</div>`);}else box.insertAdjacentHTML('beforeend','<div class="al more" data-a="alToggle">▴ Gizle</div>');}}catch(e){}};}
ACT.alToggle=()=>{UI.alAll=!UI.alAll;};

/* ana sayfa: kısa özet + hızlı eylemler (eski içerik açılır bölümlerde) */
function myTitle(){const m=S.me;if(!m.title||typeof BADGES==='undefined')return '';const b=BADGES.find(x=>x.id===m.title);return b&&b.f(m)?`${b.i} ${b.n}`:'';}
function avHtml(sz){const m=S.me;const base=`width:${sz}px;height:${sz}px;border-radius:50%;border:2px solid var(--gold);flex:none;`;
  return m.avatar?`<img src="${m.avatar}" alt="" style="${base}object-fit:cover">`:`<div style="${base}background:var(--red);display:flex;align-items:center;justify-content:center;font-size:${Math.round(sz*.45)}px;color:#fff;font-family:Georgia,serif">${esc((m.name||'?').slice(0,1).toUpperCase())}</div>`;}
function avHead(){const e=document.getElementById('hAv');if(!e)return;const m=S.me;if(m&&m.avatar){e.innerHTML=`<img src="${m.avatar}" alt="">`;e.style.display='';}else e.style.display='none';}
function quickHome(){const m=S.me,r=myReg(),ec=energyCost(),si=streakInfo(),qb=(typeof questBadge==='function')?questBadge():0,
  ws=S.wars.filter(w=>w.state!=='done'&&(w.att==='A'||w.def==='A')),on=ws.find(w=>w.state==='on'),tt=myTitle();
  const q=(ic,t,sub,attrs,hot)=>`<div class="qb ${hot?'hot':''}" ${attrs}><b>${ic} ${t}</b><span>${sub}</span></div>`;
  return `<div class="panel"><div class="card glow" style="display:flex;gap:12px;align-items:center" data-a="tab" data-t="char">${avHtml(54)}<div style="flex:1;min-width:0"><div style="font-size:17px;color:var(--tx0);font-weight:600">${esc(m.name)}${tt?` <span class="dim" style="font-size:12px">${tt}</span>`:''}</div><div class="dim">${rankName()} · ${esc(r.n)} · Gün ${Math.floor((S.t-S.startT)/DAY)+1}</div><div style="margin-top:4px">⭐ Sv <b data-live="level"></b>${bar(m.xp,xpNeed(m.level))}</div></div></div>
  <div class="qh" style="margin-top:8px">
   ${si.can?q('🎁','Günlük ödül','Görevlerde almaya hazır!','data-a="tab" data-t="quest"',1):q('📋','Görevler',qb?qb+' ödül bekliyor':'günlük & haftalık','data-a="tab" data-t="quest"',qb)}
   ${q('⛏️','Çalış',m.energy>=ec?'enerji yeterli':'enerji az','data-a="tab" data-t="work"')}
   ${q('🔧','Üretim',(m.craftQ||[]).length+' iş sırada','data-a="tab" data-t="craft"')}
   ${on?q('💥','Vur: '+esc(S.regions[on.region].n),'aktif savaş — dokun','data-a="hit" data-w="'+on.id+'"',1):q('⚔️','Savaş',ws.length?ws.length+' savaş':'savaş yok','data-a="tab" data-t="war"')}
   ${q('📚','Öğrenme',m.learn?'sürüyor · '+cd(m.learn.end):'boşta — başlat!','data-a="tab" data-t="char"',!m.learn)}
   ${q('🏦','Depo',fmt(m.money)+'₺','data-a="tab" data-t="store"')}
  </div></div>`;}
{const _th=tabHome;tabHome=function(){return quickHome()+_th().replace(/<div class="panel"><h2>🏠 Ana Sayfa<\/h2>/,'<div class="panel"><h2>🏠 Tüm ayrıntılar</h2>');};}

/* profil fotoğrafı + unvan */
{const _tc=tabChar;tabChar=function(){let h=_tc.apply(this,arguments);const m=S.me;
  h=h.replace(/<div style="width:58px;height:58px;border-radius:50%[^>]*>[^<]*<\/div>/,`<div style="display:flex;flex-direction:column;align-items:center;gap:4px">${avHtml(58)}<div style="display:flex;gap:4px"><button class="act sm" data-a="avPick" title="Fotoğraf seç">📷</button>${m.avatar?'<button class="act sm" data-a="avDel" title="Fotoğrafı kaldır">✕</button>':''}</div></div>`);
  try{const got=(typeof BADGES!=='undefined')?BADGES.filter(b=>b.f(m)):[];const idx=h.indexOf('<div class="card glow"'),j=idx>=0?h.indexOf('<div class="card">',idx):-1;
    if(j>0&&got.length)h=h.slice(0,j)+`<div class="card" style="padding:8px 12px"><label>🏷️ Unvanım</label><select id="ttSel" onchange="S.me.title=this.value;S.dirty=true;save();render()"><option value="">— yok —</option>${got.map(b=>`<option value="${b.id}" ${m.title===b.id?'selected':''}>${b.i} ${b.n}</option>`).join('')}</select></div>`+h.slice(j);}catch(e){}
  return h;};}
ACT.avPick=()=>{S.dirty=false;const f=document.getElementById('avFile');if(f)f.click();};
ACT.avDel=()=>{S.me.avatar=null;msg('Fotoğraf kaldırıldı.','ok');};
document.addEventListener('change',e=>{if(!e.target||e.target.id!=='avFile')return;const f=e.target.files&&e.target.files[0];if(!f)return;if(!/^image\//.test(f.type)){msg('Bir resim dosyası seç.');return;}
  const img=new Image(),url=URL.createObjectURL(f);img.onload=()=>{const c=document.createElement('canvas');c.width=c.height=160;const x=c.getContext('2d'),s=Math.min(img.width,img.height);x.drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,160,160);
    S.me.avatar=c.toDataURL('image/jpeg',0.75);URL.revokeObjectURL(url);S.dirty=true;save();render();msg('📷 Profil fotoğrafı güncellendi.','ok');};img.onerror=()=>msg('Resim açılamadı.');img.src=url;e.target.value='';});

/* bildirim: titreşim seçeneği */
{let last=0;const _nb=nfBadge;nfBadge=function(){_nb.apply(this,arguments);try{const n=nfUnread()+nfWars().length;if(S.me.vib&&n>last&&navigator.vibrate)navigator.vibrate(180);last=n;}catch(e){}};}
ACT.nfVib=()=>{S.me.vib=!S.me.vib;if(S.me.vib&&navigator.vibrate)navigator.vibrate(120);nfDraw();S.dirty=false;};
{const _nd2=nfDraw;nfDraw=function(){_nd2();try{if(NF.open){const b=document.querySelector('#modal-root .box');if(b)b.insertAdjacentHTML('beforeend',`<div class="btns" style="margin-top:8px">${btn('📳 Titreşim: '+(S.me.vib?'açık':'kapalı'),'data-a="nfVib"','sm')}</div>`);}}catch(e){}};}
/* ================= YOLDAYKEN GERİ DÖNÜŞ + OTOMATİK ENERJİ YENİLEME ================= */
ACT.travelBack=()=>{const m=S.me,t=m.travel;if(!t)return msg('Yolda değilsin.');if(t.back)return msg('Zaten geri dönüyorsun.');
  const el=Math.max(0,S.t-t.start);
  if(el<30000){m.travel=null;msg('Yolculuk iptal edildi.','ok');L('↩ Yolculuktan vazgeçtin.','info');return;}
  m.travel={to:m.loc,start:S.t,arrive:S.t+el,back:1};
  msg(`↩ Geri dönüyorsun (${fmtDur(el)}).`,'ok');L(`↩ ${S.regions[t.to].n} yolundan geri döndün (${fmtDur(el)}).`,'info');};
/* otomatik enerji: enerji eşiğin altına düşünce (yoldayken de) altınla içecek içer */
const AEN_THR=30;
function autoEnTick(){const m=S.me;if(!m||!m.autoEn||m.admin&&m.inf)return;if(m.energy>=AEN_THR)return;
  if(m.stor.gold<(+m.autoEnKeep||0)+2)return;
  if(drinkEnergy()===true){m.autoEnN=(m.autoEnN||0)+1;L(`⚡ Otomatik enerji: içecek içildi (enerji ${Math.floor(m.energy)}).`,'info');S.dirty=true;}}
ACT.autoEn=()=>{S.me.autoEn=!S.me.autoEn;msg('Otomatik enerji '+(S.me.autoEn?'açıldı: enerji '+AEN_THR+'’un altına inince altınla içecek içilir.':'kapatıldı.'),'ok');};
{const _q=questTick;questTick=function(){_q.apply(this,arguments);try{autoEnTick();}catch(e){}};}
{const _tc=tabChar;tabChar=function(){let h=_tc.apply(this,arguments);const m=S.me;
  h=h.replace('Enerji içeceği (2 altın) +50</button>',`Enerji içeceği (2 altın) +50</button> ${btn('🔁 Oto enerji: '+(m.autoEn?'açık':'kapalı'),'data-a="autoEn"',m.autoEn?'gold sm':'sm')}`);return h;};}
/* ================= AI DANIŞMAN (kendi API anahtarınla; anahtar sadece bu telefonda) ================= */
const AI={msgs:[],busy:false,draft:'',cfg:(()=>{try{return Object.assign({prov:'gemini',model:'gemini-3.8-flash',key:''},JSON.parse(localStorage.getItem('rr-ai')||'{}'));}catch(e){return {prov:'gemini',model:'gemini-3.8-flash',key:''};}})()};
function aiSaveCfg(){try{localStorage.setItem('rr-ai',JSON.stringify(AI.cfg));}catch(e){}}
function aiSummary(){
  const m=S.me,r=S.regions[m.loc]||{};
  const q=(m.craftQ||[]).length;
  const items=Object.entries(m.items||{}).filter(x=>x[1]>0).map(x=>x[0]+':'+x[1]).join(', ')||'yok';
  const pr=RES.map(k=>k+'='+Math.round(S.prices[k])).join(', ');
  const stor=RES.map(k=>k+':'+Math.floor((m.stor||{})[k]||0)).join(', ');
  return `Oyuncu: ${m.name}, seviye ${m.level}, güç ${m.str}, eğitim ${m.edu}, dayanıklılık ${m.end}.
Enerji: ${Math.round(m.energy)}/100. Para: ${Math.round(m.money)}. Konum: ${r.name||m.loc}${m.travel?' (yolda)':''}.
Depo: ${stor}. Eşyalar: ${items}. Üretim kuyruğu: ${q} iş.
Pazar fiyatları: ${pr}.
Parti: ${m.party||'yok'}. Savaş sayısı: ${(S.wars||[]).length}. Korunma bitti mi: ${S.protectUntil<=S.t?'evet':'hayır'}.`;
}
function aiSys(){return 'Sen Bilâd-ı Mütenâfise adlı tarayıcı strateji oyununda oyuncuya yardım eden kısa ve net bir danışmansın. Türkçe yaz, en fazla 6 madde ver, uydurma kural söyleme; emin olmadığın oyun kuralını "emin değilim" diye belirt. Oyuncunun güncel durumu:\n'+aiSummary();}
async function aiAsk(text){
  const c=AI.cfg;if(!c.key)return 'Önce API anahtarı gir.';
  const hist=AI.msgs.filter(x=>!x.err).slice(-8).map(x=>({role:x.role,content:x.content}));
  hist.push({role:'user',content:text});
  while(hist.length&&hist[0].role!=='user')hist.shift();
  let r;
  if(c.prov==='gemini'){
    r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(c.model)+':generateContent',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':c.key},body:JSON.stringify({systemInstruction:{parts:[{text:aiSys()}]},contents:hist.map(h=>({role:h.role==='user'?'user':'model',parts:[{text:h.content}]})),generationConfig:{temperature:.5,maxOutputTokens:1024}})});
    if(!r.ok)throw new Error(aiErr(r.status));
    const j=await r.json();return (((j.candidates||[])[0]||{}).content||{parts:[]}).parts.map(p=>p.text||'').join('')||'(boş cevap)';
  }
  r=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+c.key},body:JSON.stringify({model:c.model,messages:[{role:'system',content:aiSys()}].concat(hist),max_tokens:1024,temperature:.5})});
  if(!r.ok)throw new Error(aiErr(r.status));
  const j=await r.json();return j.choices[0].message.content||'(boş cevap)';
}
const aiErr=s=>s===400||s===401||s===403?'API anahtarı veya model geçersiz ('+s+').':s===429?'Kota/hız sınırı (429), biraz bekle.':s===404?'Model bulunamadı (404), modeli değiştir.':'Sunucu hatası ('+s+').';
function aiMd(t){return esc(t).replace(/\*\*([^*\n]+)\*\*/g,'<b>$1</b>').replace(/^\s*[-*]\s+/gm,'• ').replace(/\n/g,'<br>');}
function tabAI(){
  const c=AI.cfg,sug=['Şu an en kârlı hamle ne?','Enerjimi nasıl verimli kullanırım?','Üretim kuyruğu için öneri ver','Bugün ne yapmalıyım?'];
  return `<div class="panel"><h2>🧠 Danışman</h2>
  <div class="dim" style="font-size:12px;margin-bottom:8px">Sadece öneri verir, oyunu değiştirmez. Oyun durumunun kısa bir özeti seçtiğin yapay zekâ servisine gönderilir. Anahtar yalnızca bu telefonda saklanır; kullanım ücreti kendi hesabına yazılır.</div>
  ${c.key?'':`<div class="al warn">Başlamak için aşağıdan API anahtarını gir.</div>`}
  <details ${c.key?'':'open'}><summary>⚙️ Anahtar / model</summary>
   <select id="aiProv" data-chg="aiprov"><option value="gemini" ${c.prov==='gemini'?'selected':''}>Google Gemini</option><option value="openai" ${c.prov==='openai'?'selected':''}>OpenAI</option></select>
   <input id="aiModel" value="${esc(c.model)}" placeholder="model adı"><input id="aiKey" type="password" value="${esc(c.key)}" placeholder="API anahtarı" autocomplete="off">
   <button class="act sm" data-a="aiSave">Kaydet</button> <button class="act sm danger" data-a="aiWipe">Anahtarı sil</button></details>
  <div id="aiLog" style="margin:10px 0;display:flex;flex-direction:column;gap:8px">${AI.msgs.map(m=>`<div class="card" style="${m.role==='user'?'margin-left:20%;':'margin-right:6%;'}padding:8px">${m.role==='user'?esc(m.content):aiMd(m.content)}</div>`).join('')||'<div class="dim">Bir soru sor ya da aşağıdaki önerilerden birini seç.</div>'}${AI.busy?'<div class="dim">Düşünüyor…</div>':''}</div>
  <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px">${sug.map(s=>`<button class="act sm" data-a="aiSug" data-q="${esc(s)}">${esc(s)}</button>`).join('')}</div>
  <textarea id="aiIn" rows="2" style="width:100%" placeholder="Sorunu yaz…" oninput="AI.draft=this.value">${esc(AI.draft)}</textarea>
  <button class="act" data-a="aiSend" ${AI.busy?'disabled':''}>Gönder</button> <button class="act sm" data-a="aiClear">Sohbeti temizle</button></div>`;
}
async function aiSend(text){
  text=(text||'').trim();if(!text||AI.busy)return;
  if(!AI.cfg.key){AI.msgs.push({role:'assistant',content:'Önce API anahtarı gir.',err:1});render();return;}
  AI.msgs.push({role:'user',content:text});AI.draft='';AI.busy=true;render();
  try{AI.msgs.push({role:'assistant',content:await aiAsk(text)});}
  catch(e){AI.msgs.push({role:'assistant',content:'⚠️ '+e.message,err:1});}
  AI.busy=false;render();
}
ACT.aiSend=()=>{const t=document.getElementById('aiIn');aiSend(t?t.value:AI.draft);S.dirty=false;};
ACT.aiSug=d=>{aiSend(d.q);S.dirty=false;};
ACT.aiClear=()=>{AI.msgs=[];};
ACT.aiSave=()=>{AI.cfg.prov=document.getElementById('aiProv').value;AI.cfg.model=document.getElementById('aiModel').value.trim()||AI.cfg.model;AI.cfg.key=document.getElementById('aiKey').value.trim();aiSaveCfg();};
ACT.aiWipe=()=>{AI.cfg.key='';aiSaveCfg();AI.msgs=[];};
TABX.ai=tabAI;
(function(){const g=GROUPS.find(x=>x[0]==='prof');if(g&&!g[2].some(t=>t[0]==='ai'))g[2].splice(1,0,['ai','🧠 Danışman']);})();
/* ================= AKILLI OYUNCULAR: sunucuda seçili botları yapay zekâ yönetir ================= */
const SMT={on:false,n:10,p:{},t:0,err:''};
(function(){try{const d=JSON.parse(localStorage.getItem('rr-smart')||'{}');if(d.n)SMT.n=d.n;SMT.on=!!d.on;}catch(e){}})();
function smtSave(){try{localStorage.setItem('rr-smart',JSON.stringify({on:SMT.on,n:SMT.n}));}catch(e){}}
{const _pc=botSrvPushCfg;botSrvPushCfg=async function(on){await _pc(on);try{await MP.fb('PUT','botsrv/cfg/smart',{on:!!SMT.on,n:Math.max(0,Math.min(SMT.cap||5000,SMT.n|0))});}catch(e){}};}
{const _pl=botSrvPull;botSrvPull=async function(){await _pl();if(!MP.ok)return;try{const sm=await MP.fb('GET','botsrv/smart');
  if(sm&&sm.p){SMT.cap=+sm.cap||SMT.cap||5000;SMT.prov=+sm.prov||0;SMT.gr=sm.gr||{};SMT.p=sm.p;SMT.t=+sm.t||0;SMARTN={};Object.keys(sm.p).forEach(i=>{if(sm.p[i]&&sm.p[i].name)SMARTN[+i]=sm.p[i].name;});}}catch(e){}};}
function smtCard(){
  if(!S.botSrv)return `<div class="panel"><h2>🧠 Akıllı oyuncular</h2><p class="dim">Önce yapay zekâları sunucu moduna al; akıllı oyuncular GitHub sunucusunda çalışır.</p></div>`;
  const ids=Object.keys(SMT.p).map(Number).sort((a,b)=>a-b);
  const inp='style="width:70px;padding:7px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px"';
  return `<div class="panel"><h2>🧠 Akıllı oyuncular ${SMT.on?'<span class="ok">(açık)</span>':'<span class="dim">(kapalı)</span>'}</h2>
  <p class="hint">İlk N yapay zekâ oyuncu özel isim ve kişilik alır. Sunucu her 15 dakikada tek bir yapay zekâ isteğiyle hepsinin kararını alır: kaynak seçimi, şehir değiştirme, eğitim, sohbette konuşma, seçimde aday olma ve oy verme. Sunucuda <b>LLM_KEY</b> gizli anahtarı tanımlı olmalı (Rehber).</p>
  <div class="row"><label>Sayı (sınırsız) <input type="number" id="smtN" min="1" max="5000" value="${SMT.n}" ${inp}></label>${btn(SMT.on?'Kapat':'Aç',`data-a="smtSet" data-on="${SMT.on?0:1}"`,SMT.on?'danger':'gold')}${btn('Kaydet','data-a="smtSet"','sm')}</div>
  ${ids.length?`<div style="overflow-x:auto;margin-top:8px"><table><tr><th align=left>Oyuncu</th><th align=left>Üretim</th><th align=left>Notu</th></tr>${ids.map(i=>{const p=SMT.p[i];return `<tr><td><b>${esc(p.name)}</b><div class="dim" style="font-size:11px;max-width:200px">${esc(p.persona||'')}</div></td><td>${esc({gold:'Altın',oil:'Petrol',ore:'Maden'}[p.pref]||'')}</td><td class="dim">${esc(p.mem||'—')}</td></tr>`;}).join('')}</table></div><p class="hint">Son karar: ${SMT.t?fmtT(SMT.t):'—'}</p>`:'<p class="dim">Sunucunun ilk turundan sonra burada görünür.</p>'}</div>`;
}
{const _tb=tabBots;tabBots=function(){return smtCard()+_tb();};}
ACT.smtSet=async d=>{
  const n=Math.max(1,Math.min(SMT.cap||5000,+((document.getElementById('smtN')||{}).value)||SMT.n));SMT.n=n;
  if(d&&d.on!==undefined)SMT.on=d.on==='1';
  smtSave();
  try{await botSrvPushCfg(true);msg(SMT.on?'🧠 Akıllı oyuncular açık; sonraki sunucu turunda başlar.':'Ayar kaydedildi.','ok');}catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
/* ================= BİLÂD v2: görünüm katmanı, hedef rehberi, ilk giriş turu, yeni başarımlar ================= */

/* ---- 1) Yeni başarımlar (mevcut sisteme eklenir; otomatik açılır, altın verir) ---- */
ACHS.push(
 {id:'l75',t:'Destan',d:'Seviye 75',f:m=>m.level>=75,g:15},{id:'l100',t:'Ölümsüz',d:'Seviye 100',f:m=>m.level>=100,g:25},
 {id:'w5k',t:'Alın Teri',d:'5000 kez çalış',f:m=>(m.works||0)>=5000,g:20},
 {id:'b50',t:'Alıcı',d:'50 kaynak satın al',f:m=>(m.buys||0)>=50,g:2},{id:'s500',t:'Büyük Tüccar',d:'500 satış yap',f:m=>(m.sells||0)>=500,g:8},
 {id:'c1',t:'Zanaatkâr',d:'İlk eşyayı üret',f:m=>(m.crafts||0)>=1,g:1},{id:'c50',t:'Atölye Ustası',d:'50 eşya üret',f:m=>(m.crafts||0)>=50,g:5},{id:'c500',t:'Sanayi Devi',d:'500 eşya üret',f:m=>(m.crafts||0)>=500,g:15},
 {id:'h1k',t:'Cephe Gazisi',d:'1000 vuruş',f:m=>(m.hits||0)>=1000,g:12},
 {id:'f3',t:'Fabrikatör',d:'3 fabrikaya sahip ol',f:m=>m.facs.length>=3,g:6},
 {id:'m100',t:'Servet',d:'100.000.000₺ biriktir',f:m=>m.money>=1e8,g:20},
 {id:'ms10',t:'Sohbet Ehli',d:'10 mesaj yaz',f:m=>(m.msgs||0)>=10,g:1},{id:'ms200',t:'Meclis Hatibi',d:'200 mesaj yaz',f:m=>(m.msgs||0)>=200,g:5},
 {id:'st7',t:'Sadık Oyuncu',d:'7 gün üst üste gir',f:m=>((m.streak||{}).n||0)>=7,g:5},
 {id:'pp',t:'Gazeteci',d:'Bir gazete kur',f:m=>!!m.paper,g:3}
);

/* ---- 2) Sıradaki hedefler (ana sayfa kartı) ---- */
function nextGoals(){
  const m=S.me,g=[];
  try{
    if(typeof streakInfo==='function'&&streakInfo().can)g.push(['🎁','Günlük giriş ödülünü al','Ücretsiz para, altın ve enerji.',btn('Al','data-a="dailyClaim"','gold sm')]);
    if(typeof qState==='function'&&qProg(qState()).some(p=>p.ok&&!p.done))g.push(['✅','Tamamlanan görevin ödülünü al','Görevler sekmesinde seni bekleyen ödül var.',btn('Git','data-a="tab" data-t="quest"','sm')]);
    if(typeof wqState==='function'&&typeof wqProg==='function'&&wqProg(wqState()).some(p=>p.ok&&!p.done))g.push(['📅','Haftalık görev ödülün hazır','Büyük ödül: Görevler sekmesinde.',btn('Git','data-a="tab" data-t="quest"','sm')]);
    if(typeof nfWars==='function'&&nfWars().length)g.push(['⚔️','Devletin savaşta','Savaş sekmesinden vurup devletine katkı yap.',btn('Savaşa git','data-a="tab" data-t="war"','danger sm')]);
    if(!m.learn)g.push(['📚','Bir yetenek öğrenmeye başla','Öğrenme boşta; güç, eğitim ve dayanıklılık kalıcı artar.',btn('Karakter','data-a="tab" data-t="char"','sm')]);
    if(m.energy>=energyCost()*4&&!m.travel)g.push(['⛏️','Enerjin dolu, çalış','Kaynak üret; satınca para kazan.',btn('Çalış','data-a="tab" data-t="work"','sm')]);
    const cap=storCap(),full=RES.find(k=>(m.stor[k]||0)>=cap*0.8);
    if(full)g.push(['📦','Deponun '+({gold:'altın',oil:'petrol',ore:'maden',uranium:'uranyum',diamonds:'elmas'}[full])+' kısmı dolmak üzere','Satarak yer aç ya da fiyatı bekle.',btn('Depo','data-a="tab" data-t="store"','sm')]);
    if(m.level>=3&&!(m.craftQ||[]).length)g.push(['🔧','Üretim kuyruğun boş','Eşya üret; pazarda satılır, savaşta işe yarar.',btn('Üretim','data-a="tab" data-t="craft"','sm')]);
    if(!m.party&&m.level>=5)g.push(['🗳️','Bir partiye katıl','Seçimlerde ve kanunlarda sözün olsun.',btn('Parti','data-a="tab" data-t="party"','sm')]);
    if(!m.paper&&m.level>=15)g.push(['📰','Kendi gazeteni kur','Başarım kazan, takipçi topla.',btn('Gazete','data-a="tab" data-t="paper"','sm')]);
  }catch(e){}
  if(!g.length)g.push(['📈','Pazarı izle','Fiyatlar düşünce al, yükselince sat.',btn('Depo / Pazar','data-a="tab" data-t="store"','sm')]);
  return g.slice(0,3);
}
