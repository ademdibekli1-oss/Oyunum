/* ===== Telefon bildirimi (Web Push): oyun kapalıyken de haber ver ===== */
const PUSH_PUB='BMKTHCk4J3iByTrluUR6vkOIId0lzpgLDihaPn2JPJ8_tSdjqQBPKZz0KM0v2XztFSHlcwSGBkrbIrudf_6A75g';
const PUSH={sub:null,checked:0,busy:0,err:''};
const pushOk=()=>!!(window.Notification&&'serviceWorker' in navigator&&window.PushManager);
const pushB64=s=>{const p='='.repeat((4-s.length%4)%4),b=(s+p).replace(/-/g,'+').replace(/_/g,'/'),r=atob(b),o=new Uint8Array(r.length);for(let i=0;i<r.length;i++)o[i]=r.charCodeAt(i);return o;};
async function pushCheck(){
  if(!pushOk()||Date.now()-PUSH.checked<5000)return;PUSH.checked=Date.now();
  try{const reg=await navigator.serviceWorker.getRegistration();const s=reg?await reg.pushManager.getSubscription():null;const was=!!PUSH.sub;PUSH.sub=s;if(was!==!!s){S.dirty=true;try{render();}catch(e){}}}catch(e){}
}
ACT.pushOn=async()=>{
  if(!pushOk())return msg('Bu tarayıcı kapalıyken bildirimi desteklemiyor.');
  if(!(MP.ok&&MP.uid()))return msg('Önce hesabına giriş yap (Profil › Hesap).');
  PUSH.busy=1;PUSH.err='';S.dirty=true;
  try{
    const perm=Notification.permission==='granted'?'granted':await Notification.requestPermission();
    if(perm!=='granted'){PUSH.err='Bildirim izni verilmedi.';return;}
    const reg=await navigator.serviceWorker.ready;
    let sub=await reg.pushManager.getSubscription();
    if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:pushB64(PUSH_PUB)});
    await MP.fb('PUT','push/'+MP.uid(),{s:JSON.stringify(sub),t:Date.now()});
    PUSH.sub=sub;msg('📲 Kapalıyken de bildirim açıldı.','ok');
  }catch(e){PUSH.err=String(e&&e.message||e).slice(0,100);}
  finally{PUSH.busy=0;S.dirty=true;}
};
ACT.pushOff=async()=>{
  try{const reg=await navigator.serviceWorker.getRegistration();const s=reg?await reg.pushManager.getSubscription():null;if(s)await s.unsubscribe();
    if(MP.ok&&MP.uid())await MP.fb('DELETE','push/'+MP.uid());PUSH.sub=null;msg('Bildirim kapatıldı.','ok');}catch(e){PUSH.err=String(e&&e.message||e).slice(0,100);}
  S.dirty=true;
};
function pushCard(){
  const on=!!PUSH.sub;
  return `<div class="panel"><h2>📲 Kapalıyken bildirim</h2><div class="card"><p>Durum: <b>${!pushOk()?'bu tarayıcıda desteklenmiyor':on?'açık':'kapalı'}</b></p>
  <p class="dim">Oyun kapalıyken bile: Vekil onayını bekleyen emirler ve devletinin savaşı için telefonuna bildirim gelir. Gece 00:00–08:00 arası bildirim gönderilmez; en fazla 3 saatte bir.</p>
  ${pushOk()?(on?btn('Kapat','data-a="pushOff"','sm'):btn(PUSH.busy?'Açılıyor…':'Kapalıyken de bildir','data-a="pushOn"','gold',!!PUSH.busy)):''}
  ${PUSH.err?'<p class="bad">'+esc(PUSH.err)+'</p>':''}</div></div>`;
}
{const _s=tabSettings;tabSettings=function(){try{pushCheck();}catch(e){}return _s.apply(this,arguments)+pushCard();};}
/* ===== Yönetici: Ekonomi ve denge raporu (sunucu hazırlar; karar sende) ===== */
const ECO={d:null,last:0,busy:0,err:''};
async function ecoLoad(force){
  if(!MP.ok||ECO.busy||(!force&&Date.now()-ECO.last<60000))return;
  if(!(typeof gdAllowed==='function'&&gdAllowed()))return;
  ECO.busy=1;ECO.last=Date.now();
  try{ECO.d=await MP.fb('GET','guard/eco');ECO.err='';}catch(e){ECO.err=rulesHint(e);}
  ECO.busy=0;S.dirty=true;try{render();}catch(e){}
}
ACT.ecoReload=()=>{ecoLoad(true);S.dirty=false;};
function ecoCard(){
  const d=ECO.d;
  let h=`<div class="panel"><h2>📈 Ekonomi ve denge</h2>`;
  if(!d)return h+`<div class="card"><p class="dim">${ECO.err?esc(ECO.err):'Rapor henüz yok (sunucu her çalışmada hazırlar).'}</p>${btn('Yenile','data-a="ecoReload"','sm')}</div></div>`;
  const fo=d.fiyatOrani||{};
  h+=`<div class="card"><p class="dim" style="margin:0 0 6px">${fmtDur(Date.now()-d.t)} önce hazırlandı</p>
  <p style="margin:2px 0">👥 ${d.oyuncu} gerçek oyuncu · 🤖 ${fmt(d.bot)} bot · 🧠 ${d.vekil||0} Vekil</p>
  <p style="margin:2px 0">💰 Toplam para: <b>${fmt(d.toplamPara)}₺</b> · ortanca: ${fmt(d.ortanca)}₺ · bot ortalaması: ${fmt(d.botOrtPara)}₺</p>
  <p style="margin:2px 0">🏆 En zengin 1 oyuncu: %${d.ilk1} · ilk 5: %${d.ilk5} · ort. seviye ${d.ortSeviye}</p>
  <p style="margin:2px 0">📊 Fiyat / taban: altın x${fo.gold} · petrol x${fo.oil} · maden x${fo.ore}</p></div>`;
  h+=(d.uyari&&d.uyari.length)?d.uyari.map(w=>`<div class="card" style="border-color:#d4a72c"><p style="margin:0">⚠️ ${esc(w)}</p></div>`).join(''):'<p class="dim">Belirgin bir dengesizlik görünmüyor. ✅</p>';
  if(d.oneri)h+=`<div class="card"><b>🧠 Yapay zekâ önerisi</b><p style="margin:4px 0 0">${esc(d.oneri)}</p><p class="dim" style="margin:4px 0 0">Yalnızca öneridir; hiçbir şey otomatik değişmez.</p></div>`;
  return h+`<div class="btns">${btn('🔄 Yenile','data-a="ecoReload"','sm')}</div></div>`;
}
{const _g=TABX.guard;if(typeof _g==='function'){TABX.guard=function(){try{ecoLoad(false);}catch(e){}return _g.apply(this,arguments)+ecoCard();};}}
/* ===== DÜZEN: her özelliğin tek bir evi var =====
   7 sekme: Ana Sayfa · Harita · Ekonomi · Devlet · Savaş · Topluluk · Profil
   Kural: bir özellik yalnızca bir sekmede yaşar; başka yerlerden sadece kısayol verilir.
   Gizli ('hid') kayıtlar menüde görünmez ama bağlantı ve bildirimler için çalışır. */
(function(){
  const G=GROUPS;G.length=0;
  G.push(['home','🏠 Ana Sayfa',[['home','Ana Sayfa'],['quest','Görevler'],['log','Günlük']]]);
  G.push(['map','🗺️ Harita',[['world','Harita'],['map','Şehirler']]]);
  G.push(['store','⛏️ Ekonomi',[['work','Çalış'],['auto','Otomatik'],['store','Depo'],['mkt','Pazar'],['craft','Üretim'],['bank','Banka'],['give','Bağış'],['ctl','Kontrol','hid']]]);
  G.push(['gov','🏛️ Devlet',[['state','Devlet'],['party','Parti'],['elect','Seçim'],['leader','Başkan','ldr'],['cities','Vali','ldr'],['stats','İstatistik']]]);
  G.push(['war','⚔️ Savaş',[['war','Savaş'],['sw','Ortak'],['spy','Casus'],['dip','Diplomasi']]]);
  G.push(['paper','👥 Topluluk',[['art','Makaleler'],['paper','Gazete'],['chat','Sohbet'],['ally','İttifak'],['lb','Sıralama']]]);
  G.push(['prof','👤 Profil',[['char','Profil'],['msg','Mesajlarım'],['help','Yardımcılar'],['set','Ayarlar'],['guide','Rehber'],['net','Hesap'],['yon','👑 Yönetim','adm'],['adm','Panel','adm'],['bots','Yapay Zekâ','adm'],['guard','Güvenlik','adm'],['ops','Yönetim Merkezi','adm'],['ai','Danışman','hid'],['vekil','Vekil','hid']]]);
})();
RR_IC.gov='<svg viewBox="0 0 24 24"><path d="M12 2 3 7v2h18V7zM5 11v7M9.500 11v7M14.500 11v7M19 11v7M3 21h18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
RR_IC.store=RR_IC.work;
const ORD_ADMT=['adm','bots','guard','ops'];
rrTabOk=function(t){
  if(t[2]==='hid')return true;
  if(t[2]==='ldr')return (typeof isLeader==='function'&&isLeader())||isAdminUI();
  if(t[0]==='yon')return isAdminUI()||(typeof opsTabOk==='function'&&(opsTabOk('guard')||opsTabOk('ops')));
  return t[2]!=='adm'||isAdminUI()||(typeof opsTabOk==='function'&&opsTabOk(t[0]));
};
rrVis=function(g){return g[2].filter(t=>t[2]!=='hid'&&rrTabOk(t));};
{const _b=ACT.rrBack;ACT.rrBack=function(){
  if(ORD_ADMT.includes(UI.tab)&&!rrCityOpen()){UI.tab='yon';UI.rrMenu=false;return;}
  return _b.apply(this,arguments);};}
{const _t=ACT.tab;ACT.tab=function(d){if(d&&(d.t==='ai'||d.t==='vekil')){UI.helpSub=d.t;}return _t.apply(this,arguments);};}

/* ---- Ana Sayfa kısayolları ---- */
rrTiles=function(){
  const hint=k=>(typeof ACC_HINT!=='undefined'&&ACC_HINT[k])||'';
  const T=[['quest','🎯','Görevler','ödüller ve hedefler'],['log','📜','Günlük','son olanlar'],['help','🤖','Yardımcılarım','Vekil ve Danışman'],['msg','✉️','Mesajlarım','özel mesaj, parti sohbeti']];
  return `<div class="panel"><h2>Kısayollar</h2><div class="rr-tiles">${T.map(t=>`<button class="rr-tile" data-a="tab" data-t="${t[0]}"><span>${t[1]}</span><b>${t[2]}</b><small>${t[3]||hint(t[0])}</small></button>`).join('')}</div>
   <p class="hint" style="margin:8px 2px 0">Bir şeyi nerede bulacağını bilmiyor musun? Üstteki 🔍 düğmesine bas ve ne aradığını yaz.</p></div>`;
};
/* ---- Profil satırları ---- */
rrProfRows=function(){
  const R=[['msg','✉️','Mesajlarım','özel mesajlar ve parti sohbeti'],['help','🤖','Yardımcılarım','Vekil ve Danışman'],['set','⚙️','Ayarlar','ses, tema, bildirimler'],['guide','📖','Rehber','oyunu öğren'],['net','🌐','Hesap','bağlantı ve hesap']];
  if(rrTabOk(['yon','','adm']))R.push(['yon','👑','Yönetim','yönetici araçları']);
  return `<div class="panel"><div class="rr-tiles one">${R.map(t=>`<button class="rr-tile" data-a="tab" data-t="${t[0]}"><span>${t[1]}</span><b>${t[2]}</b><small>${t[3]}</small></button>`).join('')}</div></div>`;
};

/* ---- Yönetim kapısı ---- */
TABX.yon=function(){
  const R=[['adm','👑','Yönetici paneli','oyuncular, duyuru, sezon'],['bots','🤖','Yapay zekâ','botlar ve sunucu']];
  const T=R.filter(r=>isAdminUI()).concat([['guard','🛡️','Güvenlik','korumalar ve raporlar'],['ops','🏛️','Yönetim Merkezi','ekip, acil durum, ayarlar, kayıt']].filter(r=>typeof opsTabOk==='function'&&opsTabOk(r[0])));
  return `<div class="panel"><h2>👑 Yönetim</h2><p class="hint">Yalnızca yetkililere görünür.</p><div class="rr-tiles one">${T.map(t=>`<button class="rr-tile" data-a="tab" data-t="${t[0]}"><span>${t[1]}</span><b>${t[2]}</b><small>${t[3]}</small></button>`).join('')}</div></div>`;
};

/* ---- Mesajlarım (özel + parti) ve Topluluk › Sohbet (genel) ---- */
const _chatFull=tabChat;
tabChat=function(){
  CHAT.ch='g';
  let h=_chatFull.apply(this,arguments);
  h=h.replace(/<button[^>]*data-c="p"[^>]*>[^<]*<\/button>/,'').replace(/<button[^>]*data-c="d"[^>]*>[^<]*<\/button>/,'');
  return h.replace('💬 Sohbet','🌍 Genel sohbet');
};
TABX.msg=function(){
  if(CHAT.ch==='g'){CHAT.ch='d';CHAT.msgs=[];CHAT.last=0;CHAT.sig='';}
  let h=_chatFull.apply(this,arguments);
  h=h.replace(/<button[^>]*data-c="g"[^>]*>[^<]*<\/button>/,'');
  return h.replace('💬 Sohbet','✉️ Mesajlarım');
};
/* Parti sayfasından parti sohbetine kısayol */
{const _tp=tabParty;tabParty=function(){
  let h=_tp.apply(this,arguments);
  try{if(S.me.party)h+=`<div class="panel"><button class="act sm blue" data-a="ordPartyChat">💬 Parti sohbetini aç</button></div>`;}catch(e){}
  return h;};}
ACT.ordPartyChat=()=>{CHAT.ch='p';CHAT.msgs=[];CHAT.last=0;CHAT.sig='';UI.tab='msg';window.scrollTo(0,0);};

/* ---- Yardımcılar: Vekil ve Danışman tek sayfada ---- */
UI.helpSub=UI.helpSub||'vekil';
ACT.helpSub=d=>{UI.helpSub=d.s;};
TABX.help=function(){
  const s=UI.helpSub==='ai'?'ai':'vekil';
  const seg=`<div class="btns" style="margin:0 0 8px">${btn('🤖 Vekil','data-a="helpSub" data-s="vekil"',s==='vekil'?'gold':'')}${btn('🧠 Danışman','data-a="helpSub" data-s="ai"',s==='ai'?'gold':'')}</div>
   <p class="hint" style="margin:0 0 8px">${s==='vekil'?'<b>Vekil</b> sen yokken senin adına karar verir ve işlem yapar.':'<b>Danışman</b> sana öneri verir; karar ve işlem sende kalır.'}</p>`;
  const body=(s==='ai'?(TABX.ai?TABX.ai():'<p class="dim">Danışman yüklenemedi.</p>'):(TABX.vekil?TABX.vekil():'<p class="dim">Vekil yüklenemedi.</p>'));
  return '<div class="panel" style="padding-bottom:0">'+seg+'</div>'+body;
};

/* ---- Ekonomi › Otomatik: Kontrol paneli artık burada ---- */
{const _ta=tabAuto;tabAuto=function(){
  let h=_ta.apply(this,arguments);
  try{if(TABX.ctl)h+=TABX.ctl();}catch(e){}
  return h;};}

/* ---- Savaş › Diplomasi (tek ev) ---- */
TABX.dip=function(){
  if(typeof MP==='undefined'||!MP.ok)return '<div class="panel"><h2>🌐 Diplomasi</h2><div class="al warn">Diplomasi için Profil › Hesap bölümünden giriş yap.</div></div>';
  try{return '<div class="panel">'+dipCard()+'</div>';}catch(e){return '<div class="panel"><h2>🌐 Diplomasi</h2><p class="dim">Henüz yüklenmedi; birkaç saniye sonra tekrar dene.</p></div>';}
};

/* ---- Nerede ne var? (🔍) ---- */
const ORD_KW={home:'ana sayfa özet',quest:'görev ödül hedef',log:'günlük kayıt geçmiş olay',world:'harita dünya devlet',map:'şehir bölge liste yolculuk',work:'çalış kaynak maden petrol altın enerji',auto:'otomatik oto çalışma kontrol panel',store:'depo envanter eşya',mkt:'pazar ilan alım satım satış',craft:'üretim fabrika atölye eşya yap',bank:'banka kredi faiz para',give:'bağış hediye ver',state:'devlet vergi bütçe kanun',party:'parti üye',elect:'seçim oy aday başkanlık',leader:'başkan karar yönetim',cities:'vali şehir yönetim',stats:'istatistik rakam',war:'savaş vur saldırı vuruş',sw:'ortak savaş',spy:'casus istihbarat',dip:'diplomasi ittifak ambargo anlaşma',art:'makale yazı',paper:'gazete haber',chat:'genel sohbet konuşma',ally:'ittifak lonca',lb:'sıralama liderlik tablosu',char:'profil karakter yetenek eğitim güç',msg:'mesaj özel dm parti sohbeti engelle',help:'yardımcı vekil danışman yapay zekâ',set:'ayar ses tema bildirim',guide:'rehber nasıl yardım öğren',net:'hesap giriş şifre bağlan',yon:'yönetim yönetici panel'};
const ordN=s=>String(s||'').toLowerCase().replace(/ç/g,'c').replace(/ğ/g,'g').replace(/ı/g,'i').replace(/i̇/g,'i').replace(/ö/g,'o').replace(/ş/g,'s').replace(/ü/g,'u').replace(/â/g,'a').replace(/î/g,'i').replace(/û/g,'u');
function ordIndex(){
  const out=[];
  GROUPS.forEach(g=>rrVis(g).forEach(t=>out.push({t:t[0],n:String(t[1]).replace(/^\S+\s/,'').trim()||t[1],g:String(g[1]).replace(/^\S+\s/,'').trim(),kw:ORD_KW[t[0]]||''})));
  out.push({t:'help',sub:'vekil',n:'Vekil',g:'Profil › Yardımcılar',kw:'yapay zeka adıma karar sen yokken'},{t:'help',sub:'ai',n:'Danışman',g:'Profil › Yardımcılar',kw:'öneri tavsiye'});
  return out;
}
function ordFind(q){
  const n=ordN(q).trim();if(!n)return [];
  const res=ordIndex().filter(x=>ordN(x.n+' '+x.kw+' '+x.g).includes(n));
  const rg=S.regions.filter(r=>ordN(r.n).includes(n)).slice(0,6).map(r=>({city:r.id,n:r.n,g:'Harita › Şehir ('+nameOf(r.state)+')'}));
  return res.slice(0,10).concat(rg);
}
function ordRows(q){
  const R=ordFind(q);
  if(!String(q||'').trim())return '<p class="dim" style="margin:8px 2px">Örnek: bağış, vekil, mesaj, banka, seçim, Moskova…</p>';
  if(!R.length)return '<p class="dim" style="margin:8px 2px">Bulunamadı.</p>';
  return R.map(x=>x.city!==undefined?`<button class="rr-tile" style="margin:5px 0;width:100%" data-a="ordGo" data-city="${x.city}"><span>📍</span><b>${esc(x.n)}</b><small>${esc(x.g)}</small></button>`:`<button class="rr-tile" style="margin:5px 0;width:100%" data-a="ordGo" data-t="${x.t}" data-sub="${x.sub||''}"><span>➡️</span><b>${esc(x.n)}</b><small>${esc(x.g)}</small></button>`).join('');
}
ACT.rrSearch=()=>{
  const root=document.getElementById('modal-root');if(!root)return;
  root.dataset.ord=1;
  root.innerHTML=`<div class="modal" data-a="ordClose"><div class="box" data-a="entNop" style="max-height:86vh;overflow:auto"><h2 style="margin:0 0 8px">🔍 Nerede ne var?</h2>
   <input id="ordQ" type="text" placeholder="Ne arıyorsun?" autocomplete="off" style="width:100%;box-sizing:border-box;padding:10px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:6px">
   <div id="ordRes">${ordRows('')}</div><div class="btns" style="margin-top:10px">${btn('Kapat','data-a="ordClose"','sm')}</div></div></div>`;
  S.dirty=false;
  setTimeout(()=>{const i=document.getElementById('ordQ');if(i)i.focus();},50);
};
ACT.ordClose=()=>{const root=document.getElementById('modal-root');if(root&&root.dataset.ord){root.innerHTML='';delete root.dataset.ord;}S.dirty=false;};
ACT.ordGo=d=>{
  ACT.ordClose();
  if(d.city!==undefined&&d.city!==''){ACT.goCity({id:d.city});return;}
  if(d.sub)UI.helpSub=d.sub;
  UI.tab=d.t;UI.rrMenu=false;window.scrollTo(0,0);
};
document.addEventListener('input',e=>{if(e.target&&e.target.id==='ordQ'){const b=document.getElementById('ordRes');if(b)b.innerHTML=ordRows(e.target.value);}});

/* ---- Ana sayfadan taşınan paneller: her biri kendi evinde ---- */
const ordFold=(t,b)=>`<div class="panel"><details class="md-fold"><summary>${t}</summary><div class="fb">${b}</div></details></div>`;
function ordNewsBody(){
  const hist=(typeof histCard==='function')?histCard().replace(/<div class="card">|<\/div>$/g,''):'';
  const nw=(S.news||[]).slice(0,8);
  return hist+'<hr style="border:none;border-top:1px solid var(--line);margin:12px 0"><h3 style="margin-top:0">📰 Haberler</h3>'+(nw.length?nw.map(x=>`<p style="font-size:13px;margin:0 0 6px">${esc(x.m)} <span class="dim">· ${agoG(x.t)}</span></p>`).join(''):'<p class="dim">Henüz haber yok.</p>');
}
{const _w=tabWar;tabWar=function(){let h=_w.apply(this,arguments);try{if(typeof mdDmg==='function')h+=ordFold('⚔️ Hasar faktörleri',mdDmg());}catch(e){}return h;};}
{const _p=tabPaper;tabPaper=function(){let h=_p.apply(this,arguments);try{h+=ordFold('📜 Tarihte bugün &amp; haberler',ordNewsBody());}catch(e){}return h;};}
{const _c=tabChar;tabChar=function(){let h=_c.apply(this,arguments);try{const m=S.me;h+=ordFold('📊 İstatistik özeti',`<p style="font-size:13px">⛏️ Çalışma: <b>${fmt(m.works||0)}</b> · ⚔️ Vuruş: <b>${fmt(m.hits||0)}</b></p><p style="font-size:13px;margin-top:4px">💰 Satış: <b>${fmt(m.sells||0)}</b> · 🔧 Üretim: <b>${fmt(m.crafts||0)}</b> · 🎖️ Eğitim: <b>${fmt(m.trains||0)}</b></p>`);}catch(e){}return h;};}
{const _s=tabSettings;tabSettings=function(){let h=_s.apply(this,arguments);try{
  h+=ordFold('🎨 Görünüm',`<div class="md-row"><span class="dim">Tema</span><div class="md-sw"><button class="${PREF.theme==='dark'?'on':''}" data-a="prefSet" data-k="theme" data-v="dark">Koyu</button><button class="${PREF.theme==='light'?'on':''}" data-a="prefSet" data-k="theme" data-v="light">Açık</button></div></div><div class="md-row" style="margin-top:10px"><span class="dim">Yazı</span><div class="md-sw">${[['A',0],['A+',1],['A++',2]].map(x=>`<button class="${PREF.fs===x[1]?'on':''}" data-a="prefSet" data-k="fs" data-v="${x[1]}">${x[0]}</button>`).join('')}</div></div><div class="md-row" style="margin-top:10px"><span class="dim">Titreşim</span><div class="md-sw"><button class="${PREF.vib?'on':''}" data-a="prefSet" data-k="vib" data-v="1">Açık</button><button class="${!PREF.vib?'on':''}" data-a="prefSet" data-k="vib" data-v="0">Kapalı</button></div></div><div style="margin-top:12px"><button class="md-btn sm ghost" data-a="mdObOpen">🧭 Tanıtımı tekrar göster</button></div>`);}catch(e){}return h;};}
{const _m=tabMap;tabMap=function(){let h=_m.apply(this,arguments);try{
  if((UI.city===null||UI.city===undefined)&&typeof cityEvents==='function'){const ev=cityEvents();if(ev.length)h=h.replace(/<\/div>$/,'')+`<div class="card"><h3>🌍 Şehirlerde olaylar</h3>${ev.map(e=>`<p>${e.t.i} <a class="lk" data-a="goCity" data-id="${e.r}"><b>${esc(S.regions[e.r].n)}</b></a> — ${e.t.n}: ${e.t.d} · ${fmtDur(e.end-Date.now())}</p>`).join('')}</div></div>`;}
  }catch(e){}return h;};}
/* ================= ORTAK KATMAN: PARTİLER · HAZİNE · MAAŞLAR · SINIR İZNİ (Firebase) =================
   party/$pid   : oyuncu partisi (başkan, üyeler, giriş-çıkış günlüğü, kasa, üye maaşı)
   gov/$state   : başkanın atadığı bakanlar/görevli, maaşlar, sınır kapıları (kara/deniz/hava: açık-kapalı, ücret)
   tr/$state    : devlet hazinesi defteri (in: gelir, out: maaş talepleri)
   border/$s/req/$uid : giriş izni başvuruları (başkan ya da sınır görevlisi karar verir, ücret hazineye) */
const G3={party:{},gov:{},tr:{},bord:{},board:null,last:0,fast:0,busy:false,err:'',pend:{},view:null,mine:null,reqs:{},open:{}};
const G3_ROLES={pres:['👑','Devlet Başkanı'],econ:['💼','Ekonomi Bakanı'],foreign:['🌐','Dışişleri Bakanı'],border:['🛂','Sınır Görevlisi'],mp:['🏛️','Milletvekili']};
const G3_SAL0={pres:40000,econ:20000,foreign:20000,border:10000,mp:5000};
const G3_MODE={land:['🚆','Kara/demiryolu'],sea:['🚢','Deniz'],air:['✈️','Hava']};
const G3_FEE0={land:500,sea:1500,air:3000};
const g3uid=()=>{try{return MP.uid();}catch(e){return null;}};
const g3St=()=>{try{return homeReg().state;}catch(e){return 'A';}};
const g3Id=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const g3Day=()=>Math.floor(Date.now()/DAY);
const g3Err=e=>(typeof rulesHint==='function'?rulesHint(e):(e&&e.message)||String(e));
const g3Sum=o=>Object.keys(o||{}).reduce((x,k)=>x+(+(o[k]||{}).a||0),0);
const g3Bal=s=>{const t=G3.tr[s]||{};return Math.max(0,g3Sum(t.in)-g3Sum(t.out));};
const g3Gov=s=>G3.gov[s]||{};
const g3Sal=(s,r)=>{const v=(g3Gov(s).sal||{})[r];return v===undefined?G3_SAL0[r]:+v||0;};
const g3Fee=(s,m)=>{const v=(g3Gov(s).fee||{})[m];return v===undefined?G3_FEE0[m]:+v||0;};
const g3IsOpen=(s,m)=>((g3Gov(s).open||{})[m])!==false;
const g3Pres=s=>{const E=(typeof EL!=='undefined'&&EL.d&&EL.d[s])||{};return E.pres&&E.phase==='term'?E.pres:null;};
const g3IsPres=s=>{const p=g3Pres(s);return !!(p&&!p.bot&&p.id===g3uid());};
const g3Off=(s,r)=>(g3Gov(s).off||{})[r]||null;
const g3IsOff=(s,r)=>{const o=g3Off(s,r);return !!(o&&o.id===g3uid());};
const g3Human=s=>{const p=g3Pres(s);return !!(p&&!p.bot);};
const g3Approver=s=>g3IsPres(s)||g3IsOff(s,'border');

/* ---------- veri çekme ---------- */
async function g3Poll(force){
  if(!MP.ok||G3.busy)return;
  if(!force&&Date.now()-G3.last<45e3)return;
  G3.busy=true;G3.last=Date.now();
  try{
    G3.party=(await MP.fb('GET','party'))||{};G3.gov=(await MP.fb('GET','gov'))||{};
    const ss=new Set([g3St()]);if(G3.view)ss.add(G3.view);
    for(const s of ss){G3.tr[s]=(await MP.fb('GET','tr/'+s))||{};}
    G3.err='';
    g3ApplyIdent();
    g3Flush();g3AutoClaim();
    S.dirty=true;
  }catch(e){G3.err=g3Err(e);}
  G3.busy=false;
}
if(typeof MP!=='undefined'&&typeof MP.sync==='function'){const _s=MP.sync;MP.sync=async function(){const r=await _s.apply(this,arguments);try{g3Poll();}catch(e){}return r;};}
/* sınır başvuruları: hızlı yoklama (kararı bekleyen veya karar veren) */
async function g3Fast(){
  if(!MP.ok)return;const m=S.me,u=g3uid();let ch=false;
  try{
    const s=g3St();
    if(g3Approver(s)&&(UI.tab==='state'||Date.now()-G3.fast>60e3)){G3.reqs[s]=(await MP.fb('GET','border/'+s+'/req'))||{};ch=true;}
    const q=m.bq;
    if(q&&q.s&&u){
      const r=await MP.fb('GET','border/'+q.s+'/req/'+u);
      if(!r){if(q.st==='wait'&&Date.now()-q.t>5000){m.bq=null;ch=true;}}
      else if(r.st!==q.st){q.st=r.st;q.until=+r.until||0;ch=true;
        if(r.st==='ok')toast(`🛂 ${nameOf(q.s)} giriş izni verdi! Yolculuğa başlayabilirsin (Harita › Buraya git).`,'ok');
        else toast(`🛂 ${nameOf(q.s)} giriş izni vermedi.`,'bad');}
    }
  }catch(e){}
  G3.fast=Date.now();if(ch)S.dirty=true;
}
setInterval(()=>{try{if(MP.ok&&((S.me.bq&&S.me.bq.st==='wait')||(g3Approver(g3St())&&UI.tab==='state')))g3Fast();}catch(e){}},15000);
setInterval(()=>{try{if(MP.ok&&Date.now()-G3.fast>90e3)g3Fast();}catch(e){}},30000);

/* ---------- hazine ---------- */
async function g3In(s,a,why){
  a=Math.round(+a||0);if(a<=0||!MP.ok)return false;
  const k=g3Id();const row={u:g3uid(),n:S.me.name,a:a,w:why||'',t:Date.now()};
  try{await MP.fb('PUT','tr/'+s+'/in/'+k,row);G3.tr[s]=G3.tr[s]||{};G3.tr[s].in=G3.tr[s].in||{};G3.tr[s].in[k]=row;return true;}
  catch(e){G3.err=g3Err(e);return false;}
}
/* çalışma vergisi: bölge devletine giden vergi hazineye de yazılır (birikir, 1000₺'yi geçince gönderilir) */
function g3Flush(){
  Object.keys(G3.pend).forEach(s=>{const v=G3.pend[s];if(v>=1000){G3.pend[s]=0;g3In(s,v,'Çalışma vergisi');}});
}
if(typeof doWork==='function'){const _dw=doWork;doWork=function(res){
  const r=_dw.apply(this,arguments);
  try{if(r&&typeof r==='object'&&r.tax>0){const st=myReg().state;const v=r.tax*(S.prices[res]||1);G3.pend[st]=(G3.pend[st]||0)+v;}}catch(e){}
  return r;};}
async function g3Claim(s,role,pid){
  const u=g3uid(),amt=g3Sal(s,role);if(!MP.ok||!u||amt<=0)return false;
  if(g3Bal(s)<amt)return false;
  const key=u+'_'+role+'_'+g3Day();
  const m=S.me;m.g3pay=m.g3pay||{};if(m.g3pay[s+role]===g3Day())return false;
  const row={u:u,r:role,a:amt,t:Date.now()};if(role==='mp'&&pid)row.pid=pid;
  try{await MP.fb('PUT','tr/'+s+'/out/'+key,row);
    G3.tr[s]=G3.tr[s]||{};G3.tr[s].out=G3.tr[s].out||{};G3.tr[s].out[key]=row;
    m.g3pay[s+role]=g3Day();m.money+=amt;L(`💰 ${G3_ROLES[role][1]} maaşı: +${fmt(amt)}₺ (devlet hazinesi)`,'ok');S.dirty=true;return true;}
  catch(e){m.g3pay[s+role]=g3Day();return false;}
}
function g3MyRoles(s){
  const r=[];if(g3IsPres(s))r.push('pres');['econ','foreign','border'].forEach(k=>{if(g3IsOff(s,k))r.push(k);});
  return r;
}
function g3AutoClaim(){
  try{const s=g3St();g3MyRoles(s).forEach(r=>g3Claim(s,r));
    const sp=g3MySeat();if(sp)g3Claim(s,'mp',sp);}catch(e){}
}
ACT.g3Claim=d=>{g3Claim(g3St(),d.r,d.pid).then(ok=>{if(!ok)msg('Maaş alınamadı: bugün zaten aldın ya da hazine yetersiz.');S.dirty=true;});};
ACT.g3Donate=async d=>{
  const m=S.me,s=g3St(),v=+d.v;if(!MP.ok)return msg('Önce giriş yap (Profil › Hesap).');
  if(m.money<v)return msg('Yetersiz para.');m.money-=v;
  if(!(await g3In(s,v,'Bağış'))){m.money+=v;return msg('Bağış yapılamadı: '+(G3.err||'bağlantı'));}
  L(`🏛️ Devlet hazinesine ${fmt(v)}₺ bağışladın.`,'ok');S.dirty=true;
};

/* ---------- parti ---------- */
const g3PMine=()=>{const id=S.me.spid;return id&&G3.party[id]?Object.assign({id:id},G3.party[id]):null;};
const g3PMembers=p=>Object.keys(p.m||{}).map(u=>Object.assign({id:u},p.m[u])).sort((a,b)=>(+a.t||0)-(+b.t||0));
const g3PBal=p=>Math.max(0,g3Sum((p.fund||{}).in)-g3Sum((p.fund||{}).out));
async function g3PLog(pid,k,n){try{await MP.fb('PUT','party/'+pid+'/log/'+g3Id(),{t:Date.now(),u:g3uid(),n:n||S.me.name,k:k});}catch(e){}}
function g3LocalParty(pid,n,lead){
  const a=A();let p=a.parties.find(x=>x.id===(lead?'me':pid));
  if(!p){p={id:lead?'me':pid,n:n,supp:1,pref:{},members:1};a.parties.push(p);}else p.n=n;
  S.me.party=p.id;S.me.partyLead=!!lead;
}
if(typeof ACT.createParty==='function'){const _cp=ACT.createParty;ACT.createParty=function(d){
  const had=S.me.party,u=g3uid();_cp.apply(this,arguments);
  const m=S.me;
  if(!had&&m.party==='me'&&m.partyLead&&MP.ok&&u){
    const p=myParty(),pid='p_'+u.slice(0,6)+g3Id();m.spid=pid;
    const row={n:p?p.n:'Parti',o:u,on:m.name,s:g3St(),t:Date.now(),sal:0,m:{[u]:{n:m.name,t:Date.now()}}};
    MP.fb('PUT','party/'+pid,row).then(()=>{G3.party[pid]=row;g3PLog(pid,'found');S.dirty=true;}).catch(e=>{G3.err=g3Err(e);m.spid=null;msg('Parti ortak listeye yazılamadı: '+G3.err);});
  }};}
ACT.g3PJoin=async d=>{
  const m=S.me,p=G3.party[d.p];if(!MP.ok)return msg('Önce giriş yap.');
  if(m.party)return msg('Önce partinden ayrıl.');if(m.level<5)return msg('Seviye 5 gerekli.');if(!p)return msg('Parti bulunamadı.');
  try{await MP.fb('PUT','party/'+d.p+'/m/'+g3uid(),{n:m.name,t:Date.now()});
    p.m=p.m||{};p.m[g3uid()]={n:m.name,t:Date.now()};m.spid=d.p;g3LocalParty(d.p,p.n,false);g3PLog(d.p,'join');
    L(`🗳️ ${p.n} partisine katıldın.`,'ok');S.dirty=true;}catch(e){msg('Katılınamadı: '+g3Err(e));}
};
if(typeof ACT.joinParty==='function'){const _jp=ACT.joinParty;ACT.joinParty=function(d){
  if(G3.party[d.p])return ACT.g3PJoin(d);return _jp.apply(this,arguments);};}
{const _lp=ACT.leaveParty;ACT.leaveParty=async function(){
  const m=S.me,pid=m.spid,u=g3uid(),p=pid&&G3.party[pid];
  if(p&&MP.ok){
    try{
      const rest=g3PMembers(p).filter(x=>x.id!==u);
      if(p.o===u&&rest.length){await MP.fb('PATCH','party/'+pid,{o:rest[0].id,on:rest[0].n});g3PLog(pid,'lead',rest[0].n);}
      await MP.fb('DELETE','party/'+pid+'/m/'+u);g3PLog(pid,'leave');
      if(p.o===u&&!rest.length)await MP.fb('DELETE','party/'+pid);
    }catch(e){msg('Ortak listeden çıkış yazılamadı: '+g3Err(e));}
    const a=A();a.parties=a.parties.filter(x=>x.id!==pid&&x.id!=='me');m.party=null;m.partyLead=false;m.spid=null;L('Partiden ayrıldın.','info');S.dirty=true;return;}
  m.spid=null;return _lp.apply(this,arguments);};}
ACT.g3PKick=async d=>{
  const p=g3PMine();if(!p||p.o!==g3uid()||d.u===g3uid())return;
  try{await MP.fb('DELETE','party/'+p.id+'/m/'+d.u);delete (G3.party[p.id].m||{})[d.u];g3PLog(p.id,'kick',d.n);S.dirty=true;}catch(e){msg(g3Err(e));}
};
ACT.g3PSal=async()=>{
  const p=g3PMine();if(!p||p.o!==g3uid())return;const v=Math.max(0,Math.min(100000,Math.round(+(($('g3sal')||{}).value)||0)));
  try{await MP.fb('PUT','party/'+p.id+'/sal',v);G3.party[p.id].sal=v;msg('Üye maaşı günlük '+fmt(v)+'₺ olarak ayarlandı.','ok');S.dirty=true;}catch(e){msg(g3Err(e));}
};
ACT.g3PDonate=async d=>{
  const p=g3PMine(),m=S.me,v=+d.v;if(!p)return;if(m.money<v)return msg('Yetersiz para.');
  m.money-=v;const k=g3Id(),row={u:g3uid(),n:m.name,a:v,t:Date.now()};
  try{await MP.fb('PUT','party/'+p.id+'/fund/in/'+k,row);const f=G3.party[p.id].fund=G3.party[p.id].fund||{};f.in=f.in||{};f.in[k]=row;L(`🎗️ Parti kasasına ${fmt(v)}₺ bağışladın.`,'ok');S.dirty=true;}
  catch(e){m.money+=v;msg(g3Err(e));}
};
ACT.g3PPay=async()=>{
  const p=g3PMine(),m=S.me,u=g3uid();if(!p||!u)return;const amt=+p.sal||0;
  if(amt<=0)return msg('Bu parti maaş vermiyor.');if(g3PBal(p)<amt)return msg('Parti kasasında yeterli para yok.');
  const key=u+'_'+g3Day();if(((p.fund||{}).out||{})[key])return msg('Bugünkü maaşını zaten aldın.');
  const row={u:u,a:amt,t:Date.now()};
  try{await MP.fb('PUT','party/'+p.id+'/fund/out/'+key,row);const f=G3.party[p.id].fund=G3.party[p.id].fund||{};f.out=f.out||{};f.out[key]=row;m.money+=amt;L(`🎗️ Parti maaşı: +${fmt(amt)}₺`,'ok');S.dirty=true;}
  catch(e){msg(g3Err(e));}
};
const G3_LOGT={found:'partiyi kurdu',join:'partiye katıldı',leave:'partiden ayrıldı',kick:'partiden çıkarıldı',lead:'parti başkanı oldu'};
function g3PartyHtml(){
  const s=g3St(),u=g3uid();let h='';
  if(!MP.ok)return `<div class="panel"><h2>🎗️ Oyuncu partileri</h2><p class="hint">Ortak partiler için önce giriş yap (Profil › Hesap).</p></div>`;
  const mine=g3PMine();
  if(mine){
    const mem=g3PMembers(mine),lead=mine.o===u,bal=g3PBal(mine),log=Object.keys(mine.log||{}).map(k=>mine.log[k]).sort((a,b)=>b.t-a.t).slice(0,12);
    const paid=((mine.fund||{}).out||{})[u+'_'+g3Day()];
    h+=`<div class="panel"><h2>🎗️ ${esc(mine.n)}</h2><div class="grid">
     ${card('👑 Parti başkanı',`<p><b>${esc(mine.on||'—')}</b>${lead?' <span class="owner">sensin</span>':''}</p><p class="dim">${mem.length} üye · kuruluş ${new Date(+mine.t||Date.now()).toLocaleDateString('tr-TR')}</p>`)}
     ${card('💰 Parti kasası',`<div class="big">${fmt(bal)}₺</div><p class="dim">Üye maaşı: ${(+mine.sal||0)?fmt(+mine.sal)+'₺ / gün':'yok'}</p>
       <div class="btns">${[10000,100000].map(v=>btn('+'+fmt(v)+'₺ bağışla',`data-a="g3PDonate" data-v="${v}"`,'gold sm',S.me.money<v)).join('')}${(+mine.sal||0)>0?btn(paid?'✅ Maaş alındı':'💵 Maaşımı al','data-a="g3PPay"','blue sm',!!paid):''}</div>`)}
    </div>
    ${lead?`<div class="card"><h3>⚙️ Başkan ayarları</h3><div class="row"><input type="number" id="g3sal" min="0" max="100000" value="${+mine.sal||0}" placeholder="Günlük üye maaşı" style="flex:1;padding:8px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px">${btn('Maaşı kaydet','data-a="g3PSal"','gold sm')}</div><p class="hint">Maaş parti kasasından ödenir; kasaya sen ve üyeler bağış yapar. Kasada para yoksa maaş alınamaz.</p></div>`:''}
    <div class="card"><h3>👥 Üyeler (${mem.length})</h3>${mem.map(x=>`<div class="q">${x.id===mine.o?'👑':'👤'} <b>${esc(x.n)}</b> <small class="dim">${new Date(+x.t||0).toLocaleDateString('tr-TR')} tarihinden beri</small>${lead&&x.id!==u?' '+btn('Çıkar',`data-a="g3PKick" data-u="${esc(x.id)}" data-n="${esc(x.n)}"`,'danger sm'):''}${x.id===u?' <span class="owner">sen</span>':''}</div>`).join('')}</div>
    <div class="card"><h3>📜 Giriş · çıkış günlüğü</h3>${log.length?log.map(l=>`<p class="dim" style="margin:3px 0">${new Date(+l.t).toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})} · <b>${esc(l.n||'?')}</b> ${G3_LOGT[l.k]||l.k}</p>`).join(''):'<p class="dim">Kayıt yok.</p>'}</div></div>`;
  }
  const all=Object.keys(G3.party).map(id=>Object.assign({id:id},G3.party[id])).filter(p=>!mine||p.id!==mine.id);
  h+=`<div class="panel"><h2>🚩 Oyuncu partileri</h2>${all.length?'<div class="grid">'+all.map(p=>card(esc(p.n),`<p>👑 ${esc(p.on||'—')} · 👥 ${g3PMembers(p).length} üye</p><p class="dim">${esc(nameOf(p.s))}${(+p.sal||0)?' · maaş '+fmt(+p.sal)+'₺/gün':''}</p><div class="btns">${!S.me.party?btn('Katıl',`data-a="g3PJoin" data-p="${p.id}"`,'sm',S.me.level<5):''}</div>`)).join('')+'</div>':'<p class="dim">Henüz başka oyuncu partisi yok. Parti kurmak için seviye 10 ve 20.000₺ gerekir.</p>'}${G3.err?`<p class="bad">${esc(G3.err)}</p>`:''}<div class="btns">${btn('🔄 Yenile','data-a="g3Refresh"','sm')}</div></div>`;
  return h;
}
ACT.g3Refresh=()=>{g3Poll(true);g3Fast();};
{const _tp=tabParty;tabParty=function(){setTimeout(()=>{if(UI.tab==='party')g3Poll();},0);return _tp.apply(this,arguments)+g3PartyHtml();};}

/* ---------- meclis: isimli üyeler (gerçek oyuncular + yapay zekâ) ---------- */
function g3MySeat(){
  try{const m=S.me;if(!m.party||!m.spid&&m.party!=='me')return null;
    const r=g3Roster();const me=r.find(x=>x.id===g3uid());return me?(m.spid||''):null;}catch(e){return null;}
}
function g3Roster(){
  const a=A(),seats=seatsOf(),out=[],u=g3uid();
  if(!a.parlSize)return out;
  let bi=0;
  a.parties.slice().sort((x,y)=>y.supp-x.supp).forEach((p,pi)=>{
    const n=seats[p.id]||0;if(!n)return;
    const sp=(p.id==='me'?S.me.spid:p.id),sh=sp&&G3.party[sp];
    const real=sh?g3PMembers(sh):[];
    let c=0;
    real.slice(0,n).forEach(x=>{out.push({n:x.n,id:x.id,p:p.id,pn:p.n,real:1});c++;});
    for(;c<n;c++){bi++;out.push({n:botName(60+pi*130+bi),id:null,p:p.id,pn:p.n,real:0});}
  });
  return out;
}

/* ---------- sınır izni ---------- */
const g3TreatyOpen=s=>{try{const t=A().treaty;return (t.mig[s]>S.t)||(t.mil[s]>S.t);}catch(e){return false;}};
function g3Need(to){
  const m=S.me,r=S.regions[+to];if(!r||r.moon)return null;
  if(m.admin)return null;
  const s=r.state,home=g3St(),here=S.regions[m.loc]?S.regions[m.loc].state:home;
  if(s===home||s===here)return null;
  if(g3TreatyOpen(s))return null;
  const v=(m.visa||{})[s];if(v&&v.until>Date.now())return null;
  return s;
}
function g3Modes(to){
  const m=S.me,r=S.regions[+to],o=S.regions[m.loc],s=r.state,out=[];
  const landOK=hopsTo(m.loc,+to)<99;
  out.push({k:'land',ok:landOK,why:landOK?'':'Kara/demiryolu bağlantısı yok'});
  const seaOK=!!(o&&o.coast&&r.coast);
  out.push({k:'sea',ok:seaOK,why:seaOK?'':'İki uçta da kıyı bölgesi gerekir'});
  const airOK=hasB(s,'airport');
  out.push({k:'air',ok:airOK,why:airOK?'':nameOf(s)+'’de havalimanı yok'});
  return out.map(x=>Object.assign(x,{open:g3IsOpen(s,x.k),fee:g3Fee(s,x.k)}));
}
function g3Cost(to,mode){
  const m=S.me,h=Math.min(8,Math.max(1,hopsTo(m.loc,+to)));
  if(mode==='air')return {c:1500+300*h,t:Math.max(10,h*2)*MIN};
  if(mode==='sea')return {c:Math.round(500*h*1.2)+300,t:h*6*MIN};
  return {c:500*h,t:h*5*MIN};
}
const g3Auto=s=>{ // insan başkanı olmayan devlet: ilişkiye göre otomatik karar
  const rel=relTo('A',s);return {ok:rel>-40,rel:rel,mul:1+Math.max(0,-rel)/50};
};
if(typeof ACT.travel==='function'){const _tr=ACT.travel;ACT.travel=function(d){
  const s=g3Need(d.to);
  if(s&&!d.__ok){G3.mine={to:+d.to,s:s};g3Modal();return;}
  return _tr.apply(this,arguments);};}
function g3Modal(){
  const root=document.getElementById('modal-root');if(!root)return;
  const q=G3.mine;if(!q){root.innerHTML='';return;}
  const m=S.me,r=S.regions[q.to],s=q.s,bq=m.bq&&m.bq.s===s&&m.bq.to===q.to?m.bq:null,human=g3Human(s),auto=g3Auto(s);
  const modes=g3Modes(q.to);
  const head=`<h2>🛂 ${esc(nameOf(s))} sınırı</h2><p class="dim">${esc(r.n)} bölgesine girmek için ${esc(nameOf(s))} devletinin izni gerekir. ${human?`Başvuruyu devlet başkanı <b>${esc(g3Pres(s).n)}</b> ya da görevlendirdiği sınır görevlisi değerlendirir.`:'Bu devleti şu an gerçek bir başkan yönetmiyor; başvuru ilişkilere göre hemen sonuçlanır.'} Giriş ücreti ancak izin verilirse ödenir ve devlet hazinesine gider. İzin 24 saat geçerlidir.</p>`;
  let body='';
  if(bq&&bq.st==='ok'&&bq.until>Date.now()){
    const mo=bq.mode,cs=g3Cost(q.to,mo),fee=+bq.fee||0;
    body=`<div class="card glow"><h3>✅ İzin verildi (${G3_MODE[mo][1]})</h3><p>Giriş ücreti: <b>${fmt(fee)}₺</b> · yol: ${fmt(cs.c)}₺ · ${fmtDur(cs.t)}</p><p class="dim">İzin bitişine ${fmtDur(bq.until-Date.now())}.</p><div class="btns">${btn(`🧳 Yolculuğa başla (${fmt(fee+cs.c)}₺)`,'data-a="g3Go"','gold',m.money<fee+cs.c||!!m.travel)}</div></div>`;
  }else if(bq&&bq.st==='wait'){
    body=`<div class="card"><h3>⏳ Başvuru bekliyor (${G3_MODE[bq.mode][1]})</h3><p class="dim">Karar verilince bildirim gelir. Cevaplanmazsa 30 dk sonra iptal edebilirsin. Başvuru ${cd(bq.t+30*MIN)}</p><div class="btns">${btn('Başvuruyu geri çek','data-a="g3Cancel"','danger sm')}</div></div>`;
  }else{
    if(bq&&bq.st==='no')body+=`<div class="al bad">Önceki başvurun reddedildi. Yeniden başvurabilirsin.</div>`;
    body+=modes.map(x=>{const dis=!x.ok||!x.open||!!m.travel,cs=g3Cost(q.to,x.k),fee=human?x.fee:Math.round(x.fee*auto.mul);
      return `<div class="card"><h3>${G3_MODE[x.k][0]} ${G3_MODE[x.k][1]}</h3><p>Giriş ücreti <b>${fmt(fee)}₺</b> · yol ${fmt(cs.c)}₺ · ${fmtDur(cs.t)}</p>${!x.ok?`<p class="dim">${esc(x.why)}</p>`:!x.open?'<p class="bad">⛔ Bu sınır kapısı kapalı.</p>':''}<div class="btns">${btn(human?'📨 İzin iste':'📨 Başvur',`data-a="g3Req" data-m="${x.k}"`,'blue sm',dis)}</div></div>`;}).join('');
    if(!human)body+=`<p class="hint">İlişki ${Math.round(auto.rel)}: ${auto.ok?'başvurun kabul edilir.':'çok kötü; başvurun reddedilir. İlişkiyi düzeltmek için Savaş › Diplomasi.'}</p>`;
  }
  root.innerHTML=`<div class="modal" data-a="g3Close"><div class="box" data-a="entNop">${head}${body}<div class="btns" style="margin-top:8px">${btn('Kapat','data-a="g3Close"','sm')}</div></div></div>`;
}
ACT.g3Close=()=>{G3.mine=null;const r=document.getElementById('modal-root');if(r)r.innerHTML='';S.dirty=false;};
ACT.g3Req=async d=>{
  const m=S.me,q=G3.mine;if(!q)return;const s=q.s,human=g3Human(s),mode=d.m,x=g3Modes(q.to).find(y=>y.k===mode);
  if(!x||!x.ok||!x.open)return msg('Bu kapı kullanılamaz.');
  if(!human){
    const au=g3Auto(s);
    if(!au.ok){m.bq={s:s,to:q.to,mode:mode,st:'no',t:Date.now()};toast(`🛂 ${nameOf(s)} giriş izni vermedi (ilişkiler kötü).`,'bad');g3Modal();return;}
    m.bq={s:s,to:q.to,mode:mode,st:'ok',fee:Math.round(x.fee*au.mul),t:Date.now(),until:Date.now()+DAY};g3Modal();return;
  }
  if(!MP.ok)return msg('Önce giriş yap (Profil › Hesap).');
  const row={n:m.name,u:g3uid(),from:g3St(),to:q.to,toN:S.regions[q.to].n,mode:mode,fee:x.fee,t:Date.now(),st:'wait'};
  try{await MP.fb('PUT','border/'+s+'/req/'+g3uid(),row);m.bq={s:s,to:q.to,mode:mode,st:'wait',fee:x.fee,t:row.t};
    toast('🛂 Giriş izni başvurusu gönderildi.','ok');g3Modal();}
  catch(e){msg('Başvuru gönderilemedi: '+g3Err(e));}
};
ACT.g3Cancel=async()=>{
  const m=S.me,q=m.bq;if(!q)return;
  if(q.st==='wait'&&Date.now()-q.t<30*MIN&&false)return;
  try{if(MP.ok&&q.st==='wait')await MP.fb('DELETE','border/'+q.s+'/req/'+g3uid());}catch(e){}
  m.bq=null;g3Modal();
};
ACT.g3Go=async()=>{
  const m=S.me,q=m.bq;if(!q||q.st!=='ok'||q.until<Date.now())return msg('İzin geçersiz.');
  if(m.travel)return msg('Zaten yoldasın.');
  const cs=g3Cost(q.to,q.mode),fee=+q.fee||0;if(m.money<fee+cs.c)return msg('Yetersiz para.');
  m.money-=fee+cs.c;
  if(fee>0)g3In(q.s,fee,'Sınır giriş ücreti').then(ok=>{if(!ok)G3.pend[q.s]=(G3.pend[q.s]||0)+fee;});
  m.visa=m.visa||{};m.visa[q.s]={until:q.until,mode:q.mode};
  m.travel={to:q.to,start:S.t,arrive:S.t+cs.t};
  L(`🛂 ${nameOf(q.s)} sınırından ${G3_MODE[q.mode][1].toLowerCase()} ile geçiyorsun (${fmtDur(cs.t)}).`,'info');
  try{if(MP.ok)MP.fb('DELETE','border/'+q.s+'/req/'+g3uid());}catch(e){}
  m.bq=null;G3.mine=null;const r=document.getElementById('modal-root');if(r)r.innerHTML='';S.dirty=true;
};
ACT.g3Dec=async d=>{
  const s=g3St();if(!g3Approver(s))return;
  const ok=d.ok==='1',row=(G3.reqs[s]||{})[d.u];if(!row)return;
  try{await MP.fb('PATCH','border/'+s+'/req/'+d.u,{st:ok?'ok':'no',by:S.me.name,d:Date.now(),until:Date.now()+DAY});
    row.st=ok?'ok':'no';toast(ok?'✅ Giriş izni verildi.':'⛔ Başvuru reddedildi.',ok?'ok':'bad');S.dirty=true;}
  catch(e){msg(g3Err(e));}
};
ACT.g3Gate=async d=>{
  const s=g3St();if(!g3IsPres(s))return;const cur=g3IsOpen(s,d.m);
  try{await MP.fb('PUT','gov/'+s+'/open/'+d.m,!cur);G3.gov[s]=G3.gov[s]||{};G3.gov[s].open=G3.gov[s].open||{};G3.gov[s].open[d.m]=!cur;S.dirty=true;}catch(e){msg(g3Err(e));}
};
ACT.g3Setv=async d=>{ // ücret ya da maaş kaydet
  const s=g3St();if(!g3IsPres(s))return;const el=$(d.id),v=Math.max(0,Math.min(1000000,Math.round(+(el&&el.value)||0)));
  try{await MP.fb('PUT','gov/'+s+'/'+d.k+'/'+d.f,v);const g=G3.gov[s]=G3.gov[s]||{};g[d.k]=g[d.k]||{};g[d.k][d.f]=v;msg('Kaydedildi.','ok');S.dirty=true;}catch(e){msg(g3Err(e));}
};
ACT.g3Find=async()=>{
  if(!G3.board){try{G3.board=(await MP.fb('GET','board'))||{};}catch(e){return msg(g3Err(e));}}
  const q=String((($('g3q')||{}).value)||'').trim().toLocaleLowerCase('tr');G3.found=Object.keys(G3.board).map(k=>({id:k,n:G3.board[k].name||'?'})).filter(x=>!q||x.n.toLocaleLowerCase('tr').includes(q)).slice(0,8);
  S.dirty=true;
};
ACT.g3Appoint=async d=>{
  const s=g3St();if(!g3IsPres(s))return;
  try{if(d.u){await MP.fb('PUT','gov/'+s+'/off/'+d.r,{id:d.u,n:d.n,t:Date.now()});}else await MP.fb('DELETE','gov/'+s+'/off/'+d.r);
    const g=G3.gov[s]=G3.gov[s]||{};g.off=g.off||{};if(d.u)g.off[d.r]={id:d.u,n:d.n};else delete g.off[d.r];S.dirty=true;}catch(e){msg(g3Err(e));}
};
/* modal canlı tazele */
{const _ar=afterRender;afterRender=function(){_ar.apply(this,arguments);try{if(G3.mine&&document.querySelector('#modal-root .box'))g3Modal();}catch(e){}};}

/* ---------- devlet adı ve rengi (gov/$s/ident, başkan ya da sahip yazar) ---------- */
function g3ApplyIdent(){let ch=0;for(const s in G3.gov){const id=(G3.gov[s]||{}).ident;if(!id||!S.states[s])continue;
  if(typeof id.n==='string'&&id.n.length>=2&&S.states[s].n!==id.n){S.states[s].n=id.n;if(typeof STATE_N!=='undefined')STATE_N[s]=id.n;ch=1;}
  if(/^#[0-9a-f]{6}$/i.test(id.c||'')&&SCOL[s]!==id.c){SCOL[s]=id.c;ch=1;}}
  if(ch&&typeof GEO!=='undefined'){GEO.inflK='';GEO.brdK='';if(typeof wmDraw==='function'&&WM.cv)try{wmDraw(true);}catch(e){}}}
ACT.g3Ident=async d=>{const s=d.s,n=((document.getElementById('g3idn')||{}).value||'').replace(/[<>&"]/g,'').trim().slice(0,28),c=((document.getElementById('g3idc')||{}).value||'');
  if(!(g3IsPres(s)||S.me.admin))return msg('Bunu sadece devlet başkanı değiştirebilir.');
  if(n.length<3)return msg('Devlet adı en az 3 harf olmalı.');if(!/^#[0-9a-f]{6}$/i.test(c))return msg('Renk geçersiz.');
  try{await MP.fb('PUT','gov/'+s+'/ident',{n:n,c:c,by:g3uid(),t:Date.now()});const g=G3.gov[s]=G3.gov[s]||{};g.ident={n:n,c:c};g3ApplyIdent();msg('Devlet adı ve rengi güncellendi.','ok');S.dirty=true;}catch(e){msg(g3Err(e));}};
/* ================ Devlet sayfası için hazır HTML parçaları (rr_pages.js kullanır) ================ */
function g3GovHtml(s){
  const gv=g3Gov(s),pres=g3Pres(s),u=g3uid(),isP=g3IsPres(s),bal=g3Bal(s);
  const rows=['pres','econ','foreign','border'].map(r=>{
    const who=r==='pres'?(pres?{n:pres.n,id:pres.id,bot:pres.bot}:null):g3Off(s,r);
    return `<div class="q">${G3_ROLES[r][0]} <b>${G3_ROLES[r][1]}</b>: ${who?`<b>${esc(who.n)}</b>${who.bot?' <span class="dim">(yapay zekâ)</span>':''}${who.id===u?' <span class="owner">sen</span>':''}`:'<span class="dim">atanmadı</span>'} · <small class="dim">maaş ${fmt(g3Sal(s,r))}₺/gün</small>${isP&&r!=='pres'?` ${who?btn('Azlet',`data-a="g3Appoint" data-r="${r}"`,'danger sm'):''}`:''}</div>`;}).join('');
  let h=rows+`<div class="q">🏛️ <b>Milletvekili</b> maaşı: <small class="dim">${fmt(g3Sal(s,'mp'))}₺/gün</small></div>`;
  const mine=g3MyRoles(s);
  if(mine.length)h+=`<div class="btns">${mine.map(r=>btn('💵 '+G3_ROLES[r][1]+' maaşını al',`data-a="g3Claim" data-r="${r}"`,'gold sm')).join('')}</div><p class="hint">Maaşlar günde bir kez, devlet hazinesinden ödenir (hazine boşsa ödenmez).</p>`;
  if(isP||S.me.admin){const cur=SCOL[s]||'#888888',nm=(S.states[s]||{}).n||s;
    h+=`<div class="card" style="margin-top:8px"><h3>🎨 Devlet adı ve rengi</h3><div class="row" style="margin:4px 0"><input id="g3idn" maxlength="28" value="${esc(nm)}" style="flex:1;padding:8px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px"><input id="g3idc" type="color" value="${cur.slice(0,7)}" style="width:52px;height:38px;border:0;background:none"></div>${btn('Kaydet',`data-a="g3Ident" data-s="${s}"`,'gold sm')}<p class="hint">Ad ve renk haritada ve herkesin ekranında görünür.</p></div>`;}
  if(isP){
    h+=`<div class="card" style="margin-top:8px"><h3>⚙️ Başkan: maaşlar</h3>${['pres','econ','foreign','border','mp'].map(r=>`<div class="row" style="margin:4px 0"><span style="flex:1">${G3_ROLES[r][0]} ${G3_ROLES[r][1]}</span><input type="number" id="g3s_${r}" value="${g3Sal(s,r)}" min="0" style="width:90px;padding:6px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px">${btn('Kaydet',`data-a="g3Setv" data-k="sal" data-f="${r}" data-id="g3s_${r}"`,'sm')}</div>`).join('')}
     <h3 style="margin-top:10px">Görevlendirme</h3><div class="row"><input id="g3q" placeholder="Oyuncu adı ara" style="flex:1;padding:8px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px">${btn('Ara','data-a="g3Find"','sm')}</div>
     ${(G3.found||[]).map(x=>`<div class="q">${esc(x.n)} ${['econ','foreign','border'].map(r=>btn(G3_ROLES[r][1],`data-a="g3Appoint" data-r="${r}" data-u="${esc(x.id)}" data-n="${esc(x.n)}"`,'sm')).join(' ')}</div>`).join('')}</div>`;
  }
  return h;
}
function g3TreasuryHtml(s){
  const t=G3.tr[s]||{},bal=g3Bal(s);
  const rows=Object.keys(t.in||{}).map(k=>Object.assign({io:1},t.in[k])).concat(Object.keys(t.out||{}).map(k=>Object.assign({io:0},t.out[k]))).sort((a,b)=>b.t-a.t).slice(0,10);
  return `<div class="big">${fmt(bal)}₺</div><p class="dim">Gelir: ${fmt(g3Sum(t.in))}₺ · Maaş gideri: ${fmt(g3Sum(t.out))}₺</p>
   <div class="btns">${[10000,100000].map(v=>btn('🎁 +'+fmt(v)+'₺ bağışla',`data-a="g3Donate" data-v="${v}"`,'gold sm',S.me.money<v||s!==g3St())).join('')}</div>
   ${rows.map(x=>`<p class="dim" style="margin:3px 0">${x.io?'➕':'➖'} ${fmt(x.a)}₺ · ${x.io?esc(x.w||'gelir')+(x.n?' · '+esc(x.n):''):esc((G3_ROLES[x.r]||['','maaş'])[1])} · ${new Date(+x.t).toLocaleDateString('tr-TR')}</p>`).join('')||'<p class="dim">Henüz hareket yok. Gelir kaynakları: çalışma vergisi, sınır giriş ücretleri, bağışlar.</p>'}`;
}
function g3BorderHtml(s){
  const isP=g3IsPres(s),ap=g3Approver(s);let h='';
  h+=`<p class="dim">Gerçek sınır düzeni: yabancılar bu devlete girmeden önce kara, deniz ya da hava kapısından izin ister; izin ücreti hazineye gider. Vatandaşlar, göç/askeri anlaşması olan devletler ve 24 saatlik izni olanlar serbest geçer.</p>`;
  h+=['land','sea','air'].map(k=>`<div class="q">${G3_MODE[k][0]} <b>${G3_MODE[k][1]}</b>: ${g3IsOpen(s,k)?'<b class="ok">açık</b>':'<b class="bad">kapalı</b>'} · giriş ${fmt(g3Fee(s,k))}₺${k==='air'&&!hasB(s,'airport')?' <small class="dim">(havalimanı yok)</small>':''}${isP?` ${btn(g3IsOpen(s,k)?'Kapat':'Aç',`data-a="g3Gate" data-m="${k}"`,'sm')} <input type="number" id="g3f_${k}" value="${g3Fee(s,k)}" min="0" style="width:80px;padding:5px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px">${btn('Ücret',`data-a="g3Setv" data-k="fee" data-f="${k}" data-id="g3f_${k}"`,'sm')}`:''}</div>`).join('');
  if(ap){
    const rq=Object.keys(G3.reqs[s]||{}).map(u=>Object.assign({id:u},G3.reqs[s][u])).filter(x=>x.st==='wait').sort((a,b)=>a.t-b.t);
    h+=`<h3 style="margin-top:10px">📨 Giriş başvuruları (${rq.length})</h3>${rq.map(x=>`<div class="q"><b>${esc(x.n)}</b> · ${G3_MODE[x.mode]?G3_MODE[x.mode][1]:x.mode} · ${esc(nameOf(x.from))} → ${esc(x.toN||'')} · ${fmt(x.fee)}₺<br>${btn('✅ Kabul',`data-a="g3Dec" data-u="${esc(x.id)}" data-ok="1"`,'gold sm')} ${btn('⛔ Reddet',`data-a="g3Dec" data-u="${esc(x.id)}" data-ok="0"`,'danger sm')}</div>`).join('')||'<p class="dim">Bekleyen başvuru yok.</p>'}<div class="btns">${btn('🔄 Yenile','data-a="g3Refresh"','sm')}</div>`;
  }
  return h;
}
/* harita çubuğu: izin gerekiyorsa düğme etiketini değiştir */
if(typeof mxBar==='function'){const _mb=mxBar;mxBar=function(){
  let h=_mb.apply(this,arguments);
  try{const id=UI.wsel;if(id!==null&&id!==undefined&&g3Need(id))h=h.replace(/🧳 Buraya git[^<]*/,'🛂 Giriş izni gerekli · izinle git');}catch(e){}
  return h;};}
/* ===== RR tarzı Devlet ve Bölge sayfaları (açılır bölümler, kutucuklar) ===== */
UI.acc=UI.acc||{};UI.st=null;
document.addEventListener('toggle',e=>{const t=e.target;if(t&&t.dataset&&t.dataset.ak)UI.acc[t.dataset.ak]=t.open;},true);
const pgAcc=(k,title,body,def)=>`<details class="rr-acc" data-ak="${k}" ${(UI.acc[k]===undefined?def:UI.acc[k])?'open':''}><summary>${title}</summary><div class="rr-accb">${body}</div></details>`;
const pgTile=(t,v,attr)=>`<div class="rr-tile" ${attr||''}><div class="dim">${t}</div><b>${v}</b></div>`;
{const st=document.createElement('style');st.textContent=`
.rr-acc{background:var(--bg2);border:1px solid var(--line);border-radius:12px;margin:8px 0;overflow:hidden}
.rr-acc>summary{padding:13px 14px;font-weight:700;cursor:pointer;list-style:none;display:flex;justify-content:space-between}
.rr-acc>summary::after{content:'›';transform:rotate(90deg);color:var(--tx2)}
.rr-acc[open]>summary::after{transform:rotate(-90deg)}
.rr-accb{padding:4px 14px 14px}
.rr-tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:8px 0}
.rr-tile{background:var(--bg2);border:1px solid var(--line);border-radius:12px;padding:9px 4px;text-align:center;font-size:13px}
.rr-tile .dim{font-size:11px}
.rr-hd{display:flex;gap:12px;align-items:center;background:var(--bg2);border:1px solid var(--line);border-radius:14px;padding:12px;margin:6px 0}
.rr-em{width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:26px;font-weight:800;color:#fff;flex:none}
`;document.head.appendChild(st);}
ACT.stView=d=>{UI.st=d.id||null;window.scrollTo(0,0);};
ACT.entGo=(_g=>d=>{if(d.k==='state'){ENT.cur=null;ENT.stack=[];entDraw();UI.st=d.id;UI.tab='state';window.scrollTo(0,0);return;}return _g(d);})(ACT.entGo);
function pgState(k){
  const regs=regOf(k),pop=regs.reduce((a,r)=>a+cityPop(r),0),col=SCOL[k]||'#888',mine=k===g3St(),sim=k==='A';
  const a=sim?A():null,pres=g3Pres(k),wars=atWar(k),rel=Math.round(relTo('A',k));
  const leader=pres?pres.n+(pres.bot?' (YZ)':''):(sim?a.leader:(S.states[k]&&S.states[k].leader)||'—');
  let h=`<div class="panel"><div class="rr-hd"><div class="rr-em" style="background:${col}">${esc(nameOf(k).replace(/[^\p{L}]/gu,'').charAt(0))}</div><div><h2 style="margin:0">${esc(nameOf(k))}</h2><div class="dim">${sim?GOVS[a.gov]:'Cumhuriyet'} · ${regs.length} bölge</div></div></div>
  ${UI.st&&UI.st!==g3St()?btn('← Kendi devletim','data-a="stView"','sm'):''}
  <div class="rr-tiles">${pgTile('👥 Nüfus',fmt(pop))}${pgTile('🏙️ Bölge',regs.length)}${pgTile('🎖️ Güç',f1(powerOf(k)))}${pgTile('💰 Hazine',fmt(g3Bal(k))+'₺')}${pgTile('⚔️ Savaş',wars.length)}${pgTile('🤝 İlişki',mine?'—':rel)}</div>`;
  h+=pgAcc('gv','🏛️ Hükümet ve maaşlar',`<p>Hükümet şekli: <b>${sim?GOVS[a.gov]:'Cumhuriyet'}</b></p><p>Başkan: <b>${esc(leader)}</b></p>`+g3GovHtml(k),true);
  if(sim){
    const roster=g3Roster();
    h+=pgAcc('parl',`🗳️ Devlet parlamentosu (${a.gov==='dictatorship'?'feshedildi':a.parlSize+' sandalye'})`,
      `<p class="hint">Gerçek oyuncular (partisinde yer alanlar) ve yapay zekâ milletvekilleri isimleriyle listelenir. Milletvekili maaşı hazineden ödenir.</p>`+
      (roster.length?roster.map(x=>`<div class="q">${x.real?'🧑':'🤖'} <b>${esc(x.n)}</b> <small class="dim">${esc(x.pn)}${x.id===g3uid()?' · sen':''}</small></div>`).join(''):'<p class="dim">Meclis yok.</p>')+
      `<div class="btns">${btn('Parti sekmesi','data-a="tab" data-t="party"','sm')}</div>`);
    h+=pgAcc('bud','💰 Bütçe ve vergiler',`<p>Simülasyon bütçesi: <b>${fmt(a.budget.money)}₺</b></p><p class="dim">${RES.map(r=>`${RES_I[r]} ${f1(a.budget[r])}`).join(' · ')}</p><p class="dim">Vergi: gelir %${a.tax.inc} · ${RES.map(r=>`${RES_I[r]} %${a.tax[r]}`).join(' ')}</p>`);
  }
  h+=pgAcc('tr','🏦 Devlet hazinesi (ortak)',g3TreasuryHtml(k));
  h+=pgAcc('bd','🛂 Sınırlar ve giriş izni',g3BorderHtml(k));
  h+=pgAcc('reg','🏙️ Devlet bölgeleri',regs.map(r=>`<div class="q">${eLink('city',r.id)} <small class="dim">👥 ${fmt(cityPop(r))}${r.coast?' · 🌊':''}</small></div>`).join('')||'<p class="dim">—</p>');
  h+=pgAcc('wr','⚔️ Savaşlar ve ilişkiler',(wars.map(w=>`<p class="bad">${eLink('state',w.att)} → ${eLink('state',w.def)} · ${eLink('city',w.region)}</p>`).join('')||'<p class="dim">Aktif savaş yok.</p>')+`<div class="btns">${btn('Savaş sekmesi','data-a="tab" data-t="war"','sm')}${btn('Diplomasi','data-a="tab" data-t="dip"','sm')}</div>`);
  if(!(UI.st&&UI.st!==g3St())&&typeof tabState_orig==='function'){}
  return h+'</div>';
}
{const _o=tabState;tabState=function(){
  const k=UI.st||g3St();G3.view=k;g3Poll();
  const s=pgState(k);
  if(k==='A')return s+pgAcc('law','📜 Kanunlar, bakanlıklar ve diğer işlemler',_o.apply(this,arguments).replace(/<h2>/g,'<h3>').replace(/<\/h2>/g,'</h3>'),false).replace(/^/,'<div class="panel">')+'</div>';
  return s;
};}
/* Bölge sayfası */
if(typeof mxCityPage==='function'){const _c=mxCityPage;mxCityPage=function(html,r){
  const m=S.me,here=m.loc===r.id,need=g3Need(r.id),hops=hopsTo(m.loc,r.id),col=SCOL[r.state]||'#888';
  const ng=r.adj.map(j=>S.regions[j]);
  const head=`<div class="rr-hd"><div class="rr-em" style="background:${col}">${esc(String(r.n).charAt(0))}</div><div><h2 style="margin:0">${esc(r.n)}</h2><div class="dim">${eLink('state',r.state)}${r.coast?' · 🌊 kıyı':''}${r.moon?' · 🌙':''}</div></div></div>`;
  const acts=pgAcc('ac','⚡ Aksiyonlar',`<p class="dim">${here?'Şu an buradasın.':(hops>=99&&!r.moon?'Kara yolu yok.':'Yolculuk '+(r.moon?'2sa':hops*20+'dk'))}${need?' · 🛂 '+esc(nameOf(need))+' giriş izni gerekir':''}</p>
   <div class="q">${here?btn('🏠 Buraya yerleş','data-a="resid"','gold sm',m.res===r.id||r.moon):btn(need?'🛂 İzinle git':'🧳 Buraya git',`data-a="travel" data-to="${r.id}"`,'gold sm',!!m.travel)}<br><small class="dim">${need?'Yabancı devlet sınırı: kara/deniz/hava kapısından izin istenir, ücret devlet hazinesine gider.':'Bölgeye yolculuk başlatır.'}</small></div>
   <div class="q">${btn('🗺️ Haritada göster',`data-a="cityOnMap" data-id="${r.id}"`,'blue sm')}<br><small class="dim">Haritada bu bölgeyi seçer.</small></div>
   <div class="q">${btn('⚔️ Savaş sekmesi','data-a="tab" data-t="war"','sm')}<br><small class="dim">Bu bölgeye saldırı/savunma işlemleri.</small></div>`,true);
  const tiles=`<div class="rr-tiles">${pgTile('👥 Nüfus',fmt(cityPop(r)))}${pgTile('❤️ Sağlık',r.idx.h)}${pgTile('🎖️ Ordu',r.idx.m)}${pgTile('🎓 Eğitim',r.idx.e)}${pgTile('🏘️ Gelişmişlik',r.idx.d)}${pgTile('🏙️ Seviye',devOf(r))}</div>
   <div class="rr-tiles">${RES.map(k=>pgTile(RES_I[k]+' '+RES_N[k],r.res[k].m>0?fmt(r.res[k].c):'—')).join('')}</div>`;
  const brd=pgAcc('nb','🧭 Sınır bölgeler',ng.map(x=>`<div class="q"><a class="lk" data-a="goCity" data-id="${x.id}">${esc(x.n)}</a> <small class="dim">${esc(nameOf(x.state))}</small></div>`).join('')||'<p class="dim">—</p>',true);
  const rest=html.replace(/^<div class="panel">/,'').replace(/<h2>[\s\S]*?<\/p>/,'').replace(/<\/div>\s*$/,'');
  return `<div class="panel"><div class="btns"><button class="act sm" data-a="cityPick" data-id="">← Şehirler</button></div>${head}${acts}${tiles}${brd}${pgAcc('det','📋 Detaylı bilgi (binalar, geliştirme, kritik şehir)',rest.replace(/<div class="btns"><button[^>]*cityPick[^>]*>[^<]*<\/button><\/div>/,''),true)}</div>`;
};}
/* ===== Sakin ekran: arka plandaki olaylar (savaş vuruşu, bot, ağ yoklaması) sayfayı kaydırmaz, kapatmaz, odağı bozmaz =====
   - Sen dokunurken/kaydırırken/yazarken arka plan yenilemesi bekler (3 sn sessizlik)
   - Çizilirse kaydırma konumu ve açık bölümler korunur
   - Arka plan yenilemesi en fazla 10 sn'de bir */
const CALM={user:0,last:0,bg:false};
['pointerdown','touchstart','touchmove','wheel','keydown','scroll','input'].forEach(ev=>document.addEventListener(ev,()=>{CALM.user=Date.now();},{passive:true,capture:true}));
function bgRender(){
  const mn=$('main'),ae=document.activeElement;
  const typing=ae&&/^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)&&mn.contains(ae);
  const now=Date.now();
  const ban=(typeof isBanned==='function'&&isBanned());
  if(ban){S.dirty=false;render();return;}
  if(typing||now-CALM.user<3000||now-CALM.last<10000){tickUI();alerts();return;} // dirty kalır, sakinleşince çizilir
  CALM.last=now;S.dirty=false;
  const y=window.scrollY,open=[...mn.querySelectorAll('details')].map(x=>x.open);
  render();
  {
    mn.querySelectorAll('details').forEach((x,i)=>{if(open[i]!==undefined&&x.open!==open[i])x.open=open[i];});
    if(Math.abs(window.scrollY-y)>2)window.scrollTo(0,y);
  }
}
/* ===== EKLENTİLER (Ayarlar'da): hata kaydı, otomatik üretim (varsayılan KAPALI), fiyat uyarısı ===== */
var MODS=(function(){
  var K='bm_mods',M={err:1,auto:0,item:'',n:1,reserve:1000,alert:0,aRes:'gold',aAbove:0,aBelow:0,errs:[]};
  try{var o=JSON.parse(localStorage.getItem(K)||'{}');for(var k in o)M[k]=o[k];}catch(e){}
  function save(){try{localStorage.setItem(K,JSON.stringify(M));}catch(e){}}
  function items(){try{return Object.keys(ITEMS);}catch(e){return [];}}
  function log(m){if(!M.err)return;M.errs.unshift(new Date().toLocaleTimeString('tr-TR')+' '+String(m).slice(0,140));if(M.errs.length>15)M.errs.length=15;save();}
  window.addEventListener('error',function(e){log(e.message);});
  window.addEventListener('unhandledrejection',function(e){log(e.reason&&e.reason.message||e.reason);});
  var lastA=0,lastP=0;
  setInterval(function(){try{
    if(typeof S==='undefined'||!S||!S.live||!S.me)return;
    var now=Date.now();
    if(M.auto&&M.item&&now-lastA>45000){lastA=now;
      if(S.me.money>=M.reserve&&maxMake(M.item)>=M.n)ACT.craft({k:M.item,n:M.n});}
    if(M.alert&&now-lastP>60000){var p=S.prices&&S.prices[M.aRes];
      if(p){var nm=(typeof RES_N!=='undefined'&&RES_N[M.aRes])||M.aRes;
        if(M.aAbove>0&&p>=M.aAbove){lastP=now;toast('📈 '+nm+' fiyatı '+Math.round(p)+' (hedef '+M.aAbove+' üstü)','ok');}
        else if(M.aBelow>0&&p<=M.aBelow){lastP=now;toast('📉 '+nm+' fiyatı '+Math.round(p)+' (hedef '+M.aBelow+' altı)','ok');}}}
  }catch(e){log(e.message);}},5000);
  ACT.modSet=function(d){var v=d.v;if(v==='1')v=1;else if(v==='0')v=0;M[d.k]=v;save();S.dirty=true;render();};
  ACT.modStep=function(d){var s=+d.s;M[d.k]=Math.max(0,(+M[d.k]||0)+s);save();S.dirty=true;render();};
  ACT.modItem=function(){var l=items();if(!l.length)return;var i=l.indexOf(M.item);M.item=l[(i+1)%l.length];save();S.dirty=true;render();};
  ACT.modRes=function(){var l=['gold','oil','ore','uranium','diamonds'],i=l.indexOf(M.aRes);M.aRes=l[(i+1)%l.length];save();S.dirty=true;render();};
  ACT.modClr=function(){M.errs=[];save();S.dirty=true;render();};
  function onoff(k){return btn('Açık','data-a="modSet" data-k="'+k+'" data-v="1"',M[k]?'gold':'sm')+btn('Kapalı','data-a="modSet" data-k="'+k+'" data-v="0"',M[k]?'sm':'gold');}
  function stp(k,s,l){return btn(l,'data-a="modStep" data-k="'+k+'" data-s="'+s+'"','sm');}
  function html(){
    var nm=function(k){try{return itDef(k).n;}catch(e){return k;}};
    var rn=(typeof RES_N!=='undefined'&&RES_N[M.aRes])||M.aRes;
    return '<div class="panel"><h2>🧩 Eklentiler</h2>'
    +card('🐞 Hata kaydı','<div class="btns">'+onoff('err')+'</div><p class="dim">Oyunda olan JavaScript hataları burada listelenir (yama denerken işe yarar).</p>'
      +(M.errs.length?'<div style="font-size:11px;max-height:120px;overflow:auto">'+M.errs.map(function(x){return '<div>'+x.replace(/</g,'&lt;')+'</div>';}).join('')+'</div>'+btn('Temizle','data-a="modClr"','sm'):'<p class="dim">Kayıtlı hata yok ✅</p>'))
    +card('⚙️ Otomatik üretim','<div class="btns">'+onoff('auto')+'</div><p class="dim">Açıkken oyun açıkken her ~45 sn\'de bir, para yedeğin korunarak ve malzeme yetiyorsa seçtiğin eşyadan üretim sıraya alır. Varsayılan kapalı.</p>'
      +'<div class="btns">'+btn('Eşya: '+(M.item?nm(M.item):'seç ▸'),'data-a="modItem"','sm')+stp('n',-1,'−')+'<b>'+M.n+' adet</b>'+stp('n',1,'+')+'</div>'
      +'<div class="btns">'+stp('reserve',-500,'−')+'<b>Yedek para: '+M.reserve+'</b>'+stp('reserve',500,'+')+'</div>')
    +card('🔔 Fiyat uyarısı','<div class="btns">'+onoff('alert')+'</div><p class="dim">Seçili kaynağın pazar fiyatı hedefe ulaşınca bildirim verir (en fazla dakikada bir). 0 = kapalı.</p>'
      +'<div class="btns">'+btn('Kaynak: '+rn+' ▸','data-a="modRes"','sm')+'</div>'
      +'<div class="btns">'+stp('aAbove',-10,'−')+'<b>Üstü: '+M.aAbove+'</b>'+stp('aAbove',10,'+')+'</div>'
      +'<div class="btns">'+stp('aBelow',-10,'−')+'<b>Altı: '+M.aBelow+'</b>'+stp('aBelow',10,'+')+'</div>')
    +'</div>';
  }
  var _ts=tabSettings;tabSettings=function(){var h=_ts.apply(this,arguments);try{h+=html();}catch(e){log(e.message);}return h;};
  return M;
})();
/* ===== Denge: kuvvet/eğitim/dayanıklılık 100'ün üstünde çok yavaş artar; sınır yok ama binlere kolay çıkılmaz ===== */
{const _lt=learnTimeMs,_lc=learnCost;
 learnTimeMs=function(p,gold){let T=_lt.apply(this,arguments);const L=S.me[p]+1;if(L>100)T*=Math.pow(L/100,1.5);return T;};
 learnCost=function(p,gold){let c=_lc.apply(this,arguments);const L=S.me[p]+1;if(gold&&L>100)c=Math.max(c,Math.floor(L*L/800));return c;};}
/* tek seferlik uyarlama: 100'ün üstündeki mevcut değerler karekök ölçeğine çekilir (8000 → ~894) */
setInterval(function(){try{
  if(typeof S==='undefined'||!S||!S.me||S.me.sv2)return;
  let ch=[];['str','edu','end'].forEach(function(k){const v=S.me[k];if(v>100){S.me[k]=Math.round(100*Math.sqrt(v/100));ch.push(k);}});
  S.me.sv2=1;if(ch.length&&typeof L==='function')L('⚖️ Denge güncellemesi: yüksek kuvvet/eğitim/dayanıklılık değerleri yeniden ölçeklendi.','info');
  if(S.me.learn&&S.me.learn.perk&&ch.indexOf(S.me.learn.perk)>=0){S.me.learn=null;}
  S.dirty=true;}catch(e){}},3000);
/* ===== Yapay Zekâ Konsolu: yalnız akıllı oyuncular. Sıradan NPC'ler kaldırıldı; sayı sağlayıcı/anahtar sayısıyla artar ===== */
botAutoGrow=function(){};            // eski otomatik NPC büyütme kapalı
if(typeof S!=='undefined'){}
const CON={q:'',open:{}};
const conRole={tuccar:'💰 Tüccar',ogretici:'📚 Öğretici',asker:'⚔️ Asker',kasif:'🧭 Kaşif',sosyal:'💬 Sosyal'};
function conPanel(){
  if(!S.botSrv)return `<div class="panel"><h2>🧠 Yapay Zekâ Konsolu</h2><p class="dim">Önce aşağıdan <b>Sunucu modunu</b> aç. Akıllı oyuncular GitHub sunucusunda çalışır.</p></div>`;
  const cap=SMT.cap||5000,ids=Object.keys(SMT.p||{}).map(Number).sort((a,b)=>a-b),q=CON.q.toLocaleLowerCase('tr');
  const rows=ids.filter(i=>!q||String((SMT.p[i]||{}).name||'').toLocaleLowerCase('tr').includes(q)||String((SMT.p[i]||{}).rol||'').includes(q)).slice(0,cap);
  const inp='style="width:70px;padding:7px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px;text-align:center"';
  const age=SMT.t?Math.round((Date.now()-SMT.t)/60000):null;
  const roles={};ids.forEach(i=>{const r=(SMT.p[i]||{}).rol||'sosyal';roles[r]=(roles[r]||0)+1;});
  return `<div class="panel"><h2>🧠 Yapay Zekâ Konsolu ${SMT.on?'<span class="ok">● açık</span>':'<span class="dim">● kapalı</span>'}</h2>
  <div class="rr-tiles">${pgTile('Oyuncu',ids.length+' / '+SMT.n)}${pgTile('Üst sınır',cap)}${pgTile('Sağlayıcı',SMT.prov||'—')}${pgTile('Son tur',age===null?'—':age+' dk önce')}${pgTile('NPC',(S.bots||[]).length)}${pgTile('Mod',SMT.on?'Aktif':'Kapalı')}</div>
  <p class="hint">Sınır yok. İstekler 25 oyunculuk gruplara bölünüp anahtarlara dağıtılır; çok oyuncu = daha çok API isteği (ücretsiz kotalar dolabilir). 20'den sonraki oyuncular adını ve kişiliğini kendisi seçer.</p>
  <div class="row" style="align-items:center;gap:6px;flex-wrap:wrap">${btn('−5','data-a="conStep" data-s="-5"','sm')}${btn('−1','data-a="conStep" data-s="-1"','sm')}<input type="number" id="conN" min="0" max="${cap}" value="${SMT.n}" ${inp}>${btn('+1','data-a="conStep" data-s="1"','sm')}${btn('+5','data-a="conStep" data-s="5"','sm')}${btn('Maks ('+cap+')','data-a="conStep" data-s="max"','sm')}</div>
  <div class="btns" style="margin-top:8px">${btn('✅ Uygula','data-a="conApply"','gold')}${btn(SMT.on?'⏸ Durdur':'▶ Başlat',`data-a="smtSet" data-on="${SMT.on?0:1}"`,SMT.on?'danger':'blue')}${btn('🧹 NPC\'leri temizle','data-a="conClean"','sm')}</div>
  <div class="card" style="margin-top:10px"><b>Rol dağılımı</b><p class="dim">${Object.keys(roles).map(r=>(conRole[r]||r)+' '+roles[r]).join(' · ')||'—'}</p></div>
  <div class="row" style="margin:10px 0"><input id="conQ" placeholder="Oyuncu veya rol ara…" value="${esc(CON.q)}" style="flex:1;min-width:0">${btn('Ara','data-a="conSearch"','sm')}</div>
  ${rows.length?`<div>${rows.map(i=>{const p=SMT.p[i]||{};return pgAcc('con'+i,`${esc(p.name||'?')} <span class="dim">${conRole[p.rol]||''}</span>`,`<p>${esc(p.persona||'')}</p>${p.mem?`<p class="dim">📝 ${esc(String(p.mem).slice(0,200))}</p>`:''}<p class="dim">${p.pref?'Tercih: '+esc(p.pref)+' · ':''}Hamle: ${p.mv||0}</p>`,false);}).join('')}</div>`:'<p class="dim">Henüz oyuncu yok; ✅ Uygula\'ya bas, sonraki sunucu turunda doğarlar.</p>'}
  </div>`;
}
smtCard=conPanel;
ACT.conStep=d=>{const cap=SMT.cap||5000;const cur=+((document.getElementById('conN')||{}).value)||SMT.n;SMT.n=d.s==='max'?cap:Math.max(0,Math.min(cap,cur+(+d.s||0)));S.dirty=true;};
ACT.conSearch=()=>{CON.q=String(((document.getElementById('conQ')||{}).value)||'').trim();S.dirty=true;};
ACT.conApply=async()=>{const cap=SMT.cap||5000,n=Math.max(0,Math.min(cap,+((document.getElementById('conN')||{}).value)||0));SMT.n=n;smtSave();
  try{S.botAuto=S.botAuto||{};if(S.botAuto)S.botAuto.on=false;}catch(e){}
  try{botSetCount(n);await botSrvPushCfg(true);msg('🧠 '+n+' akıllı oyuncu ayarlandı. Sonraki sunucu turunda uygulanır.','ok');}catch(e){msg(typeof rulesHint==='function'?rulesHint(e):String(e.message||e));}S.dirty=true;};
ACT.conClean=()=>{if(!confirm('Sıradan NPC oyuncular silinsin? Akıllı oyuncular ('+SMT.n+') kalır.'))return;try{botSetCount(Math.max(SMT.n,0));msg('NPC\'ler temizlendi.','ok');}catch(e){msg('Yapılamadı.');}S.dirty=true;};
/* NPC paneli kalır (sıradan botlar zamanla gelişir); konsol akıllı oyuncular içindir */

/* ---- ortak hafıza, hazine ve ilişkiler (yönetici görünümü) ---- */
{const _pl=botSrvPull;botSrvPull=async function(){await _pl();if(!MP.ok)return;try{const sm=await MP.fb('GET','botsrv/smart');if(sm){SMT.mm=sm.mm||[];SMT.rel=sm.rel||{};SMT.tre=sm.tre||null;}}catch(e){}};}
function conTeam(){
  const T=SMT.tre||{m:0,g:0,o:0,k:0,log:[]},mm=(Array.isArray(SMT.mm)?SMT.mm:[]).slice(-10).reverse(),nm=i=>esc((SMT.p[i]||{}).name||('Bot '+i)),log=(Array.isArray(T.log)?T.log:[]).slice(-6).reverse();
  const rel=Object.keys(SMT.rel||{}).map(k=>[k,SMT.rel[k]]).sort((a,b)=>Math.abs(b[1])-Math.abs(a[1])).slice(0,8);
  return `<div class="card" style="margin-top:10px"><b>🏦 Ortak hazine</b><p style="margin:4px 0">${fmt(T.m||0)}₺ · ${fmt(T.g||0)} altın · ${fmt(T.o||0)} petrol · ${fmt(T.k||0)} maden</p>
  <p class="dim" style="margin:0 0 6px">Akıllı oyuncular buraya bağış yapar, ihtiyaç duyunca hazinenin en çok %25'ini 6 saatte bir isteyebilir. Çok zengin botlar 12 saatte bir %2 vakıf bırakır.</p>
  <div class="row" style="gap:6px"><input type="number" id="treM" placeholder="₺" style="flex:1;min-width:0"><input type="number" id="treG" placeholder="altın" style="flex:1;min-width:0">${btn('➕ Hazineye ekle','data-a="treAdd"','gold sm')}</div>
  ${log.length?'<p class="dim" style="margin:8px 0 2px">Son hareketler</p>'+log.map(l=>`<p style="margin:2px 0;font-size:13px">• ${esc(l.tx||'')}</p>`).join(''):''}</div>
  <div class="card"><b>🧠 Ortak hafıza</b>${mm.length?mm.map(x=>`<p style="margin:4px 0;font-size:13px"><b>${nm(x.i)}</b>: ${esc(x.tx)} <span class="dim">· ${fmtDur(Date.now()-(+x.t||Date.now()))} önce</span></p>`).join(''):'<p class="dim">Henüz not yok.</p>'}</div>
  <div class="card"><b>🤝 İlişkiler</b>${rel.length?rel.map(r=>{const [a,b]=r[0].split('-');return `<p style="margin:4px 0;font-size:13px">${r[1]>0?'💚':'🔴'} ${nm(+a)} ↔ ${nm(+b)} <span class="dim">(${r[1]>0?'+':''}${r[1]})</span></p>`;}).join(''):'<p class="dim">Henüz ilişki yok.</p>'}</div>`;}
{const _c=conPanel;conPanel=function(){let h=_c.apply(this,arguments);return h.replace('<div class="card" style="margin-top:10px"><b>Rol dağılımı</b>',conTeam()+'<div class="card" style="margin-top:10px"><b>Rol dağılımı</b>');};smtCard=conPanel;}
ACT.treAdd=()=>{const m=Math.max(0,+(($('treM')||{}).value)||0),g=Math.max(0,+(($('treG')||{}).value)||0);if(!m&&!g)return msg('Miktar yaz.');botSrvCmd({k:'tre',money:m,gold:g});msg('Hazineye ekleme emri gönderildi; sunucu bir sonraki turda uygular.','ok');};
/* ===== Sadeleştirme: Harita yalnız harita; İstatistik üst barda; Bağış devlet sayfasında; Parti ≠ Meclis ===== */
/* 1) Harita sekmesi yalnız harita; alttaki bölge/devlet bilgileri Şehirler sekmesine taşınır */
{const _tw=tabWorld,KEY='Seçili bölgeye yakınlaş</button></div>';
  const split=()=>{const h=_tw();const i=h.indexOf(KEY);return i<0?[h,'']:[h.slice(0,i+KEY.length),h.slice(i+KEY.length)];};
  tabWorld=function(){const p=split();return p[1]?p[0]+'</div>':p[0];};
  window.mapRestHtml=function(){const p=split();let r=p[1];if(!r)return '';
    r=r.replace(/<p class="hint"[^]*?<\/p>/,'').replace(/<div class="row" style="margin:8px 0"><input id="wmQ"[^]*?<\/div>/,'');
    return '<div class="panel"><h2>🧭 Seçili bölge ve devletler</h2><p class="hint">Haritada bir bölgeye dokunduğunda ayrıntısı burada.</p>'+r;};
  const _tm=tabMap;tabMap=function(){const h=_tm.apply(this,arguments);if(UI.city!==null&&S.regions[UI.city])return h;
    let rest='';try{rest=mapRestHtml();}catch(e){}
    return h+(rest?pgAcc('mrest','🌍 Devletler ve seçili bölge',rest.replace(/^<div class="panel"><h2>[^<]*<\/h2>/,'<div>'),false):'');};
}
/* 2) Kutucuklardan Bağış ve İstatistik kalkar; İstatistik üst bara 📊 olarak gelir */
{const _rt=rrTiles;rrTiles=function(){return _rt.apply(this,arguments).replace(/<button class="rr-tile" data-a="tab" data-t="(give|stats)">[^]*?<\/button>/g,'');};
 const _rb=rrBarHtml;rrBarHtml=function(){let h=_rb.apply(this,arguments);if(UI.tab!=='stats')h=h.replace('<button class="rb-b" data-a="bell"','<button class="rb-b" data-a="tab" data-t="stats" aria-label="İstatistik">📊</button><button class="rb-b" data-a="bell"');return h;};}
/* 3) Bağış: her devletin kendi sayfasında */
{const _pg=pgState;pgState=function(k){
  let h=_pg.apply(this,arguments);
  try{
    const m=S.me,ok=(k==='A'||(S.states[k]&&k!=='O'));
    if(ok){
      const wh=[['money:','💰 Para ('+fmt(m.money)+'₺)']].concat(RES.map(r=>['res:'+r,RES_I[r]+' '+RES_N[r]+' ('+f1(m.stor[r])+')'])).concat(Object.keys(MATS).map(q=>['mat:'+q,MATS[q].i+' '+MATS[q].n+' ('+f1(prodS().mats[q]||0)+')'])).concat(Object.keys(ITEMS).map(q=>['item:'+q,ITEMS[q].i+' '+ITEMS[q].n+' ('+(m.items[q]||0)+')']));
      const what=k==='A'?'Devlet bütçesine bağış yap.':'Yabancı devlete bağış ilişkiyi düzeltir.';
      const body=`<p class="hint">${what}</p><input type="hidden" id="dnTo" value="${k}"><div class="row" style="margin:4px 0">Ne: ${sel('dnWhat',wh,UI.dnWhat||'money:')}</div><div class="row" style="margin:4px 0"><input id="dnAmt" type="number" min="1" placeholder="Miktar" style="width:140px"></div><div class="btns">${btn('🎁 Bağışla','data-a="donate"','gold')}${btn('Hepsini bağışla','data-a="donate" data-all="1"','sm')}</div><p class="dim">Toplam bağışın: <b>${fmt(m.dnTot||0)}₺</b></p>`;
      h=h.slice(0,h.lastIndexOf('</div>'))+pgAcc('give','🎁 Bağış',body,false)+'</div>';
    }
    if(k==='A'){const mh=meclisHtml();if(mh)h=h.slice(0,h.lastIndexOf('</div>'))+pgAcc('mec','🗳️ Meclis ve seçim',mh,false)+'</div>';}
  }catch(e){}
  return h;};}
/* 4) Parti sekmesi: önce partin; Meclis bilgisi Devlet sayfasına gider */
{const _tp=tabParty;let cache='';
  const parts=h=>{const a=h.indexOf('<div class="panel"><h2>🗳️ Meclis'),g=h.indexOf('<div class="grid">',a),b=h.indexOf('<div class="panel"><h2>🚩 Partin');return a<0||g<0||b<0?null:{head:h.slice(a,g),cards:h.slice(g,b),mine:h.slice(b)};};
  window.meclisHtml=function(){const p=parts(_tp.apply(null,[]));return p?p.head.replace(/^<div class="panel"><h2>[^<]*<\/h2>/,'<div>')+'</div>':'';};
  tabParty=function(){const h=_tp.apply(this,arguments),p=parts(h);if(!p)return h;
    const cards=p.cards;
    return p.mine+'<div class="panel"><h2>🏳️ Ulusal partiler</h2><p class="hint">Katılmak için seviye 5 gerekir. Meclis dağılımı ve seçim bilgisi Devlet sayfasında.</p>'+cards+'</div>';};
}
GROUPS[0][2]=GROUPS[0][2].filter(t=>t[0]!=='give'&&t[0]!=='stats');
/* ===== Geçmiş harita: bölge sahipliği değiştikçe kaydedilir; tarih seçip eski siyasi durum görülür ===== */
const HMH={view:null};
const hDT=t=>new Date(t).toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
function hmList(){S.hist2=S.hist2||[];return S.hist2;}
function hmRec(){try{
  if(typeof S==='undefined'||!S||!S.regions||!S.me)return;const L2=hmList(),cur=S.regions.map(r=>r.state),sig=cur.join(''),now=Date.now();
  const nm={};Object.keys(S.states||{}).forEach(k=>nm[k]=S.states[k].n);
  if(!L2.length){L2.push({t:now,s:(HM&&HM.rs&&HM.rs.length===cur.length?HM.rs.slice():cur).join(''),n:nm,f:1});}
  const last=L2[L2.length-1];
  if(last.s!==sig){L2.push({t:now,s:sig,n:nm});if(L2.length>400)L2.splice(1,L2.length-400);S.dirty=true;}
  else if(JSON.stringify(last.n)!==JSON.stringify(nm)){last.n=nm;}
}catch(e){}}
setInterval(hmRec,20000);setTimeout(hmRec,4000);
ACT.hmSet=d=>{HMH.view=d.v===''||d.v==null?null:+d.v;if(typeof GEO!=='undefined'){GEO.inflK='';GEO.brdK='';}};
ACT.hmAgo=d=>{const L2=hmList(),tg=Date.now()-(+d.ms),c=L2.filter(x=>x.t<=tg);if(!c.length){msg('O tarihte kayıt yok. En eski kayıt: '+(L2[0]?hDT(L2[0].t):'—'));return;}
  HMH.view=c[c.length-1].t;if(typeof GEO!=='undefined'){GEO.inflK='';GEO.brdK='';}};
{const _wd=wmDraw;wmDraw=function(){
  if(HMH.view==null)return _wd.apply(this,arguments);
  const L2=hmList(),snap=L2.filter(x=>x.t<=HMH.view).pop()||L2[0];
  if(!snap)return _wd.apply(this,arguments);
  const old=S.regions.map(r=>r.state),oldN={};Object.keys(S.states).forEach(k=>oldN[k]=S.states[k].n);
  S.regions.forEach((r,i)=>{r.state=snap.s[i]||r.state;});Object.keys(snap.n||{}).forEach(k=>{if(S.states[k])S.states[k].n=snap.n[k];});
  try{return _wd.apply(this,arguments);}finally{S.regions.forEach((r,i)=>{r.state=old[i];});Object.keys(oldN).forEach(k=>{S.states[k].n=oldN[k];});}
};}
function hmBar(){
  const L2=hmList(),v=HMH.view;
  const opts=['<option value="">🕰️ Şimdi</option>'].concat(L2.slice().reverse().slice(0,60).map(x=>`<option value="${x.t}" ${v===x.t?'selected':''}>${hDT(x.t)}${x.f?' (başlangıç)':''}</option>`)).join('');
  const D=864e5;
  return `<div class="card" style="margin:6px 0"><div class="row" style="margin:2px 0"><select id="histSel" onchange="ACT.hmSet({v:this.value});S.dirty=true;render&&render()">${opts}</select></div>
   <div class="btns" style="margin-top:6px">${btn('1 gün','data-a="hmAgo" data-ms="'+D+'"','sm')}${btn('1 hafta','data-a="hmAgo" data-ms="'+7*D+'"','sm')}${btn('1 ay','data-a="hmAgo" data-ms="'+30*D+'"','sm')}${btn('1 yıl','data-a="hmAgo" data-ms="'+365*D+'"','sm')}${v!=null?btn('Şimdiye dön','data-a="hmSet" data-v=""','sm gold'):''}</div>
   ${v!=null?`<p class="warn">🕰️ Geçmiş görünüm: ${hDT(v)} — harita o günkü siyasi durumu gösterir.</p>`:`<p class="dim" style="margin:6px 0 0">Haritadaki devlet sınırlarının geçmişi (${L2.length} kayıt).</p>`}</div>`;
}
{const _tw=tabWorld;tabWorld=function(){const h=_tw.apply(this,arguments);return h.replace('<div id="mxBar"',hmBar()+'<div id="mxBar"');};}
/* Bölge sayfası: geçmiş sahipler */
if(typeof mxCityPage==='function'){const _c=mxCityPage;mxCityPage=function(html,r){let h=_c.apply(this,arguments);
  try{const L2=hmList(),rows=[];let prev=null;L2.forEach(x=>{const st=x.s[r.id];if(st!==prev){rows.push([x.t,st,(x.n||{})[st]||nameOf(st)]);prev=st;}});
    const body=rows.length?rows.slice().reverse().map(z=>`<div class="q"><b>${esc(z[2])}</b> <small class="dim">${hDT(z[0])} tarihinden beri</small></div>`).join(''):'<p class="dim">Kayıt yok.</p>';
    const acc=pgAcc('hist'+r.id,'🕰️ Bölgenin geçmiş sahipleri',body,false);
    const i=h.lastIndexOf('</div>');h=i>=0?h.slice(0,i)+acc+h.slice(i):h+acc;}catch(e){}
  return h;};}
/* ===== Darbe ve bağımsızlık: 24 saatte en az 3 oyuncu imzalarsa bölge bağımsız yeni devlet olur;
   24 saat parti kurma süresi, sonra seçim (sunucu); kazanan yeni devletin başkanı olur ===== */
const CP={d:{},ind:{},last:0,busy:false};
const CP_NEED=3,CP_WIN=24*3600e3,CP_COL=['#e84393','#00cec9','#ff9f43','#a29bfe','#55efc4','#fab1a0','#74b9ff','#ffeaa7','#fd79a8','#81ecec'];
async function cpPoll(force){
  if(!MP.ok||CP.busy)return;if(!force&&Date.now()-CP.last<30e3)return;CP.busy=true;CP.last=Date.now();
  try{CP.d=(await MP.fb('GET','coup'))||{};CP.ind=(await MP.fb('GET','world/ind'))||{};cpApply();if(UI.city!==null||UI.tab==='world')S.dirty=true;}catch(e){}
  CP.busy=false;
}
function cpMkState(k,n){
  const T=S.t||Date.now();
  if(!S.states[k])S.states[k]={n:n,aggr:0.3,next:T+(6+Math.random()*8)*3600e3,truce:{},bonus:1,ind:1};
  else S.states[k].n=n;
  STATE_N[k]=n;
  if(!SCOL[k]){let h=0;for(const c of k)h=(h*31+c.charCodeAt(0))>>>0;SCOL[k]=CP_COL[h%CP_COL.length];}
  S.rel[k]=S.rel[k]||{};
  Object.keys(S.states).forEach(o=>{if(o===k)return;S.rel[o]=S.rel[o]||{};if(typeof S.rel[o][k]!=='number')S.rel[o][k]=S.rel[k][o]=(o==='A'?5:0);});
}
function cpApply(){
  S.cpApplied=S.cpApplied||{};let ch=0;
  Object.keys(CP.ind).forEach(i=>{const x=CP.ind[i],r=S.regions[+i];if(!x||!x.k||!r||S.cpApplied[i])return;
    S.cpApplied[i]=1;cpMkState(x.k,x.n||'Bağımsız Devlet');r.state=x.k;ch=1;
    L('✊ '+r.n+' darbeyle bağımsızlığını ilan etti: '+(x.n||'yeni devlet')+'. 24 saat içinde parti kurulabilir, ardından seçim yapılır.','warn');news(r.n+' bölgesi bağımsız oldu: '+(x.n||'')+'.');});
  if(ch){if(typeof GEO!=='undefined'){GEO.inflK='';GEO.brdK='';}S.dirty=true;}
}
if(typeof MP!=='undefined'&&typeof MP.sync==='function'){const _s=MP.sync;MP.sync=async function(){const r=await _s.apply(this,arguments);try{cpPoll();}catch(e){}return r;};}
setInterval(()=>{try{if(MP.ok&&UI.city!==null)cpPoll();}catch(e){}},30000);
const cpSigs=i=>{const s=((CP.d[i]||{}).sig)||{},now=Date.now();return Object.keys(s).filter(u=>now-(+s[u].t||0)<CP_WIN).map(u=>Object.assign({id:u},s[u]));};
ACT.cpJoin=async d=>{
  const i=+d.id,r=S.regions[i],m=S.me;if(!MP.ok)return msg('Önce giriş yap (Profil › Hesap).');if(!r||r.moon)return;
  if(CP.ind[i])return msg('Bu bölge zaten bağımsız oldu.');if(m.level<3)return msg('Darbeye katılmak için seviye 3 gerekir.');
  if(S.regions.filter(x=>x.state===r.state).length<2)return msg('Devletin tek bölgesi bağımsız olamaz.');
  const u=g3uid();
  try{await MP.fb('PUT','coup/'+i+'/sig/'+u,{n:m.name,t:Date.now()});(CP.d[i]=CP.d[i]||{}).sig=CP.d[i].sig||{};CP.d[i].sig[u]={n:m.name,t:Date.now()};
    const sg=cpSigs(i);
    if(sg.length>=CP_NEED){const k='I'+i,nm=r.n+' Cumhuriyeti';
      await MP.fb('PUT','world/ind/'+i,{k:k,n:nm,t:Date.now(),by:u});CP.ind[i]={k:k,n:nm,t:Date.now()};cpApply();msg('✊ Darbe başarılı! '+r.n+' bağımsız oldu.','ok');}
    else msg('✊ İmzan eklendi ('+sg.length+'/'+CP_NEED+').','ok');}
  catch(e){msg(g3Err(e));}S.dirty=true;};
ACT.cpLeave=async d=>{const i=+d.id;try{await MP.fb('DELETE','coup/'+i+'/sig/'+g3uid());if(CP.d[i]&&CP.d[i].sig)delete CP.d[i].sig[g3uid()];msg('İmzan geri çekildi.','ok');}catch(e){msg(g3Err(e));}S.dirty=true;};
if(typeof mxCityPage==='function'){const _c=mxCityPage;mxCityPage=function(html,r){let h=_c.apply(this,arguments);
  try{if(r.moon)return h;cpPoll();
    const ind=CP.ind[r.id],sg=cpSigs(r.id),me=g3uid(),mine=sg.some(x=>x.id===me);
    const body=ind?`<p class="ok">Bu bölge darbeyle bağımsız oldu: <b>${esc(nameOf(ind.k)||ind.n)}</b></p><p class="dim">Yeni devlette 24 saat parti kurulur, sonra seçim yapılır; kazanan devlet başkanı olur.</p>`:
     `<p class="hint">${esc(r.n)} bölgesinde ${CP_NEED} oyuncu 24 saat içinde imzalarsa bölge ${esc(nameOf(r.state))} devletinden ayrılıp bağımsız yeni bir devlet olur. 24 saat sonra seçim başlar; önce parti kurulabilir.</p>
      <p>İmzalar: <b>${sg.length}/${CP_NEED}</b> ${sg.map(x=>esc(x.n)).join(', ')}</p><div class="btns">${mine?btn('İmzayı geri çek','data-a="cpLeave" data-id="'+r.id+'"','sm'):btn('✊ Darbeyi destekle','data-a="cpJoin" data-id="'+r.id+'"','gold')}</div>`;
    const acc=pgAcc('cp'+r.id,'✊ Darbe ve bağımsızlık',body,false);const i=h.lastIndexOf('</div>');h=i>=0?h.slice(0,i)+acc+h.slice(i):h+acc;}catch(e){}
  return h;};}
