/* ================= YÖNETİCİ ARAÇLARI + OYUNCU TARAFI (duyuru, olay, sezon, ceza) ================= */
const EVT={
  gold_rush:{n:'⛏️ Altın Çağı',d:'Çalışma kazancı ×2',h:true},
  price_up:{n:'📈 Fiyat patlaması',d:'Seçilen kaynağın fiyatı +%35',r:true},
  price_down:{n:'📉 Fiyat çöküşü',d:'Seçilen kaynağın fiyatı −%30',r:true},
  energy:{n:'⚡ Enerji bayramı',d:'Herkesin enerjisi dolar (+50)'},
  money:{n:'💰 Devlet yardımı',d:'Herkese para (miktarı yaz)',v:true}
};
const evtMult=()=>(S.evt&&S.evt.k==='gold_rush'&&S.evt.until>S.t)?2:1;
function applyEvent(e){
  const m=S.me,k=e.k;if(!EVT[k])return;
  const nm=EVT[k].n;
  if(k==='gold_rush'){S.evt={k:k,until:S.t+Math.max(1,+e.h||2)*HOUR};L(`🎉 ${nm}: ${+e.h||2} saat boyunca çalışma kazancı iki katı!`,'ok');}
  else if(k==='price_up'&&PRICE0[e.r]){S.prices[e.r]=Math.min(PRICE0[e.r]*2.2,S.prices[e.r]*1.35);L(`📈 ${RES_N[e.r]} fiyatı yükseldi!`,'ok');}
  else if(k==='price_down'&&PRICE0[e.r]){S.prices[e.r]=Math.max(PRICE0[e.r]*0.5,S.prices[e.r]*0.7);L(`📉 ${RES_N[e.r]} fiyatı düştü!`,'warn');}
  else if(k==='energy'){m.energy=Math.max(m.energy,Math.min(150,m.energy+50));L('⚡ Enerji bayramı: enerjin yükseldi!','ok');}
  else if(k==='money'){const v=Math.max(0,Math.min(1e6,+e.v||0));m.money+=v;L(`💰 Devlet yardımı: ${fmt(v)}₺ hesabına yattı.`,'ok');}
  S.dirty=true;
}
/* ---- oyuncu: sunucudan gelenler ---- */
async function adminSync(){
  if(!MP.ok)return;
  const c=await MP.fb('GET','cfg')||{};
  const m=S.me;
  if(c.announce&&c.announce.id){
    S.ann=c.announce;
    if(m.annSeen!==c.announce.id){m.annSeen=c.announce.id;toast('📣 '+c.announce.m,'ok');L('📣 Duyuru: '+c.announce.m,'ok');S.dirty=true;}
  }else if(S.ann){S.ann=null;S.dirty=true;}
  if(c.event&&c.event.id&&m.evtSeen!==c.event.id){
    m.evtSeen=c.event.id;
    if(Date.now()-c.event.t<12*3600e3)applyEvent(c.event);
  }
  if(c.taxRes&&typeof c.taxRes==='object')MP.rates=c.taxRes;if(c.prodTax&&typeof c.prodTax==='object')MP.pt=c.prodTax;
  if(!c.season&&S.season===undefined)S.season=0;
  if(c.season){
    if(S.season===undefined){S.season=c.season;}
    else if(S.season!==c.season&&!m.admin){
      const keep={name:m.name,annSeen:m.annSeen,evtSeen:m.evtSeen};
      const mu=S.mpUid;S=newState();S.adm={claimed:{},collected:0};S.bots=[];S.mpUid=mu;S.season=c.season;S.me.name=keep.name;S.me.annSeen=keep.annSeen;S.me.evtSeen=keep.evtSeen;S.live=true;
      L('🆕 Yeni sezon başladı! Herkes sıfırdan başlıyor.','ok');save();S.dirty=true;UI.tab='char';
    }else if(m.admin&&S.season!==c.season)S.season=c.season;
  }
  try{MP.ban=await MP.fb('GET','bans/'+MP.uid())||null;}catch(e){MP.ban=null;}
  const b=MP.ban;
  if(b&&b.wipe&&!m.admin&&b.wipe>(m.wipedAt||0)){ // yönetici ceza olarak ilerlemeyi sıfırladı / hesabı sildi
    const nm=m.name,mu=S.mpUid;S=newState();S.adm={claimed:{},collected:0};S.bots=[];S.mpUid=mu;S.season=c.season;S.me.name=nm;S.me.wipedAt=b.wipe;S.live=true;
    L('⚠️ Hesabın yönetici tarafından ceza olarak sıfırlandı.'+(b.why?' Sebep: '+b.why:''),'bad');save();S.dirty=true;UI.tab='char';return;
  }
  if(b&&b.jail>Date.now()&&!m.admin){const u=S.t+(b.jail-Date.now());if(!(m.jail>u))m.jail=u;S.dirty=true;}
  if(b&&b.ban!==MP.banShown){MP.banShown=b.ban;S.dirty=true;}
}
function banScreen(){
  const w=MP.ban&&MP.ban.why?esc(MP.ban.why):'';
  return `<div class="panel"><h2>⛔ Hesabın askıya alındı</h2><div class="al bad">Yönetici bu hesabın oyuna katılmasını durdurdu.${w?` Sebep: <b>${w}</b>`:''}</div></div>`;
}
const isBanned=()=>!!(MP.ban&&MP.ban.ban&&MP.role!=='admin');
/* ---- yönetici eylemleri ---- */
ACT.admAnnounce=async()=>{
  const v=(($('annTxt')||{}).value||'').trim().slice(0,200);if(!v)return msg('Duyuru metnini yaz.');
  try{await MP.fb('PUT','cfg/announce',{id:String(Date.now()),m:v,t:Date.now()});S.me.annSeen=null;msg('📣 Duyuru yayınlandı.','ok');MP.sync();}catch(e){msg(rulesHint(e));}
};
ACT.admAnnClear=async()=>{try{await MP.fb('DELETE','cfg/announce');S.ann=null;msg('Duyuru kaldırıldı.','ok');}catch(e){msg(rulesHint(e));}S.dirty=true;};
ACT.admEvent=async()=>{
  const k=($('evK')||{}).value;if(!EVT[k])return;
  const e={id:String(Date.now()),k:k,t:Date.now(),r:($('evR')||{}).value||'gold',v:+($('evV')||{}).value||0,h:+($('evH')||{}).value||2};
  try{await MP.fb('PUT','cfg/event',e);S.me.evtSeen=e.id;msg('🎲 Olay tetiklendi: '+EVT[k].n,'ok');}catch(x){msg(rulesHint(x));}
};
ACT.admSeason=async()=>{
  if(!confirm('YENİ SEZON: tüm oyuncuların ilerlemesi sıfırlanır (hesaplar kalır). Emin misin?'))return;
  try{const v=Date.now();await MP.fb('PUT','cfg/season',v);S.season=v;
    try{await MP.fb('DELETE','board');await MP.fb('DELETE','chat');}catch(e){}
    msg('🆕 Yeni sezon başlatıldı. Oyuncular bir sonraki eşitlemede sıfırlanır.','ok');}catch(e){msg(rulesHint(e));}
};
ACT.admMod=async d=>{
  const id=MP.sel;if(!id||botById(id))return msg('Önce gerçek bir oyuncu seç.');
  if(id===MP.uid())return msg('Kendine uygulayamazsın.');
  let cur={};try{cur=await MP.fb('GET','bans/'+id)||{};}catch(e){}
  const k=d.k,now=Date.now();
  if(k==='mute')cur.chat=cur.chat?null:true;
  else if(k==='ban')cur.ban=cur.ban?null:true;
  else if(k==='jail1')cur.jail=now+3600e3;else if(k==='jail24')cur.jail=now+24*3600e3;else if(k==='free')cur.jail=null;
  cur.why=(($('modWhy')||{}).value||cur.why||'').slice(0,80);cur.name=(MP.players[id]||{}).name||'';
  const o={};Object.keys(cur).forEach(x=>{if(cur[x]!==null&&cur[x]!==undefined&&cur[x]!==false)o[x]=cur[x];});
  try{if(o.chat||o.ban||o.jail)await MP.fb('PUT','bans/'+id,o);else await MP.fb('DELETE','bans/'+id);MP.bans=MP.bans||{};MP.bans[id]=o;msg('Uygulandı.','ok');}
  catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
async function admBansLoad(){try{MP.bans=await MP.fb('GET','bans')||{};}catch(e){}}
function adminExtra(){
  const opt=Object.keys(EVT).map(k=>`<option value="${k}">${EVT[k].n}</option>`).join('');
  const rs=RES.map(r=>`<option value="${r}">${RES_N[r]}</option>`).join('');
  const inp='style="width:100%;padding:7px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px;margin:3px 0"';
  let h=`<div class="panel"><h2>📣 Duyuru ve olaylar</h2><div class="grid">
  ${card('📣 Duyuru',`<input type="text" id="annTxt" ${inp} maxlength="200" placeholder="Tüm oyunculara mesaj" value="${esc((S.ann&&S.ann.m)||'')}"><div class="btns">${btn('Yayınla','data-a="admAnnounce"','gold')}${S.ann?btn('Kaldır','data-a="admAnnClear"','sm'):''}</div>`)}
  ${card('🎲 Olay tetikle',`<select id="evK" ${inp}>${opt}</select><select id="evR" ${inp}>${rs}</select><div class="row"><input type="number" id="evV" ${inp} placeholder="Para (yardım)"><input type="number" id="evH" ${inp} placeholder="Süre (sa)" value="2"></div>${btn('Tetikle','data-a="admEvent"','gold')}<p class="dim">Altın Çağı: süre; fiyat olayları: kaynak; yardım: miktar.</p>`)}
  ${card('🆕 Sezon',`<p class="dim">Tüm oyuncuların ilerlemesini sıfırlar, hesaplar kalır. Sıralama ve sohbet temizlenir.</p>${btn('Yeni sezon başlat','data-a="admSeason"','danger')}`)}
  </div></div>`;
  const id=MP.sel;
  if(id&&!botById(id)&&id!==MP.uid()&&MP.players[id]){
    const b=(MP.bans||{})[id]||{};
    h+=`<div class="panel"><h2>🛡️ Moderasyon: ${esc(MP.players[id].name)}</h2><div class="card"><p>${b.ban?'⛔ Banlı ':''}${b.chat?'🔇 Susturulmuş ':''}${b.jail>Date.now()?'⛓️ Hapiste ':''}${!b.ban&&!b.chat&&!(b.jail>Date.now())?'<span class="dim">Ceza yok</span>':''}</p>
    <input type="text" id="modWhy" ${inp} maxlength="80" placeholder="Sebep (isteğe bağlı)" value="${esc(b.why||'')}">
    <div class="btns">${btn(b.chat?'🔊 Susturmayı kaldır':'🔇 Sustur','data-a="admMod" data-k="mute"')}${btn('⛓️ Hapis 1sa','data-a="admMod" data-k="jail1"')}${btn('⛓️ Hapis 24sa','data-a="admMod" data-k="jail24"')}${b.jail>Date.now()?btn('Hapisten çıkar','data-a="admMod" data-k="free"'):''}${btn(b.ban?'✅ Banı kaldır':'⛔ Banla','data-a="admMod" data-k="ban"','danger')}</div>${(typeof opsRole==='function'&&opsRole()==='owner')?`<div class="btns">${btn('♻️ İlerlemeyi sıfırla (ceza)',`data-a="punish" data-k="reset" data-id="${esc(id)}"`,'danger')}${btn('🗑️ Hesabı kalıcı sil',`data-a="punish" data-k="delete" data-id="${esc(id)}"`,'danger')}</div><p class="dim">Sıfırlama: karakter yeniden başlar. Kalıcı silme: tüm veri silinir ve hesap banlanır.</p>`:''}</div></div>`;
  }
  return h;
}
/* ================= GÜNLÜK GÖREV, GİRİŞ ÖDÜLÜ, BAŞARIM ================= */
const dayKey=()=>{try{return new Date().toLocaleDateString('sv');}catch(e){return new Date().toISOString().slice(0,10);}};
const dayNum=()=>Math.floor(new Date(dayKey()+'T00:00:00Z').getTime()/864e5);
const QPOOL=[
  {id:'work',t:'Çalış',k:'works',n:8,i:'⛏️'},
  {id:'sell',t:'Kaynak sat',k:'sells',n:3,i:'💰'},
  {id:'buy',t:'Kaynak satın al',k:'buys',n:2,i:'🛒'},
  {id:'hit',t:'Savaşta vur',k:'hits',n:2,i:'⚔️'},
  {id:'craft',t:'Eşya üret',k:'crafts',n:1,i:'🔧'},
  {id:'chat',t:'Sohbette mesaj yaz',k:'msgs',n:1,i:'💬'}];
const ACHS=[
  {id:'l5',t:'Çırak',d:'Seviye 5',f:m=>m.level>=5,g:1},{id:'l10',t:'Usta',d:'Seviye 10',f:m=>m.level>=10,g:2},
  {id:'l25',t:'Üstat',d:'Seviye 25',f:m=>m.level>=25,g:5},{id:'l50',t:'Efsane',d:'Seviye 50',f:m=>m.level>=50,g:10},
  {id:'w10',t:'İşçi',d:'10 kez çalış',f:m=>(m.works||0)>=10,g:1},{id:'w100',t:'Çalışkan',d:'100 kez çalış',f:m=>(m.works||0)>=100,g:3},
  {id:'w1k',t:'Vazgeçmez',d:'1000 kez çalış',f:m=>(m.works||0)>=1000,g:10},
  {id:'h10',t:'Savaşçı',d:'10 vuruş',f:m=>(m.hits||0)>=10,g:1},{id:'h100',t:'Komutan',d:'100 vuruş',f:m=>(m.hits||0)>=100,g:4},
  {id:'f1',t:'Sanayici',d:'İlk fabrika',f:m=>m.facs.length>=1,g:2},
  {id:'p1',t:'Siyasetçi',d:'Bir partiye katıl',f:m=>!!m.party,g:1},
  {id:'m1',t:'Milyoner',d:'1.000.000₺ biriktir',f:m=>m.money>=1e6,g:3},{id:'m10',t:'Zengin',d:'10.000.000₺ biriktir',f:m=>m.money>=1e7,g:8},
  {id:'s50',t:'Tüccar',d:'50 satış yap',f:m=>(m.sells||0)>=50,g:3},
  {id:'ld',t:'Lider',d:'Devletin başkanı ol',f:()=>isLeader(),g:10}];
function qState(){
  const m=S.me,k=dayKey();
  if(!m.q||m.q.day!==k){
    const seed=dayNum(),pool=QPOOL.slice(),pick=[];
    for(let i=0;i<3;i++){const x=pool.splice((seed*7+i*3+i*i)%pool.length,1)[0];pick.push(x.id);}
    m.q={day:k,ids:pick,base:{works:m.works||0,sells:m.sells||0,buys:m.buys||0,hits:m.hits||0,crafts:m.crafts||0,msgs:m.msgs||0},done:{}};
  }
  return m.q;
}
const qProg=q=>q.ids.map(id=>{const d=QPOOL.find(x=>x.id===id),cur=(S.me[d.k]||0)-(q.base[d.k]||0);return Object.assign({cur:Math.min(d.n,Math.max(0,cur)),done:!!q.done[id],ok:cur>=d.n},d);});
const qReward=()=>({money:2000+S.me.level*300,gold:1,xp:10+S.me.level});
ACT.qClaim=d=>{
  const q=qState(),p=qProg(q).find(x=>x.id===d.id);if(!p||!p.ok||p.done)return;
  const r=qReward();q.done[p.id]=1;S.me.money+=r.money;S.me.stor.gold=Math.min(storCap(),S.me.stor.gold+r.gold);addXP(r.xp);
  msg(`✅ Görev tamam: +${fmt(r.money)}₺, +${r.gold} altın`,'ok');
  if(q.ids.every(i=>q.done[i])){S.me.stor.gold=Math.min(storCap(),S.me.stor.gold+2);L('🏅 Bugünün tüm görevleri tamam: +2 altın bonus.','ok');}
};
function streakInfo(){
  const m=S.me,k=dayKey(),s=m.streak||{last:'',n:0};
  const y=new Date(Date.now()-864e5).toLocaleDateString('sv');
  const can=s.last!==k,n=can?((s.last===y)?s.n+1:1):s.n;
  return {can:can,n:n,day:((n-1)%7)+1};
}
const streakReward=day=>({money:1000*day+S.me.level*100,gold:day===7?10:(day>=4?2:0),en:day>=3?30:0});
ACT.dailyClaim=()=>{
  const m=S.me,i=streakInfo();if(!i.can)return;
  const r=streakReward(i.day);m.streak={last:dayKey(),n:i.n};m.money+=r.money;m.stor.gold=Math.min(storCap(),m.stor.gold+r.gold);m.energy=Math.min(150,m.energy+r.en);
  msg(`🎁 Giriş ödülü (${i.day}. gün): +${fmt(r.money)}₺${r.gold?` +${r.gold} altın`:''}${r.en?` +${r.en} enerji`:''}`,'ok');
};
let _qT=0;
function questTick(){
  if(Date.now()-_qT<3000)return;_qT=Date.now();
  const m=S.me;m.ach=m.ach||{};let got=0;
  ACHS.forEach(a=>{if(!m.ach[a.id]&&a.f(m)){m.ach[a.id]=Date.now();m.stor.gold=Math.min(storCap(),m.stor.gold+a.g);toast(`🏆 Başarım: ${a.t} (+${a.g} altın)`,'ok');L(`🏆 Başarım açıldı: ${a.t} — ${a.d} (+${a.g} altın)`,'ok');got++;}});
  if(got)S.dirty=true;
}
function questBadge(){
  try{const q=qState();let n=qProg(q).filter(p=>p.ok&&!p.done).length;if(streakInfo().can)n++;return n;}catch(e){return 0;}
}
function tabQuest(){
  const q=qState(),ps=qProg(q),si=streakInfo(),r=qReward(),m=S.me;m.ach=m.ach||{};
  let h=`<div class="panel"><h2>🎁 Günlük giriş ödülü</h2><div class="card"><p>Seri: <b>${si.n}</b> gün · Bugünkü ödül (${si.day}. gün): <b>${fmt(streakReward(si.day).money)}₺</b>${streakReward(si.day).gold?` + ${streakReward(si.day).gold} altın`:''}${streakReward(si.day).en?` + ${streakReward(si.day).en} enerji`:''}</p>
  <div class="dim">7. günde büyük ödül (10 altın). Bir gün atlarsan seri başa döner.</div>
  ${btn(si.can?'🎁 Ödülü al':'Bugün alındı ✓','data-a="dailyClaim"','gold',!si.can)}</div></div>
  <div class="panel"><h2>📋 Bugünün görevleri</h2>`;
  ps.forEach(p=>{h+=`<div class="card"><h3>${p.i} ${p.t}: ${p.cur}/${p.n}</h3>${bar(p.cur,p.n,p.done?'#3fb950':undefined)}<p class="dim">Ödül: ${fmt(r.money)}₺ + ${r.gold} altın</p>${btn(p.done?'Alındı ✓':'Ödülü al',`data-a="qClaim" data-id="${p.id}"`,'gold',!p.ok||p.done)}</div>`;});
  h+=`<p class="hint">Görevler her gün yenilenir. Üçünü de bitirirsen +2 altın bonus.</p></div><div class="panel"><h2>🏆 Başarımlar (${Object.keys(m.ach).length}/${ACHS.length})</h2><div class="grid">`;
  ACHS.forEach(a=>{const o=!!m.ach[a.id];h+=`<div class="card" style="${o?'border-color:#3fb950':'opacity:.55'}"><h3>${o?'🏆':'🔒'} ${a.t}</h3><p class="dim">${a.d}</p><p class="dim">Ödül: ${a.g} altın</p></div>`;});
  return h+'</div></div>';
}
/* ================= YATIRIMLAR (para harcama yolları) ================= */
const INV={
  house:{i:'🏠',n:'Ev',d:'Her seviye +4 enerji/saat',max:5,cost:l=>40000*Math.pow(2.2,l)},
  depo:{i:'📦',n:'Depo genişletme',d:'Her seviye kaynak kapasitesi +25%',max:5,cost:l=>25000*Math.pow(2,l)},
  akad:{i:'🎓',n:'Akademi',d:'Her seviye kazanılan XP +8%',max:5,cost:l=>60000*Math.pow(2.3,l)},
  fab:{i:'🏭',n:'Verimlilik ofisi',d:'Her seviye çalışma kazancı +5%',max:5,cost:l=>80000*Math.pow(2.4,l)}
};
const invL=k=>((S.me.inv||{})[k])||0;
const invCost=k=>Math.round(INV[k].cost(invL(k))/100)*100;
ACT.invBuy=d=>{
  const k=d.k,I=INV[k],m=S.me;if(!I)return;
  if(invL(k)>=I.max)return msg('Bu yatırım en üst seviyede.');
  const c=invCost(k);if(m.money<c)return msg(`Yetersiz para (${fmt(c)}₺).`);
  m.money-=c;m.inv=m.inv||{};m.inv[k]=invL(k)+1;
  L(`${I.i} ${I.n} seviye ${m.inv[k]} oldu (−${fmt(c)}₺).`,'ok');msg(`${I.n} geliştirildi!`,'ok');
};
function invPanel(){
  let h='<div class="panel"><h2>💼 Yatırımlar</h2><p class="hint">Paranı kalıcı güçlendirmelere harca. Seviye attıkça maliyet artar.</p><div class="grid">';
  Object.keys(INV).forEach(k=>{const I=INV[k],l=invL(k),mx=l>=I.max;
    h+=card(`${I.i} ${I.n} <small>(${l}/${I.max})</small>`,`${bar(l,I.max,'#58a6ff')}<p class="dim">${I.d}</p>${btn(mx?'Maksimum ✓':'Geliştir · '+fmt(invCost(k))+'₺',`data-a="invBuy" data-k="${k}"`,'gold',mx||S.me.money<invCost(k))}`);});
  return h+'</div></div>';
}
/* ================= ANTRENMAN SAVAŞI (risksiz, gerçek savaş yokken) ================= */
const TR_COST=5;
function trState(){
  const m=S.me;if(!m.tr)m.tr={lv:1,hp:0,max:0,wins:0};
  const t=m.tr;
  if(!(t.max>0)){t.max=Math.round(hitDamage(null)*22*(1+t.lv*0.18));t.hp=t.max;}
  return t;
}
ACT.trHit=d=>{
  const m=S.me,t=trState(),n=d&&d.n==='all'?Math.floor(m.energy/TR_COST):1;
  if(m.jail>S.t)return msg('Hapistesin.');
  if(m.travel)return msg('Yoldasın.');
  if(m.energy<TR_COST)return msg(`Yetersiz enerji (${TR_COST}).`);
  let tot=0,k=0;
  while(k<Math.max(1,n)&&m.energy>=TR_COST&&t.hp>0){
    const dm=Math.max(1,Math.round(hitDamage(null)*(0.9+Math.random()*0.2)));
    m.energy-=TR_COST;t.hp-=dm;tot+=dm;k++;m.hits=(m.hits||0)+1;m.dmg=(m.dmg||0)+dm*0.25;addXP(2);
  }
  if(t.hp<=0){
    const mo=1500*t.lv+m.level*100,xp=15+t.lv*3;
    m.money+=mo;addXP(xp);t.wins++;
    if(t.lv%5===0)m.stor.gold=Math.min(storCap(),m.stor.gold+2);
    L(`🥊 Antrenman rakibi (Sv ${t.lv}) yenildi: +${fmt(mo)}₺, +${xp} XP${t.lv%5===0?', +2 altın':''}.`,'ok');
    msg(`🥊 Rakip yenildi! +${fmt(mo)}₺`,'ok');
    t.lv=Math.min(30,t.lv+1);t.max=0;trState();
  }else msg(`💥 ${fmt(tot)} hasar (${k} vuruş)`,'ok');
};
ACT.trReset=()=>{const t=S.me.tr;if(t){t.max=0;}trState();};
function trPanel(){
  const m=S.me,t=trState(),real=S.wars.some(w=>w.state!=='done'&&(w.att==='A'||w.def==='A'));
  return `<h2 style="margin-top:12px">🥊 Antrenman savaşı</h2><div class="card">
  <p class="dim">${real?'Devletin savaşta ama antrenman da yapabilirsin. ':'Gerçek savaş yok: antrenmanla XP ve para kazan. '}Risk yok; vuruş başına ${TR_COST} enerji. Rakibi yenince seviye atlar ve ödülü büyür. Hasarın %25'i rütbe puanına eklenir.</p>
  <p><b>Rakip: Sv ${t.lv}</b> · ${t.wins} galibiyet</p>
  <div class="bar"><div style="width:${clamp(t.hp/t.max*100,0,100)}%;background:#f85149"></div></div><p class="dim">${fmt(Math.max(0,t.hp))} / ${fmt(t.max)} can · vuruş ≈ ${fmt(hitDamage(null))}</p>
  <div class="btns">${btn('🥊 Vur','data-a="trHit"','danger')}${btn('Tüm enerjiyle vur','data-a="trHit" data-n="all"','danger')}</div></div>`;
}
/* ================= ORTAK DÜNYA: bölge valileri + oyuncular arası gerçek savaş (Firebase) ================= */
const SW={regs:{},wars:{},last:0,err:'',sig:'',busy:false};
const SW_CLAIM=100000,SW_DECL=50000,SW_PREP=10*60e3,SW_LEN=60*60e3,SW_MAXREG=3;
const swHue=uid=>{let h=0;for(const c of String(uid))h=(h*31+c.charCodeAt(0))%360;return `hsl(${h},75%,60%)`;};
const swMine=()=>Object.keys(SW.regs).filter(i=>SW.regs[i]&&SW.regs[i].o===MP.uid());
const swActive=()=>Object.keys(SW.wars).map(id=>Object.assign({id:id},SW.wars[id])).filter(w=>!w.win&&w.t1+5000>Date.now());
const swWarOn=i=>swActive().find(w=>+w.i===+i);
async function swPoll(){
  if(!MP.ok||SW.busy)return;SW.busy=true;SW.last=Date.now();
  try{
    const d=await MP.fb('GET','world')||{};
    SW.regs=d.regions||{};SW.wars=d.wars||{};SW.err='';
    const now=Date.now(),me=MP.uid(),m=S.me;
    // biten savaşları sonuçlandır
    for(const id of Object.keys(SW.wars)){
      const w=SW.wars[id];if(!w||!(w.t1<now-2000))continue;
      if(!w.win){
        const win=(+w.dA>+w.dD)?w.a:w.d,nm=(+w.dA>+w.dD)?w.an:w.dn;
        try{await MP.fb('PUT','world/wars/'+id+'/win',win);w.win=win;
          await MP.fb('PUT','world/regions/'+w.i,{o:win,on:nm||'?',t:now,w:id});SW.regs[w.i]={o:win,on:nm,t:now,w:id};}catch(e){}
      }else{
        const r=SW.regs[w.i];
        if(!r||(r.w!==id&&(r.t||0)<w.t1)){try{const nm=w.win===w.a?w.an:w.dn;await MP.fb('PUT','world/regions/'+w.i,{o:w.win,on:nm||'?',t:now,w:id});SW.regs[w.i]={o:w.win,on:nm,t:now,w:id};}catch(e){}}
      }
    }
    // saldırı bildirimi
    m.swSeen=m.swSeen||{};
    swActive().forEach(w=>{if(w.d===me&&!m.swSeen[w.id]){m.swSeen[w.id]=1;const rn=(S.regions[w.i]||{}).n||'bölgen';toast(`⚠️ ${w.an} ${rn} bölgene savaş açtı!`,'bad');L(`⚠️ ${w.an}, valisi olduğun ${rn} bölgesine savaş açtı (savaş ${Math.round((w.t0-now)/60000)} dk sonra başlıyor).`,'bad');S.dirty=true;}});
    // savaş ödülleri
    m.swClaimed=m.swClaimed||{};
    Object.keys(SW.wars).forEach(id=>{const w=SW.wars[id];if(!w||!w.win||m.swClaimed[id])return;
      const p=w.ps&&w.ps[me];m.swClaimed[id]=1;if(!p||!(+p.dmg>0))return;
      const wside=w.win===w.a?'A':'D',won=p.side===wside,rn=(S.regions[w.i]||{}).n||'';
      const mo=Math.min(300000,Math.round(p.dmg*2))+(won?30000:0),g=won?3:0;
      m.money+=mo;m.stor.gold=Math.min(storCap(),m.stor.gold+g);
      L(`${won?'🏆':'🎖️'} ${rn} savaşı bitti (${won?'kazanan taraf':'kaybeden taraf'}): katkın ${fmt(p.dmg)} → +${fmt(mo)}₺${g?` +${g} altın`:''}`,won?'ok':'info');S.dirty=true;});
    const ks=Object.keys(m.swClaimed);if(ks.length>60)ks.slice(0,30).forEach(k=>{delete m.swClaimed[k];delete m.swSeen[k];});
    // vali geliri
    const mine=swMine();
    if(mine.length){
      const last=m.swInc||now,hrs=Math.min(24,Math.max(0,(now-last)/3600e3));
      if(hrs>0.02){let g=0;mine.forEach(i=>{const r=S.regions[+i];g+=1500*hrs*(1+0.1*(r?r.idx.d:5))*(1+0.15*((r&&r.dev)||0));});
        m.money+=g;m.swInc=now;if(g>=1000){L(`🏛️ Vali geliri: +${fmt(g)}₺ (${mine.length} bölge)`,'ok');S.dirty=true;}}
    }else m.swInc=now;
    const sig=Object.keys(SW.regs).map(i=>i+(SW.regs[i].o||'')).join(',')+'|'+swActive().map(w=>w.id+(+w.dA)+'/'+(+w.dD)).join(',');
    if(sig!==SW.sig){SW.sig=sig;S.dirty=true;}
  }catch(e){SW.err=rulesHint(e);if(UI.tab==='sw')S.dirty=true;}
  SW.busy=false;
}
ACT.swClaim=async d=>{
  const i=+d.i,m=S.me,r=S.regions[i];
  if(!MP.ok)return msg('Önce giriş yap (Profil › Hesap).');
  if(m.level<8)return msg('Vali olmak için seviye 8 gerekli.');
  if(m.money<SW_CLAIM)return msg(`Yetersiz para (${fmt(SW_CLAIM)}₺).`);
  if(swMine().length>=SW_MAXREG)return msg(`En fazla ${SW_MAXREG} bölgeye vali olabilirsin.`);
  if(SW.regs[i])return msg('Bu bölgenin zaten bir valisi var.');
  try{await MP.fb('PUT','world/regions/'+i,{o:MP.uid(),on:m.name,t:Date.now()});m.money-=SW_CLAIM;SW.regs[i]={o:MP.uid(),on:m.name,t:Date.now()};
    m.swInc=m.swInc||Date.now();L(`🏛️ ${r.n} bölgesinin valisi oldun (−${fmt(SW_CLAIM)}₺). Saatlik gelir kazanırsın.`,'ok');MP.ev&&MP.ev(`${r.n} bölgesine vali oldu`);msg('Vali oldun!','ok');}
  catch(e){msg(/401|403|ermission/i.test(e.message)?'Bu bölge az önce başkasına geçti ya da kurallar güncel değil.':rulesHint(e));swPoll();}
  S.dirty=true;
};
ACT.swDeclare=async d=>{
  const i=+d.i,m=S.me,r=S.regions[i],reg=SW.regs[i];
  if(!MP.ok)return msg('Önce giriş yap (Profil › Hesap).');
  if(m.level<10)return msg('Savaş açmak için seviye 10 gerekli.');
  if(!reg)return msg('Bu bölge boş; vali olabilirsin.');
  if(reg.o===MP.uid())return msg('Kendi bölgene savaş açamazsın.');
  if(swWarOn(i))return msg('Bu bölgede zaten savaş var.');
  if(m.money<SW_DECL)return msg(`Yetersiz para (${fmt(SW_DECL)}₺).`);
  const id=Date.now()+'_'+MP.uid().slice(0,6),t0=Date.now()+SW_PREP;
  const w={i:i,a:MP.uid(),an:m.name,d:reg.o,dn:reg.on,t0:t0,t1:t0+SW_LEN,dA:0,dD:0};
  try{await MP.fb('PUT','world/wars/'+id,w);m.money-=SW_DECL;SW.wars[id]=w;L(`⚔️ ${r.n} bölgesine ${reg.on} aleyhine savaş ilan ettin (−${fmt(SW_DECL)}₺). 10 dk sonra başlar, 1 saat sürer.`,'ok');
    MP.ev&&MP.ev(`${r.n} için ${reg.on} aleyhine savaş açtı`);msg('Savaş ilan edildi!','ok');}
  catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
ACT.swHit=async d=>{
  const w=SW.wars[d.id],m=S.me,now=Date.now();
  if(!w)return msg('Savaş bulunamadı.');
  if(now<w.t0)return msg('Savaş henüz başlamadı.');if(now>w.t1)return msg('Savaş bitti.');
  if(m.jail>S.t)return msg('Hapistesin.');
  if(m.energy<10)return msg('Yetersiz enerji (10).');
  const side=d.side==='D'?'D':'A',dm=Math.max(1,Math.round(hitDamage(null)));
  m.energy-=10;
  try{
    await MP.fb('PUT','world/wars/'+d.id+'/d'+side,{'.sv':{increment:dm}});
    await MP.fb('PATCH','world/wars/'+d.id+'/ps/'+MP.uid(),{dmg:{'.sv':{increment:dm}},side:side,n:m.name});
    m.dmg=(m.dmg||0)+dm;m.hits=(m.hits||0)+1;addXP(6);
    w['d'+side]=(+w['d'+side]||0)+dm;msg(`💥 ${fmt(dm)} hasar`,'ok');
  }catch(e){m.energy+=10;msg(rulesHint(e));}
  S.dirty=true;
};
ACT.swRelease=async d=>{
  if(!confirm('Valiliği bırakmak istiyor musun? Bölge boşa düşer.'))return;
  try{await MP.fb('DELETE','world/regions/'+d.i);delete SW.regs[d.i];msg('Valilik bırakıldı.','ok');}catch(e){msg(rulesHint(e));}S.dirty=true;
};
function swAlerts(){
  if(!MP.ok)return [];const out=[],me=MP.uid(),now=Date.now();
  swActive().forEach(w=>{if(w.a!==me&&w.d!==me)return;const rn=(S.regions[w.i]||{}).n||'';
    out.push(`<div class="al ${w.d===me?'bad':'info'}">⚔️ Ortak savaş: <b>${esc(rn)}</b> — ${esc(w.an)} → ${esc(w.dn)} · ${now<w.t0?'başlamasına '+Math.max(1,Math.round((w.t0-now)/60000))+' dk':'bitişine '+Math.max(0,Math.round((w.t1-now)/60000))+' dk'} <button class="act sm blue" data-a="tab" data-t="sw">Git</button></div>`);});
  return out;
}
function tabSW(){
  let h=`<div class="panel"><h2>🤝 Ortak dünya — oyuncular arası</h2>`;
  if(!MP.ok)return h+'<div class="al warn">Ortak dünya için Profil › Hesap bölümünden giriş yap.</div></div>';
  if(SW.err)h+=`<div class="al bad">${esc(SW.err)}</div>`;
  const m=S.me,me=MP.uid(),now=Date.now();
  h+=`<p class="hint">Burada herkes aynı haritayı görür. Boş bir bölgeye <b>vali</b> ol (${fmt(SW_CLAIM)}₺, seviye 8): saatlik gelir kazanırsın. Başkasının bölgesine <b>savaş aç</b> (${fmt(SW_DECL)}₺, seviye 10): 10 dk hazırlık, 1 saat savaş; herkes istediği tarafa vurabilir, çok hasar veren taraf bölgeyi alır. Katkın ödül kazandırır. En fazla ${SW_MAXREG} bölgen olabilir.</p>`;
  const act=swActive();
  if(act.length){h+='<h2>Aktif savaşlar</h2><div class="grid">';
    act.forEach(w=>{const r=S.regions[w.i]||{n:'?'},tot=(+w.dA||0)+(+w.dD||0)||1,on=now>=w.t0&&now<=w.t1,my=w.ps&&w.ps[me];
      h+=card(`⚔️ <a class="lk" data-a="goCity" data-id="${r.id}">${esc(r.n)}</a>`,`<p>${esc(w.an)} <span class="dim">→</span> ${esc(w.dn)}</p><div class="bar2"><div style="width:${(+w.dA||0)/tot*100}%"></div></div><p class="dim">${fmt(+w.dA||0)} / ${fmt(+w.dD||0)} (saldırgan / savunan)${my?` · katkın ${fmt(my.dmg)}`:''}</p><p>${on?'bitişine '+Math.max(0,Math.round((w.t1-now)/60000))+' dk':'başlamasına '+Math.max(1,Math.round((w.t0-now)/60000))+' dk'}</p>
        <div class="btns">${btn(`⚔️ Saldırgana vur (${fmt(hitDamage(null))})`,`data-a="swHit" data-id="${w.id}" data-side="A"`,'danger',!on)}${btn('🛡️ Savunana vur',`data-a="swHit" data-id="${w.id}" data-side="D"`,'blue',!on)}</div>`);});
    h+='</div>';}
  const mine=swMine();
  h+=`<h2 style="margin-top:12px">Bölgeler <span class="dim">(valiliğin: ${mine.length}/${SW_MAXREG})</span></h2><div style="overflow-x:auto"><table><tr><th align=left>Bölge</th><th align=left>Vali</th><th></th></tr>`;
  S.regions.forEach(r=>{const reg=SW.regs[r.id],war=swWarOn(r.id);
    let act2='';
    if(!reg)act2=btn('Vali ol',`data-a="swClaim" data-i="${r.id}"`,'gold sm');
    else if(reg.o===me)act2=war?'<span class="bad">savaşta</span>':btn('Bırak',`data-a="swRelease" data-i="${r.id}"`,'sm');
    else act2=war?'<span class="bad">savaşta</span>':btn('Savaş aç',`data-a="swDeclare" data-i="${r.id}"`,'danger sm');
    h+=`<tr><td><a class="lk" data-a="goCity" data-id="${r.id}">${esc(r.n)}</a></td><td>${reg?`<span style="color:${swHue(reg.o)}">●</span> ${esc(reg.on)}${reg.o===me?' (sen)':''}`:'<span class="dim">boş</span>'}</td><td>${act2}</td></tr>`;});
  return h+'</table></div></div>';
}
/* ================= REHBER ================= */
function tabGuide(){
  const sec=(t,b)=>`<details class="card"><summary><b>${t}</b></summary><div style="margin-top:6px">${b}</div></details>`;
  return `<div class="panel"><h2>📖 Rehber</h2><p class="hint">Oyun gerçek zamanlıdır: sayfayı kapatsan da enerjin dolar, öğrenmen ve üretimin sürer (en fazla 3 gün).</p>
  ${sec('🏠 Başlangıç','<p>1) <b>Ana › Çalış</b>: kaynak üret, para ve altın kazan.<br>2) <b>Karakter</b>: bir yeteneği öğrenmeye başla (Güç, Eğitim, Dayanıklılık).<br>3) <b>Ekonomi › Depo</b>: kaynaklarını sat, <b>Yatırımlar</b> ile kalıcı güçlen.<br>4) <b>Görevler</b>: her gün giriş ödülü ve 3 görev.</p>')}
  ${sec('💰 Ekonomi','<p>Fiyatlar zamanla oynar, alıp satınca da etkilenir. <b>Oyuncu Pazarı</b>nda kaynaklarını kendi fiyatına satarsın; yöneticiye pazar vergisi ödenir. Altın en değerli kaynaktır; enerji içeceği ve bazı eşyalar altınla alınır.</p>')}
  ${sec('⚔️ Savaş','<p><b>Antrenman savaşı</b> risksizdir: XP ve para kazanırsın, rütbene katkı yapar. <b>Devlet savaşları</b> bota karşıdır. <b>Ortak dünya</b> savaşları gerçek oyuncular arasındadır: bir bölgenin valisine savaş açarsın, herkes bir tarafa vurur, çok hasar veren taraf bölgeyi alır.</p>')}
  ${sec('🏛️ Siyaset','<p>Seviye 5\'te partiye katıl, oy ver. Devletin başkanı vergileri, yasaları ve savaşı yönetir. Yeterince güçlüysen <b>darbe</b> yapabilirsin (riskli!). Vali olduğun bölgeden saatlik gelir alırsın.</p>')}
  ${sec('🏙️ Şehirler','<p><b>Dünya › Bölgeler</b>: bir şehre dokununca nüfus, indeksler, kaynaklar, binalar ve geliştirme seviyesi görünür. ⭐ <b>Kritik şehirler</b> sahibi devlete bonus verir (üretim, savunma, XP, öğrenme). Şehre para bağışlayarak <b>geliştirme</b> seviyesini artırırsın: çalışma verimi ve tesis üretimi yükselir.</p>')}
  ${sec('⚙️ Otomatik modlar','<p><b>Menü › Otomatik</b>: oyun içi parayla otomatik çalışma ve otomatik savaş paketi satın al. İstek yöneticiye gider; onaylanırsa mod açılır, reddedilirse paran iade edilir.</p>')}
  ${sec('👥 Sosyal','<p><b>Sohbet</b>: genel, parti kanalı ve özel mesaj. <b>Sıralama</b>: seviye, servet, hasar ve vergiye göre. Kurallara uy: küfür ve reklam yasak; yönetici susturabilir.</p>')}
  ${sec('🌍 Hesap','<p>Profil › Hesap: kullanıcı adı veya e-postayla giriş yap; oyunun hesabında bulutta durur, her telefondan devam edersin. Şifreni unutursan e-postayla sıfırlayabilirsin (e-postayla açtıysan).</p>')}</div>`;
}
/* ================= CASUSLUK / İSTİHBARAT ================= */
const SPY_COST=8000,SPY_EN=15,SPY_CD=30*MIN;
function spyChance(k){
  const edu=perk('edu'),lvl=S.me.level;
  return clamp(0.55+edu/500+lvl/400-(S.states[k].aggr||0.5)*0.12,0.25,0.9);
}
ACT.spy=d=>{
  const k=d.s,s=S.states[k],m=S.me;
  if(!s||k==='A')return;
  if(m.jail>S.t)return msg('Hapistesin.');
  if(m.travel)return msg('Yoldasın.');
  m.spyCd=m.spyCd||{};
  if((m.spyCd[k]||0)>S.t)return msg('Bu devlete yeni casus göndermek için beklemelisin.');
  if(!m.admin&&m.money<SPY_COST)return msg(`Yetersiz para (${fmt(SPY_COST)}₺).`);
  if(!m.admin&&m.energy<SPY_EN)return msg(`Yetersiz enerji (${SPY_EN}).`);
  if(!m.admin){m.money-=SPY_COST;m.energy-=SPY_EN;}
  m.spyCd[k]=S.t+SPY_CD;
  if(Math.random()<spyChance(k)){
    const cand=adjacentStates(k).filter(x=>x!=='O'),tgt=cand.length?cand.slice().sort((x,y)=>S.rel[k][x]-S.rel[k][y])[0]:null;
    const wars=atWar(k).map(w=>`${nameOf(w.att)} → ${nameOf(w.def)} (${S.regions[w.region].n})`);
    m.intel=m.intel||{};
    m.intel[k]={t:S.t,power:powerOf(k),mine:powerOf('A'),rel:relTo('A',k),regs:regOf(k).length,aggr:s.aggr||0,bonus:s.bonus||1,next:s.next,
      tgt:tgt,tgtRel:tgt?S.rel[k][tgt]:0,wars:wars,truce:!!(s.truce&&s.truce.A>S.t),mil:!!(A().treaty.mil[k]>S.t),
      threat:(tgt==='A'&&S.rel[k].A<=-20&&powerOf(k)>=powerOf('A')*0.8&&S.t>=S.protectUntil)};
    addXP(8);
    L(`🕵️ Casus ${nameOf(k)} hakkında rapor getirdi.`,'ok');msg('🕵️ İstihbarat raporu hazır.','ok');
  }else{
    addRel('A',k,-6);
    L(`🕵️ Casus ${nameOf(k)} tarafından yakalandı: ilişkiler −6.`,'bad');msg('🕵️ Casus yakalandı! İlişkiler bozuldu.');
  }
};
function intelCard(k){
  const m=S.me,s=S.states[k],i=(m.intel||{})[k],rel=relTo('A',k),cd=((m.spyCd||{})[k]||0)>S.t;
  const ch=Math.round(spyChance(k)*100);
  let b=`<p>İlişki: <b class="${rel>20?'ok':rel<-20?'bad':'warn'}">${Math.round(rel)}</b> · Bölge: ${regOf(k).length}</p>${bar(rel+100,200,rel>20?'#3fb950':rel<-20?'#f85149':'#d29922')}`;
  if(i){
    const age=S.t-i.t,old=age>6*HOUR;
    b+=`<div class="q ${i.threat?'bad':''}" style="${old?'opacity:.6':''}"><b>📄 İstihbarat raporu</b> <span class="dim">(${fmtDur(age)} önce${old?' · eskimiş':''})</span><br>
    Askeri güç: <b>${f1(i.power)}</b> (bizimki ${f1(i.mine)}) · saldırganlık ${f1(i.aggr)}<br>
    Bir sonraki karar: ${i.next>S.t?cd_(i.next):'her an'}<br>
    ${i.tgt?`Gözüne kestirdiği devlet: <b>${esc(nameOf(i.tgt))}</b> (ilişki ${Math.round(i.tgtRel)})<br>`:''}
    ${i.wars.length?`Savaşları: ${i.wars.map(esc).join('; ')}<br>`:'Şu an savaşta değil.<br>'}
    ${i.mil?'Askeri anlaşmamız var. ':''}${i.truce?'Ateşkes sürüyor. ':''}
    ${i.threat?'<b class="bad">⚠️ Devletimize saldırı hazırlığı olabilir!</b>':'<span class="ok">Yakın tehdit görünmüyor.</span>'}</div>`;
  }
  b+=btn(cd?`Bekle (${fmtDur(m.spyCd[k]-S.t)})`:`🕵️ Casus gönder · ${fmt(SPY_COST)}₺ + ${SPY_EN} enerji`,`data-a="spy" data-s="${k}"`,'purple',cd);
  b+=`<p class="dim">Başarı şansı ≈ %${ch}. Yakalanırsan ilişkiler bozulur.</p>`;
  return card(`🌐 ${esc(nameOf(k))}`,b);
}
const cd_=t=>fmtDur(t-S.t);
function tabSpy(){
  return `<div class="panel"><h2>🕵️ İstihbarat</h2><p class="hint">Casus gönder, diğer devletlerin gücünü ve niyetini öğren. Rapor birkaç saat içinde eskir. Eğitim ve seviye başarı şansını artırır.</p><div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(240px,1fr))">${AI_S.map(intelCard).join('')}</div></div>`;
}
/* ================= AYARLAR: ses, titreşim, tema, yazı boyutu ================= */
const PREF_K='bm_prefs';
let PREF={snd:1,vib:1,theme:'dark',fs:0};
try{PREF=Object.assign(PREF,JSON.parse(localStorage.getItem(PREF_K)||'{}'));}catch(e){}
function prefSave(){try{localStorage.setItem(PREF_K,JSON.stringify(PREF));}catch(e){}}
function prefApply(){
  const c=document.documentElement.classList;
  let light=PREF.theme==='light';
  try{if(PREF.theme==='auto')light=window.matchMedia('(prefers-color-scheme: light)').matches;}catch(e){}
  c.toggle('light',light);c.toggle('fs1',PREF.fs===1);c.toggle('fs2',PREF.fs===2);
  const tc=document.querySelector('meta[name=theme-color]');if(tc)tc.setAttribute('content',light?'#eef1f6':'#07090f');
}
let _ac=null,_fbT=0;
function tone(f,d,at,vol){
  try{
    _ac=_ac||new (window.AudioContext||window.webkitAudioContext)();
    if(_ac.state==='suspended')_ac.resume();
    const o=_ac.createOscillator(),g=_ac.createGain(),t0=_ac.currentTime+(at||0);
    o.type='sine';o.frequency.value=f;g.gain.setValueAtTime(0.0001,t0);g.gain.exponentialRampToValueAtTime(vol||0.12,t0+0.01);g.gain.exponentialRampToValueAtTime(0.0001,t0+d);
    o.connect(g);g.connect(_ac.destination);o.start(t0);o.stop(t0+d+0.02);
  }catch(e){}
}
function feedback(kind){
  const n=Date.now();if(n-_fbT<250)return;_fbT=n;
  try{if(navigator.userActivation&&!navigator.userActivation.hasBeenActive)return;}catch(e){}
  if(kind!=='ok'&&kind!=='bad'&&kind!=='warn')return;
  if(PREF.snd){if(kind==='ok'){tone(660,0.09);tone(880,0.12,0.09);}else if(kind==='bad'){tone(220,0.22,0,0.16);}else tone(440,0.12);}
  try{if(PREF.vib&&navigator.vibrate)navigator.vibrate(kind==='bad'?[60,40,60]:kind==='ok'?25:40);}catch(e){}
}
const _toastBase=toast;
toast=function(m,c){_toastBase(m,c);try{feedback(c);}catch(e){}};
ACT.prefSet=d=>{
  const k=d.k;let v=d.v;if(k==='snd'||k==='vib')v=+v;if(k==='fs')v=+v;
  PREF[k]=v;prefSave();prefApply();
  if(k==='snd'&&v)tone(660,0.09),tone(880,0.12,0.09);
  if(k==='vib'&&v){try{navigator.vibrate&&navigator.vibrate(60);}catch(e){}}
};
function tabSettings(){
  const o=(k,v,label)=>btn(label,`data-a="prefSet" data-k="${k}" data-v="${v}"`,String(PREF[k])===String(v)?'gold':'sm');
  return `<div class="panel"><h2>🎛️ Ayarlar</h2>
  ${card('🔊 Ses',`<div class="btns">${o('snd',1,'Açık')}${o('snd',0,'Kapalı')}</div><p class="dim">Ödül, hata ve uyarılarda kısa bir ses çalar.</p>`)}
  ${card('📳 Titreşim',`<div class="btns">${o('vib',1,'Açık')}${o('vib',0,'Kapalı')}</div><p class="dim">Telefonunuz destekliyorsa bildirimlerde titrer (iPhone Safari titreşimi desteklemez).</p>`)}
  ${card('🎨 Tema',`<div class="btns">${o('theme','dark','Koyu')}${o('theme','light','Açık')}${o('theme','auto','Telefona uy')}</div>`)}
  ${card('🔠 Yazı boyutu',`<div class="btns">${o('fs',0,'Normal')}${o('fs',1,'Büyük')}${o('fs',2,'Çok büyük')}</div>`)}
  </div>`;
}
/* ================= YENİ OYUNCU İLK ADIMLAR ================= */
function firstSteps(){
  const m=S.me;
  return [
    ['Çalış: kaynak üret',(m.works||0)>=1,'work'],
    ['Karakter: bir yetenek öğrenmeye başla',!!(m.learn||m.str>30||m.edu>30||m.end>30),'char'],
    ['Depodan bir kaynak sat',(m.sells||0)>=1,'store'],
    ['Günlük giriş ödülünü al',!!(m.streak&&m.streak.last),'quest'],
    ['Sohbete bir mesaj yaz',(m.msgs||0)>=1,'chat'],
    ['Seviye 5\'e ulaş ve bir partiye katıl',!!m.party,'party']];
}
function tutCard(){
  if(S.tut)return '';
  const st=firstSteps(),done=st.filter(x=>x[1]).length;
  if(done===st.length&&S.me.level>=4)return '';
  return `<div class="card glow" style="margin-bottom:10px"><h3>👋 İlk adımlar <span class="owner">${done}/${st.length}</span></h3>${bar(done,st.length,'#3fb950')}
  ${st.map(s=>`<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:4px 0;border-bottom:1px solid var(--bg4)"><span style="font-size:13px;${s[1]?'opacity:.55;text-decoration:line-through':''}">${s[1]?'✅':'⬜'} ${s[0]}</span>${s[1]?'':btn('Git',`data-a="tab" data-t="${s[2]}"`,'sm blue')}</div>`).join('')}
  <div class="btns">${btn('Gizle','data-a="tutOff"','sm')}</div></div>`;
}
prefApply();
/* ================= OTOMATİK ÇALIŞMA / OTOMATİK SAVAŞ (yönetici onayıyla) ================= */
const AUTO_SKU={
  work7:{k:'work',d:7,p:150000,n:'⚙️ Otomatik çalışma · 7 gün'},
  work30:{k:'work',d:30,p:500000,n:'⚙️ Otomatik çalışma · 30 gün'},
  war7:{k:'war',d:7,p:200000,n:'⚔️ Otomatik savaş · 7 gün'},
  war30:{k:'war',d:30,p:700000,n:'⚔️ Otomatik savaş · 30 gün'}
};
const AU_STEP=5; // bir adımda en çok vuruş/çalışma
const auOf=()=>{const m=S.me;if(!m.au)m.au={work:0,war:0,res:'',sell:true,st:{w:0,h:0}};return m.au;};
const auOn=k=>{const a=S.me&&S.me.au;return !!(a&&a[k]>S.t);};
function autoRun(){
  const m=S.me,a=m.au;if(!a||m.admin)return;
  if(m.travel||m.jail>S.t)return;
  if(a.war>S.t){
    const w=S.wars.find(x=>x.state==='on'&&(x.att==='A'||x.def==='A'));
    if(w){const hr=a.mode==='hourly',fr=(S.t-(m.fhAt||0))>=FH_MS;if(!hr||fr){let n=0;const lim=hr?1:AU_STEP;while(n<lim&&(m.energy>=10||(hr&&fr&&n===0))){const r=doHit(w.id);if(typeof r==='string')break;n++;a.st.h++;}if(n)return;}}
  }
  if(a.work>S.t){
    const r=myReg(),war=a.war>S.t&&S.wars.some(x=>x.state==='on'&&(x.att==='A'||x.def==='A'));
    const keep=war?10:0,ec=energyCost();
    let rs=a.res&&YIELD[a.res]&&r.res[a.res].c>0?a.res:RES.filter(k=>YIELD[k]&&r.res[k].c>0).sort((p,q)=>S.prices[q]*YIELD[q]-S.prices[p]*YIELD[p])[0];
    if(!rs)return;
    let n=0;
    while(n<AU_STEP&&m.energy>=ec+keep){
      if(a.sell&&m.stor[rs]>=storCap()*0.9)sellRes(rs,1e9);
      const q=doWork(rs);if(typeof q==='string')break;n++;a.st.w++;}
  }
}
/* ---- satın alma ---- */
function autoActivate(sku,from){
  const s=AUTO_SKU[sku];if(!s)return;const a=auOf();
  a[s.k]=Math.max(a[s.k],S.t)+s.d*24*HOUR;
  L(`${s.n} etkinleşti${from?' ('+from+')':''}.`,'ok');S.dirty=true;
}
ACT.autoBuy=d=>{
  const sku=d.s,s=AUTO_SKU[sku],m=S.me;if(!s)return;
  if(m.admin){autoActivate(sku,'yönetici');return msg('✅ Etkinleşti.','ok');}
  if(m.money<s.p)return msg('Yetersiz para ('+fmt(s.p)+'₺).');
  if(typeof MP==='undefined'||!MP.ok||!MP.owner||MP.owner===MP.uid()){ // tek oyunculu: doğrudan
    m.money-=s.p;autoActivate(sku);return msg('✅ Etkinleşti.','ok');}
  m.apend=m.apend||[];
  if(m.apend.some(x=>x.s===sku))return msg('Bu paket için onay bekleniyor.');
  const id='a'+Date.now().toString(36)+Math.floor(Math.random()*1e4).toString(36);
  m.money-=s.p;m.apend.push({id:id,s:sku,amt:s.p,t:Date.now()});
  m.psettle=m.psettle||[];m.psettle.push({to:MP.owner,id:id,kind:'areq',sku:sku,amt:s.p,bn:m.name,from:MP.uid(),t:Date.now()});
  L(`⏳ ${s.n} için istek yöneticiye gönderildi. Para onaya kadar bekletilir; reddedilirse iade edilir.`,'info');
  msg('⏳ İstek yöneticiye gönderildi.','ok');
};
ACT.autoSet=d=>{const a=auOf();if(d.k==='sell')a.sell=!a.sell;else if(d.k==='res')a.res=($('auRes')||{}).value||'';};
/* ---- yönetici: onay / red ---- */
function autoReqs(){const a=(S.adm=S.adm||{claimed:{},collected:0});return a.autoReq=a.autoReq||[];}
ACT.autoOk=d=>{
  const L0=autoReqs(),i=L0.findIndex(x=>x.id===d.id);if(i<0)return;const x=L0[i];
  S.me.money+=x.amt;S.adm.collected+=x.amt;
  S.me.psettle=S.me.psettle||[];S.me.psettle.push({to:x.from,id:'g'+x.id,kind:'agrant',sku:x.sku,amt:x.amt,bn:'Yönetici',t:Date.now()});
  L0.splice(i,1);L(`✅ ${x.bn} için ${AUTO_SKU[x.sku].n} onaylandı: +${fmt(x.amt)}₺`,'ok');msg('✅ Onaylandı, para hesabına geçti.','ok');
};
ACT.autoNo=d=>{
  const L0=autoReqs(),i=L0.findIndex(x=>x.id===d.id);if(i<0)return;const x=L0[i];
  S.me.psettle=S.me.psettle||[];S.me.psettle.push({to:x.from,id:'r'+x.id,kind:'arej',sku:x.sku,amt:x.amt,bn:'Yönetici',t:Date.now()});
  L0.splice(i,1);msg('Reddedildi, para oyuncuya iade edilecek.','ok');
};
ACT.autoGift=d=>{ // yönetici bir yapay zekâya / kendine bedava verir (kendi testi için)
  autoActivate(d.s,'yönetici');
};
/* ---- sunucudan gelen kayıtlar (settleCollect çağırır) ---- */
function autoHandle(k,x){
  const m=S.me;
  if(x.kind==='areq'){
    const L0=autoReqs();if(!L0.some(y=>y.id===k)&&AUTO_SKU[x.sku]&&+x.amt>0)L0.push({id:k,sku:x.sku,amt:Math.min(+x.amt,AUTO_SKU[x.sku].p),bn:String(x.bn||'Oyuncu').slice(0,30),from:String(x.from||''),t:+x.t||Date.now()});
    if(L0.length>100)L0.shift();
    toast('⚙️ Yeni otomatik mod isteği var','ok');return true;}
  if(x.kind==='agrant'){
    m.apend=(m.apend||[]).filter(y=>y.s!==x.sku);autoActivate(x.sku,'yönetici onayladı');return true;}
  if(x.kind==='arej'){
    m.apend=(m.apend||[]).filter(y=>y.s!==x.sku);m.money+=Math.min(+x.amt||0,AUTO_SKU[x.sku]?AUTO_SKU[x.sku].p:0);
    L(`↩️ ${(AUTO_SKU[x.sku]||{n:'İstek'}).n} reddedildi, ${fmt(x.amt)}₺ iade edildi.`,'warn');S.dirty=true;return true;}
  return false;
}
/* ---- yapay zekâ oyuncular da satın alır ---- */
function botAuto(b,rate){
  if(!b.au&&Math.random()<0.06&&b.m>AUTO_SKU.work7.p*0.12){
    const p=Math.round(AUTO_SKU.work7.p*0.12); // oyun içi ölçeğe uygun küçük bedel
    b.m-=p;b.t+=0;S.me.money+=p;if(S.adm)S.adm.collected+=p;b.au=Date.now()+7*24*3600e3;botEv(b,'⚙️ otomatik çalışma satın aldı',1);}
}
/* ---- sekme ---- */
function tabAuto(){
  const m=S.me,a=auOf(),isAdm=(typeof MP!=='undefined'&&MP.role==='admin')||m.admin;
  const left=k=>a[k]>S.t?fmtDur(a[k]-S.t):'kapalı';
  let h=`<div class="panel"><h2>⚙️ Otomatik modlar</h2><div class="grid">
  ${card('⚙️ Otomatik çalışma',`<div class="big ${a.work>S.t?'ok':'dim'}">${left('work')}</div><p class="dim">Enerji dolunca kendiliğinden çalışır, depo dolmak üzereyse satar.</p>`)}
  ${card('⚔️ Otomatik savaş',`<div class="big ${a.war>S.t?'ok':'dim'}">${left('war')}</div><p class="dim">Devletin savaştaysa enerjin yettikçe vurur. Savaş varken çalışma enerjiden pay bırakır.</p>`)}
  ${card('📊 Bu modlarla',`<p>${a.st.w} çalışma · ${a.st.h} vuruş</p>`)}
  </div>`;
  if(m.admin)h+='<p class="hint">Yönetici olarak enerji harcamazsın; modlar sende gerekmez ama aşağıdan deneyebilirsin.</p>';
  h+=`<div class="card" style="margin-top:8px"><h3>Ayarlar</h3><div class="row" style="margin:4px 0">${sel('auRes',[['','En kârlı kaynak']].concat(RES.filter(r=>YIELD[r]).map(r=>[r,RES_I[r]+' '+RES_N[r]])),a.res||'')}</div>
  <div class="btns">${btn(a.sell?'💰 Otomatik satış: açık':'💰 Otomatik satış: kapalı','data-a="autoSet" data-k="sell"','sm')}${btn('Kaynağı kaydet','data-a="autoSet" data-k="res"','sm')}</div></div>
  <div class="grid" style="margin-top:8px">`;
  Object.keys(AUTO_SKU).forEach(k=>{const s=AUTO_SKU[k],pend=(m.apend||[]).some(x=>x.s===k);
    h+=card(s.n,`<div class="big">${fmt(s.p)}₺</div>${pend?'<p class="warn">⏳ Yönetici onayı bekleniyor</p>':btn(m.admin?'Etkinleştir':'Satın al · onaya gönder',`data-a="autoBuy" data-s="${k}"`,'gold')}`);});
  h+=`</div><p class="hint">Satın alma isteği yöneticiye gider. Onaylanırsa mod açılır ve ücret yöneticiye geçer; reddedilirse paran iade edilir.</p></div>`;
  if(isAdm){const L0=autoReqs();
    h+=`<div class="panel"><h2>📬 Onay bekleyen istekler (${L0.length})</h2>${L0.length?L0.map(x=>`<div class="card"><b>${esc(x.bn)}</b> · ${AUTO_SKU[x.sku].n} · <b>${fmt(x.amt)}₺</b><div class="btns">${btn('✅ Onayla','data-a="autoOk" data-id="'+x.id+'"','gold')}${btn('❌ Reddet','data-a="autoNo" data-id="'+x.id+'"','danger sm')}</div></div>`).join(''):'<p class="dim">Bekleyen istek yok.</p>'}</div>`;}
  return h;
}
/* ================= ŞEHİRLER: bilgi, binalar, kritik şehir bonusu, şehir geliştirme ================= */
const CRIT_KINDS=[['work','⛏️','Üretim','çalışma verimi'],['power','🛡️','Savunma','askeri güç'],['xp','⭐','Deneyim','kazanılan XP'],['learn','🎓','Bilgelik','öğrenme hızı']];
let _crit=null;
function critList(){ // en zengin rezervli 4 bölge "kritik şehir"dir; her biri bir bonus türü verir
  if(_crit)return _crit;
  const sc=S.regions.map(r=>({id:r.id,v:RES.reduce((a,k)=>a+r.res[k].m*(PRICE0[k]/100),0)})).sort((a,b)=>b.v-a.v||a.id-b.id).slice(0,4);
  _crit=sc.map((x,i)=>({id:x.id,k:CRIT_KINDS[i][0]}));return _crit;
}
const critOf=id=>critList().find(c=>c.id===id)||null;
const devOf=r=>r.dev||0;
function critBonus(state,kind){ // devletin kritik şehirlerden aldığı toplam bonus (oran)
  let b=0;critList().forEach(c=>{if(c.k===kind){const r=S.regions[c.id];if(r&&r.state===state)b+=0.06+0.01*devOf(r);}});
  if(state==='A'&&typeof swMine==='function'&&typeof MP!=='undefined'&&MP.ok)swMine().forEach(i=>{const cc=critOf(+i);if(cc&&cc.k===kind)b+=0.06+0.01*devOf(S.regions[+i]);}); // ortak dünyada valisi olduğun kritik şehir sana da bonus verir
  return b;
}
const devCost=l=>Math.round(150000*(l+1)*Math.pow(1.6,l));
const cityPop=r=>Math.round(2000*(r.idx.d+1)*(1+0.12*devOf(r))+((typeof BOTAGG!=='undefined'&&BOTAGG.reg&&BOTAGG.reg[r.id])||0)*10);
const devFx=l=>`çalışma verimi +%${3*l} · tesis üretimi +%${2*l}`;
UI.city=null;
ACT.cityPick=d=>{UI.city=(d.id===''||d.id===undefined)?null:+d.id;};
ACT.cityFund=d=>{
  const r=S.regions[UI.city],m=S.me,v=Math.max(0,+d.v||0);if(!r||!v)return;
  if(devOf(r)>=10)return msg('Bu şehir zaten en üst seviyede.');
  if(m.money<v)return msg('Yetersiz para.');
  m.money-=v;r.devP=(r.devP||0)+v;let up=0;
  while(devOf(r)<10&&r.devP>=devCost(devOf(r))){r.devP-=devCost(devOf(r));r.dev=devOf(r)+1;up++;}
  if(devOf(r)>=10)r.devP=0;
  m.donated=(m.donated||0)+v;
  if(up){L(`🏙️ ${r.n} gelişti: seviye ${r.dev}! (${devFx(r.dev)})`,'ok');news(`${r.n} şehri geliştirme seviyesi ${r.dev}'e yükseldi.`);}
  msg(up?`🏙️ ${r.n} seviye ${r.dev}!`:`💰 ${fmt(v)}₺ bağışlandı.`,'ok');
};
function bldFx(b,lv){
  const B=BUILD[b];
  const fx={hospital:`❤️ sağlık +${lv} · enerji yenilenmesi +${f1(lv*1.5)}/sa (bölgede ikamet edenlere)`,school:`🎓 eğitim +${lv} · öğrenme süresi kısalır`,base:`🎖️ askeri +${lv} · devletin gücü +${lv*7}`,house:`🏘️ gelişmişlik +${lv} · nüfus ve verim artar · devlet gücü +${lv*2}`,
    academy:`saldırı hasarı +%${5*lv}`,library:`öğrenme süresi −%${5*lv}`};
  return fx[b]||B.d;
}
function tabMap(){
  if(UI.city!==null&&S.regions[UI.city])return tabCity(S.regions[UI.city]);
  const m=S.me,cl=critList();
  let h=`<div class="panel"><h2>🗺️ Şehirler</h2><p class="hint">Bir şehre dokun: nüfus, binalar, kaynaklar ve geliştirme bilgisi. ⭐ <b>Kritik şehirler</b> sahibi devlete özel bonus verir. İndeksler: ❤️ sağlık · 🎖️ askeri · 🎓 eğitim · 🏘️ gelişmişlik.</p>
  <div class="card"><h3>⭐ Kritik şehirler</h3>${cl.map(c=>{const r=S.regions[c.id],K=CRIT_KINDS.find(x=>x[0]===c.k);return `<p>${K[1]} <b>${esc(r.n)}</b> — ${K[2]} (+%${Math.round((0.06+0.01*devOf(r))*100)} ${K[3]}) · <span class="${r.state==='A'?'ok':'dim'}">${esc(nameOf(r.state))}</span> <button class="act sm" data-a="cityPick" data-id="${r.id}">Aç</button></p>`;}).join('')}</div>`;
  Object.keys(STATE_N).forEach(s=>{
    const regs=regOf(s);if(!regs.length)return;
    h+=`<h2 style="margin-top:12px">${s==='A'?'🏠 ':''}${nameOf(s)} <span class="dim">(${regs.length} şehir)</span></h2><div class="grid">`;
    regs.forEach(r=>{const here=m.loc===r.id,home=m.res===r.id,c=critOf(r.id);
      h+=card(`${c?'⭐ ':''}${esc(r.n)} ${here?'📍':''}${home?'🏠':''}`,
        `<p>❤️${r.idx.h} 🎖️${r.idx.m} 🎓${r.idx.e} 🏘️${r.idx.d} · 🏙️ sv ${devOf(r)}</p><p class="dim">👥 ${fmt(cityPop(r))}${r.coast?' · 🌊':''}${r.moon?' · 🌙':''}</p>
        <div class="btns">${btn('📋 Şehir bilgisi',`data-a="cityPick" data-id="${r.id}"`,'sm')}</div>`,here?'glow':'');});
    h+='</div>';});
  return h+'</div>';
}
function tabCity(r){
  const m=S.me,c=critOf(r.id),here=m.loc===r.id,home=m.res===r.id,hops=hopsTo(m.loc,r.id),l=devOf(r),cost=l<10?devCost(l):0,K=c&&CRIT_KINDS.find(x=>x[0]===c.k);
  const bl=Object.keys(BUILD).filter(k=>(r.b[k]||0)>0);
  let h=`<div class="panel"><div class="btns">${btn('← Şehirler','data-a="cityPick" data-id=""','sm')}</div>
  <h2>${c?'⭐ ':''}${esc(r.n)} ${here?'📍':''}${home?'🏠':''}</h2>
  <p class="dim"><a class="lk" data-a="tab" data-t="state">${esc(nameOf(r.state))}</a>${r.coast?' · 🌊 kıyı':''}${r.moon?' · 🌙 Ay':''} · komşular: ${r.adj.map(j=>`<a class="lk" data-a="goCity" data-id="${j}">${esc(S.regions[j].n)}</a>`).join(', ')||'—'}</p>
  <div class="grid">
   ${card('👥 Nüfus',`<div class="big">${fmt(cityPop(r))}</div><p class="dim">Gelişmişlik ve geliştirme seviyesiyle büyür.</p>`)}
   ${card('📊 İndeksler',`<p>❤️ Sağlık <b>${r.idx.h}</b> — enerji yenilenmesi +${f1(Math.max(0,r.idx.h-3)*1.5)}/sa</p><p>🎖️ Askeri <b>${r.idx.m}</b> — devlet gücüne +${r.idx.m*7}</p><p>🎓 Eğitim <b>${r.idx.e}</b> — öğrenme süresi −%${Math.round(Math.min(r.idx.e,11)/50*100)}</p><p>🏘️ Gelişmişlik <b>${r.idx.d}</b> — çalışma verimi +%${r.idx.d*2}</p>`)}
   ${card('⛏️ Yer altı kaynakları',RES.filter(k=>r.res[k].m>0).map(k=>`<p>${RES_I[k]} ${RES_N[k]} ${fmt(r.res[k].c)} / ${fmt(r.res[k].m)}${bar(r.res[k].c,r.res[k].m,'#2aa6a0')}</p>`).join('')||'<p class="dim">Kaynak yok</p>')}
  </div>`;
  {const ev=cityEvents().find(x=>x.r===r.id);if(ev)h+=`<div class="card" style="border-left-color:var(--gold)"><h3>${ev.t.i} Olay: ${ev.t.n}</h3><p>${ev.t.d} · kalan ${fmtDur(ev.end-Date.now())}</p></div>`;}
  h+=`<div class="card" style="margin-top:8px;${c?'border-color:var(--gold,#f0c040)':''}"><h3>⭐ Kritik şehir</h3>${c?`<p><b>${K[1]} ${K[2]} şehri.</b> Bu şehre sahip olan devlet <b>${K[3]}</b> için <b>+%${Math.round((0.06+0.01*l)*100)}</b> bonus alır (geliştirme seviyesi başına +%1).</p><p>Şu an: <b class="${r.state==='A'?'ok':'bad'}">${esc(nameOf(r.state))}</b>${r.state==='A'?' — bonus sende aktif ✅':' — bonus onda'}</p>`:'<p class="dim">Bu şehir kritik değil. Kritik şehirler dünyanın en zengin 4 rezervli şehridir.</p>'}</div>`;
  h+=`<div class="card"><h3>🏙️ Şehir geliştirme — seviye ${l}/10</h3><p>${l?devFx(l):'Henüz geliştirilmedi.'}</p>
   ${l<10?`${bar(r.devP||0,cost,'#e30a17')}<p class="dim">${fmt(r.devP||0)} / ${fmt(cost)}₺ → seviye ${l+1} (${devFx(l+1)})</p>
   <div class="btns">${[10000,100000,1000000].map(v=>btn('+'+fmt(v)+'₺ bağışla',`data-a="cityFund" data-v="${v}"`,'gold sm',m.money<v)).join('')}</div>`:'<p class="ok">En üst seviye ✅</p>'}
   <p class="hint">Bağış yapan herkes şehri birlikte geliştirir. Şehir hangi devlette olursa olsun fayda sağlar; en çok o devletin vatandaşlarına.</p></div>`;
  h+=`<div class="card"><h3>🏗️ Binalar</h3>${bl.length?bl.map(k=>`<p>${BUILD[k].i} <b>${BUILD[k].n}</b> × ${r.b[k]} — ${bldFx(k,r.b[k])}</p>`).join(''):'<p class="dim">Hiç bina yok.</p>'}
   ${r.bq.length?`<p>⏳ İnşa sırası: ${r.bq.map(x=>`${BUILD[x.b].i} ${BUILD[x.b].n} ${cd(x.end)}`).join(' · ')}</p>`:''}
   <details><summary class="dim">İnşa edilebilecek binalar ve etkileri</summary>${Object.keys(BUILD).map(k=>`<p>${BUILD[k].i} <b>${BUILD[k].n}</b> — ${bldFx(k,1)} <span class="dim">(${fmt(buildCost(r,k))}₺ · ${fmtDur(buildTime(r,k))})</span></p>`).join('')}<p class="hint">Binalar Devlet sekmesindeki <b>Bina inşası</b> kanunuyla, devlet bütçesinden yapılır.</p></details></div>
  <div class="btns">${here?btn('🏠 Buraya yerleş','data-a="resid"','',home||r.moon):btn(`🧳 Git (${r.moon?'2sa':hops*20+'dk'})`,`data-a="travel" data-to="${r.id}"`,'',!!m.travel||hops>=99&&!r.moon)}</div></div>`;
  return h;
}
/* ================= İTTİFAK + HAFTALIK ÖDÜL + ROZET ================= */
const AL={list:{},chat:[],last:0,err:'',busy:false,sig:''};
const AL_COST=1000000,AL_MAXLV=5,AL_UP=lv=>1500000*(lv+1)*(lv+1);
const alMy=()=>{const id=S.me&&S.me.ally;return id&&AL.list[id]?Object.assign({id:id},AL.list[id]):null;};
const allyLv=()=>{const a=alMy();return a?Math.min(AL_MAXLV,+a.lv||0):0;};
const allyBonus=()=>0.02*allyLv();
async function allyPoll(){
  if(!MP.ok||AL.busy)return;AL.busy=true;AL.last=Date.now();
  try{
    AL.list=await MP.fb('GET','alliances')||{};AL.err='';
    const m=S.me,me=MP.uid();
    if(m.ally&&!(AL.list[m.ally]&&AL.list[m.ally].m&&AL.list[m.ally].m[me])){m.ally=null;L('İttifaktan ayrıldın ya da ittifak kapandı.','info');S.dirty=true;}
    if(!m.ally){for(const id in AL.list){const a=AL.list[id];if(a&&a.m&&a.m[me]){m.ally=id;break;}}}
    if(m.ally&&UI.tab==='ally'){const d=await MP.fb('GET','achat/'+m.ally,undefined,'orderBy=%22%24key%22&limitToLast=40');AL.chat=d?Object.keys(d).sort().map(k=>d[k]):[];}
    const sig=JSON.stringify([m.ally,m.ally&&AL.list[m.ally]?[AL.list[m.ally].lv,AL.list[m.ally].bank,Object.keys(AL.list[m.ally].m||{}).length]:0,AL.chat.length]);
    if(sig!==AL.sig){AL.sig=sig;if(UI.tab==='ally')S.dirty=true;}
  }catch(e){AL.err=rulesHint(e);if(UI.tab==='ally')S.dirty=true;}
  AL.busy=false;
}
ACT.alCreate=async()=>{
  const m=S.me,n=(($('alName')||{}).value||'').trim().slice(0,24);
  if(!MP.ok)return msg('Önce giriş yap (Profil › Hesap).');if(m.ally)return msg('Zaten bir ittifaktasın.');
  if(n.length<3)return msg('İttifak adı en az 3 harf.');if(m.level<5)return msg('İttifak kurmak için seviye 5 gerekli.');
  if(m.money<AL_COST)return msg(`Yetersiz para (${fmt(AL_COST)}₺).`);
  const id=Date.now().toString(36)+MP.uid().slice(0,4);
  try{await MP.fb('PUT','alliances/'+id,{n:n,o:MP.uid(),on:m.name,t:Date.now(),lv:0,bank:0,m:{[MP.uid()]:m.name}});
    m.money-=AL_COST;m.ally=id;AL.list[id]={n:n,o:MP.uid(),on:m.name,lv:0,bank:0,m:{[MP.uid()]:m.name}};L(`🛡️ "${n}" ittifakını kurdun (−${fmt(AL_COST)}₺).`,'ok');msg('İttifak kuruldu!','ok');}
  catch(e){msg(rulesHint(e));}S.dirty=true;
};
ACT.alJoin=async d=>{
  const m=S.me;if(!MP.ok)return msg('Önce giriş yap.');if(m.ally)return msg('Önce mevcut ittifaktan ayrıl.');
  const a=AL.list[d.id];if(!a)return;if(Object.keys(a.m||{}).length>=30)return msg('İttifak dolu (30).');
  try{await MP.fb('PUT','alliances/'+d.id+'/m/'+MP.uid(),m.name);m.ally=d.id;(AL.list[d.id].m=AL.list[d.id].m||{})[MP.uid()]=m.name;L(`🛡️ "${a.n}" ittifakına katıldın.`,'ok');}
  catch(e){msg(rulesHint(e));}S.dirty=true;
};
ACT.alLeave=async()=>{
  const m=S.me,a=alMy();if(!a)return;
  if(a.o===MP.uid()){
    if(Object.keys(a.m||{}).length>1)return msg('Lider ayrılmadan önce ittifakta tek kişi kalmalı.');
    if(!confirm('İttifak kapatılsın mı? Kasa kaybolur.'))return;
    try{await MP.fb('DELETE','alliances/'+a.id);}catch(e){return msg(rulesHint(e));}
  }else{try{await MP.fb('DELETE','alliances/'+a.id+'/m/'+MP.uid());}catch(e){return msg(rulesHint(e));}}
  delete AL.list[a.id];m.ally=null;msg('İttifaktan ayrıldın.','ok');S.dirty=true;
};
ACT.alDonate=async d=>{
  const m=S.me,a=alMy(),v=+d.v;if(!a||!v)return;if(m.money<v)return msg('Yetersiz para.');
  try{await MP.fb('PUT','alliances/'+a.id+'/bank',{'.sv':{increment:v}});m.money-=v;AL.list[a.id].bank=(+a.bank||0)+v;m.allyDon=(m.allyDon||0)+v;msg(`💰 ${fmt(v)}₺ kasaya bağışlandı.`,'ok');}
  catch(e){msg(rulesHint(e));}S.dirty=true;
};
ACT.alUp=async()=>{
  const a=alMy();if(!a||a.o!==MP.uid())return;const lv=+a.lv||0;if(lv>=AL_MAXLV)return;
  const c=AL_UP(lv);if((+a.bank||0)<c)return msg(`Kasa yetersiz (${fmt(c)}₺).`);
  try{await MP.fb('PATCH','alliances/'+a.id,{lv:lv+1,bank:(+a.bank||0)-c});AL.list[a.id].lv=lv+1;AL.list[a.id].bank-=c;L(`🛡️ İttifak seviye ${lv+1}: üyelere çalışma verimi +%${(lv+1)*2}.`,'ok');}
  catch(e){msg(rulesHint(e));}S.dirty=true;
};
ACT.alSend=async()=>{
  const a=alMy(),el=$('alMsg'),t=((el&&el.value)||'').trim().slice(0,200);if(!a||!t)return;
  if(MP.ban&&MP.ban.chat&&!S.me.admin)return msg('Yönetici seni susturdu.');
  try{await MP.fb('PUT','achat/'+a.id+'/'+Date.now()+'_'+MP.uid().slice(0,6),{u:S.me.name,m:t,t:Date.now(),uid:MP.uid()});if(el)el.value='';allyPoll();}catch(e){msg(rulesHint(e));}
};
function tabAlly(){
  let h='<div class="panel"><h2>🛡️ İttifak</h2>';
  if(!MP.ok)return h+'<div class="al warn">İttifak için Profil › Hesap bölümünden giriş yap.</div></div>';
  if(AL.err)h+=`<div class="al bad">${esc(AL.err)}</div>`;
  const m=S.me,a=alMy();
  if(!a){
    h+=`<p class="hint">İttifak: oyuncuların ortak kasası ve ortak sohbeti. Kasa ile ittifak seviyesi yükselir; her seviye üyelere <b>+%2 çalışma verimi</b> verir (en çok 5 seviye).</p>
    <div class="card"><h3>Yeni ittifak kur</h3><div class="row"><input type="text" id="alName" maxlength="24" placeholder="İttifak adı" style="flex:1;padding:8px"></div>${btn(`Kur (${fmt(AL_COST)}₺ · seviye 5)`,'data-a="alCreate"','gold')}</div>`;
    const ids=Object.keys(AL.list).filter(i=>AL.list[i]&&AL.list[i].n);
    h+=`<h2 style="margin-top:12px">Mevcut ittifaklar (${ids.length})</h2>`+(ids.length?ids.sort((x,y)=>Object.keys(AL.list[y].m||{}).length-Object.keys(AL.list[x].m||{}).length).map(i=>{const x=AL.list[i];return `<div class="card"><h3>${esc(x.n)} <span class="owner">sv ${+x.lv||0}</span></h3><p>Lider: ${esc(x.on||'?')} · ${Object.keys(x.m||{}).length} üye</p>${btn('Katıl',`data-a="alJoin" data-id="${i}"`,'sm')}</div>`;}).join(''):'<p class="dim">Henüz ittifak yok. İlkini sen kur.</p>');
    return h+'</div>';
  }
  const lead=a.o===MP.uid(),lv=+a.lv||0,mem=Object.keys(a.m||{});
  h+=`<div class="grid">${card('🛡️ '+esc(a.n),`<p>Seviye <b>${lv}/${AL_MAXLV}</b> · üyelere çalışma verimi +%${lv*2}</p><p class="dim">${mem.length} üye · lider: ${esc(a.on||'?')}</p>`)}
   ${card('💰 Ortak kasa',`<div class="big">${fmt(+a.bank||0)}₺</div><div class="btns">${[10000,100000,1000000].map(v=>btn('+'+fmt(v),`data-a="alDonate" data-v="${v}"`,'gold sm',m.money<v)).join('')}</div>`)}
   ${card('⬆️ Seviye',lv>=AL_MAXLV?'<p class="ok">En üst seviye ✅</p>':`<p class="dim">Sonraki: ${fmt(AL_UP(lv))}₺ kasadan</p>${lead?btn('Seviye yükselt','data-a="alUp"','gold sm',(+a.bank||0)<AL_UP(lv)):'<p class="dim">Lider yükseltir.</p>'}`)}</div>
   <div class="card" style="margin-top:8px"><h3>Üyeler</h3><p>${mem.map(u=>esc(a.m[u])+(u===a.o?' 👑':'')).join(' · ')}</p></div>
   <div class="card"><h3>💬 İttifak sohbeti</h3><div class="log" style="height:140px">${AL.chat.map(x=>`<div><b>${esc(x.u)}</b>: ${esc(x.m)}</div>`).join('')||'<div class="dim">Henüz mesaj yok.</div>'}</div>
   <div class="row" style="margin:6px 0"><input type="text" id="alMsg" maxlength="200" placeholder="Mesaj yaz…" style="flex:1;padding:8px"></div>${btn('Gönder','data-a="alSend"','sm')}</div>
   <div class="btns">${btn('İttifaktan ayrıl','data-a="alLeave"','danger sm')}</div></div>`;
  return h;
}
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='alMsg'){e.preventDefault();ACT.alSend();}});
/* ---- haftalık ödüller ---- */
const WK_PRIZE=[{g:20,m:1000000,b:'🥇'},{g:10,m:500000,b:'🥈'},{g:5,m:250000,b:'🥉'}]; // ödülleri buradan değiştirebilirsin
async function wkReward(){
  const m=S.me;if(!MP.ok||m.admin)return;wkState();
  const w=wkNo();
  if(m.wkPub&&!m.wkPubDone){try{await MP.fb('PUT','wk/'+m.wkPub.w+'/'+MP.uid(),{n:m.name,wm:m.wkPub.wm,wd:m.wkPub.wd});m.wkPubDone=1;}catch(e){}}
  const pw=w-1;if(m.wkPaid===pw||!m.wkPubDone||!m.wkPub||m.wkPub.w!==pw)return;
  if(Date.now()<(wkEnd()-WK_MS)+24*3600e3)return; // ilk gün herkesin yayınlaması için beklenir
  try{
    const d=await MP.fb('GET','wk/'+pw)||{},me=MP.uid();
    const rows=Object.keys(d).map(u=>({u:u,wm:+d[u].wm||0})).filter(x=>x.wm>0).sort((a,b)=>b.wm-a.wm);
    const i=rows.findIndex(x=>x.u===me);m.wkPaid=pw;
    if(i>=0&&i<3){const p=WK_PRIZE[i];m.money+=p.m;m.stor.gold=Math.min(storCap(),m.stor.gold+p.g);m.badges=m.badges||[];m.badges.push({k:'wk'+(i+1),w:pw});
      L(`${p.b} Geçen haftanın ${i+1}. oldun! +${fmt(p.m)}₺ +${p.g} altın ve rozet.`,'ok');toast(`${p.b} Haftanın ${i+1}.'si oldun!`,'ok');S.dirty=true;}
  }catch(e){}
}
const BADGES=[
  {id:'wk1',i:'🥇',n:'Haftanın birincisi',f:m=>(m.badges||[]).some(b=>b.k==='wk1')},
  {id:'wk2',i:'🥈',n:'Haftanın ikincisi',f:m=>(m.badges||[]).some(b=>b.k==='wk2')},
  {id:'wk3',i:'🥉',n:'Haftanın üçüncüsü',f:m=>(m.badges||[]).some(b=>b.k==='wk3')},
  {id:'ally',i:'🛡️',n:'İttifak üyesi',f:m=>!!m.ally},
  {id:'dev',i:'🏙️',n:'Şehir kurucusu (1M₺ bağış)',f:m=>(m.donated||0)>=1e6},
  {id:'war',i:'⚔️',n:'Savaşçı (100 vuruş)',f:m=>(m.hits||0)>=100},
  {id:'work',i:'⛏️',n:'Çalışkan (500 iş)',f:m=>(m.works||0)>=500},
  {id:'lv20',i:'⭐',n:'Seviye 20',f:m=>m.level>=20},
  {id:'auto',i:'⚙️',n:'Otomasyon sahibi',f:m=>!!(m.au&&(m.au.work>0||m.au.war>0))}
];
/* ================= ANA SAYFA + PROFİL (Rival Regions düzeni, Türk renkleriyle) ================= */
const PLBL={str:'Kuvvet',edu:'Eğitim',end:'Dayanıklılık'},PICO={str:'💪',edu:'🎓',end:'🫀'};
const agoG=t=>{const s=Math.max(0,(S.t-t)/1000);return s<90?'az önce':s<3600?Math.round(s/60)+' dk':s<86400?Math.round(s/3600)+' sa':Math.round(s/86400)+' gün';};
ACT.bioSave=()=>{S.me.bio=String((($('bioTxt')||{}).value||'')).slice(0,200);msg('Kaydedildi.','ok');};
function ico(e,bg){return `<span style="display:inline-flex;width:34px;height:34px;border-radius:50%;background:${bg||'var(--bg4)'};align-items:center;justify-content:center;font-size:18px;flex:none">${e}</span>`;}
function prow(e,t,s,x,a){return `<div ${a||''} class="${a?'prow-a':''}" style="display:flex;gap:10px;align-items:center;padding:8px 2px;border-bottom:1px solid var(--bg4)">${ico(e)}<div style="flex:1;min-width:0"><div style="color:var(--tx0)">${t}</div>${s?`<div class="dim" style="font-size:12px">${s}</div>`:''}</div>${x||''}${a?'<span class="chev">›</span>':''}</div>`;}
function badgeSection(){
  const m=S.me,got=BADGES.filter(b=>b.f(m));
  return `<details class="card"><summary><b>🏅 Rozetler (${got.length}/${BADGES.length})</b></summary><div class="grid" style="margin-top:8px">${BADGES.map(b=>`<div class="card ${b.f(m)?'':'locked'}"><h3>${b.i} ${b.n}</h3></div>`).join('')}</div></details>`;
}
function tabChar(){
  const m=S.me,hr=homeReg(),mr=myReg(),pt=myParty(),al=(typeof alMy==='function')?alMy():null;
  let h='';
  h+=`<div class="panel"><div class="card glow" style="display:flex;gap:12px;align-items:center"><div style="width:58px;height:58px;border-radius:50%;background:var(--red);border:2px solid var(--gold);display:flex;align-items:center;justify-content:center;font-size:26px;color:#fff;font-family:Georgia,serif;flex:none">${esc((m.name||'?').slice(0,1).toUpperCase())}</div>
   <div style="flex:1;min-width:0"><div style="font-size:18px;color:var(--tx0);font-weight:600">${esc(m.name)}</div><div class="dim">${rankName()} · ${roleName()}</div>
   <div style="margin-top:4px">⭐ Seviye <b data-live="level"></b>${bar(m.xp,xpNeed(m.level))}</div></div></div>`;
  h+=`<div class="card">`+
    prow('📍',`Bölge: ${esc(mr.n)}`,esc(nameOf(mr.state)),'',`data-a="goCity" data-id="${mr.id}"`)+
    prow('🏠',`İkamet bölgesi: ${esc(hr.n)}`,fmtDur(S.t-m.resSince)+' önce yerleşildi','',`data-a="goCity" data-id="${hr.id}"`)+
    prow('🏳️',`${esc(nameOf(hr.state))}`,'Ülke bonusu: çalışma, savaş, vergi','','data-a="tab" data-t="state"')+
    prow('🎗️',`Parti: ${pt?esc(pt.n):'partisiz'}`,'Siyaset','','data-a="tab" data-t="party"')+
    prow('🛡️',`İttifak: ${al?esc(al.n):'yok'}`,al?`Seviye ${+al.lv||0} · çalışma +%${(+al.lv||0)*2}`:'Sosyal ▸ İttifak','','data-a="tab" data-t="ally"')+`</div>`;
  h+=`<details class="card"><summary><b>Hakkımda</b></summary><div style="margin-top:8px"><textarea id="bioTxt" maxlength="200" rows="2" style="width:100%;background:var(--bg3);color:var(--tx);border:1px solid var(--line);border-radius:6px;padding:8px;font-size:16px" placeholder="Kendini kısaca anlat…">${esc(m.bio||'')}</textarea>${btn('Kaydet','data-a="bioSave"','sm')}</div></details>`;
  for(const k in PERKS){
    const v=perk(k),boosted=v!==m[k],lr=m.learn&&m.learn.perk===k;
    const tm=learnTimeMs(k,false),tg=learnTimeMs(k,true);
    h+=`<details class="card" ${lr?'open':''} style="padding:0"><summary style="display:flex;align-items:center;gap:10px;padding:12px;cursor:pointer;list-style:none">${ico(PICO[k],'var(--red)')}<b style="flex:1;font-size:16px;color:var(--tx0);font-family:Georgia,serif;letter-spacing:1px;text-transform:uppercase">${PLBL[k]}</b><b style="font-size:20px;color:var(--gold)">${v}</b>▾</summary>
     <div style="padding:0 12px 12px"><p class="dim">${PERK_D[k]}${boosted?` <span class="ok">(+100 güçlendirici)</span>`:''}</p>`+(lr?`<p>Öğreniliyor → ${m[k]+1}: ${cd(m.learn.end)}</p>${pb(m.learn.start,m.learn.end)}`:
     `<div class="btns">${btn(`Para: ${fmt(learnCost(k,false))}₺<br><small>${fmtDur(tm)}</small>`,`data-a="learn" data-p="${k}" data-g="0"`,'',m.learn||m.money<learnCost(k,false))}
      ${btn(`Altın: ${learnCost(k,true)}<br><small>${fmtDur(tg)}</small>`,`data-a="learn" data-p="${k}" data-g="1"`,'gold',m.learn||m.stor.gold<learnCost(k,true))}</div>`)+`</div></details>`;
  }
  h+=`<div class="card"><h3>Detaylı Bilgi</h3>
   <table><tr><td>⚡ Enerji</td><td class="num"><b class="ok" data-live="energy"></b></td></tr>
   <tr><td colspan="2" class="dim" style="font-size:11px">Bölgenizdeki tıp indeksi (${hr.idx.h}) saatte ${f1(30+4*(((m.inv||{}).house)||0)+Math.max(0,hr.idx.h-3)*1.5)} enerji kazandırıyor.</td></tr>
   <tr><td>🏭 Fabrikalar</td><td class="num">${m.facs.length}</td></tr>
   <tr><td>⭐ Tecrübe</td><td class="num">${fmt(m.xp)}</td></tr>
   <tr><td colspan="2" class="dim" style="font-size:11px">Bir sonraki seviye: ${fmt(xpNeed(m.level))} (ihtiyacın olan: ${fmt(Math.max(0,xpNeed(m.level)-m.xp))})</td></tr>
   <tr><td>💥 Verilen hasar</td><td class="num">${fmt(m.dmg||0)}</td></tr>
   <tr><td>⚔️ Savaşlar</td><td class="num">${m.hits} vuruş</td></tr>
   <tr><td>⛏️ Çalışma</td><td class="num">${m.works}</td></tr>
   <tr><td>🏆 Rütbe</td><td class="num">${rankName()}</td></tr>
   <tr><td>🔧 Üretim bonusu</td><td class="num">%${f1(craftBonus())} indirim</td></tr>
   <tr><td>📦 Depo kapasitesi</td><td class="num">${fmt(storCap())}</td></tr>
   <tr><td>🗡️ Vuruş gücü</td><td class="num">${fmt(hitDamage(null))}</td></tr></table></div>`;
  h+=`<details class="card"><summary><b>💪 Güçlendirici (+100 puan)</b></summary><div style="margin-top:8px">`;
  if(m.boost&&m.boost.end>S.t)h+=`<p>Aktif: ${PLBL[m.boost.perk]} +100 — ${cd(m.boost.end)}</p>`;
  else if(S.t<m.boostCd)h+=`<p class="dim">Yeniden kullanılabilir: ${cd(m.boostCd)}</p>`;
  else h+=Object.keys(PERKS).map(k=>`<div class="btns"><b style="min-width:110px">${PLBL[k]}</b>${btn('2 saat · 30.000₺',`data-a="boost" data-p="${k}" data-g="0"`,'',m.money<30000)}${btn('20 saat · 25 altın',`data-a="boost" data-p="${k}" data-g="1"`,'gold',m.stor.gold<25)}</div>`).join('');
  h+=`</div></details>`+badgeSection()+`</div>`;
  return h;
}
function tabHome(){
  const m=S.me,r=myReg(),ec=energyCost();
  let h=tutCard()+`<div class="panel"><h2>🏠 Ana Sayfa</h2><div class="card glow"><div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font-size:16px;color:var(--tx0)">Merhaba, ${esc(m.name)}</b><div class="dim">${rankName()} · ${esc(r.n)} · Gün ${Math.floor((S.t-S.startT)/DAY)+1}</div></div><div style="text-align:right"><div class="big" style="font-size:22px">⚡ <span data-live="energy"></span></div></div></div></div>
  <div class="card"><h3>⛏️ Hızlı çalış</h3><div class="btns">${['gold','oil','ore'].map(k=>btn(`${RES_I[k]} ${RES_N[k]}`,`data-a="work" data-r="${k}" data-n="1"`,'',!!m.travel||r.moon||r.res[k].c<=0||m.energy<ec||!regionAllows(r))).join('')}${btn('Çalışmaya git','data-a="tab" data-t="work"','sm blue')}</div></div>`;
  const ws=S.wars.filter(w=>w.state!=='done'&&(w.att==='A'||w.def==='A'));
  if(ws.length)h+=`<div class="card" style="border-left-color:#e30a17"><h3>⚔️ Savaşlar</h3>${ws.map(w=>`<p><a class="lk" data-a="goCity" data-id="${w.region}">${esc(S.regions[w.region].n)}</a> · ${esc(nameOf(w.att))} → ${esc(nameOf(w.def))} · ${w.state==='prep'?'başlamasına '+cd(w.start):'bitmesine '+cd(w.end)}</p>`).join('')}${btn('Savaşlara git','data-a="tab" data-t="war"','danger sm')}</div>`;
  if(typeof cityEvents==='function'){const ev=cityEvents();if(ev.length)h+=`<div class="card"><h3>🌍 Şehirlerde olaylar</h3>${ev.map(e=>`<p>${e.t.i} <a class="lk" data-a="goCity" data-id="${e.r}"><b>${esc(S.regions[e.r].n)}</b></a> — ${e.t.n}: ${e.t.d} · ${fmtDur(e.end-Date.now())}</p>`).join('')}</div>`;}
  const nt=(m.notes||[]).slice(0,6);
  if(nt.length)h+=`<div class="card"><h3>🔔 Bildirimler</h3>${nt.map(x=>`<p><b class="${x.c==='bad'?'bad':x.c==='warn'?'warn':'ok'}">●</b> ${esc(x.m)} <span class="dim">· ${agoG(x.t)}</span></p>`).join('')}${btn('Temizle','data-a="notesClear"','sm')}</div>`;
  const nw=(S.news||[]).slice(0,8);
  h+=`<div class="card"><h3>📰 Haberler</h3>${nw.length?nw.map(x=>`<p>${esc(x.m)} <span class="dim">· ${agoG(x.t)}</span></p>`).join(''):'<p class="dim">Henüz haber yok.</p>'}</div></div>`;
  return h;
}
ACT.notesClear=()=>{S.me.notes=[];};
/* ================= ŞEHİR OLAYLARI + BİLDİRİMLER + BANKA ================= */
const CEV=[
  {k:'vein',n:'Altın damarı bulundu',i:'💎',d:'çalışma verimi +%25',f:1.25},
  {k:'boom',n:'Ticaret patlaması',i:'📈',d:'çalışma verimi +%10',f:1.1},
  {k:'fest',n:'Şenlik',i:'🎉',d:'çalışma verimi +%20',f:1.2},
  {k:'famine',n:'Kıtlık',i:'🌾',d:'çalışma verimi −%15',f:0.85},
  {k:'quake',n:'Deprem',i:'🌋',d:'çalışma verimi −%25',f:0.75}
];
const CEV_MS=6*HOUR;
function _h(n){n=(n^61)^(n>>>16);n=Math.imul(n+(n<<3),0x27d4eb2d);n^=n>>>15;return n>>>0;}
function cityEvents(){ // herkes için aynı: zamana göre deterministik, 6 saatte bir 4 şehirde olay
  const slot=Math.floor(Date.now()/CEV_MS),end=(slot+1)*CEV_MS,n=S.regions.length,out=[],used={};
  for(let j=0;j<4;j++){let r=_h(slot*131+j*977)%n,g=0;while(used[r]&&g++<n)r=(r+1)%n;used[r]=1;out.push({r:r,t:CEV[_h(slot*17+j*313)%CEV.length],end:end});}
  return out;
}
function cityEvtF(id){const e=cityEvents().find(x=>x.r===id);return e?e.t.f:1;}
/* ---- bildirimler ---- */
function pushNote(m,c){
  const s=S.me;if(!s)return;s.notes=s.notes||[];
  s.notes.unshift({t:S.t,m:String(m).slice(0,140),c:c||'ok'});if(s.notes.length>30)s.notes.pop();
  try{if(document.hidden&&window.Notification&&Notification.permission==='granted')new Notification('Bilâd-ı Mütenâfise',{body:String(m).slice(0,140),icon:'icon-192.png'});}catch(e){}
}
const _toastN=toast;
toast=function(m,c){_toastN(m,c);if(/^(⚠️|📣|🥇|🥈|🥉|⚙️|🎉|⛓️|🗳️|🤝)/.test(String(m)))pushNote(m,c);};
ACT.notifyAsk=async()=>{try{if(!window.Notification)return msg('Bu tarayıcı bildirim desteklemiyor.');const r=await Notification.requestPermission();msg(r==='granted'?'🔔 Bildirimler açıldı (oyun açıkken/arka plandayken).':'Bildirim izni verilmedi.',r==='granted'?'ok':'warn');S.dirty=true;}catch(e){}};
const _tabSet=tabSettings;
tabSettings=function(){
  const st=(window.Notification?Notification.permission:'yok');
  return _tabSet()+`<div class="panel"><h2>🔔 Bildirimler</h2><div class="card"><p>Durum: <b>${st==='granted'?'açık':st==='denied'?'engelli (tarayıcı ayarlarından aç)':st==='yok'?'desteklenmiyor':'kapalı'}</b></p><p class="dim">Savaş ilanı, ödül ve onay haberleri Ana Sayfa'da listelenir; oyun arka plandayken telefon bildirimi de gelir. Oyun tamamen kapalıyken bildirim gelmez (sunucu yok).</p>${st==='default'?btn('Bildirimleri aç','data-a="notifyAsk"','gold'):''}</div></div>`;
};
/* ---- banka ---- */
const BK={depRate:0.008,loanRate:0.05,depCap:5000000,days:3}; // günlük oranlar
const bkOf=()=>{const m=S.me;if(!m.bank)m.bank={dep:0,loan:0,due:0};return m.bank;};
const loanLimit=()=>Math.min(5000000,100000*S.me.level);
function bankTick(h){
  const m=S.me,b=m.bank;if(!b||m.admin)return;
  if(b.dep>0)b.dep+=b.dep*BK.depRate*h/24;
  if(b.loan>0){const i=b.loan*BK.loanRate*h/24;b.loan+=i;A().budget.money+=i*0.5;
    if(S.t>b.due){b.loan*=1.15;b.due=S.t+2*DAY;m.jail=Math.max(m.jail||0,S.t+6*HOUR);L('⛓️ Kredi vadesi geçti! 6 saat hapis ve %15 gecikme faizi.','bad');toast('⛓️ Kredi vadesi geçti: hapis + gecikme faizi','bad');}}
}
ACT.bankDep=d=>{const b=bkOf(),m=S.me,v=Math.floor(+d.v);if(v<=0)return;if(m.money<v)return msg('Yetersiz para.');if(b.dep+v>BK.depCap)return msg(`Mevduat üst sınırı ${fmt(BK.depCap)}₺.`);m.money-=v;b.dep+=v;msg('🏦 Yatırıldı.','ok');};
ACT.bankWd=d=>{const b=bkOf(),m=S.me,v=Math.min(Math.floor(+d.v),Math.floor(b.dep));if(v<=0)return;b.dep-=v;m.money+=v;msg('💰 Çekildi.','ok');};
ACT.bankLoan=d=>{const b=bkOf(),m=S.me,v=Math.floor(+d.v);if(v<=0)return;if(b.loan>0)return msg('Önce mevcut krediyi öde.');if(v>loanLimit())return msg(`Kredi limitin ${fmt(loanLimit())}₺ (seviyeye göre).`);
  b.loan=v;b.due=S.t+BK.days*DAY;m.money+=v;L(`🏦 ${fmt(v)}₺ kredi aldın. Vade ${BK.days} gün, günlük faiz %${BK.loanRate*100}.`,'info');msg('Kredi hesabına yattı.','ok');};
ACT.bankPay=d=>{const b=bkOf(),m=S.me;if(b.loan<=0)return;const v=d.v==='all'?Math.ceil(b.loan):Math.floor(+d.v);const p=Math.min(v,Math.ceil(b.loan));if(m.money<p)return msg('Yetersiz para.');m.money-=p;b.loan=Math.max(0,b.loan-p);if(b.loan<1)b.loan=0;msg('Ödendi.','ok');};
function tabBank(){
  const b=bkOf(),m=S.me;
  let h=`<div class="panel"><h2>🏦 Banka</h2><p class="hint">Mevduat günde %${BK.depRate*100} getirir (üst sınır ${fmt(BK.depCap)}₺). Kredi günde %${BK.loanRate*100} faizlidir, vade ${BK.days} gün; faizin yarısı devlet bütçesine gider. Vadeyi kaçırırsan %15 ceza ve 6 saat hapis.</p>
  <div class="grid">${card('💰 Mevduat',`<div class="big">${fmt(b.dep)}₺</div><div class="btns">${[10000,100000,1000000].map(v=>btn('+'+fmt(v),`data-a="bankDep" data-v="${v}"`,'sm',m.money<v)).join('')}</div><div class="btns">${btn('Tümünü çek','data-a="bankWd" data-v="999999999"','sm',b.dep<1)}</div>`)}
  ${card('📄 Kredi',b.loan>0?`<div class="big bad">${fmt(b.loan)}₺</div><p>Vade: ${cd(b.due)}</p><div class="btns">${btn('Tümünü öde','data-a="bankPay" data-v="all"','gold',m.money<Math.ceil(b.loan))}${btn('100.000₺ öde','data-a="bankPay" data-v="100000"','sm',m.money<100000)}</div>`:`<p>Limit: <b>${fmt(loanLimit())}₺</b></p><div class="btns">${[0.25,0.5,1].map(f=>btn(fmt(Math.floor(loanLimit()*f))+'₺',`data-a="bankLoan" data-v="${Math.floor(loanLimit()*f)}"`,'gold sm')).join('')}</div>`)}</div></div>`;
  return h;
}
/* ================= MAKALELER: yazı + fotoğraf, beğen/beğenme, yorum, sıralama (Firebase) ================= */
const AR={list:[],sort:'new',last:0,open:null,img:null,imgName:'',cm:[],oimg:null,err:'',busy:false,sig:''};
const AR_SORT={new:'⏱️ Yeni',top:'👍 En beğenilen',hot:'💬 En çok yorumlanan',week:'🔥 Haftanın'};
const arScore=a=>(+a.l||0)-(+a.d||0);
function arSorted(){
  let a=AR.list.slice();const wk=Date.now()-7*86400e3;
  if(AR.sort==='top')a.sort((x,y)=>arScore(y)-arScore(x)||y.t-x.t);
  else if(AR.sort==='hot')a.sort((x,y)=>(+y.c||0)-(+x.c||0)||y.t-x.t);
  else if(AR.sort==='week')a=a.filter(x=>x.t>wk).sort((x,y)=>arScore(y)-arScore(x)||y.t-x.t);
  else a.sort((x,y)=>y.t-x.t);
  return a;
}
const arMy=()=>(S.me.areact=S.me.areact||{});
async function artPoll(){
  if(!MP.ok||AR.busy)return;AR.busy=true;AR.last=Date.now();
  try{
    const d=await MP.fb('GET','articles',undefined,'orderBy=%22%24key%22&limitToLast=60');
    AR.list=d?Object.keys(d).map(k=>Object.assign({id:k},d[k])):[];AR.err='';
    if(AR.open){const c=await MP.fb('GET','acom/'+AR.open,undefined,'orderBy=%22%24key%22&limitToLast=60');AR.cm=c?Object.keys(c).sort().map(k=>Object.assign({k:k},c[k])):[];}
    const sig=AR.list.map(a=>a.id+a.l+'/'+a.d+'/'+a.c).join(',')+'|'+AR.cm.length+'|'+AR.open;
    if(sig!==AR.sig){AR.sig=sig;if(UI.tab==='art')S.dirty=true;}
  }catch(e){AR.err=rulesHint(e);if(UI.tab==='art')S.dirty=true;}
  AR.busy=false;
}
function arCompress(file,cb){
  const fr=new FileReader();
  fr.onload=()=>{const im=new Image();im.onload=()=>{
    const mx=640,k=Math.min(1,mx/Math.max(im.width,im.height)),cv=document.createElement('canvas');cv.width=Math.round(im.width*k);cv.height=Math.round(im.height*k);
    cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);
    let q=0.62,u=cv.toDataURL('image/jpeg',q);while(u.length>140000&&q>0.3){q-=0.1;u=cv.toDataURL('image/jpeg',q);}
    cb(u);};im.onerror=()=>cb(null);im.src=fr.result;};
  fr.onerror=()=>cb(null);fr.readAsDataURL(file);
}
document.addEventListener('change',e=>{
  const t=e.target;if(!t||t.id!=='arFile'||!t.files||!t.files[0])return;
  arCompress(t.files[0],u=>{if(!u){msg('Fotoğraf okunamadı.');return;}AR.img=u;AR.imgName=t.files[0].name;S.dirty=true;render();});
});
ACT.arSort=d=>{AR.sort=d.s;};
ACT.arNoImg=()=>{AR.img=null;};
ACT.artPost=async()=>{
  const m=S.me,ti=(($('arTi')||{}).value||'').trim().slice(0,80),b=(($('arBody')||{}).value||'').trim().slice(0,3000);
  if(!MP.ok)return msg('Önce giriş yap (Profil › Hesap).');
  if(ti.length<3)return msg('Başlık en az 3 harf.');if(b.length<20)return msg('Makale en az 20 harf olmalı.');
  if(MP.ban&&MP.ban.chat&&!m.admin)return msg('Yönetici seni susturdu.');
  if(!m.admin&&Date.now()-(m.artLast||0)<3*3600e3)return msg('Üç saatte bir makale yazabilirsin.');
  const id=Date.now()+'_'+MP.uid().slice(0,6);
  try{
    await MP.fb('PUT','articles/'+id,{uid:MP.uid(),an:m.name,ti:ti,b:b,t:Date.now(),l:0,d:0,c:0,im:AR.img?1:0,pid:AR.pid||null});
    if(AR.img)await MP.fb('PUT','aimg/'+id,AR.img);
    m.artLast=Date.now();AR.img=null;['arTi','arBody'].forEach(i=>{const e=$(i);if(e)e.value='';});
    MP.ev&&MP.ev(`makale yayımladı: ${ti}`);msg('📰 Makale yayımlandı!','ok');AR.sort='new';artPoll();
  }catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
ACT.artOpen=async d=>{
  AR.open=d.id||null;AR.oimg=null;AR.cm=[];S.dirty=true;
  if(!AR.open)return;
  const a=AR.list.find(x=>x.id===AR.open);
  try{if(a&&a.im){const u=await MP.fb('GET','aimg/'+AR.open);AR.oimg=(typeof u==='string'&&u.indexOf('data:image/')===0)?u:null;}
    const c=await MP.fb('GET','acom/'+AR.open,undefined,'orderBy=%22%24key%22&limitToLast=60');AR.cm=c?Object.keys(c).sort().map(k=>Object.assign({k:k},c[k])):[];}catch(e){}
  S.dirty=true;
};
ACT.artReact=async d=>{
  const id=d.id,v=+d.v,my=arMy(),cur=my[id]||0,a=AR.list.find(x=>x.id===id);if(!a||!MP.ok)return;
  if(a.uid===MP.uid())return msg('Kendi makaleni oylayamazsın.');
  const inc=async(k,n)=>{await MP.fb('PUT','articles/'+id+'/'+k,{'.sv':{increment:n}});a[k]=(+a[k]||0)+n;};
  try{
    if(cur===v){await MP.fb('DELETE','areact/'+id+'/'+MP.uid());await inc(v===1?'l':'d',-1);delete my[id];}
    else{await MP.fb('PUT','areact/'+id+'/'+MP.uid(),v);if(cur)await inc(cur===1?'l':'d',-1);await inc(v===1?'l':'d',1);my[id]=v;}
  }catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
ACT.artComment=async d=>{
  const el=$('arCm'),t=((el&&el.value)||'').trim().slice(0,300),id=d.id;if(!t||!MP.ok)return;
  if(MP.ban&&MP.ban.chat&&!S.me.admin)return msg('Yönetici seni susturdu.');
  if(Date.now()-(AR.cmLast||0)<2000)return msg('Biraz yavaş.');AR.cmLast=Date.now();
  try{await MP.fb('PUT','acom/'+id+'/'+Date.now()+'_'+MP.uid().slice(0,6),{u:S.me.name,m:t,t:Date.now(),uid:MP.uid()});
    await MP.fb('PUT','articles/'+id+'/c',{'.sv':{increment:1}});const a=AR.list.find(x=>x.id===id);if(a)a.c=(+a.c||0)+1;if(el)el.value='';
    const c=await MP.fb('GET','acom/'+id,undefined,'orderBy=%22%24key%22&limitToLast=60');AR.cm=c?Object.keys(c).sort().map(k=>Object.assign({k:k},c[k])):[];}
  catch(e){msg(rulesHint(e));}S.dirty=true;
};
ACT.artDel=async d=>{
  if(!confirm('Makale silinsin mi?'))return;
  try{await MP.fb('DELETE','articles/'+d.id);try{await MP.fb('DELETE','aimg/'+d.id);}catch(e){}AR.list=AR.list.filter(x=>x.id!==d.id);AR.open=null;msg('Silindi.','ok');}catch(e){msg(rulesHint(e));}S.dirty=true;
};
function arAgo(t){const s=Math.max(0,(Date.now()-t)/1000);return s<90?'az önce':s<3600?Math.round(s/60)+' dk önce':s<86400?Math.round(s/3600)+' sa önce':Math.round(s/86400)+' gün önce';}
const arBody=b=>esc(b).replace(/\n/g,'<br>');
function tabArt(){
  let h='<div class="panel"><h2>📰 Makaleler</h2>';
  if(!MP.ok)return h+'<div class="al warn">Makaleler için Profil › Hesap bölümünden giriş yap.</div></div>';
  if(AR.err)h+=`<div class="al bad">${esc(AR.err)}</div>`;
  const me=MP.uid(),isAdm=(MP.role==='admin'||S.me.admin),my=arMy();
  if(AR.open){
    const a=AR.list.find(x=>x.id===AR.open);
    if(!a){AR.open=null;}else{
      const r=my[a.id]||0;
      h+=`<div class="btns">${btn('← Makaleler','data-a="artOpen" data-id=""','sm')}</div><div class="card glow"><h3 style="font-size:17px">${esc(a.ti)}</h3><p class="dim">${esc(a.an)} · ${arAgo(a.t)}</p>
      ${AR.oimg?`<img src="${AR.oimg}" style="max-width:100%;border-radius:8px;margin:8px 0;display:block">`:(a.im?'<p class="dim">Fotoğraf yükleniyor…</p>':'')}
      <p style="color:var(--tx);font-size:14px;line-height:1.6">${arBody(a.b)}</p>
      <div class="btns">${btn(`👍 ${+a.l||0}`,`data-a="artReact" data-id="${a.id}" data-v="1"`,r===1?'gold':'sm')}${btn(`👎 ${+a.d||0}`,`data-a="artReact" data-id="${a.id}" data-v="-1"`,r===-1?'danger':'sm')}${(a.uid===me||isAdm)?btn('🗑️ Sil',`data-a="artDel" data-id="${a.id}"`,'danger sm'):''}</div></div>
      <div class="card"><h3>💬 Yorumlar (${+a.c||0})</h3>${AR.cm.length?AR.cm.map(x=>`<p><b>${esc(x.u)}</b> <span class="dim">· ${arAgo(x.t)}</span><br>${esc(x.m)}</p>`).join(''):'<p class="dim">İlk yorumu sen yaz.</p>'}
      <div class="row" style="margin:6px 0"><input type="text" id="arCm" maxlength="300" placeholder="Yorum yaz…" style="flex:1;padding:8px"></div>${btn('Gönder',`data-a="artComment" data-id="${a.id}"`,'sm')}</div></div>`;
      return h;}
  }
  h+=`<details class="card" ${AR.img?'open':''}><summary><b>✍️ Makale yaz</b></summary><div style="margin-top:8px">
   <input type="text" id="arTi" maxlength="80" placeholder="Başlık" style="width:100%;padding:8px;margin-bottom:6px">
   <textarea id="arBody" maxlength="3000" rows="6" placeholder="Makalen (en az 20 harf)…" style="width:100%;background:var(--bg3);color:var(--tx);border:1px solid var(--line);border-radius:6px;padding:8px;font-size:16px"></textarea>
   <div class="row" style="margin:6px 0"><label class="act sm" style="cursor:pointer;display:inline-block;padding:6px 10px;border:1px dashed var(--line);border-radius:6px">📷 Fotoğraf ekle<input type="file" id="arFile" accept="image/*" style="display:none"></label>${AR.img?`<span class="ok">✔ ${esc(AR.imgName)}</span> ${btn('Kaldır','data-a="arNoImg"','sm danger')}`:''}</div>
   ${AR.img?`<img src="${AR.img}" style="max-width:100%;max-height:160px;border-radius:8px;display:block;margin-bottom:6px">`:''}
   ${btn('Yayımla','data-a="artPost"','gold')}<p class="hint">Üç saatte bir makale yazabilirsin. Fotoğraf otomatik küçültülür.</p></div></details>
   <div class="btns" style="margin:8px 0">${Object.keys(AR_SORT).map(k=>btn(AR_SORT[k],`data-a="arSort" data-s="${k}"`,AR.sort===k?'gold sm':'sm')).join('')}</div>`;
  const L=arSorted();
  h+=L.length?L.map(a=>`<div class="card"><h3>${esc(a.ti)} ${a.im?'📷':''}</h3><p class="dim">${esc(a.an)} · ${arAgo(a.t)}</p><p>${esc(a.b.slice(0,140))}${a.b.length>140?'…':''}</p>
   <div class="btns"><span style="align-self:center">👍 ${+a.l||0} · 👎 ${+a.d||0} · 💬 ${+a.c||0}</span>${btn('Oku',`data-a="artOpen" data-id="${a.id}"`,'blue sm')}</div></div>`).join(''):`<p class="dim">${AR.sort==='week'?'Bu hafta makale yok.':'Henüz makale yok. İlkini sen yaz.'}</p>`;
  return h+'</div>';
}
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='arCm'){e.preventDefault();const a=AR.open;if(a)ACT.artComment({id:a});}});
