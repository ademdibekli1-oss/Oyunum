/* ================= BAĞLANTILAR: bölge/ülke/parti/ittifak adlarına tıklayınca ilgili sayfaya git ================= */
ACT.goCity=d=>{const i=+d.id;if(!S.regions[i])return;UI.city=i;UI.tab='map';window.scrollTo(0,0);};
ACT.goMyCity=()=>{UI.city=S.me.loc;UI.tab='map';window.scrollTo(0,0);};

/* ================= TARİHTE BUGÜN kartı (Ana Sayfa) ================= */
const HIST=[
 [1,22,1517,'Ridaniye Savaşı: Yavuz Sultan Selim, Mısır’da Memlük ordusunu yendi.'],
 [3,12,1921,'İstiklal Marşı, Türkiye Büyük Millet Meclisi’nde kabul edildi.'],
 [3,18,1915,'Çanakkale Deniz Zaferi kazanıldı.'],
 [4,6,1453,'Fatih Sultan Mehmed, İstanbul kuşatmasını başlattı.'],
 [4,23,1920,'Türkiye Büyük Millet Meclisi, Ankara’da açıldı.'],
 [5,19,1919,'Mustafa Kemal Paşa Samsun’a çıktı; Millî Mücadele başladı.'],
 [5,29,1453,'İstanbul fethedildi.'],
 [7,24,1923,'Lozan Barış Antlaşması imzalandı.'],
 [8,24,1516,'Mercidabık Savaşı: Osmanlı ordusu Memlükleri yenerek Suriye’nin yolunu açtı.'],
 [8,26,1071,'Malazgirt Zaferi: Sultan Alparslan, Bizans ordusunu yendi ve Anadolu’nun kapıları Türklere açıldı.'],
 [8,26,1922,'Büyük Taarruz başladı.'],
 [8,29,1526,'Mohaç Meydan Muharebesi: Kanunî Sultan Süleyman, Macar ordusunu yendi.'],
 [8,30,1922,'Başkomutan Meydan Muharebesi kazanıldı.'],
 [9,9,1922,'İzmir düşman işgalinden kurtuldu.'],
 [9,28,1538,'Preveze Deniz Savaşı: Barbaros Hayreddin Paşa, Haçlı donanmasını yendi.'],
 [10,29,1923,'Türkiye Cumhuriyeti ilan edildi.'],
 [11,10,1938,'Mustafa Kemal Atatürk vefat etti.'],
 [12,17,1273,'Mevlânâ Celâleddîn-i Rûmî vefat etti (Şeb-i Arus).']
];
function histCard(){
  const now=new Date(),y=now.getFullYear(),t0=new Date(y,now.getMonth(),now.getDate()).getTime();
  let best=null;
  HIST.forEach(e=>{let d=new Date(y,e[0]-1,e[1]).getTime();if(d<t0)d=new Date(y+1,e[0]-1,e[1]).getTime();const days=Math.round((d-t0)/86400000);if(!best||days<best.days)best={e:e,days:days};});
  if(!best)return '';
  const e=best.e,ago=(best.days===0?y:(new Date(y,e[0]-1,e[1]).getTime()<t0?y+1:y))-e[2];
  const when=best.days===0?'Bugün':best.days===1?'Yarın':best.days+' gün sonra';
  return `<div class="card"><h3>📜 Tarihte Bugün</h3><p><b>${e[1]} ${['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'][e[0]-1]} ${e[2]}</b> <span class="dim">· ${when} · ${ago} yıl önce</span></p><p>${esc(e[3])}</p></div>`;
}
if(typeof tabHome==='function'){const _th0=tabHome;tabHome=function(){return _th0()+histCard();};}

/* ================= PAZAR FİYAT GEÇMİŞİ (10 dk aralıkla, son 24 saat) ================= */
function phRec(t){
  if(!S)return;S.ph=S.ph||[];
  S.ph.push([t].concat(RES.map(k=>Math.round(S.prices[k]*10)/10)));
  if(S.ph.length>144)S.ph.splice(0,S.ph.length-144);
}
function spark(vals,w,h){
  const mn=Math.min.apply(null,vals),mx=Math.max.apply(null,vals),rg=(mx-mn)||1;
  const pts=vals.map((v,i)=>((i/(vals.length-1))*(w-4)+2).toFixed(1)+','+(h-3-((v-mn)/rg)*(h-6)).toFixed(1)).join(' ');
  return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" style="vertical-align:middle"><polyline points="${pts}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/></svg>`;
}
function priceChart(){
  const ph=S.ph||[];
  let h=`<div class="panel"><h2>📈 Fiyat geçmişi</h2><div class="card">`;
  if(ph.length<3)return h+`<p class="dim">Veri toplanıyor. Fiyatlar 10 dakikada bir kaydedilir; birkaç saat sonra grafik dolar.</p></div></div>`;
  const span=Math.round((ph[ph.length-1][0]-ph[0][0])/3600e3*10)/10;
  h+=`<p class="dim">Son ${span<1?'birkaç dakika':span+' saat'} (en fazla 24 saat)</p><table>`;
  RES.forEach((k,i)=>{
    const vals=ph.map(r=>r[i+1]),cur=S.prices[k],first=vals[0],ch=Math.round((cur/first-1)*100);
    h+=`<tr><td>${RES_I[k]} ${RES_N[k]}</td><td class="${ch>=0?'ok':'bad'}">${spark(vals.concat([cur]),110,30)}</td><td class="num">${fmt(cur)}₺<br><small class="${ch>=0?'ok':'bad'}">${ch>=0?'▲':'▼'}${Math.abs(ch)}%</small></td></tr>`;
  });
  return h+`</table><p class="hint">Ucuz zamanda al, pahalı zamanda sat. Büyük işlemler fiyatı oynatır.</p></div></div>`;
}
if(typeof tabStore==='function'){const _ts0=tabStore;tabStore=function(){return _ts0()+priceChart();};}

/* ================= ARKADAŞ DAVET SİSTEMİ ================= */
const INV_URL=(()=>{try{const d=new URLSearchParams(location.search).get('d')||'';if(/^[A-Za-z0-9_-]{20,40}$/.test(d)){try{localStorage.setItem('bm_inv',d);}catch(e){}return d;}}catch(e){}return '';})();
const IVT={list:null,last:0,busy:false,errT:0};
const INV_BONUS=20000,INV_BONUS_G=2,INV_REW=40000,INV_REW_G=3,INV_MAX=25;
const invLink=()=>location.href.split('#')[0].split('?')[0]+'?d='+(MP.uid()||'');
const invBy=()=>{let d=(S.me&&S.me.invBy)||INV_URL;if(!d){try{d=localStorage.getItem('bm_inv')||'';}catch(e){}}return d;};
function invGold(g){const m=S.me;m.stor.gold=Math.min(storCap(),m.stor.gold+g);}
async function invTick(){
  if(!MP.ok||!MP.uid()||IVT.busy||Date.now()-IVT.errT<10*60e3)return;
  IVT.busy=true;
  try{
    const m=S.me,me=MP.uid(),by=invBy();
    if(by&&!m.invDone){
      if(by===me||m.level>3){m.invDone=1;} // kendi kendini ya da eski oyuncuyu davet sayma
      else{await MP.fb('PUT','invites/'+by+'/'+me,{n:m.name,t:Date.now()});
        m.invDone=1;m.invBy=by;m.money+=INV_BONUS;invGold(INV_BONUS_G);
        L(`🤝 Davetle katıldın: +${fmt(INV_BONUS)}₺ +${INV_BONUS_G} altın.`,'ok');toast(`🤝 Davet hoş geldin ödülü: +${fmt(INV_BONUS)}₺`,'ok');S.dirty=true;}
    }
    if(Date.now()-IVT.last>120e3){
      IVT.last=Date.now();
      const d=await MP.fb('GET','invites/'+me)||{};IVT.list=d;
      m.invClaim=m.invClaim||{};
      for(const u of Object.keys(d)){
        if(m.invClaim[u]||Object.keys(m.invClaim).length>=INV_MAX)continue;
        const p=(MP.players||{})[u];
        if(p&&+p.lv>=5){m.invClaim[u]=1;m.money+=INV_REW;invGold(INV_REW_G);
          L(`🤝 Davet ettiğin ${esc(d[u].n||'oyuncu')} 5. seviyeye ulaştı: +${fmt(INV_REW)}₺ +${INV_REW_G} altın.`,'ok');toast(`🤝 Davet ödülü: +${fmt(INV_REW)}₺ +${INV_REW_G} altın`,'ok');S.dirty=true;}
      }
    }
  }catch(e){IVT.errT=Date.now();IVT.err=String(e&&e.message||e);}
  IVT.busy=false;
}
if(typeof MP!=='undefined'&&typeof MP.sync==='function'){const _s0=MP.sync;MP.sync=async function(){const r=await _s0.apply(this,arguments);try{invTick();}catch(e){}return r;};}
function invCard(){
  const m=S.me;
  if(!MP.ok||!MP.uid())return card('🤝 Arkadaşını davet et','<p class="dim">Davet bağlantını almak için önce giriş yap (Profil › Hesap).</p>');
  const n=Object.keys(IVT.list||{}).length,got=Object.keys(m.invClaim||{}).length;
  return card('🤝 Arkadaşını davet et',`<p>Bağlantınla gelen arkadaşın <b>5. seviyeye</b> ulaşınca sen <b>${fmt(INV_REW)}₺ + ${INV_REW_G} altın</b>, o da girişte <b>${fmt(INV_BONUS)}₺ + ${INV_BONUS_G} altın</b> kazanır.</p>
   <p class="dim" style="word-break:break-all;font-size:12px">${esc(invLink())}</p>
   <div class="btns">${btn('📤 Paylaş','data-a="invShare"','gold')}${btn('📋 Kopyala','data-a="invCopy"')}</div>
   <p class="dim">Davet ettiğin: ${n} · ödül alınan: ${got}/${INV_MAX}</p>`);
}
function invCopyTxt(t){
  try{if(navigator.clipboard&&navigator.clipboard.writeText)return navigator.clipboard.writeText(t);}catch(e){}
  const a=document.createElement('textarea');a.value=t;a.style.cssText='position:fixed;opacity:0';document.body.appendChild(a);a.select();try{document.execCommand('copy');}catch(e){}a.remove();return Promise.resolve();
}
ACT.invCopy=()=>{invCopyTxt(invLink()).then(()=>msg('Bağlantı kopyalandı.','ok'));};
ACT.invShare=()=>{
  const u=invLink();
  if(navigator.share){navigator.share({title:'Bilâd-ı Mütenâfise',text:'Bu oyunda seni bekliyorum! Bağlantıyla katılırsan hoş geldin ödülü kazanırsın.',url:u}).catch(()=>{});}
  else invCopyTxt(u).then(()=>msg('Bağlantı kopyalandı, istediğin yerde paylaş.','ok'));
};
if(typeof tabChar==='function'){const _tc0=tabChar;tabChar=function(){return _tc0()+invCard();};}
/* ================= BİLÂD MODERN ARAYÜZ: üst bar, bağlamsal şerit, yeni ana sayfa, 5'li menü + "Daha" paneli ================= */
const MD={mode:'simple',sheet:false,alertsOpen:false,ob:0,ctxSig:'',alSig:''};
try{MD.mode=localStorage.getItem('bm_ui_mode')==='full'?'full':'simple';}catch(e){}
const mdSave=()=>{try{localStorage.setItem('bm_ui_mode',MD.mode);}catch(e){}};
const mdFull=()=>MD.mode==='full';

/* ---------- Görünüm (CSS) ---------- */
(function(){
  const st=document.createElement('style');st.id='mdcss';
  st.textContent=`
  :root{--bg0:#0c0809;--bg1:#161012;--bg2:#1c1416;--bg3:#241a1d;--bg4:#2e2024;--line:#3d2a30;--line2:#5a3d45;--tx:#f0e6df;--tx0:#fff7ee;--tx2:#b9a59f;--tx3:#8a7570;--gold:#e8b93a;--gold2:#ffd770;--blue:#2ec4c4;--red:#e30a17;--red2:#b3000f;--ok:#3ecf8e;--warn:#e0a12b;--bad:#ff6b6b;--mdr:14px;--mdrs:10px}
  html.light{--bg0:#f5efe6;--bg1:#fffdf9;--bg2:#f7f0e6;--bg3:#efe6d8;--bg4:#e9dcc6;--line:#dccfb8;--line2:#c4b49a;--tx:#1a0e0e;--tx0:#1a0e0e;--tx2:#5c4a44;--tx3:#85736c;--gold:#9a6b00;--gold2:#b8860b;--blue:#0b7a80;--ok:#17703d;--warn:#9a6700;--bad:#c62828}
  body{font-feature-settings:"tnum";-webkit-font-smoothing:antialiased}
  .app{max-width:520px;margin:0 auto}
  /* üst bar */
  header.topbar{position:sticky;top:0;z-index:40;display:block;background:linear-gradient(105deg,#b3000f 0%,#e30a17 55%,#9c0010 100%);padding:12px 14px 10px;border:none;border-bottom:3px solid var(--gold2);border-radius:0 0 14px 14px;box-shadow:0 8px 28px rgba(0,0,0,.45);overflow:visible;margin:0 -2px}
  header.topbar::after{display:none}
  .topbar-row{display:flex;align-items:center;gap:10px}
  .md-av{width:44px;height:44px;border-radius:50%;border:2px solid var(--gold2);background:rgba(0,0,0,.25);display:grid;place-items:center;font-weight:700;font-size:18px;color:#fff;flex:none;overflow:hidden;cursor:pointer}
  .md-av img{width:100%;height:100%;object-fit:cover}
  .top-meta{flex:1;min-width:0}.top-meta .name{font-size:16px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .top-meta .sub{font-size:12px;color:rgba(255,255,255,.8);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .top-meta .sub span{background:none!important;border:none!important;padding:0!important;color:inherit!important;font-size:inherit!important}
  .top-meta .sub #hDay{display:block;font-size:11px;opacity:.85}
  header.topbar #hBell{position:relative;width:40px;height:40px;border-radius:12px;background:rgba(0,0,0,.22);border:1px solid rgba(255,215,112,.35);display:grid;place-items:center;font-size:18px;flex:none;padding:0;color:#fff;cursor:pointer}
  header.topbar #hBell b{position:absolute;top:-5px;right:-5px;min-width:18px;height:18px;padding:0 4px;border-radius:9px;background:#fff!important;color:#b3000f!important;font-size:11px;font-weight:800;margin:0!important;display:grid;place-items:center;line-height:1}
  header.topbar .stats{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
  header.topbar .stats>span{background:rgba(0,0,0,.28);border:1px solid rgba(255,215,112,.4);border-radius:999px;padding:4px 10px;font-size:12px;color:#fff;display:inline-flex;align-items:center;gap:4px}
  header.topbar .stats b{color:var(--gold2);font-weight:700}
  header.topbar .stats>span.low b{color:#ffb4b4;animation:mdp 1.2s ease infinite}
  @keyframes mdp{0%,100%{opacity:1}50%{opacity:.6}}
  /* bağlamsal şerit */
  #ctx{display:none;align-items:center;gap:10px;padding:10px 12px;font-size:13px;font-weight:600;border-bottom:1px solid var(--line);margin:0 -2px}
  #ctx.show{display:flex}
  #ctx.war{background:linear-gradient(90deg,#3a1216,var(--bg1));color:#ffc9c9;border-bottom-color:#c62828}
  #ctx.travel{background:linear-gradient(90deg,#0f2426,var(--bg1));color:var(--blue);border-bottom-color:#0e8c8c}
  #ctx.elect{background:linear-gradient(90deg,#0f1e30,var(--bg1));color:#8ec8ff;border-bottom-color:#1f6feb}
  #ctx.energy{background:linear-gradient(90deg,#2a2210,var(--bg1));color:var(--gold);border-bottom-color:#9e6a03}
  html.light #ctx.war{background:linear-gradient(90deg,#fde8e8,var(--bg1));color:#8b1a1a}html.light #ctx.travel{background:linear-gradient(90deg,#dff3f3,var(--bg1))}html.light #ctx.elect{background:linear-gradient(90deg,#e4eefc,var(--bg1));color:#1f4fa0}html.light #ctx.energy{background:linear-gradient(90deg,#fff3d6,var(--bg1))}
  #ctx .ctx-ico{font-size:20px;flex:none}#ctx .ctx-body{flex:1;min-width:0}#ctx small{display:block;font-weight:500;opacity:.85;font-size:11px;margin-top:1px}
  /* uyarılar */
  #alerts{display:flex;flex-direction:column;gap:8px;padding:0}
  #alerts:empty{display:none}
  .md-al{border-radius:var(--mdrs);padding:10px 12px;font-size:13px;border:1px solid var(--line);display:flex;align-items:flex-start;gap:10px;background:var(--bg2);animation:mdin .3s ease}
  .md-al.bad{border-color:#c62828;background:linear-gradient(90deg,#2a1214,var(--bg2))}.md-al.warn{border-color:#9e6a03;background:linear-gradient(90deg,#2a2210,var(--bg2))}.md-al.info{border-color:#0e8c8c;background:linear-gradient(90deg,#0f2426,var(--bg2))}
  html.light .md-al.bad{background:linear-gradient(90deg,#fde8e8,var(--bg2))}html.light .md-al.warn{background:linear-gradient(90deg,#fff3d6,var(--bg2))}html.light .md-al.info{background:linear-gradient(90deg,#dff3f3,var(--bg2))}
  .md-al .ico{font-size:18px;line-height:1.2;flex:none}.md-al .body{flex:1;min-width:0}.md-al .actions{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
  .md-more{text-align:center;font-size:12px;color:var(--tx2);padding:6px;border-radius:8px;border:1px dashed var(--line);background:var(--bg1);width:100%;cursor:pointer}
  .md-empty{text-align:center;padding:18px 14px;background:var(--bg1);border:1px dashed var(--line);border-radius:var(--mdr);color:var(--tx2);font-size:13px}.md-empty .big{font-size:28px;margin-bottom:6px}.md-empty b{color:var(--tx);display:block;margin-bottom:4px}
  /* genel kart/düğme */
  main#main{padding:12px 12px 8px;background:none;border:none;border-radius:0;box-shadow:none}
  main#main::before,main#main::after{display:none}
  .md-home{display:flex;flex-direction:column;gap:12px}
  .md-sum{font-size:12px;color:var(--tx2);padding:8px 12px;background:var(--bg1);border:1px solid var(--line);border-radius:var(--mdrs);line-height:1.5}.md-sum b{color:var(--tx)}
  .md-card{background:var(--bg1);border:1px solid var(--line);border-radius:var(--mdr);padding:14px;box-shadow:0 2px 12px rgba(0,0,0,.2)}
  .md-card.glow{border-color:rgba(232,185,58,.45);box-shadow:0 0 0 1px rgba(232,185,58,.15),0 4px 20px rgba(0,0,0,.3)}
  .md-card h2{font-size:13px;text-transform:uppercase;letter-spacing:.06em;color:var(--blue);margin:0 0 10px;font-weight:700;border:none;padding:0}
  .md-card h3{font-size:15px;color:var(--gold);margin:0 0 6px}
  .md-row{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap}
  .md-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:8px 14px;border-radius:9px;font-size:13px;font-weight:600;background:var(--red);color:#fff;min-height:36px;border:1px solid transparent;cursor:pointer;font-family:inherit;transition:transform .1s,filter .15s}
  .md-btn:active{transform:scale(.96);filter:brightness(1.1)}.md-btn.sm{padding:5px 10px;font-size:12px;min-height:30px}.md-btn.gold{background:#a87a0a}.md-btn.ghost{background:var(--bg3);border-color:var(--line);color:var(--tx2)}.md-btn.danger{background:#6b1018}.md-btn.blue{background:#0e8c8c}.md-btn:disabled{opacity:.45;cursor:not-allowed}
  .md-sw{display:flex;background:var(--bg3);border-radius:999px;padding:3px;border:1px solid var(--line);width:fit-content}
  .md-sw button{padding:6px 12px;border-radius:999px;font-size:12px;font-weight:600;color:var(--tx3);background:none;border:none;cursor:pointer;font-family:inherit}.md-sw button.on{background:var(--red);color:#fff}
  .md-quests{display:flex;flex-direction:column;gap:8px}
  .md-q{display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--bg2);border:1px solid var(--line);border-radius:var(--mdrs)}
  .md-q.done{border-color:var(--ok);background:linear-gradient(90deg,rgba(62,207,142,.08),var(--bg2))}
  .md-q .qi{font-size:22px;flex:none}.md-q .qt{flex:1;min-width:0}.md-q .qt .t{font-size:13px;font-weight:600}.md-q .qt .p{font-size:11px;color:var(--tx3);margin-top:2px}
  .md-bar{height:6px;background:var(--bg3);border-radius:4px;overflow:hidden;margin-top:6px}.md-bar>i{display:block;height:100%;background:linear-gradient(90deg,var(--red),var(--gold));border-radius:4px;transition:width .4s ease}.md-q.done .md-bar>i{background:var(--ok)}
  .md-quick{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .md-qb{background:var(--bg2);border:1px solid var(--line);border-radius:var(--mdrs);padding:14px 12px;text-align:left;min-height:72px;cursor:pointer;color:var(--tx);font-family:inherit;transition:border-color .15s,transform .12s}
  .md-qb:active{transform:scale(.96)}.md-qb.hot{border-color:var(--gold);background:linear-gradient(145deg,#2a2010,var(--bg2));animation:mdpb 2s ease infinite}html.light .md-qb.hot{background:linear-gradient(145deg,#fff8e6,var(--bg2))}.md-qb.off{opacity:.45;pointer-events:none}
  .md-qb .ico{font-size:22px;line-height:1;margin-bottom:6px;display:block}.md-qb .lab{font-size:14px;font-weight:700;display:block}.md-qb .sub{font-size:11px;color:var(--tx3);margin-top:2px;display:block}
  @keyframes mdpb{0%,100%{box-shadow:0 0 0 0 rgba(232,185,58,.35)}50%{box-shadow:0 0 0 4px rgba(232,185,58,.12)}}
  @keyframes mdin{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
  #main>*{animation:mdin .2s ease both}
  details.md-fold{background:var(--bg1);border:1px solid var(--line);border-radius:var(--mdr);overflow:hidden}
  details.md-fold>summary{list-style:none;padding:12px 14px;font-size:14px;font-weight:700;color:var(--gold);cursor:pointer;display:flex;justify-content:space-between;align-items:center;user-select:none}
  details.md-fold>summary::-webkit-details-marker{display:none}details.md-fold>summary::after{content:"▾";color:var(--tx3);font-size:12px}details.md-fold[open]>summary::after{content:"▴"}
  details.md-fold .fb{padding:12px 14px 14px;border-top:1px solid var(--line)}
  .md-idx{display:grid;grid-template-columns:1fr 1fr;gap:8px}.md-i{background:var(--bg2);border:1px solid var(--line);border-radius:var(--mdrs);padding:10px 12px}
  .md-i .lab{font-size:11px;color:var(--tx3);text-transform:uppercase;letter-spacing:.04em}.md-i .val{font-size:22px;font-weight:800;color:var(--gold);line-height:1.2;margin-top:2px}.md-i .val.top{color:var(--ok)}.md-i .hint{font-size:11px;color:var(--tx3);margin-top:2px}
  .md-perks{display:flex;flex-direction:column;gap:8px}.md-p{display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--bg2);border:1px solid var(--line);border-radius:var(--mdrs)}.md-p.learning{border-color:var(--blue)}
  .md-p .pi{font-size:20px;flex:none}.md-p .pt{flex:1;min-width:0}.md-p .pt .n{font-size:13px;font-weight:700}.md-p .pt .d{font-size:11px;color:var(--tx3)}.md-p .pv{font-size:18px;font-weight:800;color:var(--gold);min-width:36px;text-align:right}
  .md-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}.md-chip{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:999px;font-size:11px;font-weight:700;border:1px solid var(--line);background:var(--bg2);color:var(--tx2)}
  .md-chip.on{border-color:var(--ok);color:var(--ok);background:rgba(62,207,142,.1)}.md-chip.warn{border-color:var(--warn);color:var(--warn);background:rgba(224,161,43,.1)}.md-chip.bad{border-color:var(--bad);color:var(--bad);background:rgba(255,107,107,.1)}
  .md-medals{display:flex;flex-wrap:wrap;gap:8px}.md-m{width:56px;text-align:center;font-size:11px;color:var(--tx3)}.md-m .mi{width:40px;height:40px;margin:0 auto 4px;border-radius:50%;background:var(--bg3);border:2px solid var(--line);display:grid;place-items:center;font-size:18px;filter:grayscale(1);opacity:.6}
  .md-m.got .mi{border-color:var(--gold);box-shadow:0 0 0 2px rgba(232,185,58,.2);filter:none;opacity:1}
  .md-train{display:flex;align-items:center;gap:12px;padding:12px;background:linear-gradient(135deg,#1a2228,var(--bg2));border:1px solid var(--line);border-radius:var(--mdrs)}html.light .md-train{background:linear-gradient(135deg,#e8f0f2,var(--bg2))}
  .md-train .tico{font-size:28px}.md-train .tb{flex:1}.md-train .tb b{display:block;font-size:14px}.md-train .tb span{font-size:12px;color:var(--tx3)}
  .md-mini{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}.md-mini span{font-size:11px;padding:3px 8px;background:var(--bg3);border-radius:6px;color:var(--tx2);border:1px solid var(--line)}
  .md-dmg{font-size:12px;color:var(--tx2);line-height:1.5;padding:10px;background:var(--bg2);border-radius:var(--mdrs);border:1px solid var(--line)}.md-dmg code{color:var(--gold);font-size:11px;word-break:break-all}
  .md-pol{display:flex;flex-direction:column;gap:8px}.md-pr{display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--bg2);border:1px solid var(--line);border-radius:var(--mdrs)}.md-pr .pico{font-size:22px;flex:none}.md-pr .pb{flex:1;min-width:0}.md-pr .pb b{display:block;font-size:13px}.md-pr .pb span{font-size:11px;color:var(--tx3)}.md-pr .pv2{font-size:13px;font-weight:700;color:var(--gold);text-align:right;white-space:nowrap}
  .md-hint{font-size:11px;color:var(--tx3);margin-top:8px}
  /* alt menü */
  nav#nav{position:fixed;left:50%;transform:translateX(-50%);bottom:0;width:min(520px,100%);z-index:50;display:flex;flex-wrap:wrap;background:rgba(22,16,18,.93);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-top:1px solid var(--line);border-radius:16px 16px 0 0;padding:6px 4px calc(6px + env(safe-area-inset-bottom,0px));box-shadow:0 -6px 24px rgba(0,0,0,.4);gap:0}
  html.light nav#nav{background:rgba(255,253,249,.95)}
  nav#nav>button{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;padding:6px 2px;font-size:10px;color:var(--tx3);border-radius:10px;min-width:0;position:relative;background:none;border:none;cursor:pointer;font-family:inherit;text-align:center}
  nav#nav>button i{font-style:normal;font-size:20px;line-height:1.15}nav#nav>button.active{color:#fff;background:rgba(227,10,23,.25)}html.light nav#nav>button.active{color:var(--red);background:rgba(227,10,23,.12)}
  nav#nav>button.active i{filter:drop-shadow(0 0 4px var(--gold2))}
  nav#nav>button .md-dot{position:absolute;top:4px;right:calc(50% - 20px);min-width:16px;height:16px;border-radius:8px;background:var(--red);color:#fff;font-size:10px;font-weight:800;display:grid;place-items:center;padding:0 3px;border:1.5px solid var(--bg1)}
  nav#nav .subnav{flex:1 1 100%;order:-1;display:flex;gap:4px;margin:0 0 6px;overflow-x:auto;padding:0 4px}
  nav#nav .subnav button{flex:1 0 auto;min-width:64px;background:var(--bg2);border:1px solid var(--line);border-radius:999px;font-size:12px;padding:6px 10px;color:var(--tx2);cursor:pointer;font-family:inherit}
  nav#nav .subnav button.on{background:var(--bg4);color:var(--gold);border-color:var(--gold);font-weight:700}
  #mdbg{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:60;opacity:0;pointer-events:none;transition:opacity .25s}#mdbg.open{opacity:1;pointer-events:auto}
  #mdsheet{position:fixed;left:50%;transform:translateX(-50%) translateY(110%);bottom:0;width:min(520px,100%);z-index:70;background:var(--bg1);border-radius:18px 18px 0 0;border:1px solid var(--line);border-bottom:none;padding:10px 14px calc(18px + env(safe-area-inset-bottom,0px));transition:transform .32s cubic-bezier(.2,.9,.2,1);max-height:78vh;overflow-y:auto}
  #mdsheet.open{transform:translateX(-50%) translateY(0)}
  #mdsheet .handle{width:40px;height:4px;background:var(--line2);border-radius:2px;margin:0 auto 12px}
  #mdsheet h3{font-size:14px;color:var(--gold);margin:0 0 10px}
  .md-sg{display:grid;grid-template-columns:1fr 1fr;gap:8px}.md-si{display:flex;align-items:center;gap:10px;padding:12px;background:var(--bg2);border:1px solid var(--line);border-radius:var(--mdrs);font-size:13px;font-weight:600;text-align:left;color:var(--tx);cursor:pointer;font-family:inherit}.md-si span{font-size:20px}
  .md-obs{display:flex;gap:6px;margin-bottom:14px}.md-obs i{flex:1;height:4px;border-radius:2px;background:var(--line)}.md-obs i.on{background:var(--gold)}
  .md-ob{font-size:14px;margin-bottom:16px;line-height:1.55}.md-ob .oi{font-size:40px;display:block;text-align:center;margin-bottom:10px}
  .confetti{position:fixed;pointer-events:none;z-index:100;width:8px;height:8px;border-radius:2px;animation:mdcf .9s ease forwards}
  @keyframes mdcf{0%{transform:translate(0,0) rotate(0);opacity:1}100%{transform:translate(var(--dx),var(--dy)) rotate(220deg);opacity:0}}
  #toasts{bottom:calc(var(--navh) + 16px)}
  @media(min-width:520px){.md-quick{grid-template-columns:1fr 1fr 1fr}}
  @media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
  `;
  document.head.appendChild(st);
})();

/* ---------- Üst bar ---------- */
(function(){
  const hd=document.querySelector('header');if(!hd)return;
  hd.className='topbar';
  hd.innerHTML=`<div class="topbar-row"><div class="md-av" id="mdAv" data-a="tab" data-t="char"></div><div class="top-meta"><div class="name" id="mdName"></div><div class="sub"><span id="mdRank"></span> · <span id="hLoc" data-a="goMyCity"></span> · <span id="hDay"></span></div></div><span id="hBell" data-a="bell">🔔<b id="hBellN" style="display:none"></b></span></div>
  <div class="stats"><span data-a="tab" data-t="store">💰 <b id="hMoney"></b></span><span data-a="tab" data-t="store">🥇 <b id="hGold"></b></span><span id="stEn" data-a="tab" data-t="work">⚡ <b id="hEn"></b></span><span data-a="tab" data-t="char">⭐ Sv <b id="hLvl"></b></span></div>`;
  const ctx=document.createElement('div');ctx.id='ctx';ctx.setAttribute('role','status');hd.insertAdjacentElement('afterend',ctx);
  const sb=document.createElement('div');sb.id='mdbg';const sh=document.createElement('div');sh.id='mdsheet';sh.setAttribute('role','dialog');sh.innerHTML='<div class="handle"></div><div id="mdsc"></div>';
  document.body.appendChild(sb);document.body.appendChild(sh);
})();
function mdTopUpdate(){
  const m=S.me,e=document.getElementById('mdName');if(!e)return;
  e.textContent=m.name||'Sen';
  const r=document.getElementById('mdRank');if(r&&typeof rankName==='function')r.textContent=rankName();
  const av=document.getElementById('mdAv'),k=(m.avatar?'i':'t')+(m.avatar||'').length+(m.name||'');
  if(av&&av.dataset.k!==k){av.dataset.k=k;av.innerHTML=m.avatar?`<img src="${m.avatar}" alt="">`:esc((m.name||'?').slice(0,1).toUpperCase());}
  const en=document.getElementById('stEn');if(en)en.classList.toggle('low',m.energy<30);
}

/* ---------- Bağlamsal şerit ---------- */
function mdCtx(){
  const bar=document.getElementById('ctx');if(!bar)return null;
  const m=S.me;let kind='',html='';
  const w=S.wars.find(x=>x.state==='on'&&(x.att==='A'||x.def==='A'));
  if(w){kind='war';html=`<span class="ctx-ico">⚔️</span><div class="ctx-body"><div>${esc(S.regions[w.region].n)} — ${WTYPE[w.type]} savaşı</div><small>${nameOf(w.att)} → ${nameOf(w.def)} · bitmesine ${cd(w.end)}</small></div><button class="md-btn sm danger" data-a="hit" data-w="${w.id}">💥 Vur</button>`;}
  else if(m.travel){kind='travel';html=`<span class="ctx-ico">🧳</span><div class="ctx-body"><div>${esc(S.regions[m.travel.to].n)} yolundasın</div><small>Varışa ${cd(m.travel.arrive)}</small></div>${m.travel.back?'':'<button class="md-btn sm blue" data-a="travelBack">↩ Geri</button>'}`;}
  else if(A().election){kind='elect';html=`<span class="ctx-ico">🗳️</span><div class="ctx-body"><div>Seçim sürüyor</div><small>Bitişine ${cd(A().election.end)}</small></div><button class="md-btn sm blue" data-a="tab" data-t="party">Oy ver</button>`;}
  else if(m.energy<30){kind='energy';html=`<span class="ctx-ico">⚡</span><div class="ctx-body"><div>Enerji düşük (${Math.floor(m.energy)})</div><small>Çalışmak için içecek al (2 altın)</small></div><button class="md-btn sm gold" data-a="drink">İçecek</button>`;}
  const sig=kind+'|'+html.replace(/data-cd="\d+"/g,'').replace(/>[^<>]*</g,'><')+(kind==='energy'?Math.floor(m.energy/5):'');
  if(sig!==MD.ctxSig){MD.ctxSig=sig;bar.className=kind?'show '+kind:'';bar.id='ctx';bar.innerHTML=html;}
  return kind;
}

/* ---------- Uyarılar (en çok 2 + "daha") ---------- */
alerts=function(){
  const box=document.getElementById('alerts');if(!box)return;
  const ctxKind=mdCtx(),m=S.me,list=[],homeTab=['home','char','work','craft','quest'].includes(UI.tab);
  const mk=(cls,ico,html)=>list.push(`<div class="md-al ${cls}"><span class="ico">${ico}</span><div class="body">${html}</div></div>`);
  S.wars.filter(w=>w.state!=='done'&&(w.att==='A'||w.def==='A')).forEach(w=>{
    if(ctxKind==='war'&&w.state==='on')return;
    const t=w.state==='prep'?`başlamasına ${cd(w.start)}`:`bitmesine ${cd(w.end)}`;
    mk('bad','⚔️',`<b><a class="lk" data-a="goCity" data-id="${w.region}">${esc(S.regions[w.region].n)}</a></b> (${WTYPE[w.type]}) — ${nameOf(w.att)} → ${nameOf(w.def)}<div class="dim">${t}</div>${w.state==='on'?`<div class="actions"><button class="md-btn sm danger" data-a="hit" data-w="${w.id}">💥 Vur</button><button class="md-btn sm ghost" data-a="tab" data-t="war">Savaşa git</button></div>`:''}`);});
  if(A().election&&ctxKind!=='elect'&&!(ctxKind==='war'))mk('info','🗳️',`<b>Seçim sürüyor</b><div class="dim">Bitişine ${cd(A().election.end)}</div><div class="actions"><button class="md-btn sm blue" data-a="tab" data-t="party">Oy ver</button></div>`);
  if(homeTab&&S.t<S.protectUntil)mk('info','🛡️',`<b>Acemilik koruması</b><div class="dim">Bitişine ${cd(S.protectUntil)} · kimse devletine saldıramaz</div>`);
  if(S.ann&&S.ann.m)mk('info','📣',`<b>Duyuru:</b> ${esc(S.ann.m)}`);
  if(S.evt&&S.evt.until>S.t)mk('warn','🎉',`<b>${EVT[S.evt.k].n}</b><div class="dim">Bitişine ${cd(S.evt.until)}</div>`);
  if(['home','char'].includes(UI.tab)&&!m.learn)mk('warn','📚',`<b>Öğrenme boşta</b><div class="dim">Profil sekmesinden yetenek geliştir</div><div class="actions"><button class="md-btn sm gold" data-a="tab" data-t="char">Öğren</button></div>`);
  if(m.travel&&ctxKind!=='travel')mk('info','🧳',`<b>Yoldasın:</b> ${esc(S.regions[m.travel.to].n)}<div class="dim">Varışa ${cd(m.travel.arrive)}</div>`);
  if(typeof swAlerts==='function')swAlerts().forEach(x=>mk('info','🛡️',x.replace(/<div class="al [a-z]+">|<\/div>$/g,'')));
  let h;
  if(!list.length)h=UI.tab==='home'?`<div class="md-empty"><div class="big">🕊️</div><b>Şu an acil bir şey yok</b>Barış var — ekonomiye veya öğrenmeye odaklanabilirsin.</div>`:'';
  else{const show=MD.alertsOpen?list:list.slice(0,2);h=show.join('');if(list.length>2)h+=`<button class="md-more" data-a="mdAlMore">${MD.alertsOpen?'▴ Gizle':'▾ '+(list.length-2)+' uyarı daha'}</button>`;}
  const sig=h.replace(/data-cd="\d+"/g,'').replace(/>[^<>]*</g,'><');
  if(sig!==MD.alSig||!box.innerHTML){MD.alSig=sig;box.innerHTML=h;}
};
ACT.mdAlMore=()=>{MD.alertsOpen=!MD.alertsOpen;MD.alSig='';alerts();S.dirty=false;};

/* ---------- Menü ---------- */
const MD_BOTTOM=['home','eco','war','gov'];
function mdUnread(){return (typeof CHAT!=='undefined')?((CHAT.unread||0)+(CHAT.dmUnread||0)):0;}
renderNav=function(){
  const qb=(typeof questBadge==='function')?questBadge():0,cg=groupOf(UI.tab),un=mdUnread();
  const dot=n=>n?`<span class="md-dot">${n>99?'99+':n}</span>`:'';
  const tit=g=>[g[1].split(' ')[0],g[1].split(' ').slice(1).join(' ')];
  let h=MD_BOTTOM.map(id=>GROUPS.find(g=>g[0]===id)).filter(Boolean).map(g=>{const t=tit(g);return `<button class="${g[0]===cg[0]?'active':''}" data-a="tab" data-t="${g[0]===cg[0]?UI.tab:g[2][0][0]}"><i>${t[0]}</i>${t[1]}${g[0]==='home'?dot(qb):''}</button>`;}).join('');
  h+=`<button class="${MD_BOTTOM.includes(cg[0])?'':'active'}" data-a="mdMore"><i>☰</i>Daha${dot(un)}</button>`;
  const vis=cg[2].filter(t=>t[2]!=='adm'||isAdminUI());
  if(vis.length>1)h+=`<div class="subnav">${vis.map(t=>`<button class="${UI.tab===t[0]?'on':''}" data-a="tab" data-t="${t[0]}">${t[1]}${t[0]==='quest'&&qb?` <span class="owner" style="background:#da3633;color:#fff">${qb}</span>`:''}${t[0]==='chat'&&un?` <span class="owner" style="background:#da3633;color:#fff">${un}</span>`:''}</button>`).join('')}</div>`;
  const nv=document.getElementById('nav');if(nv.innerHTML!==h)nv.innerHTML=h;
  try{document.documentElement.style.setProperty('--navh',nv.offsetHeight+'px');}catch(e){}
};
function mdSheet(on){
  MD.sheet=on;document.getElementById('mdsheet').classList.toggle('open',on);document.getElementById('mdbg').classList.toggle('open',on);
}
const MD_IC={auto:'⚙️',ctl:'🎛️',art:'📝',paper:'📰',chat:'💬',ally:'🛡️',lb:'🏆',char:'👤',ai:'🧠',stats:'📊',set:'⚙️',guide:'📖',net:'🌐',adm:'👑',bots:'🤖',give:'🎁',cities:'🏙️',leader:'👑',elect:'🗳️',sw:'🤝',spy:'🕵️',map:'🗺️'};
function mdMoreHtml(){
  const rest=GROUPS.filter(g=>!MD_BOTTOM.includes(g[0]));
  return rest.map(g=>`<h3>${g[1]}</h3><div class="md-sg" style="margin-bottom:12px">${g[2].filter(t=>t[2]!=='adm'||isAdminUI()).map(t=>{const p=String(t[1]).split(' ');const ic=/^[^\wÇĞİÖŞÜçğıöşü]/.test(p[0])?p.shift():(MD_IC[t[0]]||'▫️');return `<button class="md-si" data-a="tab" data-t="${t[0]}"><span>${ic}</span>${esc(p.join(' ')||t[1])}</button>`;}).join('')}</div>`).join('');
}
ACT.mdMore=()=>{document.getElementById('mdsc').innerHTML=mdMoreHtml();mdSheet(true);S.dirty=false;};
{const _t=ACT.tab;ACT.tab=function(d){if(MD.sheet)mdSheet(false);window.scrollTo(0,0);return _t(d);};}
document.addEventListener('click',e=>{if(e.target&&e.target.id==='mdbg')mdSheet(false);});

/* ---------- Askeri eğitim (saatlik, enerji harcamaz) ---------- */
const MD_TRAIN_CD=HOUR;
ACT.hourTrain=()=>{
  const m=S.me;if(m.travel)return msg('Yoldasın.');
  if((m.trainAt||0)+MD_TRAIN_CD>S.t)return msg('Eğitim henüz hazır değil.');
  m.trainAt=S.t;m.trains=(m.trains||0)+1;const xp=8+m.level;addXP(xp);
  msg(`🎖️ Askeri eğitim tamam: +${xp} XP`,'ok');L(`🎖️ Askeri eğitim yaptın (+${xp} XP).`,'ok');
};

/* ---------- Bugünkü özet sayaçları ---------- */
function mdDay(){
  const m=S.me,k=dayKey();
  if(!m.dsum||m.dsum.k!==k)m.dsum={k:k,w:m.works||0,h:m.hits||0,mo:m.money};
  return {w:(m.works||0)-m.dsum.w,h:(m.hits||0)-m.dsum.h,mo:m.money-m.dsum.mo};
}

/* ---------- Madalyalar ---------- */
function mdMedals(){
  const m=S.me;
  return [['⛏️','İşçi',(m.works||0)>=100],['⚔️','Savaşçı',(m.hits||0)>=25],['🎖️','Eğitim',(m.trains||0)>=10],['🗳️','Politikacı',!!m.party],['📰','Basın',!!m.paper],['👑','Lider',typeof isLeader==='function'&&isLeader()]];
}

/* ---------- Ana sayfa ---------- */
function mdQuests(){
  const m=S.me,out=[],full=mdFull();
  try{if(typeof streakInfo==='function'&&streakInfo().can)out.push({i:'🎁',t:'Günlük giriş ödülünü al',p:'Ücretsiz para, altın ve enerji',claim:'<button class="md-btn sm gold" data-a="dailyClaim">Al</button>',done:1});}catch(e){}
  try{qProg(qState()).forEach(p=>{if(p.done)return;out.push({i:p.i,t:'Günlük: '+p.t,p:`${p.cur} / ${p.n}`,cur:p.cur,max:p.n,done:p.ok,claim:p.ok?`<button class="md-btn sm gold" data-a="qClaim" data-id="${p.id}">Al</button>`:'<button class="md-btn sm ghost" disabled>Ödül</button>'});});}catch(e){}
  try{const r=wqReward();wqProg(wqState()).forEach(p=>{if(p.done)return;if(!p.ok&&!full)return;out.push({i:p.i,t:'Haftalık: '+p.t,p:`${p.cur} / ${p.n} · +${fmt(r.money)}₺ + ${r.gold} altın`,cur:p.cur,max:p.n,done:p.ok,claim:p.ok?`<button class="md-btn sm gold" data-a="wqClaim" data-id="${p.id}">Al</button>`:'<button class="md-btn sm ghost" disabled>Ödül</button>'});});}catch(e){}
  if(!m.learn)out.push({i:'📚',t:'Öğrenme boşta',p:'Profil → yetenek geliştir',claim:'<button class="md-btn sm ghost" data-a="tab" data-t="char">Profil</button>'});
  return out;
}
function mdQuestHtml(){
  const qs=mdQuests();
  if(!qs.length)return '<div class="md-empty" style="border:none;padding:12px 0"><div class="big">📋</div><b>Aktif görev yok</b><span class="dim">Görevler her gün yenilenir.</span></div>';
  return qs.slice(0,mdFull()?20:5).map(q=>`<div class="md-q${q.done?' done':''}"><span class="qi">${q.i}</span><div class="qt"><div class="t">${esc(q.t)}</div><div class="p">${esc(q.p)}</div>${q.max?`<div class="md-bar"><i style="width:${Math.min(100,Math.round(q.cur/q.max*100))}%"></i></div>`:''}</div>${q.claim}</div>`).join('');
}
function mdQuick(){
  const m=S.me,war=S.wars.some(w=>w.state==='on'&&(w.att==='A'||w.def==='A')),ec=energyCost(),el=A().election;
  const it=[
    ['work','⛏️','Çalış',m.energy>=ec?'Enerji yeterli':'Enerji az — içecek al',!!m.travel,false],
    ['craft','🔧','Üretim',(m.craftQ||[]).length?(m.craftQ.length+' iş sırada'):'Kuyruk boş',false,false],
    ['war','⚔️','Savaş',war?'Aktif — dokun':'Aktif savaş yok',false,war],
    ['store','🏦','Depo',fmt(m.money)+'₺',false,false],
    ['char','📚','Öğren',m.learn?('Sürüyor · '+fmtDur(m.learn.end-S.t)):'Boşta — başlat',false,!m.learn],
    ['state','🏛️','Yönet',el?'Seçim var!':'Devlet · Parti',false,!!el]];
  return it.map(x=>`<button class="md-qb${x[5]?' hot':''}${x[4]?' off':''}" data-a="tab" data-t="${x[0]}"><span class="ico">${x[1]}</span><span class="lab">${x[2]}</span><span class="sub">${esc(x[3])}</span></button>`).join('');
}
function mdRegion(){
  const m=S.me,r=myReg(),hr=homeReg(),homeOk=m.loc===m.res&&S.t-m.resSince>6*HOUR;
  const L4={h:['❤️ Sağlık','Enerji yenilenmesi'],m:['🎖️ Askeri','Savaş hasarı / savunma'],e:['🎓 Eğitim','Öğrenme hızı'],d:['🏘️ Gelişmişlik','Vergi & verim']};
  const hrs=Math.floor((S.t-m.resSince)/HOUR),days=Math.floor(hrs/24);
  const idx=Object.keys(L4).map(k=>{const v=r.idx[k];return `<div class="md-i"><div class="lab">${L4[k][0]}</div><div class="val${v>=10?' top':''}">${v}${v>=11?' ★':''}</div><div class="hint">${L4[k][1]}</div></div>`;}).join('');
  const RN={gold:'🥇 Altın',oil:'🛢️ Petrol',ore:'⛏️ Maden',uranium:'☢️ Uranyum',diamonds:'💎 Elmas'};
  const res=RES.filter(k=>r.res[k]&&r.res[k].m>0).map(k=>`<span>${RN[k]} ${Math.floor(r.res[k].c)}/${r.res[k].m}</span>`).join('')||'<span class="dim">Rezerv yok</span>';
  const ch=[];
  const resident=hr&&hr.id===r.id;
  ch.push(m.res===r.id?(homeOk||m.res!==m.loc?`<span class="md-chip on">🏠 İkametgâhın</span>`:`<span class="md-chip on">🏠 İkametgâhın</span>`):`<span class="md-chip">✈️ Misafirsin</span>`);
  if(homeReg().state==='A')ch.push(S.t-m.resSince>6*HOUR?'<span class="md-chip on">⭐ Anavatan bonusu</span>':`<span class="md-chip warn">⭐ Anavatan için ${Math.max(0,Math.ceil(6-(S.t-m.resSince)/HOUR))}sa daha</span>`);
  if(r.coast)ch.push('<span class="md-chip">⚓ Kıyı</span>');if(r.moon)ch.push('<span class="md-chip">🌙 Ay</span>');
  ch.push(regionAllows(r)?'<span class="md-chip on">📋 Çalışma izni</span>':'<span class="md-chip bad">📋 İzin yok</span>');
  const nb=Object.values(r.b||{}).filter(v=>v>0).length,cz=(typeof BOTAGG!=='undefined'&&BOTAGG.reg&&BOTAGG.reg[r.id])||0;
  ch.push(`<span class="md-chip">👥 ${fmt(cz+1)}</span><span class="md-chip">🏗️ ${nb}</span>`);
  return `<section class="md-card"><div class="md-row" style="margin-bottom:8px"><h2 style="margin:0">📍 Bölge</h2><span class="md-chip ${m.res===r.id?'on':'warn'}">${m.res===r.id?'🏠 İkametgâh':'🧳 Ziyaret'}</span></div>
  <p style="font-size:14px;font-weight:700;margin:0 0 4px">${typeof eLink==='function'?eLink('city',r.id,esc(r.n)):esc(r.n)}</p><p class="dim" style="margin:0 0 10px">${String(nameOf(r.state)).replace(/<[^>]+>/g,'')} · ikamet ${days?days+'g ':''}${hrs%24}sa</p>
  <div class="md-idx">${idx}</div><div class="md-mini">${res}</div><div class="md-chips">${ch.join('')}</div></section>`;
}
function mdPerks(){
  const m=S.me,IC={str:'💪',edu:'📚',end:'🛡️'},DS={str:'Savaş hasarı, üretim maliyeti −',edu:'İş deneyimi, hasar, maliyet −',end:'İş enerjisi −, depo +%1/puan'};
  return Object.keys(PERKS).map(k=>{const lr=m.learn&&m.learn.perk===k;return `<div class="md-p${lr?' learning':''}"><span class="pi">${IC[k]}</span><div class="pt"><div class="n">${PERKS[k]}${lr?' · öğreniliyor':''}</div><div class="d">${DS[k]}${lr?' · '+cd(m.learn.end):''}</div></div><div class="pv">${perk(k)}</div></div>`;}).join('');
}
function mdTrain(){
  const m=S.me,left=(m.trainAt||0)+MD_TRAIN_CD-S.t,ready=left<=0;
  return `<div class="md-train"><div class="tico">🛡️</div><div class="tb"><b>Saatlik eğitim</b><span>${ready?'Hazır — enerji harcamadan XP':'Sonraki eğitim: '+cd(S.t+left)}</span></div><button class="md-btn sm gold" data-a="hourTrain" ${ready?'':'disabled'}>${ready?'Eğit':'Bekle'}</button></div>`;
}
function mdDmg(){
  const m=S.me,r=myReg(),home=(homeReg().state==='A'&&S.t-m.resSince>6*HOUR)?1.1:1;
  let d=0;try{d=Math.round(hitDamage(null));}catch(e){}
  return `<div class="md-dmg"><p>Savaş vuruşunu etkileyen ana faktörler:</p><code>Güç · Eğitim · Dayanıklılık · Seviye · Bölgenin askeri indeksi (${r.idx.m}) · anavatan${home>1?' (+%10 aktif)':''} · birlikler</code><p style="margin-top:8px">Şu anki vuruşun: <b style="color:var(--gold)">${d?fmt(d):'—'}</b> hasar</p><p class="dim" style="margin-top:6px">Askeri akademi, füze, liman, havaalanı ve birlikler çarpanı artırır.</p></div>`;
}
/* ---------- Parti & makam ---------- */
function mdPolitics(){
  const m=S.me,a=A(),rows=[];
  const row=(i,t,sb,v)=>rows.push(`<div class="md-pr"><span class="pico">${i}</span><div class="pb"><b>${esc(t)}</b><span>${esc(sb)}</span></div>${v?`<div class="pv2">${v}</div>`:''}</div>`);
  if(m.party){
    const p=(a.parties||[]).find(x=>x.id===m.party)||{n:m.party,supp:0};let seats=0;
    try{seats=(seatsOf()||{})[m.party]||0;}catch(e){}
    const tot=(a.parties||[]).reduce((x,q)=>x+Math.max(0,q.supp),0)||1;
    row('🎗️',p.n,(m.partyLead?'Parti lideri':'Üye')+' · '+seats+' sandalye · %'+Math.round(Math.max(0,p.supp)/tot*100),'');
  }else row('🎗️','Partisiz',m.level>=5?'Bir partiye katıl, seçimlerde sözün olsun':'Seviye 5\'te partiye katılabilirsin',m.level>=5?'<button class="md-btn sm ghost" data-a="tab" data-t="party">Parti</button>':'');
  let lead=false;try{lead=isLeader();}catch(e){}
  if(lead)row('👑','Devlet başkanı','Kanun, bakan atama, savaş ilanı','Aktif');
  if(a.min&&a.min.econ==='me')row('💼','Ekonomi bakanı','Vergi / bina / keşif kanunları anında','Aktif');
  if(a.min&&a.min.foreign==='me')row('🌐','Dışişleri bakanı','Anlaşma ve ambargo','Aktif');
  let gv=[];try{gv=typeof myGovs==='function'?myGovs():[];}catch(e){}
  if(gv&&gv.length)row('🏙️','Vali — '+gv.map(x=>x.n).join(', '),'Şehir hazinesi · inşaat · geliştirme','Aktif');
  if(!lead&&!(a.min&&(a.min.econ==='me'||a.min.foreign==='me'))&&!(gv&&gv.length)&&m.party)row('📋','Makam yok','Seçim, kampanya veya valilik ile yüksel','—');
  if(m.party&&!lead&&m.level>=10&&typeof coupChance==='function'){let c=0;try{c=Math.round(coupChance()*100);}catch(e){}row('🗡️','Darbe şansın','Devlet sekmesinden girişim yapılır (riskli)','%'+c);}
  return `<section class="md-card"><div class="md-row" style="margin-bottom:8px"><h2 style="margin:0">🗳️ Parti &amp; makam</h2><button class="md-btn sm ghost" data-a="tab" data-t="party">Parti</button></div><div class="md-pol">${rows.join('')}</div></section>`;
}
const _mdOldHome=tabHome;
tabHome=function(){
  const m=S.me,d=mdDay(),full=mdFull();
  let h=`<div class="md-home">`;
  const sm=[`Bugün: <b>${d.w} iş</b>`,`<b>${d.h} vuruş</b>`,`<b>${d.mo>=0?'+':''}${fmt(d.mo)}₺</b> net`];
  if(m.learn)sm.push(`öğrenme sürüyor <b>(${cd(m.learn.end)})</b>`);else sm.push('<b>öğrenme boşta</b>');
  h+=`<div class="md-sum">${sm.join(' · ')}</div>`;
  h+=mdRegion();
  h+=`<section class="md-card"><h2>📈 Yetenekler</h2><div class="md-perks">${mdPerks()}</div><p class="md-hint">Aynı anda yalnızca biri öğrenilir. Altınla süre kısalır.</p></section>`;
  h+=`<section class="md-card"><h2>🎖️ Askeri eğitim</h2>${mdTrain()}</section>`;
  h+=mdPolitics();
  if(full){h+=`<section class="md-card"><h2>🏅 Madalyalar</h2><div class="md-medals">${mdMedals().map(x=>`<div class="md-m${x[2]?' got':''}"><div class="mi">${x[0]}</div>${x[1]}</div>`).join('')}</div></section>`;}
  h+=`<section class="md-card glow"><div class="md-row" style="margin-bottom:10px"><h2 style="margin:0">🎯 Bugün ne yapmalıyım?</h2><div class="md-sw"><button class="${full?'':'on'}" data-a="mdMode" data-m="simple">Basit</button><button class="${full?'on':''}" data-a="mdMode" data-m="full">Tam</button></div></div><div class="md-quests" id="mdQL">${mdQuestHtml()}</div></section>`;
  h+=`<section><h2 style="font-size:13px;color:var(--blue);text-transform:uppercase;letter-spacing:.06em;margin:0 0 8px 4px;font-weight:700">⚡ Hızlı eylemler</h2><div class="md-quick">${mdQuick()}</div></section>`;
  return h+'</div>';
};
ACT.mdMode=d=>{MD.mode=d.m==='full'?'full':'simple';mdSave();};
/* tabHome ile yarışan eski sarmalayıcılar (ilk adımlar kartı vb.) Tam görünümde eski panelde kalır */

/* ---------- Tanıtım (ilk giriş) ---------- */
const MD_OB=[
 {i:'⛏️',t:'Kaynak çıkar',d:'Ekonomi → Çalış bölümünden altın, petrol veya maden topla. Enerji harcarsın; depon dolar.'},
 {i:'🏦',t:'Sat ve biriktir',d:'Depodaki kaynakları pazarda sat. Parayla üretim, öğrenme ve binalar açılır.'},
 {i:'📚',t:'Güçlen',d:'Profilinden güç, eğitim veya dayanıklılık öğren. Savaş ve üretim daha verimli olur.'},
 {i:'🎯',t:'Hedeflerini izle',d:'Ana sayfadaki "Bugün ne yapmalıyım?" kartı sıradaki işi gösterir. Alttaki "Daha" düğmesinde diğer tüm bölümler var.'}];
function mdObDraw(){
  const s=MD_OB[MD.ob],last=MD.ob>=MD_OB.length-1;
  document.getElementById('mdsc').innerHTML=`<h3>Hoş geldin</h3><div class="md-obs">${MD_OB.map((_,i)=>`<i class="${i<=MD.ob?'on':''}"></i>`).join('')}</div><div class="md-ob"><span class="oi">${s.i}</span><b style="display:block;margin-bottom:6px;font-size:16px">${s.t}</b>${s.d}</div><div class="md-row">${MD.ob>0?'<button class="md-btn sm ghost" data-a="mdObPrev">Geri</button>':'<span></span>'}<button class="md-btn gold" data-a="mdObNext">${last?'Başla':'İleri'}</button></div><p class="dim" style="margin-top:12px;text-align:center"><button data-a="mdObSkip" style="color:var(--tx3);text-decoration:underline;background:none;border:none;cursor:pointer">Atla</button></p>`;
}
ACT.mdObOpen=()=>{MD.ob=0;mdObDraw();mdSheet(true);S.dirty=false;};
ACT.mdObNext=()=>{if(MD.ob>=MD_OB.length-1){ACT.mdObSkip();return;}MD.ob++;mdObDraw();S.dirty=false;};
ACT.mdObPrev=()=>{MD.ob=Math.max(0,MD.ob-1);mdObDraw();S.dirty=false;};
ACT.mdObSkip=()=>{S.tourDone=1;mdSheet(false);toast('İyi oyunlar! Ana sayfadan devam et.','ok');S.dirty=false;};
setTimeout(()=>{try{if(S.tourDone===undefined&&!navigator.webdriver){if((S.me.works||0)===0&&S.me.level<=1&&!S.me.admin)ACT.mdObOpen();else S.tourDone=1;}}catch(e){}},1200);

/* ---------- Konfeti (ödül) ---------- */
function mdConfetti(x,y){
  const c=['#e8b93a','#e30a17','#2ec4c4','#3ecf8e','#fff'];
  for(let i=0;i<14;i++){const d=document.createElement('div');d.className='confetti';d.style.left=x+'px';d.style.top=y+'px';d.style.background=c[i%c.length];d.style.setProperty('--dx',(Math.random()-.5)*120+'px');d.style.setProperty('--dy',(40+Math.random()*80)+'px');document.body.appendChild(d);setTimeout(()=>d.remove(),950);}
}
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-a="qClaim"],[data-a="wqClaim"],[data-a="dailyClaim"]');if(b){const r=b.getBoundingClientRect();mdConfetti(r.left+r.width/2,r.top);}},true);

/* ---------- Canlı güncelleme ---------- */
{const _tu=tickUI;tickUI=function(){_tu.apply(this,arguments);try{mdTopUpdate();}catch(e){}};}
try{mdTopUpdate();}catch(e){}

/* ---------- Bildirimler (toast): ekranı kapatmasın, tuşları engellemesin ---------- */
(function(){
  const st=document.createElement('style');
  st.textContent=`#toasts{position:fixed;left:50%;right:auto;transform:translateX(-50%);bottom:calc(var(--navh) + 10px);width:min(92vw,360px);display:flex;flex-direction:column;gap:4px;align-items:center;pointer-events:none;z-index:80}
  #toasts .toast{pointer-events:none;width:auto;max-width:100%;padding:6px 12px;font-size:12px;line-height:1.3;border-radius:999px;box-shadow:0 4px 14px rgba(0,0,0,.4);opacity:.95;margin:0}
  #toasts .toast b{color:var(--gold);margin-left:6px}`;
  document.head.appendChild(st);
})();
{
  const _t=toast,MAXT=2;
  toast=function(m,c){
    const box=document.getElementById('toasts');if(!box)return _t(m,c);
    const txt=String(m);
    const same=[...box.children].find(e=>e.dataset.t===txt);
    if(same){const n=(+same.dataset.n||1)+1;same.dataset.n=n;same.innerHTML=esc(txt)+`<b>×${n}</b>`;clearTimeout(same._to);same._to=setTimeout(()=>same.remove(),2200);return;}
    _t(m,c);
    const el=box.lastElementChild;if(!el)return;
    el.dataset.t=txt;el.dataset.n=1;
    el._to=setTimeout(()=>el.remove(),2400);
    while(box.children.length>MAXT)box.firstElementChild.remove();
  };
}
/* ===== Derinlik paketi: bölge uzmanlığı + kirlilik + diplomasi (hızlı yol) ===== */
const DP_SPEC_BY_ID={0:'baskent',1:'ova',2:'askeri',3:'liman',4:'maden',5:'liman',6:'ova',7:'sanayi',8:'askeri',9:'ova',10:'petrol',11:'ova',12:'askeri',13:'liman',14:'ova',15:'askeri',16:'maden',17:'ova',18:'liman',19:'sanayi',20:'maden',21:'ay',22:'ay',23:'liman',24:'liman',25:'maden',26:'liman',27:'askeri',28:'petrol',29:'ova',30:'maden',31:'liman',32:'askeri',33:'maden',34:'ova',35:'liman',36:'liman'};
const DP_SPEC={
 baskent:{n:'Başkent',i:'🏛️',work:{},trade:0,def:0},
 ova:{n:'Ova',i:'🌾',work:{},trade:0,def:0},
 sanayi:{n:'Sanayi',i:'🏭',work:{ore:0.12,oil:0.08},trade:0,def:0},
 petrol:{n:'Petrol',i:'🛢️',work:{oil:0.15,gold:-0.05,ore:-0.05},trade:0,def:0},
 maden:{n:'Maden',i:'⛏️',work:{gold:0.12,ore:0.12},trade:0,def:0},
 liman:{n:'Liman',i:'⚓',work:{},trade:0.03,def:-0.03},
 askeri:{n:'Askeri',i:'🎖️',work:{gold:-0.05,oil:-0.05,ore:-0.05},trade:0,def:0.08},
 ay:{n:'Ay',i:'🌙',work:{uranium:0.1,diamonds:0.1},trade:0,def:0}};
const DP_TREATY={mil:{money:40000,gold:2,relMin:0,delta:25,hours:72,n:'Askeri anlaşma'},mig:{money:20000,gold:0,relMin:-20,delta:10,hours:72,n:'Göç anlaşması'},emb:{money:15000,gold:0,relMax:20,delta:-20,hours:72,n:'Ambargo'},truce:{money:30000,gold:1,delta:8,hours:36,n:'Ateşkes'}};
function dpSpecKey(r){if(!r)return 'ova';if(!r.spec)r.spec=DP_SPEC_BY_ID[r.id]||(r.moon?'ay':r.coast?'liman':'ova');if(r.pollution==null)r.pollution=0;return r.spec;}
function dpSpec(r){return DP_SPEC[dpSpecKey(r)]||DP_SPEC.ova;}
function dpWorkMul(r,res){return 1+((dpSpec(r).work||{})[res]||0);}
function dpPolMul(r){const p=(r&&r.pollution)||0;return p>=80?0.9:p>=50?0.95:1;}
function dpHomeBonus(res){const m=S.me,h=S.regions[m.res];if(!h||h.state!=='A'||S.t-(m.resSince||0)<=6*HOUR)return 1;return dpWorkMul(h,res)>1?1.05:1;}
function dpBand(v){return v>=60?{n:'Müttefik',c:'ok'}:v>=20?{n:'Dost',c:'ok'}:v>-20?{n:'Tarafsız',c:'dim'}:v>-60?{n:'Gergin',c:'warn'}:{n:'Düşman',c:'bad'};}
function dpPolTick(h){(S.regions||[]).forEach(r=>{dpSpecKey(r);if(r.moon)return;const fac=((S.me.facs)||[]).filter(f=>f.region===r.id).length;
  r.pollution=clamp((r.pollution||0)+(0.008+((r.idx&&r.idx.d)||0)*0.002+fac*0.01)*h,0,100);r.pollution=Math.max(0,r.pollution-0.002*h);});}
function dpClean(rid,heavy){const r=S.regions[rid];if(!r)return 'Bölge yok';dpSpecKey(r);const p=r.pollution||0;if(p<1)return 'Kirlilik yok';
  const cost=heavy?80000:25000,gold=heavy?2:0;if(S.me.money<cost)return 'Yetersiz para ('+fmt(cost)+'₺)';if(gold&&S.me.stor.gold<gold)return 'Yetersiz altın ('+gold+')';
  S.me.money-=cost;S.me.stor.gold-=gold;r.pollution=Math.max(0,p-(heavy?40:15));L('🌿 '+r.n+' temizlendi.','ok');return true;}
function dpLogPush(o,k,d,n){if(!S.diploLog)S.diploLog=[];S.diploLog.unshift({t:S.t,other:o,kind:k,delta:d,note:n});if(S.diploLog.length>30)S.diploLog.pop();}
function dpGift(o,opt){if(!S.states[o]||o==='A')return 'Geçersiz devlet';
  const money=Math.max(0,Math.floor(+opt.money||0)),gold=Math.max(0,Math.floor(+opt.gold||0)),oil=Math.max(0,Math.floor(+opt.oil||0));
  if(money+gold+oil<=0)return 'Miktar gir';if(S.me.money<money)return 'Yetersiz para';if(S.me.stor.gold<gold)return 'Yetersiz altın';if(S.me.stor.oil<oil)return 'Yetersiz petrol';
  const rel=relTo('A',o),value=money+gold*(S.prices.gold||800)+oil*(S.prices.oil||28);
  let ch=0.35+rel/200+Math.min(0.4,value/500000);if(rel<-40)ch*=0.5;
  const ok=Math.random()<clamp(ch,0.08,0.92);
  S.me.money-=money;S.me.stor.gold-=gold;S.me.stor.oil-=oil;
  if(!ok){addRel('A',o,-3);dpLogPush(o,'gift_reject',-3,'Hediye reddedildi');L('📭 '+nameOf(o).replace(/<[^>]+>/g,'')+' hediyeyi reddetti (−3).','warn');return 'Reddedildi';}
  const d=clamp(Math.round(5+value/40000),5,25);addRel('A',o,d);dpLogPush(o,'gift',d,'Hediye kabul');L('🎁 '+nameOf(o).replace(/<[^>]+>/g,'')+' hediyeyi kabul etti (+'+d+').','ok');return true;}
function dpCanTreaty(){return !!(S.me.admin||(typeof isLeader==='function'&&isLeader())||A().min.foreign==='me');}
function dpTreaty(o,k){if(!S.states[o]||o==='A')return 'Geçersiz devlet';const c=DP_TREATY[k];if(!c)return 'Tür yok';
  if(!dpCanTreaty())return 'Anlaşma için devlet başkanı ya da dışişleri bakanı olmalısın (yoksa Siyaset sekmesinden kanun teklif et).';
  const rel=relTo('A',o);if(c.relMin!=null&&rel<c.relMin)return 'İlişki yetersiz (en az '+c.relMin+')';if(c.relMax!=null&&rel>c.relMax)return 'İlişki bu anlaşma için fazla yüksek';
  const a=A();if(a.budget.money<c.money)return 'Bütçe yetersiz ('+fmt(c.money)+'₺)';if(c.gold&&a.budget.gold<c.gold)return 'Bütçede altın yetersiz';
  a.budget.money-=c.money;a.budget.gold-=c.gold||0;const until=S.t+c.hours*HOUR;
  if(k==='truce'){a.truce=a.truce||{};a.truce[o]=until;const so=S.states[o];so.truce=so.truce||{};so.truce.A=until;}else a.treaty[k][o]=until;
  addRel('A',o,c.delta);dpLogPush(o,k,c.delta,c.n);L('📜 '+nameOf(o).replace(/<[^>]+>/g,'')+': '+c.n+' ('+c.hours+' sa).',c.delta>=0?'ok':'warn');return true;}
/* kancalar */
{const _w=workAmount;workAmount=function(res,region){let v=_w.apply(this,arguments);try{v*=dpWorkMul(region,res)*dpPolMul(region)*dpHomeBonus(res);}catch(e){}return v;};}
{const _f=facRate;facRate=function(f){let v=_f.apply(this,arguments);try{const r=S.regions[f.region];if(r)v*=dpWorkMul(r,f.res)*dpPolMul(r);}catch(e){}return v;};}
{const _b=buyRes;buyRes=function(res,n){const out=_b.apply(this,arguments);try{const t=dpSpec(myReg()).trade||0;if(out&&typeof out==='object'&&t>0&&out.c){const back=Math.floor(out.c*t*0.5);if(back>0){S.me.money+=back;out.c-=back;}}}catch(e){}return out;};}
{const _s=sellRes;sellRes=function(res,n){const out=_s.apply(this,arguments);try{const t=dpSpec(myReg()).trade||0;if(out&&typeof out==='object'&&t>0&&out.g){const bn=Math.floor(out.g*t);if(bn>0){S.me.money+=bn;out.g+=bn;}}}catch(e){}return out;};}
{const _h=hitDamage;hitDamage=function(it){let d=_h.apply(this,arguments);try{const df=dpSpec(myReg()).def||0;if(df>0)d*=1+df*0.5;
  const w=S.wars.find(x=>x.state==='on'&&(x.att==='A'||x.def==='A'));if(w){const o=w.att==='A'?w.def:w.att;if(A().treaty.mil[o]>S.t)d*=1.05;}}catch(e){}return d;};}
{const _i=integrate;integrate=function(ms){_i.apply(this,arguments);try{dpPolTick(ms/HOUR);}catch(e){}};}
ACT.diploGift=function(d){const o=d.state;if(!o)return msg('Devlet seç');const r=dpGift(o,{money:d.money,gold:d.gold,oil:d.oil});if(r!==true)return msg(r,r==='Reddedildi'?'warn':'bad');msg('🎁 Hediye kabul edildi','ok');render();};
ACT.diploTreaty=function(d){const r=dpTreaty(d.state,d.kind);if(r!==true)return msg(r,'bad');msg('📜 Anlaşma yapıldı','ok');render();};
ACT.cleanPol=function(d){const rid=d.id!=null?+d.id:S.me.loc;const r=dpClean(rid,d.heavy==='1');if(r!==true)return msg(r,'bad');msg('🌿 Temizlik tamam','ok');render();};
function dpSpecLabel(r){const i=dpSpec(r),p=Math.round(r.pollution||0);return i.i+' '+i.n+(p>=50?' · ☢'+p:'');}
function dpPanel(){
  let h='<div class="panel"><h2>🤝 Diplomasi</h2><p class="hint">Hediye ilişkiyi artırabilir (reddedilebilir). Anlaşmalar bütçeden ödenir; yalnızca başkan / dışişleri bakanı yapabilir. Askeri anlaşma varken o devlete savaş açılamaz.</p><div class="grid">';
  AI_S.filter(s=>S.states[s]&&regOf(s).length).forEach(st=>{const v=relTo('A',st),b=dpBand(v),tr=A().treaty,tru=A().truce&&A().truce[st]>S.t;
    h+='<div class="card"><h3>'+nameOf(st)+' <span class="'+b.c+'">'+b.n+' ('+Math.round(v)+')</span></h3><p class="dim">'+(tr.mil[st]>S.t?'🤝 Askeri · ':'')+(tr.mig[st]>S.t?'🧳 Göç · ':'')+(tr.emb[st]>S.t?'⛔ Ambargo · ':'')+(tru?'🕊️ Ateşkes · ':'')+'Güç '+fmt(powerOf(st))+'</p><div class="btns">'+
    ['mil:Askeri','mig:Göç','emb:Ambargo','truce:Ateşkes'].map(x=>{const[k,n]=x.split(':');return '<button class="act sm" data-a="diploTreaty" data-state="'+st+'" data-kind="'+k+'">'+n+'</button>';}).join('')+
    '<button class="act sm gold" data-a="diploGift" data-state="'+st+'" data-money="50000">Hediye 50k₺</button></div></div>';});
  h+='</div>';
  const lg=(S.diploLog||[]).slice(0,4);if(lg.length)h+='<p class="dim" style="margin-top:6px">Son: '+lg.map(e=>nameOf(e.other).replace(/<[^>]+>/g,'')+' '+e.note+' ('+(e.delta>0?'+':'')+e.delta+')').join(' · ')+'</p>';
  h+='</div>';
  const r=myReg();if(r){dpSpecKey(r);const i=dpSpec(r),p=Math.round(r.pollution||0),tips=Object.keys(i.work).map(k=>(i.work[k]>0?'+':'')+Math.round(i.work[k]*100)+'% '+(RES_N[k]||k));
    if(i.trade)tips.push('ticaret +%'+Math.round(i.trade*100));if(i.def)tips.push('hasar '+(i.def>0?'+':'')+Math.round(i.def*50)+'%');
    h+='<div class="panel"><h2>📍 Bölge uzmanlığı</h2><div class="card"><h3>'+i.i+' '+esc(r.n)+' — '+i.n+'</h3><p class="dim">'+(tips.join(' · ')||'Nötr bölge')+'</p><p>Kirlilik: <b>'+p+'</b>/100'+(p>=80?' (üretim −%10)':p>=50?' (üretim −%5)':'')+'</p><div class="bar"><div style="width:'+p+'%;background:'+(p>=80?'#da3633':p>=50?'#d4a72c':'#3fb950')+'"></div></div><div class="btns" style="margin-top:8px"><button class="act sm" data-a="cleanPol" data-id="'+r.id+'">Temizle 25k₺ (−15)</button><button class="act sm gold" data-a="cleanPol" data-id="'+r.id+'" data-heavy="1">Ağır 80k₺+2G (−40)</button></div></div></div>';}
  return h;}
{const _tw=tabWorld;tabWorld=function(){return _tw.apply(this,arguments)+dpPanel();};}
{const _ts=tabState;tabState=function(){return _ts.apply(this,arguments)+dpPanel();};}
try{window.bmDepth={specOf:dpSpec,diploGift:dpGift,diploTreaty:dpTreaty,cleanPollution:dpClean,panel:dpPanel};}catch(e){}
/* ===== Yönetim Merkezi: ekip (yardımcılar), denetim kaydı, acil durum düğmesi, canlı ayarlar ===== */
const OPS={staff:{},audit:null,kill:{},params:{},last:0,pLast:0,loading:false,err:''};
const OPS_ROLES={mod:'🛡️ Moderatör',eco:'📈 Ekonomi',icerik:'📝 İçerik'};
/* canlı ayarlar: [anahtar, ad, varsayılan, en az, en çok] */
const OPS_PARAMS=[
 ['enPrice','⚡ Enerji içeceği fiyatı (altın)',2,1,20],
 ['enGain','⚡ Bir içeceğin verdiği enerji',50,10,100],
 ['enMakeMoney','🥤 İçecek üretimi: para (₺)',4000,100,100000],
 ['enMakeOre','🥤 İçecek üretimi: cevher',3,1,50]];
function prm(k,d){const v=OPS.params?+OPS.params[k]:NaN;return (isFinite(v)&&v>0)?v:d;}
function opsMe(){try{return MP.uid&&MP.uid()||'';}catch(e){return '';}}
function opsRole(){if(typeof isAdminUI==='function'&&isAdminUI())return 'owner';const s=OPS.staff&&OPS.staff[opsMe()];return (s&&s.role)||'';}
function opsTabOk(id){const r=opsRole();if(!r)return false;if(r==='owner')return true;if(id==='ops')return true;if(id==='guard')return r==='mod';return false;}
function opsCan(what){const r=opsRole();if(r==='owner')return true;if(what==='params')return r==='eco';return false;}
async function opsLog(kind,text){
  try{if(!MP.ok||!opsRole())return;await MP.fb('POST','audit',{t:Date.now(),by:opsMe(),n:String((S.me&&S.me.name)||'?').slice(0,30),k:String(kind).slice(0,20),x:String(text||'').slice(0,160)});OPS.audit=null;}catch(e){}
}
/* herkes için: canlı ayarlar, acil durum durumu, ekip listesi (hafif, 5 dakikada bir) */
async function opsLoadLight(){
  if(!MP.ok||!MP.uid||!MP.uid()||Date.now()-OPS.pLast<300000)return false;OPS.pLast=Date.now();
  try{
    const c=await MP.fb('GET','cfg');
    if(c){OPS.params=c.params||{};OPS.kill=c.kill||{};}
    OPS.staff=(await MP.fb('GET','staff'))||{};
  }catch(e){}
  return true;
}
async function opsLoadFull(force){
  if(!opsRole()||!MP.ok||OPS.loading)return false;if(!force&&OPS.audit&&Date.now()-OPS.last<60000)return false;
  OPS.loading=true;
  try{
    const c=await MP.fb('GET','cfg');if(c){OPS.params=c.params||{};OPS.kill=c.kill||{};}
    OPS.staff=(await MP.fb('GET','staff'))||{};
    const a=await MP.fb('GET','audit',undefined,'orderBy=%22%24key%22&limitToLast=40');
    OPS.audit=a?Object.keys(a).sort().reverse().map(k=>a[k]):[];OPS.err='';OPS.last=Date.now();
  }catch(e){OPS.err=(typeof rulesHint==='function')?rulesHint(e):String(e&&e.message||e);OPS.audit=OPS.audit||[];OPS.last=Date.now();}
  OPS.loading=false;return true;
}
setInterval(()=>{try{opsLoadLight().then(ok=>{if(ok&&UI.tab==='ops')render();});}catch(e){}},60000);
setTimeout(()=>{try{opsLoadLight();}catch(e){}},4000);
/* eylemler */
ACT.opsReload=()=>{OPS.pLast=0;opsLoadFull(true).then(()=>render());S.dirty=false;};
ACT.opsKill=async d=>{
  if(opsRole()!=='owner')return msg('Yalnızca yönetici açabilir.');
  const k=d.k,k2=Object.assign({},OPS.kill);k2[k]=!k2[k];k2.t=Date.now();k2.by=opsMe();
  try{await MP.fb('PUT','cfg/kill',k2);OPS.kill=k2;msg(k2[k]?'⛔ Durduruldu.':'▶️ Yeniden başlatıldı.','ok');opsLog('kill',(k==='all'?'tüm otomasyon':'yapay zekâ')+' '+(k2[k]?'DURDURULDU':'devam ettirildi'));}
  catch(e){msg(typeof rulesHint==='function'?rulesHint(e):String(e));}
  S.dirty=true;
};
ACT.opsStaffAdd=async()=>{
  if(opsRole()!=='owner')return msg('Yalnızca yönetici ekip ekleyebilir.');
  const uid=(($('opsPl')||{}).value||''),role=(($('opsRole')||{}).value||'mod');
  if(!uid)return msg('Bir oyuncu seç.');if(!OPS_ROLES[role])return msg('Rol geçersiz.');
  if(uid===opsMe())return msg('Kendin zaten yöneticisin.');
  const p=(MP.players||{})[uid]||{};
  try{await MP.fb('PUT','staff/'+uid,{role:role,name:String(p.name||'?').slice(0,30),by:opsMe(),t:Date.now()});OPS.staff[uid]={role:role,name:p.name||'?'};msg('Ekibe eklendi: '+(p.name||'?'),'ok');opsLog('ekip',(p.name||uid)+' → '+OPS_ROLES[role]);}
  catch(e){msg(typeof rulesHint==='function'?rulesHint(e):String(e));}
  S.dirty=true;
};
ACT.opsStaffDel=async d=>{
  if(opsRole()!=='owner')return msg('Yalnızca yönetici çıkarabilir.');
  const s=OPS.staff[d.id]||{};if(!confirm((s.name||'Yardımcı')+' ekipten çıkarılsın mı?'))return;
  try{await MP.fb('DELETE','staff/'+d.id);delete OPS.staff[d.id];msg('Ekipten çıkarıldı.','ok');opsLog('ekip',(s.name||d.id)+' ekipten çıkarıldı');}
  catch(e){msg(typeof rulesHint==='function'?rulesHint(e):String(e));}
  S.dirty=true;
};
ACT.opsParam=async d=>{
  if(!opsCan('params'))return msg('Bu ayar için yetkin yok.');
  const def=OPS_PARAMS.find(p=>p[0]===d.k);if(!def)return;
  const el=$('opsP_'+d.k),v=+(el&&el.value);
  if(!isFinite(v)||v<def[3]||v>def[4])return msg(def[1]+': '+def[3]+' ile '+def[4]+' arasında olmalı.');
  const np=Object.assign({},OPS.params);np[d.k]=v;
  try{await MP.fb('PUT','cfg/params',np);OPS.params=np;msg('Kaydedildi: '+def[1]+' = '+v,'ok');opsLog('ayar',def[1]+' = '+v);}
  catch(e){msg(typeof rulesHint==='function'?rulesHint(e):String(e));}
  S.dirty=true;
};
ACT.opsParamReset=async d=>{
  if(!opsCan('params'))return msg('Bu ayar için yetkin yok.');
  const def=OPS_PARAMS.find(p=>p[0]===d.k);if(!def)return;
  const np=Object.assign({},OPS.params);delete np[d.k];
  try{await MP.fb('PUT','cfg/params',Object.keys(np).length?np:null);OPS.params=np;msg('Varsayılana döndü: '+def[1],'ok');opsLog('ayar',def[1]+' varsayılana döndü');}
  catch(e){msg(typeof rulesHint==='function'?rulesHint(e):String(e));}
  S.dirty=true;
};
/* mevcut yönetici işlemlerini denetim kaydına yaz */
[['admAnnounce','duyuru','Duyuru yayınlandı'],['admAnnClear','duyuru','Duyuru kaldırıldı'],['admEvent','olay','Olay/etkinlik ayarı'],['admSeason','sezon','Sezon işlemi'],['admMod','moderasyon','Oyuncu moderasyonu'],['admTaxSave','vergi','Vergi ayarı kaydedildi'],['admGiftBulk','hediye','Toplu hediye'],['gdDo','güvenlik','Güvenlik kararı'],['gdCfg','güvenlik','Güvenlik ayarı']].forEach(a=>{
  const f=ACT[a[0]];if(typeof f!=='function')return;
  ACT[a[0]]=function(d){const r=f.apply(this,arguments);const x=a[2]+(d&&(d.k||d.id)?' ('+String(d.k||'')+' '+String(d.id||'').slice(0,12)+')':'');
    if(r&&typeof r.then==='function')r.then(()=>opsLog(a[1],x));else opsLog(a[1],x);return r;};
});
/* sekme */
TABX.ops=function(){
  const role=opsRole();
  if(!role)return '<div class="panel"><p class="dim">Bu bölüm yalnızca yönetici ve ekip içindir.</p></div>';
  opsLoadFull(false).then(ok=>{if(ok&&UI.tab==='ops')render();});
  const own=role==='owner',k=OPS.kill||{};
  let h=`<div class="panel"><h2>🏛️ Yönetim Merkezi</h2><p class="dim">Rolün: <b>${own?'👑 Yönetici':OPS_ROLES[role]||role}</b> · yapılan her işlem denetim kaydına yazılır.</p>${OPS.err?`<div class="al bad">${esc(OPS.err)}</div>`:''}
  <div class="btns">${btn('🔄 Yenile','data-a="opsReload"','sm')}</div></div>`;
  h+=card('⛔ Acil durum',`<p class="dim">Yapay zekâ ya da tüm sunucu otomasyonu bir sorun çıkarırsa buradan durdur. Sunucu bir sonraki turda durumu okur (en çok birkaç dakika).</p>
   <p>Yapay zekâ (akıllı oyuncular + güvenlik): <b class="${k.ai?'bad':'ok'}">${k.ai?'⏸ durduruldu':'çalışıyor'}</b></p>
   <p>Tüm sunucu otomasyonu (botlar, pazar, seçim): <b class="${k.all?'bad':'ok'}">${k.all?'⏸ durduruldu':'çalışıyor'}</b></p>
   ${own?`<div class="btns">${btn(k.ai?'▶️ Yapay zekâyı başlat':'⏸ Yapay zekâyı durdur','data-a="opsKill" data-k="ai"',k.ai?'gold':'danger')}${btn(k.all?'▶️ Tümünü başlat':'⛔ Tümünü durdur','data-a="opsKill" data-k="all"',k.all?'gold':'danger')}</div>`:'<p class="dim">Sadece yönetici değiştirebilir.</p>'}`);
  /* ekip */
  const st=Object.keys(OPS.staff||{});
  let tm=st.length?`<table>${st.map(id=>{const s=OPS.staff[id]||{};return `<tr><td>${esc(s.name||id)}</td><td>${OPS_ROLES[s.role]||esc(s.role||'')}</td><td>${own?btn('Çıkar',`data-a="opsStaffDel" data-id="${esc(id)}"`,'sm danger'):''}</td></tr>`;}).join('')}</table>`:'<p class="dim">Henüz yardımcı yok.</p>';
  if(own){
    const pl=Object.keys(MP.players||{}).map(id=>({id:id,n:(MP.players[id]||{}).name||id})).filter(p=>p.id!==opsMe()&&!(OPS.staff||{})[p.id]).sort((a,b)=>String(a.n).localeCompare(String(b.n),'tr')).slice(0,300);
    tm+=`<div class="row" style="margin-top:8px"><select id="opsPl"><option value="">Oyuncu seç…</option>${pl.map(p=>`<option value="${esc(p.id)}">${esc(p.n)}</option>`).join('')}</select>
    <select id="opsRole">${Object.keys(OPS_ROLES).map(r=>`<option value="${r}">${OPS_ROLES[r]}</option>`).join('')}</select>${btn('Ekle','data-a="opsStaffAdd"','gold sm')}</div>
    <p class="dim">🛡️ Moderatör: güvenlik sekmesi, susturma/ban/uyarı · 📈 Ekonomi: canlı ayarlar · 📝 İçerik: duyuru ve olay. Yardımcı eklemek için oyuncunun girişli olması gerekir.</p>`;
  }
  h+=card('👥 Ekip (yardımcılar)',tm);
  /* canlı ayarlar */
  const canP=opsCan('params');
  h+=card('🎚️ Canlı ayarlar',`<p class="dim">Değer burada değişince tüm oyuncularda birkaç dakika içinde geçerli olur. Boş bırakılan ayar varsayılanı kullanır.</p>
   <table>${OPS_PARAMS.map(p=>{const cur=(OPS.params||{})[p[0]];return `<tr><td>${p[1]}<br><small class="dim">varsayılan ${p[2]} · ${p[3]}–${p[4]}</small></td><td>${canP?`<input id="opsP_${p[0]}" type="number" step="any" style="width:84px" value="${cur!==undefined?esc(String(cur)):''}" placeholder="${p[2]}">`:`<b>${cur!==undefined?esc(String(cur)):p[2]}</b>`}</td><td>${canP?btn('Kaydet',`data-a="opsParam" data-k="${p[0]}"`,'sm gold')+btn('↺',`data-a="opsParamReset" data-k="${p[0]}"`,'sm'):''}</td></tr>`;}).join('')}</table>
   ${canP?'':'<p class="dim">Değiştirmek için yönetici ya da ekonomi yetkisi gerekir.</p>'}`);
  /* denetim kaydı */
  const au=OPS.audit;
  h+=card('📜 Denetim kaydı (son 40)',au===null?'<p class="dim">Yükleniyor…</p>':au.length?`<div style="max-height:320px;overflow:auto"><table>${au.map(a=>`<tr><td style="white-space:nowrap;font-size:11px">${new Date(+a.t||0).toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}</td><td><b>${esc(a.n||'?')}</b> <small class="dim">[${esc(a.k||'')}]</small><br><span style="font-size:12px">${esc(a.x||'')}</span></td></tr>`).join('')}</table></div>`:'<p class="dim">Kayıt yok.</p>');
  return h;
};
/* acil durum bandı (yalnızca ekip görür) */
{const _al=alerts;alerts=function(){_al.apply(this,arguments);try{
  if(!opsRole())return;const k=OPS.kill||{};if(!k.ai&&!k.all)return;const el=document.getElementById('alerts');if(!el)return;
  el.insertAdjacentHTML('afterbegin',`<div class="al bad">⛔ Acil durum: ${k.all?'tüm sunucu otomasyonu':'yapay zekâ'} durduruldu. <a class="lk" data-a="tab" data-t="ops">Yönetim Merkezi</a></div>`);}catch(e){}};}
/* ===== Ceza: ilerlemeyi sıfırla / hesabı kalıcı sil (yalnızca yönetici, onaylı, denetim kaydına yazılır) ===== */
async function punWipePublic(id,del){
  const fail=[];
  for(const p of ['players/'+id,'saves/'+id,'board/'+id]){try{await MP.fb('DELETE',p);}catch(e){fail.push(p);}}
  if(del){try{const al=(await MP.fb('GET','alliances'))||{};for(const k of Object.keys(al)){const a=al[k]||{};
    if(a.m&&a.m[id]){try{await MP.fb('DELETE','alliances/'+k+'/m/'+id);}catch(e){fail.push('alliances/'+k);}}}}catch(e){}}
  return fail;
}
ACT.punish=async d=>{
  S.dirty=false;
  if(typeof opsRole!=='function'||opsRole()!=='owner')return msg('Bu işlemi yalnızca yönetici yapabilir.');
  const id=d.id||MP.sel,k=d.k;
  if(!id||(typeof botById==='function'&&botById(id))||String(id).startsWith('bot_'))return msg('Önce gerçek bir oyuncu seç.');
  if(id===MP.uid())return msg('Kendine uygulayamazsın.');
  const nm=String(d.name||((MP.players||{})[id]||{}).name||id).slice(0,40);
  const why=String(d.why||(($('modWhy')||{}).value)||'').slice(0,80);
  if(k==='reset'){if(!confirm(nm+' adlı oyuncunun TÜM ilerlemesi sıfırlanacak (hesabı açık kalır). Onaylıyor musun?'))return;}
  else if(k==='delete'){const t=prompt('Bu işlem GERİ ALINAMAZ: '+nm+' hesabının tüm verisi silinir ve hesap kalıcı banlanır.\nOnaylamak için oyuncunun adını aynen yaz:');if(t===null)return;if(String(t).trim()!==nm)return msg('Ad uyuşmadı, işlem iptal edildi.');}
  else return;
  try{
    let cur={};try{cur=(await MP.fb('GET','bans/'+id))||{};}catch(e){}
    cur.wipe=Date.now();cur.name=nm;if(why)cur.why=why;if(k==='delete'){cur.ban=true;cur.deleted=cur.wipe;}
    await MP.fb('PUT','bans/'+id,cur);               // önce bayrak: banlı hesap yeniden yazamaz, açık cihaz kendini sıfırlar
    const fail=await punWipePublic(id,k==='delete');
    if(MP.bans)MP.bans[id]=cur;
    if(typeof opsLog==='function')opsLog('ceza',(k==='delete'?'Hesap silindi: ':'İlerleme sıfırlandı: ')+nm+(why?' — '+why:''));
    msg((k==='delete'?'🗑️ Hesap silindi ve banlandı: ':'♻️ İlerleme sıfırlandı: ')+nm+(fail.length?' (bazı kayıtlar silinemedi: Firebase kurallarını güncelle)':''),fail.length?'bad':'ok');
  }catch(e){msg(typeof rulesHint==='function'?rulesHint(e):String(e));}
  S.dirty=true;
};
/* ===== Enerji: anında doldur, içecek stoğu + üretim, otomatik yenilenme ===== */
const enP=()=>prm('enPrice',2),enG=()=>prm('enGain',50),enPm=()=>prm('enMakeMoney',4000),enPo=()=>prm('enMakeOre',3);
function enM(){const m=S.me;if(m.drinks==null)m.drinks=0;if(!m.enAuto)m.enAuto={on:false,thr:30,gold:false,used:0};return m;}
function enSpend(){/* içecek stoğundan ya da altından bir içecek içer */
  const m=enM();if(m.drinks>0){m.drinks--;m.energy=Math.min(200,m.energy+enG());return 'stok';}
  if(m.stor.gold>=enP()){m.stor.gold-=enP();m.energy=Math.min(200,m.energy+enG());return 'altın';}return null;}
ACT.enFill=()=>{const m=enM();if(m.energy>=100)return msg('Enerji zaten dolu.','info');
  let n=0,g=0;while(m.energy<100&&n<10){const k=enSpend();if(!k)break;if(k==='altın')g++;n++;}
  if(!n)return msg('İçecek ya da altın yok ('+enP()+' altın / içecek).');
  msg('⚡ '+n+' içecek içildi'+(g?' ('+g*enP()+' altın)':'')+' → enerji '+Math.floor(m.energy),'ok');L('⚡ Enerji dolduruldu ('+n+' içecek).','info');};
ACT.enDrinkStock=()=>{const m=enM();if(m.drinks<1)return msg('Stokta içecek yok.');m.drinks--;m.energy=Math.min(200,m.energy+enG());msg('⚡ +'+enG()+' enerji','ok');};
ACT.enBuy=d=>{const m=enM(),n=Math.max(1,Math.min(20,+d.n||1)),c=n*enP();if(m.stor.gold<c)return msg('Yetersiz altın ('+c+').');m.stor.gold-=c;m.drinks+=n;msg('🥤 '+n+' içecek stoğa eklendi','ok');};
ACT.enMake=d=>{const m=enM(),n=Math.max(1,Math.min(20,+d.n||1));if(m.travel)return msg('Yoldasın.');
  if(m.money<enPm()*n)return msg('Yetersiz para ('+fmt(enPm()*n)+'₺).');if(m.stor.ore<enPo()*n)return msg('Yetersiz cevher ('+enPo()*n+').');
  m.money-=enPm()*n;m.stor.ore-=enPo()*n;m.drinks+=n;msg('🥤 '+n+' enerji içeceği üretildi','ok');};
ACT.enAutoT=()=>{const a=enM().enAuto;a.on=!a.on;msg(a.on?'Otomatik yenilenme AÇIK':'Otomatik yenilenme kapalı','info');};
ACT.enAutoG=()=>{const a=enM().enAuto;a.gold=!a.gold;msg(a.gold?'Stok bitince altın da kullanılacak':'Yalnızca stoktan içilecek','info');};
ACT.enThr=d=>{enM().enAuto.thr=+d.v;};
function enAutoTick(){const m=enM(),a=m.enAuto;if(!a.on||m.admin)return;let n=0;
  while(m.energy<a.thr&&n<6){if(m.drinks>0){m.drinks--;}else if(a.gold&&m.stor.gold>=enP()){m.stor.gold-=enP();}else break;m.energy=Math.min(200,m.energy+enG());a.used++;n++;}
  if(n)L('⚡ Otomatik yenilenme: '+n+' içecek.','info');}
{const _i=integrate;integrate=function(ms){_i.apply(this,arguments);try{enAutoTick();}catch(e){}};}
function enPanel(){const m=enM(),a=m.enAuto,need=Math.max(0,Math.ceil((100-m.energy)/enG()));
  return `<div class="panel"><h2>⚡ Enerji merkezi</h2><div class="card">
  <p>Enerji: <b>${fmt(m.energy)}</b> · Stok: <b>${m.drinks}</b> 🥤 · Altın: <b>${f1(m.stor.gold)}</b></p>
  <div class="btns"><button class="act gold" data-a="enFill">⚡ Anında doldur${need?` (${need} içecek${m.drinks<need?` · en çok ${(need-Math.min(need,m.drinks))*enP()} altın`:''})`:''}</button>
  <button class="act sm" data-a="enDrinkStock">Stoktan iç</button></div>
  <p class="dim" style="margin-top:8px">İçecek +${enG()} enerji verir (100 üstüne de çıkar).</p>
  <div class="btns"><button class="act sm gold" data-a="enBuy" data-n="1">1 al · ${enP()} altın</button><button class="act sm gold" data-a="enBuy" data-n="5">5 al · ${5*enP()} altın</button>
  <button class="act sm" data-a="enMake" data-n="1">Üret · ${fmt(enPm())}₺ + ${enPo()} cevher</button><button class="act sm" data-a="enMake" data-n="5">5 üret</button></div></div>
  <div class="card"><p><b>Otomatik yenilenme</b> ${a.on?'<span class="ok">AÇIK</span>':'<span class="dim">kapalı</span>'} · şimdiye dek ${a.used} içecek</p>
  <p class="dim">Enerji eşiğin altına inince stoktan otomatik içer${a.gold?', stok bitince altın harcar':''}. Eşik: <b>${a.thr}</b></p>
  <div class="btns"><button class="act sm ${a.on?'danger':'blue'}" data-a="enAutoT">${a.on?'Kapat':'Aç'}</button><button class="act sm" data-a="enAutoG">Altın da kullan: ${a.gold?'evet':'hayır'}</button>
  ${[10,30,50].map(v=>`<button class="act sm ${a.thr===v?'blue':''}" data-a="enThr" data-v="${v}">Eşik ${v}</button>`).join('')}</div></div></div>`;}
/* Enerji merkezi artık Depo'da; Çalış ve Savaş sayfalarının tepesinde hızlı enerji çubuğu var */
function enBar(){const m=enM();
  return `<div class="card en-bar" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:8px 10px;margin:0 0 8px"><span>⚡ <b data-live="energy"></b></span><span class="dim" style="font-size:12px">🥤 ${m.drinks}</span><span style="flex:1"></span><button class="act sm gold" data-a="enFill"${m.energy>=100?' disabled':''}>⚡ Doldur</button><button class="act sm" data-a="enDrinkStock"${m.drinks<1?' disabled':''}>🥤 +${enG()}</button></div>`;}
{const _w=tabWork;tabWork=function(){return enBar()+_w.apply(this,arguments);};}
{const _wr=tabWar;tabWar=function(){return enBar()+_wr.apply(this,arguments);};}
{const _s=tabStore;tabStore=function(){return _s.apply(this,arguments)+enPanel();};}
/* ===== Güvenlik sekmesi (yönetici): sunucunun işaretlediği şüpheli içerik / hile kayıtları. Karar her zaman yöneticide ===== */
const GD={flags:{},cfg:{on:true,dm:true,llm:true,cheat:true},last:0,loading:false};
(function(){const g=GROUPS.find(x=>x[0]==='prof');if(g&&!g[2].some(t=>t[0]==='guard'))g[2].push(['guard','🛡️ Güvenlik','adm']);})();
const gdAllowed=()=>isAdminUI()||(typeof opsTabOk==='function'&&opsTabOk('guard'));
function gdOpen(){return Object.keys(GD.flags).filter(k=>(GD.flags[k]||{}).st==='open');}
async function gdLoad(force){
  if(!gdAllowed()||!MP.ok||GD.loading)return false;if(!force&&Date.now()-GD.last<120000)return false;GD.loading=true;
  try{const f=await MP.fb('GET','guard/flags'),c=await MP.fb('GET','guard/cfg');GD.cur=(await MP.fb('GET','guard/cur'))||null;GD.err='';GD.flags=f||{};GD.cfg=Object.assign({on:true,dm:true,llm:true,cheat:true},c||{});GD.last=Date.now();S.dirty=true;}
  catch(e){GD.err=rulesHint(e);GD.last=Date.now();}
  GD.loading=false;return true;
}
ACT.gdReload=()=>{gdLoad(true).then(()=>render());S.dirty=false;};
ACT.gdCfg=async d=>{const k=d.k;GD.cfg[k]=GD.cfg[k]===false;try{await MP.fb('PUT','guard/cfg',GD.cfg);msg('Ayar kaydedildi.','ok');}catch(e){GD.cfg[k]=!GD.cfg[k];msg(rulesHint(e));}S.dirty=true;};
async function gdMark(id,st,act){const f=GD.flags[id];if(!f)return;f.st=st;f.act=act;f.at=Date.now();await MP.fb('PUT','guard/flags/'+id,f);}
ACT.gdDo=async d=>{
  const id=d.id,f=GD.flags[id];if(!f)return;const k=d.k;
  try{
    if(k==='ignore'){await gdMark(id,'ign','yoksayıldı');msg('Yoksayıldı.','ok');}
    else if(k==='del'){if(!f.ref)return msg('Silinecek içerik yok.');await MP.fb('DELETE',f.ref);await gdMark(id,'done','içerik silindi');msg('İçerik silindi.','ok');}
    else{
      if(!f.uid)return msg('Oyuncu kimliği yok.');
      let cur={};try{cur=await MP.fb('GET','bans/'+f.uid)||{};}catch(e){}
      const txt=(f.cat||'ihlal')+(f.why?': '+f.why:'');
      if(k==='warn')cur.warn={t:Date.now(),m:('Yönetici uyarısı — '+txt).slice(0,160)};
      else if(k==='mute'){cur.chat=true;cur.why=txt.slice(0,80);}
      else if(k==='ban'){if(!confirm((f.name||'Oyuncu')+' banlansın mı?'))return;cur.ban=true;cur.why=txt.slice(0,80);}
      cur.name=f.name||cur.name||'';
      await MP.fb('PUT','bans/'+f.uid,cur);await gdMark(id,'done',{warn:'uyarıldı',mute:'susturuldu',ban:'banlandı'}[k]);msg('Uygulandı.','ok');
    }
  }catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
const GD_SRC={chat:'Genel sohbet',pchat:'Parti sohbeti',dm:'Özel mesaj',art:'Makale',acom:'Makale yorumu',oyuncu:'Oyuncu verisi'};
function gdCard(id,f){
  const sv='●'.repeat(f.sev||1)+'○'.repeat(Math.max(0,3-(f.sev||1)));
  const canDel=f.ref&&f.src!=='dm'&&f.src!=='oyuncu';
  return `<div class="card" style="margin-bottom:8px"><h3>${f.kind==='hile'?'🕵️':'💬'} ${esc(f.cat||'')} <span class="${f.sev>=3?'bad':f.sev===2?'warn':'dim'}">${sv}</span></h3>
  <p><b>${esc(f.name||'?')}</b> · <span class="dim">${GD_SRC[f.src]||esc(f.src||'')}</span></p>
  <p style="background:var(--bg3,#1b1416);padding:6px 8px;border-radius:8px;word-break:break-word">${esc(f.text||'')}</p>
  <p class="dim">${esc(f.why||'')} · öneri: <b>${esc(f.sugg||'—')}</b> · ${esc(f.by||'')}</p>
  <div class="btns"><button class="act sm" data-a="gdDo" data-k="warn" data-id="${id}">⚠️ Uyar</button><button class="act sm" data-a="gdDo" data-k="mute" data-id="${id}">🔇 Sustur</button>
  <button class="act sm danger" data-a="gdDo" data-k="ban" data-id="${id}">⛔ Ban</button>${canDel?`<button class="act sm" data-a="gdDo" data-k="del" data-id="${id}">🗑️ Sil</button>`:''}
  <button class="act sm blue" data-a="gdDo" data-k="ignore" data-id="${id}">✅ Yoksay</button></div>${(f.uid&&typeof opsRole==='function'&&opsRole()==='owner'&&!String(f.uid).startsWith('bot_'))?`<div class="btns"><button class="act sm danger" data-a="punish" data-k="reset" data-id="${esc(f.uid)}" data-name="${esc(f.name||'')}" data-why="${esc((f.cat||'')+(f.why?': '+f.why:''))}">♻️ Sıfırla (ceza)</button><button class="act sm danger" data-a="punish" data-k="delete" data-id="${esc(f.uid)}" data-name="${esc(f.name||'')}" data-why="${esc((f.cat||'')+(f.why?': '+f.why:''))}">🗑️ Hesabı sil</button></div>`:''}</div>`;}
TABX.guard=function(){
  if(!gdAllowed())return '<div class="panel"><p class="dim">Bu bölüm yalnızca yönetici içindir.</p></div>';
  gdLoad(false).then(ok=>{if(ok&&UI.tab==='guard')render();});
  const op=gdOpen().sort((a,b)=>((GD.flags[b].sev||0)-(GD.flags[a].sev||0))||((GD.flags[b].t||0)-(GD.flags[a].t||0)));
  const done=Object.keys(GD.flags).filter(k=>GD.flags[k].st!=='open').length,c=GD.cfg,sw=(k,n)=>`<button class="act sm ${c[k]===false?'':'blue'}" data-a="gdCfg" data-k="${k}">${n}: ${c[k]===false?'kapalı':'açık'}</button>`;
  let h=`<div class="panel"><h2>🛡️ Güvenlik</h2><p class="hint">Sunucu 15 dakikada bir sohbet, özel mesaj, makale ve oyuncu verilerini tarar. Yapay zekâ yalnızca <b>işaretler</b>; ban, susturma ve silme kararı sende. Özel mesajlar sadece kural filtresine takılırsa incelenir.</p>
  <div class="btns">${sw('on','Tarama')}${sw('dm','Özel mesaj')}${sw('llm','Yapay zekâ yargısı')}${sw('cheat','Hile tespiti')}<button class="act sm gold" data-a="gdReload">🔄 Yenile</button></div>
  ${GD.err?`<div class="al warn">${esc(GD.err)}</div>`:''}
  <p class="dim" style="margin-top:8px">${GD.cur&&GD.cur.run?`🕒 Son tarama: <b>${new Date(GD.cur.run).toLocaleString('tr-TR')}</b>${GD.cur.sum?' · '+esc(GD.cur.sum):''}`:'⚠️ Sunucu henüz hiç tarama yapmamış. GitHub\'daki botserver.js güncel mi? Actions’tan bir kez Run workflow çalıştır.'}</p></div>
  <div class="panel"><h2>Bekleyen kayıtlar (${op.length})</h2>${op.length?op.map(id=>gdCard(id,GD.flags[id])).join(''):'<p class="dim">Şu an incelenecek kayıt yok. 👍</p>'}<p class="dim">Karara bağlanan: ${done}</p></div>`;
  return h;};
/* yönetici uyarısı: oyuncuya bir kez gösterilir */
function gdWarn(){try{const w=MP.ban&&MP.ban.warn;if(!w||!w.t)return '';if(localStorage.getItem('gd_warn')==String(w.t))return '';
  return `<div class="al bad">⚠️ ${esc(w.m||'Yönetici seni uyardı.')} <button class="act sm" data-a="gdAck">Tamam</button></div>`;}catch(e){return '';}}
ACT.gdAck=()=>{try{localStorage.setItem('gd_warn',String(MP.ban.warn.t));}catch(e){}try{document.querySelectorAll('#alerts .al').forEach(e=>{if(e.innerHTML.includes('gdAck'))e.remove();});if(typeof MD!=='undefined')MD.alSig='';}catch(e){}S.dirty=true;};
{const _al=alerts;alerts=function(){_al.apply(this,arguments);try{const el=$('alerts');let x=gdWarn();
  if(gdAllowed()&&MP.ok){gdLoad(false);const n=gdOpen().length;if(n)x+=`<div class="al warn">🛡️ ${n} şüpheli kayıt inceleme bekliyor <button class="act sm blue" data-a="tab" data-t="guard">Aç</button></div>`;}
  if(x&&el&&!el.innerHTML.includes('data-a="gdAck"')&&!el.innerHTML.includes('data-t="guard"'))el.insertAdjacentHTML('beforeend',x);}catch(e){}};}
{const _tc=tabChat;tabChat=function(){return _tc.apply(this,arguments)+'<p class="hint" style="margin-top:8px">🛡️ Mesajlar otomatik denetlenir. Küfür, tehdit ve yasadışı içerik yöneticiye bildirilir; özel mesajlar yalnızca bu tür kelimeler geçerse incelenir.</p>';};}
