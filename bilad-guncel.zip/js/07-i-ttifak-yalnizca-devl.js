/* ===== İttifak: yalnızca devlet başkanı kurar · Özel mesaj: herkes herkesle (arama, isme dokun) · Engelle / Bildir ===== */
const BLK={get(){try{return JSON.parse(localStorage.getItem('bm_blocked')||'{}');}catch(e){return {};}},set(o){try{localStorage.setItem('bm_blocked',JSON.stringify(o));}catch(e){}}};
const dmVisible=()=>{const b=BLK.get();return (CHAT.msgs||[]).filter(x=>!(x.uid&&b[x.uid]));};
/* --- ittifak --- */
const canFoundAlly=()=>!!(S.me.admin||(typeof isLeader==='function'&&isLeader()));
{const _c=ACT.alCreate;ACT.alCreate=async function(){
  if(!canFoundAlly())return msg('İttifakı yalnızca devlet başkanı kurabilir.');
  const n=((($('alName')||{}).value)||'').trim();const had=S.me.ally;await _c.apply(this,arguments);
  if(!had&&S.me.ally&&MP.ok){try{const nm=(AL.list[S.me.ally]||{}).n||n;
    await MP.fb('PUT','chat/'+Date.now()+'_'+MP.uid().slice(0,6),{u:S.me.name,m:'🛡️ "'+nm+'" ittifakı kuruldu! Katılmak için Sosyal › İttifak sekmesine bak.',t:Date.now(),uid:MP.uid(),ad:S.me.admin?1:0});}catch(e){}}
};}
{const _ta=tabAlly;tabAlly=function(){let h=_ta.apply(this,arguments);
  if(!canFoundAlly()&&!S.me.ally)h=h.replace(/<div class="card"><h3>Yeni ittifak kur<\/h3>[\s\S]*?<\/button><\/div>/,'<div class="card"><h3>Yeni ittifak kur</h3><p class="dim">🏛️ İttifakı yalnızca <b>devlet başkanı</b> kurabilir. Başkan değilsen aşağıdaki ittifaklardan birine katılabilirsin.</p></div>');
  return h;};}
/* --- özel mesaj --- */
{const _o=ACT.dmOpen;ACT.dmOpen=function(d){_o.apply(this,arguments);UI.tab='msg';};}
{const _tc=tabChat;tabChat=function(){
  const all=CHAT.msgs,ib=CHAT.inbox;const b=BLK.get();CHAT.msgs=dmVisible();
  if(ib){const f={};Object.keys(ib).forEach(k=>{if(!b[k])f[k]=ib[k];});CHAT.inbox=f;}
  let h;try{h=_tc.apply(this,arguments);}finally{CHAT.msgs=all;CHAT.inbox=ib;}
  if(MP.ok&&CHAT.ch==='d'&&!CHAT.dm){
    h=h.replace(/<h2 style="margin-top:10px">Konuşmalar<\/h2>/,'<div class="card"><h3>🔎 Oyuncu ara</h3><input type="text" id="dmQ" placeholder="İsim yaz…" style="width:100%;padding:9px;box-sizing:border-box"><div id="dmRes" class="btns" style="margin-top:6px"></div><p class="dim">Herkes herkese mesaj atabilir. Rahatsız eden olursa engelle ya da bildir.</p></div>$&');
    const bl=Object.keys(b);if(bl.length)h=h.replace(/<\/div>$/,'<div class="card"><h3>🚫 Engellenenler</h3>'+bl.map(k=>esc(b[k])+' '+btn('Kaldır',`data-a="dmUnblock" data-id="${k}"`,'sm')).join('<br>')+'</div></div>');
  }
  if(MP.ok&&CHAT.ch==='d'&&CHAT.dm)h=h.replace(/(<b style="padding:6px">✉️ [^<]*<\/b>)/,`$1${btn('🚫 Engelle',`data-a="dmBlock" data-id="${esc(CHAT.dm.id)}" data-name="${esc(CHAT.dm.name)}"`,'sm danger')}${btn('📢 Bildir',`data-a="dmReport" data-id="${esc(CHAT.dm.id)}" data-name="${esc(CHAT.dm.name)}"`,'sm')}`);
  return h;};}
function dmSearchUpdate(inp){
  const q=trn2(inp.value),box=$('dmRes');if(!box)return;const bl=BLK.get();
  const rows=(LB.rows||[]).filter(r=>r.id!==MP.uid()&&!bl[r.id]&&q&&trn2(r.name).includes(q)).slice(0,12);
  box.innerHTML=rows.map(r=>btn('✉️ '+esc(r.name)+' (Sv '+(+r.lv||1)+')',`data-a="dmOpen" data-id="${esc(r.id)}" data-name="${esc(r.name)}"`,'sm blue')).join('')||(q?'<span class="dim">Bulunamadı.</span>':'');}
document.addEventListener('input',e=>{if(e.target&&e.target.id==='dmQ')dmSearchUpdate(e.target);});
/* sayfa yeniden çizilince (ör. saniyelik yenileme) arama sonuçları kaybolmasın */
{const _ar=(typeof afterRender==='function')?afterRender:null;if(_ar)afterRender=function(){_ar.apply(this,arguments);try{const i=$('dmQ');if(i&&i.value)dmSearchUpdate(i);}catch(e){}};}
function trn2(s){return String(s||'').toLowerCase().replace(/ç/g,'c').replace(/ğ/g,'g').replace(/ı/g,'i').replace(/ö/g,'o').replace(/ş/g,'s').replace(/ü/g,'u');}
ACT.dmBlock=d=>{if(!confirm((d.name||'Oyuncu')+' engellensin mi? Mesajlarını görmeyeceksin.'))return;const b=BLK.get();b[d.id]=d.name||'Oyuncu';BLK.set(b);CHAT.dm=null;msg('Engellendi.','ok');S.dirty=true;};
ACT.dmUnblock=d=>{const b=BLK.get();delete b[d.id];BLK.set(b);msg('Engel kaldırıldı.','ok');S.dirty=true;};
ACT.dmReport=async d=>{
  if(!MP.ok)return;const peer=d.id,name=d.name||'?';
  const ev=(CHAT.msgs||[]).filter(x=>x.uid===peer).slice(-5).map(x=>String(x.m||'').slice(0,160));
  if(!confirm(name+' yöneticiye bildirilsin mi? Son mesajları incelenmek üzere gönderilir.'))return;
  try{await MP.fb('PUT','guard/reports/'+Date.now()+'_'+MP.uid().slice(0,6),{t:Date.now(),by:MP.uid(),byn:S.me.name,uid:peer,name:name,src:CHAT.ch==='d'?'dm':'chat',ev:ev});msg('Bildirildi, yönetici inceleyecek.','ok');}
  catch(e){msg(rulesHint(e));}};
/* genel sohbette isme dokununca özel mesaj / bildir menüsü */
ACT.chatName=d=>{if(!d.id||d.id===MP.uid())return;ACT.dmOpen({id:d.id,name:d.name});};
{const _ar=afterRender;afterRender=function(){const r=_ar.apply(this,arguments);try{
  if((UI.tab==='chat'||UI.tab==='msg')&&CHAT.ch!=='d'){const box=$('chatBox');if(box){const ms=dmVisible();[...box.children].forEach((d,i)=>{const m=ms[i],bb=d.querySelector('b');if(!m||!bb||!m.uid||m.uid===MP.uid()||String(m.uid).startsWith('bot_')||m.ad)return;
    bb.setAttribute('data-a','chatName');bb.setAttribute('data-id',m.uid);bb.setAttribute('data-name',m.u||'?');bb.style.cursor='pointer';bb.style.textDecoration='underline dotted';});}}
  }catch(e){}return r;};}
/* lider ayrılırken yalnızca gerçek üyeler sayılır (akıllı oyuncular engel olmasın) */
{const _l=ACT.alLeave;ACT.alLeave=async function(){const a=alMy();
  if(a&&a.o===MP.uid()){const real=Object.keys(a.m||{}).filter(u=>!String(u).startsWith('bot_')).length;
    if(real>1)return msg('Lider ayrılmadan önce ittifakta başka oyuncu kalmamalı.');
    if(!confirm('İttifak kapatılsın mı? Kasa kaybolur.'))return;
    try{await MP.fb('DELETE','alliances/'+a.id);}catch(e){return msg(rulesHint(e));}
    delete AL.list[a.id];S.me.ally=null;msg('İttifak kapatıldı.','ok');S.dirty=true;return;}
  return _l.apply(this,arguments);};}
/* ===== Açılır-kapanır bölümler: alt sekme çubuğu yerine, ana sekme içinde dikey bölüm listesi ===== */
const ACC_HINT={state:'bütçe, vergi, kanunlar, dış ilişkiler',leader:'başkan yetkileri',cities:'vali / şehir yönetimi',party:'parti, üyelik, oy',elect:'seçim ve adaylık',give:'bağış ve hediye',
 work:'kaynak çıkar',craft:'eşya üret',store:'depo ve eşyalar',mkt:'alış-satış',bank:'banka ve faiz',auto:'otomatik çalışma',ctl:'toplu kontrol',war:'savaşlar ve vur',sw:'ortak savaş',spy:'casus işleri',
 art:'makaleler',paper:'gazete',chat:'sohbet',ally:'ittifak',lb:'sıralama',char:'karakter ve yetenek',set:'ayarlar',guide:'rehber',net:'hesap / bağlantı',ai:'yapay zekâ danışman',stats:'istatistik',
 home:'özet ve hedefler',quest:'günlük görevler',log:'olay günlüğü',world:'dünya haritası, diplomasi',map:'şehirler'};
ACT.accFold=()=>{UI.accFold=!UI.accFold;S.dirty=false;render();};
{const _t=ACT.tab;ACT.tab=function(d){if(d&&d.t!==UI.tab)UI.accFold=false;return _t.apply(this,arguments);};}
{const _rn=renderNav;renderNav=function(){_rn.apply(this,arguments);try{document.querySelectorAll('#nav .subnav').forEach(e=>e.remove());const nv=document.getElementById('nav');document.documentElement.style.setProperty('--navh',nv.offsetHeight+'px');}catch(e){}};}
{const _r=render;render=function(){
  _r.apply(this,arguments);
  try{
    if(window.RRX)return;const mn=document.getElementById('main');if(!mn||(typeof isBanned==='function'&&isBanned()))return;
    const g=groupOf(UI.tab),vis=g[2].filter(t=>t[2]!=='adm'||isAdminUI());if(vis.length<2)return;
    const qb=(typeof questBadge==='function')?questBadge():0,un=(typeof mdUnread==='function')?mdUnread():0;
    const nodes=[...mn.childNodes],wrap=document.createElement('div');wrap.className='acc';
    vis.forEach(t=>{
      const on=t[0]===UI.tab,open=on&&!UI.accFold,bd=t[0]===('quest')&&qb?qb:(t[0]==='chat'&&un?un:0);
      const h=document.createElement('button');h.className='acc-h'+(open?' open':'');h.setAttribute('data-a',on?'accFold':'tab');if(!on)h.setAttribute('data-t',t[0]);
      h.innerHTML='<span class="acc-t">'+t[1]+(bd?' <span class="owner" style="background:#da3633;color:#fff">'+bd+'</span>':'')+'</span><span class="acc-s">'+(ACC_HINT[t[0]]||'')+'</span><span class="acc-c">'+(open?'▾':'▸')+'</span>';
      wrap.appendChild(h);
      if(on){const b=document.createElement('div');b.className='acc-b';if(!open)b.style.display='none';nodes.forEach(n=>b.appendChild(n));wrap.appendChild(b);}
    });
    mn.innerHTML='';mn.appendChild(wrap);
  }catch(e){console.warn('acc',e);}
};}
{const st=document.createElement('style');st.textContent=`
.acc-h{display:flex;align-items:center;gap:8px;width:100%;text-align:left;background:var(--bg2);border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin:0 0 6px;color:var(--tx);min-height:48px}
.acc-h .acc-t{font-weight:700;font-size:14px;white-space:nowrap}
.acc-h .acc-s{flex:1;font-size:11px;color:var(--tx2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right}
.acc-h .acc-c{color:var(--gold);font-size:14px}
.acc-h.open{border-color:var(--gold);background:var(--bg4);color:var(--gold)}
.acc-b{margin:0 0 10px;padding:2px 0}`;document.head.appendChild(st);}
/* ===== Alt menü sabitleme: bazı telefonlarda (Samsung / Chrome araç çubuğu) fixed + transform + blur menüyü aşağı kaydırıp gizleyebiliyor ===== */
(function(){
  const st=document.createElement('style');
  st.textContent='nav#nav{left:0!important;right:0!important;margin:0 auto!important;transform:translateZ(0)!important;-webkit-backdrop-filter:none!important;backdrop-filter:none!important;background:var(--bg1)!important;width:100%!important;max-width:520px!important;bottom:0;will-change:transform;overscroll-behavior:contain}'+
   'html.light nav#nav{background:var(--bg1)!important}';
  document.head.appendChild(st);
  const nav=()=>document.getElementById('nav');
  function place(){const n=nav(),vv=window.visualViewport;if(!n)return;
    let off=0;if(vv){off=Math.round(window.innerHeight-(vv.height+vv.offsetTop));if(!(off>0&&off<160))off=0;}
    const v=off?off+'px':'';if(n.style.bottom!==v)n.style.bottom=v;
    const r=n.getBoundingClientRect();
    if(r.height&&(r.top>window.innerHeight+1||r.bottom<0)){n.style.display='none';void n.offsetHeight;n.style.display='';}
  }
  try{if(window.visualViewport){visualViewport.addEventListener('resize',place);visualViewport.addEventListener('scroll',place);}}catch(e){}
  window.addEventListener('scroll',place,{passive:true});window.addEventListener('resize',place);window.addEventListener('orientationchange',place);
  setInterval(place,1500);
})();
/* ================= TÜRK & İSLAM DEVLETLERİ TEMALARI =================
   Renkler tarihî bayrak/sancak renklerinden esinlenmiş yeniden kurgudur (çoğu bayrak
   zaten sonradan çizilmiş rekonstrüksiyondur). Amblemler ÖZGÜN çizimlerdir; tarihî
   motiflerden (kurt başı, yay-ok, güneş, hilal, aslan, kartal, lotus...) esinlenir. */
const SK_TURK=[
 ['hun','Büyük Hun','M.Ö. 220','#1f5fa8','#123a6b','#f2c14e','sun'],
 ['bhun','Batı Hun','M.Ö. 48','#b3261e','#5f1410','#e9c46a','tamga'],
 ['ahun','Avrupa Hun','375','#8e1b2b','#470d15','#d9b44a','sword'],
 ['akhun','Akhun (Eftalit)','420','#3f6a9e','#1c3454','#e6e9ee','star8'],
 ['gokturk','Göktürk','552','#2a7fba','#14456b','#f0c75e','wolf'],
 ['avar','Avar','562','#9b2a2a','#4f1313','#e8c25a','ring'],
 ['hazar','Hazar','650','#1d7f86','#0c4448','#f0d58a','hexa'],
 ['uygur','Uygur','744','#3d5fb5','#1f3166','#f3d27a','cloud'],
 ['karahanli','Karahanlı','840','#1f7a4d','#0f4a2e','#f0d060','bow'],
 ['gazneli','Gazneli','963','#34343a','#0f0f12','#e0b84a','pars'],
 ['selcuklu','Selçuklu','1040','#244f96','#102a58','#f4c542','bow2'],
 ['harezm','Harezmşah','1077','#a8700f','#5c3b06','#f6e3a1','sun2'],
 ['altinorda','Altın Orda','1242','#c0830a','#6e4604','#a52a1f','tamga2'],
 ['timur','Timur','1370','#a3221b','#52100c','#f1d27a','rings3'],
 ['babur','Babür','1526','#2e7d4f','#164a2c','#f2d36b','lionsun'],
 ['osmanli','Osmanlı','1299','#c8102e','#6d0716','#ffd770','crescent']
];
const SK_ISL=[
 ['emevi','Emevî','661','#6d7278','#35383c','#f4f1e8','arch'],
 ['abbasi','Abbâsî','750','#1d1d21','#000000','#f2f2f2','star8'],
 ['endulus','Endülüs Emevîsi','756','#2c7a56','#143d2a','#f4efe0','arch'],
 ['fatimi','Fâtımî','909','#1f8a4c','#0e4a28','#f1e4a6','bowl'],
 ['zengi','Zengî','1127','#14767a','#093f42','#f0d58a','lotus'],
 ['eyyubi','Eyyûbî','1171','#c99a12','#6b4f06','#202024','eagle'],
 ['memluk','Memlûk','1250','#c9981b','#6b4b09','#b3261e','pars'],
 ['safevi','Safevî','1501','#0f8a6a','#064a38','#f3d77a','star12']
];
const SK_ALL=SK_TURK.concat(SK_ISL);
function skGet(id){return SK_ALL.find(s=>s[0]===id)||null;}
function skMix(a,b,t){
  const p=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)),x=p(a),y=p(b);
  return '#'+x.map((v,i)=>Math.round(v+(y[i]-v)*t).toString(16).padStart(2,'0')).join('');
}
function skStar(n,r1,r2,rot){
  let o=[];for(let i=0;i<n*2;i++){const r=i%2?r2:r1,a=rot+Math.PI*i/n;o.push((32+r*Math.cos(a)).toFixed(1)+','+(32+r*Math.sin(a)).toFixed(1));}
  return o.join(' ');
}
function skMotif(k,A,W){
  const f=`fill="${A}"`,s=`stroke="${A}" fill="none" stroke-linecap="round" stroke-linejoin="round"`;
  const rays=(n,r1,r2,w)=>{let o='';for(let i=0;i<n;i++){const a=Math.PI*2*i/n;o+=`<line x1="${(32+r1*Math.cos(a)).toFixed(1)}" y1="${(32+r1*Math.sin(a)).toFixed(1)}" x2="${(32+r2*Math.cos(a)).toFixed(1)}" y2="${(32+r2*Math.sin(a)).toFixed(1)}" stroke="${A}" stroke-width="${w}" stroke-linecap="round"/>`;}return o;};
  switch(k){
   case 'sun':return rays(12,13,22,3)+`<circle cx="32" cy="32" r="9" ${f}/>`;
   case 'sun2':return rays(8,15,23,3.5)+`<circle cx="32" cy="32" r="11" ${f}/><circle cx="32" cy="32" r="5" fill="${W}"/>`;
   case 'tamga':return `<path d="M32 14v36M20 20c0 8 5 11 12 11s12-3 12-11M24 50h16" ${s} stroke-width="4"/>`;
   case 'tamga2':return `<path d="M20 18v14c0 6 5 10 12 10s12-4 12-10V18M32 18v34M24 52h16" ${s} stroke-width="4"/>`;
   case 'sword':return `<path d="M32 12v34M22 40h20M32 46v6" ${s} stroke-width="4"/><path d="M32 12l-4 8h8z" ${f}/>`;
   case 'star8':return `<polygon points="${skStar(8,22,12,-Math.PI/2)}" ${f}/><circle cx="32" cy="32" r="5" fill="${W}"/>`;
   case 'star12':return `<polygon points="${skStar(12,23,15,-Math.PI/2)}" ${f}/><circle cx="32" cy="32" r="7" fill="${W}"/>`;
   case 'wolf':return `<polygon points="19,46 20,17 29,26 35,26 44,17 45,46 32,55" ${f}/><polygon points="26,36 30,39 26,40" fill="${W}"/><polygon points="38,36 34,39 38,40" fill="${W}"/><polygon points="29,47 35,47 32,52" fill="${W}"/>`;
   case 'ring':return `<circle cx="32" cy="32" r="19" ${s} stroke-width="4"/><circle cx="32" cy="32" r="9" ${f}/>`;
   case 'hexa':return `<polygon points="32,11 49,41 15,41" ${f}/><polygon points="32,53 15,23 49,23" fill="none" stroke="${A}" stroke-width="4"/>`;
   case 'cloud':return `<path d="M16 40c-5-1-6-9 0-10 1-7 11-9 14-3 5-4 13 0 12 6 6 0 8 8 2 9z" ${f}/><path d="M22 48h20" ${s} stroke-width="3"/>`;
   case 'bow':return `<path d="M22 12c14 6 14 34 0 40" ${s} stroke-width="4"/><path d="M22 12v40M22 32h26" ${s} stroke-width="3"/><path d="M48 32l-8-5v10z" ${f}/>`;
   case 'bow2':return `<path d="M18 14c16 6 16 30 0 36" ${s} stroke-width="4"/><path d="M18 14v36" ${s} stroke-width="2.5"/><path d="M30 32h20M20 20l22 12-22 12" ${s} stroke-width="3"/><path d="M50 32l-8-5v10z" ${f}/>`;
   case 'pars':{let m='';for(let i=0;i<10;i++){const a=Math.PI*2*i/10;m+=`<circle cx="${(32+16*Math.cos(a)).toFixed(1)}" cy="${(32+16*Math.sin(a)).toFixed(1)}" r="5" ${f}/>`;}return m+`<circle cx="32" cy="32" r="11" ${f}/><circle cx="28" cy="30" r="1.8" fill="${W}"/><circle cx="36" cy="30" r="1.8" fill="${W}"/><path d="M29 37q3 3 6 0" stroke="${W}" stroke-width="2" fill="none" stroke-linecap="round"/>`;}
   case 'rings3':return `<circle cx="32" cy="22" r="9" ${s} stroke-width="4"/><circle cx="22" cy="40" r="9" ${s} stroke-width="4"/><circle cx="42" cy="40" r="9" ${s} stroke-width="4"/>`;
   case 'lionsun':return rays(14,17,24,3)+`<circle cx="32" cy="32" r="12" ${f}/><path d="M26 30l3-2M38 30l-3-2M32 31v5l-3 3M32 36l3 3" stroke="${W}" stroke-width="2" fill="none" stroke-linecap="round"/>`;
   case 'crescent':return `<path d="M38 14a18 18 0 1 0 0 36 14 14 0 1 1 0-36z" ${f}/><polygon points="${skStar(5,6.5,2.7,-Math.PI/2).split(' ').map(p=>{const q=p.split(',');return (+q[0]+11).toFixed(1)+','+q[1];}).join(' ')}" ${f}/>`;
   case 'bowl':return `<path d="M14 30h36c0 12-8 20-18 20s-18-8-18-20z" ${f}/><circle cx="32" cy="20" r="3" ${f}/><circle cx="22" cy="21" r="2.4" ${f}/><circle cx="42" cy="21" r="2.4" ${f}/>`;
   case 'eagle':return `<path d="M32 22c-4 4-16 4-22 14 8-2 12 0 14 6l8 4 8-4c2-6 6-8 14-6-6-10-18-10-22-14z" ${f}/><circle cx="32" cy="17" r="5" ${f}/><path d="M32 15l5 2-5 2z" fill="${W}"/>`;
   case 'lotus':{let p='';for(let i=0;i<5;i++){p+=`<ellipse cx="32" cy="21" rx="6" ry="12" ${f} transform="rotate(${-60+i*30} 32 40)"/>`;}return p+`<path d="M18 48q14 8 28 0" ${s} stroke-width="3"/>`;}
   case 'arch':return `<path d="M18 52V34c0-9 6-16 14-16s14 7 14 16v18" ${s} stroke-width="4.5"/><path d="M26 52V36c0-4 2-8 6-8s6 4 6 8v16" ${f}/>`;
  }
  return `<circle cx="32" cy="32" r="10" ${f}/>`;
}
function skEmblem(id,size){
  const s=skGet(id);if(!s)return '';
  return `<svg viewBox="0 0 64 64" width="${size||34}" height="${size||34}" aria-hidden="true"><circle cx="32" cy="32" r="30" fill="${s[3]}" stroke="${s[5]}" stroke-width="3"/>${skMotif(s[6],s[5],'#ffffff')}</svg>`;
}
function skUri(svg){return 'url("data:image/svg+xml,'+encodeURIComponent(svg)+'")';}
/* alt menü ikonları (currentColor) */
const SK_NAV={
 eco:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="32" r="22" fill="none" stroke="#000" stroke-width="5"/><path d="M38 20a13 13 0 1 0 0 24 10 10 0 1 1 0-24z" fill="#000"/></svg>`,
 war:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M18 8c20 8 20 40 0 48" fill="none" stroke="#000" stroke-width="5" stroke-linecap="round"/><path d="M18 8v48M30 32h28" stroke="#000" stroke-width="4" stroke-linecap="round"/><path d="M60 32l-12-8v16z" fill="#000"/></svg>`,
 gov:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M8 54h48M14 54V28M26 54V28M38 54V28M50 54V28M8 28h48L32 10z" fill="none" stroke="#000" stroke-width="5" stroke-linejoin="round" stroke-linecap="round"/></svg>`,
 more:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M10 16h44M10 32h44M10 48h44" stroke="#000" stroke-width="7" stroke-linecap="round"/></svg>`
};
function skCss(){
  let css=`
  html[data-skin] #nav>button:nth-child(1)>i{background:var(--emb) center/contain no-repeat}
  html[data-skin] #nav>button:nth-child(1)>i svg{display:none}
  html[data-skin] header.topbar{background:var(--embw) no-repeat right 8px center/84px,linear-gradient(105deg,var(--th2),var(--th1) 55%,var(--th3))!important;border-bottom-color:var(--gold2)!important}
  html[data-skin] header#hdr,html[data-skin] body>.app>header:not(.topbar){background:linear-gradient(100deg,var(--th2),var(--th1) 55%,var(--th3))!important}
  html[data-skin] nav#nav>button.active{background:color-mix(in srgb,var(--th1) 45%,transparent)!important}
  html[data-skin].light nav#nav>button.active{background:color-mix(in srgb,var(--th1) 15%,transparent)!important}
  html[data-skin] .bar>div{background:linear-gradient(90deg,var(--th1),var(--gold))!important}
  html[data-skin] header.topbar #hBell b{color:var(--th2)!important}
  .sk-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin:6px 0 10px}
  .sk-chip{display:flex;align-items:center;gap:8px;padding:8px;border-radius:12px;border:1px solid var(--line);background:var(--bg2);color:var(--tx);cursor:pointer;text-align:left;font-family:inherit;font-size:13px}
  .sk-chip.on{border-color:var(--gold2);box-shadow:0 0 0 2px var(--gold2) inset}
  .sk-chip small{display:block;color:var(--tx2);font-size:11px}
  .sk-chip .sk-sw{display:flex;flex-direction:column;gap:2px;margin-left:auto}
  .sk-chip .sk-sw i{display:block;width:14px;height:6px;border-radius:2px}
  `;
  return css;
}
let _skStyle=null;
function skApply(){
  const h=document.documentElement,id=(typeof PREF!=='undefined'&&PREF.skin)||'',s=skGet(id);
  if(!_skStyle){_skStyle=document.createElement('style');_skStyle.id='skcss';document.head.appendChild(_skStyle);}
  if(!s){h.removeAttribute('data-skin');_skStyle.textContent='';return;}
  const c1=s[3],c2=s[4],ac=s[5];
  const lum=x=>{const p=[1,3,5].map(i=>parseInt(x.slice(i,i+2),16));return (p[0]*299+p[1]*587+p[2]*114)/1000;};
  const gold=lum(ac)>60?ac:skMix(ac,'#ffffff',.5);   // koyu vurgu rengini görünür tut
  const gold2=skMix(gold,'#ffffff',.25);
  const th1=c1,th2=c2,th3=skMix(c2,c1,.15);
  const emb=skUri(skEmblem(id,64).replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" '));
  const embw=skUri(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><g opacity=".16">${skMotif(s[6],'#ffffff','#000000')}</g></svg>`);
  const d=(t,m)=>skMix('#050505',m||c2,t);
  h.setAttribute('data-skin',id);
  _skStyle.textContent=skCss()+`
  html[data-skin]{--th1:${th1};--th2:${th2};--th3:${th3};--red:${c1};--red2:${c2};--emb:${emb};--embw:${embw}}
  html[data-skin]:not(.light){--bg0:${d(.1)};--bg1:${d(.16)};--bg2:${d(.13)};--bg3:${d(.2)};--bg4:${d(.27)};--line:${d(.38)};--line2:${d(.55)};--gold:${gold};--gold2:${gold2}}
  html[data-skin].light{--bg0:${skMix('#ffffff',c1,.07)};--bg1:${skMix('#ffffff',c1,.02)};--bg2:${skMix('#ffffff',c1,.05)};--bg3:${skMix('#ffffff',c1,.10)};--bg4:${skMix('#ffffff',c1,.16)};--line:${skMix('#ffffff',c1,.25)};--line2:${skMix('#ffffff',c1,.4)};--gold:${lum(ac)<150?ac:skMix(ac,'#000000',.45)};--gold2:${lum(ac)<150?ac:skMix(ac,'#000000',.35)}}
  `;
  const tc=document.querySelector('meta[name=theme-color]');if(tc)tc.setAttribute('content',c2);
}
try{
  const _pa=prefApply;
  prefApply=function(){_pa();try{skApply();}catch(e){}};
  skApply();
}catch(e){}
/* Ayarlar: tema seçici */
try{
  const _ts=tabSettings;
  tabSettings=function(){
    const cur=(PREF.skin||'');
    const chip=s=>`<button class="sk-chip${cur===s[0]?' on':''}" data-a="prefSet" data-k="skin" data-v="${s[0]}">${skEmblem(s[0],34)}<span><b>${s[1]}</b><small>${s[2].startsWith('M.Ö')?s[2]:'MS '+s[2]}</small></span><span class="sk-sw"><i style="background:${s[3]}"></i><i style="background:${s[5]}"></i></span></button>`;
    const html=`<div class="panel"><h2>🏛️ Devlet Temaları</h2>
    <p class="dim">Oyunun renklerini ve amblemlerini bir devletin sancak renklerinden esinlenerek seç. (Tarihî bayrakların çoğu sonradan çizilmiş yeniden kurgudur; amblemler özgün çizimdir.)</p>
    <div class="btns"><button class="${cur===''?'gold':'sm'}" data-a="prefSet" data-k="skin" data-v="">Varsayılan (Bilâd)</button></div>
    <h3>🏹 16 Büyük Türk Devleti</h3><div class="sk-grid">${SK_TURK.map(chip).join('')}</div>
    <h3>☪️ Eski İslam Devletleri</h3><div class="sk-grid">${SK_ISL.map(chip).join('')}</div></div>`;
    return _ts()+html;
  };
}catch(e){}
window.bmSkin={SK_ALL,skApply,skEmblem};
/* ===== Sekme düzeni: 7 sabit alt sekme + üst başlık çubuğu + kutucuktan açılan alt sayfalar ===== */
window.RRX=1;
(function(){
  const G=GROUPS;G.length=0;
  G.push(['home','🏠 Ana Sayfa',[['home','Ana Sayfa'],['quest','Görevler'],['log','Günlük'],['state','Devlet'],['party','Parti'],['elect','Seçim'],['leader','👑 Başkan'],['cities','🏙️ Vali'],['give','Bağış'],['ai','Danışman'],['stats','İstatistik']]]);
  G.push(['paper','📰 Makaleler',[['art','Makaleler'],['paper','Gazete'],['chat','Sohbet'],['ally','İttifak'],['lb','Sıralama']]]);
  G.push(['map','🗺️ Harita',[['world','Harita'],['map','Şehirler']]]);
  G.push(['store','📦 Depo',[['store','Depo'],['mkt','Pazar'],['craft','Üretim'],['bank','Banka']]]);
  G.push(['work','⛏️ Çalışma',[['work','Çalış'],['auto','Otomatik'],['ctl','Kontrol']]]);
  G.push(['war','⚔️ Savaşlar',[['war','Savaş'],['sw','Ortak'],['spy','Casus']]]);
  G.push(['prof','👤 Profil',[['char','Profil'],['set','Ayarlar'],['guide','Rehber'],['net','Hesap'],['adm','👑 Panel','adm'],['bots','🤖 Yapay Zekâ','adm'],['guard','🛡️ Güvenlik','adm'],['ops','🏛️ Yönetim Merkezi','adm']]]);
})();
const RR_IC={
 home:'<svg viewBox="0 0 24 24"><path d="M3 11.5 12 3l9 8.5V21h-6.5v-6h-5v6H3z" fill="currentColor"/></svg>',
 paper:'<svg viewBox="0 0 24 24"><path d="M5 4h12a2 2 0 0 1 2 2v13a1 1 0 0 1-1 1H6a3 3 0 0 1-3-3V6a2 2 0 0 1 2-2zm1 4v8m0 0a1 1 0 0 0 1 1h10M9 8h7M9 11h7M9 14h5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 map:'<svg viewBox="0 0 24 24"><path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.500a2.5 2.5 0 0 1 0 5z" fill="currentColor"/></svg>',
 store:'<svg viewBox="0 0 24 24"><path d="M3 9l9-6 9 6v12H3zM7 21v-8h10v8M7 15h10M7 18h10" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
 work:'<svg viewBox="0 0 24 24"><path d="M4 21 14 11M8 5c5-3 11-1 13 4-5-1-8 0-10 2z" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 war:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="2.5" fill="currentColor"/><path d="M12 2v5M12 17v5M2 12h5M17 12h5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
 prof:'<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4.5" fill="currentColor"/><path d="M3.500 21c0-5 4-7.500 8.500-7.500S20.500 16 20.500 21z" fill="currentColor"/></svg>'
};
const RR_NAME={home:'Ana Sayfa',paper:'Topluluk',map:'Harita',store:'Ekonomi',gov:'Devlet',war:'Savaş',prof:'Profil'};
renderNav=function(){
  const qb=(typeof questBadge==='function')?questBadge():0,un=(typeof mdUnread==='function')?mdUnread():0,cg=groupOf(UI.tab);
  const dot=n=>n?`<span class="md-dot">${n>99?'99+':n}</span>`:'';
  const h=GROUPS.map(g=>`<button class="${g[0]===cg[0]?'active':''}" data-a="tab" data-t="${g[0]===cg[0]?UI.tab:g[2][0][0]}"><i>${RR_IC[g[0]]||''}</i>${RR_NAME[g[0]]||g[1]}${g[0]==='home'?dot(qb):''}${g[0]==='prof'?dot(un):''}</button>`).join('');
  const nv=document.getElementById('nav');if(nv.innerHTML!==h)nv.innerHTML=h;
  try{document.documentElement.style.setProperty('--navh',nv.offsetHeight+'px');}catch(e){}
};
{const _t=ACT.tab;ACT.tab=function(d){UI.rrMenu=false;return _t.apply(this,arguments);};}
const RR_STRIP=['paper','store','gov','war','map'];
function rrCityOpen(){return UI.tab==='map'&&UI.city!==null&&UI.city!==undefined&&S.regions&&S.regions[UI.city];}
function rrRoot(g,tab){if(g[0]==='map'&&rrCityOpen())return false;return RR_STRIP.includes(g[0])||g[2][0][0]===tab;}
function rrTabOk(t){return t[2]!=='adm'||isAdminUI()||(typeof opsTabOk==='function'&&opsTabOk(t[0]));}
function rrVis(g){return g[2].filter(rrTabOk);}
function rrTitle(g,tab){
  const root=rrRoot(g,tab);
  if(g[0]==='map'&&rrCityOpen())return S.regions[UI.city].n;
  if(RR_STRIP.includes(g[0]))return String(g[1]).replace(/^\S+\s/,'').trim();
  if(g[0]==='home'&&root)return 'Bilâd-ı Mütenâfise';
  if(g[0]==='prof'&&root)return 'Profilim';
  const t=g[2].find(x=>x[0]===tab);return String((t&&t[1])||g[1]).replace(/^\S+\s/,'').trim()||g[1];
}
ACT.rrBack=()=>{if(rrCityOpen()){UI.city=null;UI.rrMenu=false;return;}const g=groupOf(UI.tab);UI.tab=g[2][0][0];UI.rrMenu=false;};
ACT.rrMenu=()=>{UI.rrMenu=!UI.rrMenu;};
ACT.rrSearch=()=>{
  const q=(prompt('Ara: sayfa, şehir veya bölge adı')||'').trim().toLowerCase();if(!q)return;
  for(const g of GROUPS)for(const t of rrVis(g)){if(String(t[1]).toLowerCase().includes(q)){UI.tab=t[0];return;}}
  try{const i=S.regions.findIndex(r=>String(r.n).toLowerCase().includes(q));if(i>=0&&ACT.goCity){ACT.goCity({id:String(i)});return;}}catch(e){}
  msg('Bulunamadı.','bad');
};
function rrBarHtml(){
  const g=groupOf(UI.tab),root=rrRoot(g,UI.tab),vis=rrVis(g);
  let L,R='';
  if(!root)L='<button class="rb-b" data-a="rrBack" aria-label="Geri">←</button>';
  else if(g[0]==='prof')L='<button class="rb-b" data-a="tab" data-t="msg" aria-label="Mesajlar">✉</button>';
  else L='<button class="rb-b" data-a="rrSearch" aria-label="Ara">🔍</button>';
  R='<button class="rb-b" data-a="bell" aria-label="Bildirimler">🔔<b id="rbBell" style="display:none"></b></button>';
  if(root&&g[0]==='prof')R+='<button class="rb-b" data-a="tab" data-t="set" aria-label="Ayarlar">⚙</button>';
  else if(!root)R+=(UI.tab!=='guide'?'<button class="rb-b" data-a="tab" data-t="guide" aria-label="Yardım">?</button>':'');
  else if(root)R+='<button class="rb-b" data-a="rrMenu" aria-label="Menü">⋮</button>';
  let menu='';
  if(UI.rrMenu)menu=`<div id="rrmenu">${(RR_STRIP.includes(g[0])?vis.filter(t=>t[0]!==UI.tab).map(t=>`<button data-a="tab" data-t="${t[0]}">${t[1]}</button>`):[]).join('')}<button data-a="dlShare">🔗 Bağlantıyı paylaş</button></div>`;
  const sub=(g[0]==='home'&&root)?'':'';
  return `<div class="rb-row">${L}<div class="rb-t">${rrTitle(g,UI.tab)}${sub}</div><div class="rb-r">${R}</div></div>${menu}`;
}
function rrTiles(){
  const T=[['state','🏛️','Devlet'],['party','🎗️','Parti'],['elect','🗳️','Seçim']];
  if((typeof isLeader==='function'&&isLeader())||isAdminUI())T.push(['leader','👑','Başkan'],['cities','🏙️','Vali']);
  T.push(['give','🎁','Bağış'],['ai','🧠','Danışman'],['stats','📊','İstatistik']);
  const hint=k=>(typeof ACC_HINT!=='undefined'&&ACC_HINT[k])||'';
  return `<div class="panel"><h2>Devlet ve diğerleri</h2><div class="rr-tiles">${T.map(t=>`<button class="rr-tile" data-a="tab" data-t="${t[0]}"><span>${t[1]}</span><b>${t[2]}</b><small>${hint(t[0])}</small></button>`).join('')}</div></div>`;
}
function rrProfRows(){
  const R=[['set','⚙️','Ayarlar','ses, tema, devlet temaları'],['guide','📖','Rehber','oyunu öğren'],['net','🌐','Hesap','bağlantı ve hesap']];
  if(isAdminUI())R.push(['adm','👑','Yönetici paneli',''],['bots','🤖','Yapay zekâ','']);
  if(typeof opsTabOk==='function'){if(opsTabOk('guard'))R.push(['guard','🛡️','Güvenlik','']);if(opsTabOk('ops'))R.push(['ops','🏛️','Yönetim Merkezi','ekip, acil durum, ayarlar, kayıt']);}
  return `<div class="panel"><div class="rr-tiles one">${R.map(t=>`<button class="rr-tile" data-a="tab" data-t="${t[0]}"><span>${t[1]}</span><b>${t[2]}</b><small>${t[3]}</small></button>`).join('')}</div></div>`;
}
{const _r=render;render=function(){
  _r.apply(this,arguments);
  try{
    const app=document.querySelector('.app');if(!app)return;
    let bar=document.getElementById('rrbar');
    if(!bar){bar=document.createElement('div');bar.id='rrbar';app.insertBefore(bar,app.firstChild);}
    const banned=(typeof isBanned==='function'&&isBanned());
    bar.style.display=banned?'none':'';
    const g=groupOf(UI.tab),root=g[2][0][0]===UI.tab;
    document.documentElement.dataset.rrt=(UI.tab==='home')?'home':'x';
    const h=banned?'':rrBarHtml();if(bar.innerHTML!==h)bar.innerHTML=h;
    const bn=document.getElementById('hBellN'),rb=document.getElementById('rbBell');
    if(bn&&rb){rb.textContent=bn.textContent;rb.style.display=(bn.style.display==='none'||!bn.textContent)?'none':'';}
    const mn=document.getElementById('main');if(!mn||banned)return;
    const vis=rrVis(g);
    if(RR_STRIP.includes(g[0])&&vis.length>1){
      const qb=(typeof mdUnread==='function')?mdUnread():0;
      const s=document.createElement('div');s.className='rr-tabs';
      s.innerHTML=vis.map(t=>`<button class="${t[0]===UI.tab?'on':''}" data-a="tab" data-t="${t[0]}">${t[1]}${t[0]==='msg'&&qb?` <span class="md-dot" style="position:static;display:inline-block">${qb}</span>`:''}</button>`).join('');
      mn.insertBefore(s,mn.firstChild);
    }
    if(UI.tab==='home')mn.insertAdjacentHTML('beforeend',rrTiles());
    if(UI.tab==='char'){const hk=[...mn.querySelectorAll('details')].find(d=>/Hakkımda/.test(d.textContent));if(hk)hk.insertAdjacentHTML('beforebegin',rrProfRows());else mn.insertAdjacentHTML('beforeend',rrProfRows());}
    window.scrollTo&&0;
  }catch(e){console.warn('rrlayout',e);}
};}
{const st=document.createElement('style');st.id='rrcss';st.textContent=`
#rrbar{position:sticky;top:0;z-index:45;background:var(--bg1);border-bottom:1px solid var(--line);padding:0}
#rrbar .rb-row{display:flex;align-items:center;gap:4px;min-height:48px;padding:0 6px}
#rrbar .rb-t{flex:1;text-align:center;font-weight:800;font-size:15px;letter-spacing:.3px;color:var(--tx0);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#rrbar .rb-r{display:flex;gap:2px;min-width:44px;justify-content:flex-end}
#rrbar .rb-b{position:relative;width:42px;height:42px;border:none;background:none;color:var(--tx0);font-size:20px;border-radius:50%;cursor:pointer;display:grid;place-items:center;font-family:inherit}
#rrbar .rb-b:active{background:var(--bg3)}
#rrbar .rb-b b{position:absolute;top:3px;right:2px;min-width:16px;height:16px;border-radius:8px;background:var(--red);color:#fff;font-size:10px;display:grid;place-items:center;padding:0 3px}
#rrmenu{position:absolute;right:8px;top:46px;min-width:170px;background:var(--bg2);border:1px solid var(--line2);border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.5);overflow:hidden;z-index:50}
#rrmenu button{display:block;width:100%;text-align:left;background:none;border:none;border-bottom:1px solid var(--line);color:var(--tx);padding:13px 16px;font-size:14px;font-family:inherit;cursor:pointer}
#rrmenu button:last-child{border-bottom:none}
html:not([data-rrt="home"]) header.topbar{display:none!important}
html[data-rrt="home"] header.topbar #hBell{display:none!important}
html[data-rrt="home"] header.topbar{position:static!important;border-radius:0!important}
.rr-tabs{display:flex;overflow-x:auto;margin:-2px -2px 10px;border-bottom:1px solid var(--line);position:sticky;top:48px;z-index:30;background:var(--bg0);scrollbar-width:none}
.rr-tabs::-webkit-scrollbar{display:none}
.rr-tabs button{flex:1 0 auto;padding:12px 14px;background:none;border:none;border-bottom:3px solid transparent;color:var(--tx2);font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;font-family:inherit;cursor:pointer;white-space:nowrap}
.rr-tabs button.on{color:var(--tx0);border-bottom-color:var(--blue)}
.rr-tiles{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}
.rr-tiles.one{grid-template-columns:1fr}
.rr-tile{display:grid;grid-template-columns:auto 1fr;grid-template-rows:auto auto;column-gap:10px;align-items:center;text-align:left;background:var(--bg2);border:1px solid var(--line);border-radius:12px;padding:12px;color:var(--tx);cursor:pointer;font-family:inherit}
.rr-tile span{grid-row:1/3;font-size:24px}
.rr-tile b{font-size:14px}
.rr-tile small{color:var(--tx2);font-size:11px;line-height:1.25}
.rr-tile:active{background:var(--bg3)}
nav#nav>button{padding:6px 1px!important;font-size:10px!important;min-width:0;display:flex;flex-direction:column;align-items:center;gap:1px;overflow:visible}
nav#nav>button i{display:block;width:24px;height:24px;margin:0 auto 1px;font-size:0!important}
nav#nav>button i svg{width:24px;height:24px;display:block}
nav#nav>button .md-dot{top:2px;right:6px}
`;document.head.appendChild(st);}

/* ===== Derin bağlantı (deep link) =====
   #/sayfa · #/map/şehir · #/p/oyuncu · #/s/devlet · #/pt/parti · #/al/ittifak · #/c/şehir · #/dm/oyuncu · #/art/makale
   Paylaşılabilir, açılışta doğru yeri açar, telefonun geri tuşu önceki yere / açık kartı kapatmaya döner. */
(function(){
  const EK={p:'player',s:'state',pt:'party',al:'ally',c:'city'},EKR={player:'p',state:'s',party:'pt',ally:'al',city:'c'};
  const okTab=t=>GROUPS.some(g=>g[2].some(x=>x[0]===t&&rrTabOk(x)));
  const cur=()=>{
    if(typeof ENT!=='undefined'&&ENT.cur&&EKR[ENT.cur.k])return '#/'+EKR[ENT.cur.k]+'/'+ENT.cur.id;
    if(UI.tab==='art'&&typeof AR!=='undefined'&&AR.open)return '#/art/'+AR.open;
    if(UI.tab==='msg'&&typeof CHAT!=='undefined'&&CHAT.dm)return '#/dm/'+(CHAT.dm.id||CHAT.dm);
    return '#/'+UI.tab+((UI.tab==='map'&&Number.isInteger(UI.city))?'/'+UI.city:'');
  };
  let last='',ready=false;const boot=String(location.hash||'');
  function closeEnt(){try{if(typeof ENT!=='undefined'&&ENT.cur){ENT.cur=null;ENT.stack=[];entDraw();}}catch(e){}}
  function apply(h){
    const m=String(h===undefined?location.hash:h||'').match(/^#\/([a-z]+)(?:\/([A-Za-z0-9_-]+))?$/);if(!m)return false;
    const k=m[1],id=m[2];
    if(EK[k]&&id){
      if(k==='c'&&S.regions[+id]){UI.tab='map';UI.city=+id;closeEnt();return true;}
      if(typeof ENT!=='undefined'){ENT.stack=[];ENT.cur={k:EK[k],id:k==='s'||k==='p'||k==='pt'||k==='al'?id:+id};try{entDraw();}catch(e){}return true;}
      return false;
    }
    if(k==='dm'&&id&&typeof ACT.dmOpen==='function'){closeEnt();ACT.dmOpen({id:id,name:''});UI.tab='msg';return true;}
    if(k==='art'&&id){closeEnt();UI.tab='art';try{ACT.artOpen({id:id});}catch(e){}return true;}
    if(!okTab(k))return false;
    closeEnt();UI.tab=k;if(k==='map'&&id!=null&&/^\d+$/.test(id)&&S.regions&&S.regions[+id])UI.city=+id;
    if(k==='art'&&typeof AR!=='undefined')AR.open=null;
    return true;
  }
  function sync(){
    if(!ready)return;
    try{const h=cur();if(h===last)return;
      if(last==='')history.replaceState(null,'',h);else history.pushState(null,'',h);last=h;}catch(e){}
  }
  const _r=render;render=function(){_r.apply(this,arguments);sync();};
  ['ent','entBack','entClose','entDm','entGo','artOpen','dmOpen','dmBack'].forEach(n=>{
    const f=ACT[n];if(typeof f!=='function')return;
    ACT[n]=function(){const r=f.apply(this,arguments);try{sync();}catch(e){}if(r&&typeof r.then==='function')r.then(()=>{try{sync();}catch(e){}});return r;};
  });
  window.addEventListener('popstate',()=>{if(apply()){last=location.hash;UI.rrMenu=false;S.dirty=false;render();}});
  setTimeout(()=>{ready=true;try{if(apply(boot)){last=boot;render();setTimeout(()=>{try{if(ENT.cur)entDraw();}catch(e){}},2500);}else sync();}catch(e){}},0);
  {const _d=entDraw;entDraw=function(){_d.apply(this,arguments);try{const bx=document.querySelector('#modal-root .box');if(bx&&ENT.cur&&!bx.querySelector('[data-a=dlShare]'))bx.insertAdjacentHTML('beforeend','<div class="btns"><button class="sm" data-a="dlShare">🔗 Bağlantıyı paylaş</button></div>');}catch(e){}};}
  ACT.dlShare=()=>{
    const url=location.href.split('#')[0]+cur();UI.rrMenu=false;
    const done=()=>msg('Bağlantı kopyalandı.','ok');
    try{if(navigator.share){navigator.share({title:'Bilâd-ı Mütenâfise',url}).catch(()=>{});S.dirty=false;return;}}catch(e){}
    try{navigator.clipboard.writeText(url).then(done,()=>prompt('Bağlantı:',url));}catch(e){prompt('Bağlantı:',url);}
  };
  window.bmDeepLink={cur,apply};
})();
/* ===== Harita ve Şehirler: kararlı kaydırma, kalabalık bölgede seçim, anlaşılır şehir listesi ve sayfası ===== */
UI.cityQ='';UI.cityF='all';UI.wcand=[];
const MX_FIT=()=>Math.max(1,WM.h/(430*(WM.w/1000)));
/* 1) dokunma: yakındaki tüm bölgeleri bul (kalabalıkta seçenek sun), en yakını seç */
wmHit=function(x,y){
  geoInit();const c=[];
  S.regions.forEach(r=>{const q=wmPos(r.id),d=Math.hypot(q[0]-x,q[1]-y);if(d<32)c.push([d,r.id]);});
  c.sort((a,b)=>a[0]-b[0]);UI.wcand=c.slice(0,8).map(v=>v[1]);
  return c.length?c[0][1]:null;
};
/* 2) yakınlaştırma durumuna göre dokunma davranışı: uzaktayken sayfa kaydırılır, yakınken harita sürüklenir */
{const _d=wmDraw;wmDraw=function(){
  _d.apply(this,arguments);
  try{
    if(!WM.cv||!WM.w)return;
    const z=UI.wv.k>MX_FIT()*1.15;
    const ta=z?'none':'pan-y';if(WM.cv.style.touchAction!==ta)WM.cv.style.touchAction=ta;
    const b=document.getElementById('wmReset');if(b)b.style.display=z?'':'none';
  }catch(e){}
};}
/* kalabalık bölgede (birden çok aday) dokununca o noktaya yakınlaş */
{const _r=render;render=function(){
  _r.apply(this,arguments);
  try{if(UI.tab==='world'&&UI.wcrowd){UI.wcrowd=false;}}catch(e){}
};}
ACT.mapFind=()=>{
  const q=String((($('wmQ')||{}).value)||'').trim().toLocaleLowerCase('tr');if(!q)return;
  const r=S.regions.find(x=>String(x.n).toLocaleLowerCase('tr')===q)||S.regions.find(x=>String(x.n).toLocaleLowerCase('tr').includes(q));
  if(!r)return msg('Bölge bulunamadı.','bad');
  UI.wsel=r.id;UI.wcand=[];if(WM.w)wmView('sel');
};
ACT.mapPick=d=>{UI.wsel=+d.id;if(WM.w)wmView('sel');};
ACT.mapMine=()=>{UI.wsel=S.me.loc;UI.wcand=[];if(WM.w)wmView('sel');};
ACT.cityOnMap=d=>{UI.wsel=+d.id;UI.tab='world';UI.wFocus=true;window.scrollTo(0,0);};
{const _ar=afterRender;afterRender=function(){_ar.apply(this,arguments);try{if(UI.wFocus&&UI.tab==='world'&&WM.w){UI.wFocus=false;wmView('sel');}}catch(e){}};}
/* RR tarzı bilgi çubuğu: dokunulan bölgenin devleti, adı ve ne yapılabileceği */
function mxBar(){
  const id=UI.wsel,r=id!==null&&id!==undefined?S.regions[id]:null,m=S.me;
  if(!r)return '<div id="mxBar" class="card" style="margin:6px 0;padding:10px"><span class="dim">👆 Haritada bir bölgeye dokun; devleti ve yapılabilecekler burada görünür.</span></div>';
  const col=SCOL[r.state]||'#888';
  let act='';
  if(m.loc===r.id)act='<button class="act" disabled style="opacity:.7">📍 Buradasın</button>';
  else if(m.travel)act='<button class="act" disabled style="opacity:.7">🧳 Yoldasın</button>';
  else{
    const moonNo=r.moon&&!hasB('A','spaceport'),h=r.moon?3:hopsTo(m.loc,r.id),closed=r.state!=='A'&&relTo('A',r.state)<-70;
    if(moonNo)act='<button class="act red" disabled>🚀 Uzay Üssü gerekli</button>';
    else if(h>=99)act='<button class="act red" disabled>Yol yok</button>';
    else if(closed)act='<button class="act red" disabled>⛔ Sınırlar kapalı</button> <span class="dim" style="font-size:12px">İlişkiler çok kötü; devletle ilişkiyi düzelt.</span>';
    else{const cost=r.moon?20000:500*h,t=r.moon?30*MIN:h*5*MIN;act=`<button class="act gold" data-a="travel" data-to="${r.id}">🧳 Buraya git · ${fmt(cost)}₺ · ${fmtDur(t)}</button>`;}
  }
  return `<div id="mxBar" class="card" style="margin:6px 0;padding:10px;border-left:4px solid ${col}">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:space-between">
      <div><span class="dim" style="font-size:12px">Devlet</span><br><b><span style="color:${col}">●</span> ${eLink('state',r.state)}</b></div>
      <div style="text-align:right"><span class="dim" style="font-size:12px">${r.moon?'Ay üssü':'Bölge'}</span><br><b>${eLink('city',r.id)}</b></div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px">${act}<button class="act sm blue" data-a="goCity" data-id="${r.id}">📋 Bölge sayfası</button></div>
  </div>`;
}
/* 3) Harita sekmesi içeriği */
{const _tw=tabWorld;tabWorld=function(){
  let h=_tw.apply(this,arguments);
  const names=S.regions.map(r=>`<option value="${esc(r.n)}">`).join('');
  h=h.replace('<div id="wmWrap" style="','<div id="wmWrap" style="position:relative;');
  h=h.replace(/(<div id="wmWrap"[^>]*>)(<\/div>)/,'$1<button id="wmReset" class="act sm blue" data-a="mapZoom" data-d="all" style="position:absolute;top:6px;right:6px;z-index:3;display:none">🌍 Tümü</button>$2');
  h=h.replace('<div id="wmWrap" style="position:relative;',mxBar()+'<div id="wmWrap" style="position:relative;');
  const here=S.regions[S.me.loc];
  const cand=(UI.wcand||[]).length>1?`<div class="card" style="margin:8px 0"><p class="dim" style="margin:0 0 6px">Burada ${UI.wcand.length} bölge var, birini seç:</p><div class="btns">${UI.wcand.map(i=>`<button class="act sm${i===UI.wsel?' gold':''}" data-a="mapPick" data-id="${i}">${esc(S.regions[i].n)}</button>`).join('')}</div></div>`:'';
  const tools=`<div class="row" style="margin:8px 0"><input id="wmQ" list="wmDl" placeholder="Bölge ara…" style="flex:1;min-width:0"><datalist id="wmDl">${names}</datalist>${btn('Bul','data-a="mapFind"','sm')}${btn('📍 Bölgem','data-a="mapMine"','sm blue')}</div>${cand}`;
  h=h.replace(/<p class="hint">Sürükle:[^]*?<\/p>/,`<p class="hint" style="margin:4px 0">Sayfayı kaydırırken harita sabit kalır. Yakınlaşınca (＋ ya da iki parmak) harita sürüklenir; çıkmak için <b>🌍 Tümü</b>. Bölgeye dokun: ayrıntı. Beyaz sınır: devlet, kırmızı halka: savaş.</p>${tools}`);
  const id=UI.wsel!==null?UI.wsel:S.me.loc;
  h=h.replace('<h2 style="margin-top:12px">Devletler</h2>',`<div class="btns" style="margin-top:8px">${btn('📋 Şehir sayfası',`data-a="goCity" data-id="${id}"`,'blue sm')}</div><h2 style="margin-top:12px">Devletler</h2>`);
  return h;
};}
/* 4) Şehirler listesi */
const MX_F=[['all','Hepsi'],['mine','Devletim'],['coast','🌊 Kıyı'],['crit','⭐ Kritik'],['dev','🏙️ Geliştirilmiş']];
ACT.cityF=d=>{UI.cityF=d.f;};
ACT.citySearch=()=>{UI.cityQ=String((($('cityQ')||{}).value)||'').trim();};
ACT.cityClear=()=>{UI.cityQ='';UI.cityF='all';};
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='cityQ'){e.preventDefault();ACT.citySearch();S.dirty=false;render();}if(e.key==='Enter'&&e.target&&e.target.id==='wmQ'){e.preventDefault();ACT.mapFind();S.dirty=false;render();}});
{const _tm=tabMap;tabMap=function(){
  if(UI.city!==null&&S.regions[UI.city])return mxCityPage(_tm.apply(this,arguments),S.regions[UI.city]);
  const m=S.me,q=String(UI.cityQ||'').toLocaleLowerCase('tr'),f=UI.cityF||'all';
  const ok=r=>{
    if(q&&!String(r.n).toLocaleLowerCase('tr').includes(q))return false;
    if(f==='mine')return r.state==='A';if(f==='coast')return !!r.coast;if(f==='crit')return !!critOf(r.id);if(f==='dev')return devOf(r)>0;return true;};
  const here=S.regions[m.loc],home=S.regions[m.res];
  let h=`<div class="panel"><h2>🗺️ Şehirler</h2>
  <div class="card"><p style="margin:0">📍 Buradasın: <b>${here?`<a class="lk" data-a="cityPick" data-id="${here.id}">${esc(here.n)}</a>`:'—'}</b>${home&&home!==here?` · 🏠 İkametgâhın: <b><a class="lk" data-a="cityPick" data-id="${home.id}">${esc(home.n)}</a></b>`:''}</p></div>
  <div class="row" style="margin:8px 0"><input id="cityQ" placeholder="Şehir ara…" value="${esc(UI.cityQ||'')}" style="flex:1;min-width:0">${btn('Ara','data-a="citySearch"','sm')}${(UI.cityQ||f!=='all')?btn('Temizle','data-a="cityClear"','sm'):''}</div>
  <div class="rr-tabs" style="position:static;margin:0 0 10px">${MX_F.map(x=>`<button class="${f===x[0]?'on':''}" data-a="cityF" data-f="${x[0]}">${x[1]}</button>`).join('')}</div>`;
  if(!q&&f==='all'){const cl=critList();
    h+=`<details class="card"><summary><b>⭐ Kritik şehirler</b> <span class="dim">(sahibi devlete bonus verir)</span></summary>${cl.map(c=>{const r=S.regions[c.id],K=CRIT_KINDS.find(x=>x[0]===c.k);return `<p>${K[1]} <b><a class="lk" data-a="cityPick" data-id="${r.id}">${esc(r.n)}</a></b> — ${K[2]} <span class="dim">· ${esc(nameOf(r.state))}</span></p>`;}).join('')}</details>`;}
  let total=0;
  Object.keys(STATE_N).forEach(s=>{
    const regs=regOf(s).filter(ok);if(!regs.length)return;total+=regs.length;
    h+=`<h3 style="margin:14px 2px 6px">${s==='A'?'🏠 ':''}${esc(nameOf(s))} <span class="dim">· ${regs.length} şehir</span></h3><div class="rr-cl">`;
    regs.forEach(r=>{const c=critOf(r.id);
      h+=`<button class="rr-city${m.loc===r.id?' here':''}" data-a="cityPick" data-id="${r.id}">
        <span class="rc-n">${c?'⭐ ':''}${esc(r.n)}${m.loc===r.id?' <em>📍 buradasın</em>':''}${m.res===r.id?' <em>🏠 ikametgâh</em>':''}</span>
        <span class="rc-p">👥 ${fmt(cityPop(r))}</span>
        <span class="rc-s">Sağlık ${r.idx.h} · Askeri ${r.idx.m} · Eğitim ${r.idx.e} · Gelişmişlik ${r.idx.d}${devOf(r)?` · Seviye ${devOf(r)}`:''}${r.coast?' · 🌊':''}${r.moon?' · 🌙':''}</span></button>`;});
    h+='</div>';});
  if(!total)h+='<p class="dim" style="margin-top:12px">Eşleşen şehir yok.</p>';
  return h+'</div>';
};}
/* 5) Şehir sayfası: eylemler en üstte */
function mxCityPage(html,r){
  const m=S.me,here=m.loc===r.id,home=m.res===r.id,hops=hopsTo(m.loc,r.id);
  html=html.replace(/<div class="btns"><button[^>]*data-a="cityPick"[^>]*data-id=""[^>]*>[^<]*<\/button><\/div>/,'');
  // alttaki eski düğme satırını kaldır
  html=html.replace(/\s*<div class="btns">(?:<button[^>]*data-a="resid"[^>]*>[^<]*<\/button>|<button[^>]*data-a="travel"[^>]*>[^<]*<\/button>)<\/div><\/div>$/,'</div>');
  const dist=here?'Şu an buradasın.':(hops>=99&&!r.moon?'Bu şehre yol yok.':`Yolculuk: ${r.moon?'2sa':hops*20+'dk'} · ${hops>=99?'':hops+' durak'}`);
  const act=`<div class="card glow" style="margin:8px 0"><h3>Eylemler</h3><p class="dim" style="margin:0 0 6px">${dist}${m.res===r.id?' · 🏠 ikametgâhın':''}</p>
   <div class="btns">${here?btn('🏠 Buraya yerleş','data-a="resid"','gold',home||r.moon):btn('🧳 Buraya git',`data-a="travel" data-to="${r.id}"`,'gold',!!m.travel||(hops>=99&&!r.moon))}${btn('🗺️ Haritada göster',`data-a="cityOnMap" data-id="${r.id}"`,'blue sm')}</div></div>`;
  const i=html.indexOf('<h2>');const j=i>=0?html.indexOf('</p>',i):-1;
  return j>=0?html.slice(0,j+4)+act+html.slice(j+4):act+html;
}
{const st=document.createElement('style');st.id='mxcss';st.textContent=`
.rr-cl{display:grid;gap:6px}
#cityQ,#wmQ{background:var(--bg2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:9px 10px;font:inherit;font-size:14px}
#cityQ::placeholder,#wmQ::placeholder{color:var(--tx2)}
.rr-city{display:grid;grid-template-columns:1fr auto;gap:2px 10px;text-align:left;background:var(--bg2);border:1px solid var(--line);border-radius:12px;padding:11px 12px;color:var(--tx);cursor:pointer;font-family:inherit;width:100%}
.rr-city.here{border-color:var(--gold2)}
.rr-city:active{background:var(--bg3)}
.rr-city .rc-n{font-weight:700;font-size:14px}.rr-city .rc-n em{font-style:normal;font-weight:400;font-size:11px;color:var(--gold2);margin-left:4px}
.rr-city .rc-p{font-size:12px;color:var(--tx2);white-space:nowrap}
.rr-city .rc-s{grid-column:1/3;font-size:11.5px;color:var(--tx2);line-height:1.35}
`;document.head.appendChild(st);}
/* ===== Tüm sekmeler: tekrarları azalt, düğmeleri düzenle, giriş gerektiren yerlere doğrudan yol ===== */
const CL_HINT={store:'Kaynaklarını burada al-sat. Fiyatlar 10 dakikada bir değişir; <b>Al</b> mavi, <b>Sat</b> altın renklidir.',
 mkt:'Başka oyunculara kaynak sat, onlardan satın al.',craft:'Ham kaynaklardan ürün ve eşya üret.',
 auto:'Sen yokken de çalışsın ya da vursun diye açılan otomatik modlar.'};
function clFix(){
  const main=document.querySelector('main');if(!main)return;
  main.dataset.tab=UI.tab;
  /* uyarı kutuları yalnızca Ana Sayfa'da */
  const al=document.getElementById('alerts');if(al)al.style.display=(UI.tab==='home')?'':'none';
  /* giriş gerektiren sayfalara doğrudan düğme */
  if(!main.querySelector('.cl-login')){
    const el=[...main.querySelectorAll('p,div.al,div.card')].reverse().find(e=>e.children.length<3&&/Profil\s*›\s*Hesap/.test(e.textContent)&&/giriş yap/i.test(e.textContent));
    if(el)el.insertAdjacentHTML('afterend','<div class="btns cl-login" style="margin:6px 0 10px"><button class="act gold" data-a="tab" data-t="net">🔑 Giriş yap / Kayıt ol</button></div>');
  }
  /* kısa açıklama */
  if(CL_HINT[UI.tab]&&!main.querySelector('.cl-hint')){
    const t=main.querySelector('.rr-tabs'),h=`<p class="hint cl-hint" style="margin:0 2px 8px">${CL_HINT[UI.tab]}</p>`;
    if(t)t.insertAdjacentHTML('afterend',h);
  }
}
UI.clOpen={};
function clHome(){
  const h=document.querySelector('main .md-home');if(!h||h.querySelector('.cl-det'))return;
  const k=[...h.children],sec=k.filter(e=>e.tagName==='SECTION');
  const by=t=>sec.find(e=>e.innerText.trim().startsWith(t));
  const todo=by('🎯'),quick=by('⚡'),det=['📈','🎖️','🗳️'].map(by).filter(Boolean);
  const sum=h.querySelector('.md-sum');
  if(sum){[quick,todo].forEach(e=>{if(e)sum.after(e);});}
  if(det.length){
    const d=document.createElement('details');d.className='cl-det card';
    d.innerHTML='<summary><b>📊 Yetenekler, askeri eğitim, parti</b> <span class="dim">(ayrıntı)</span></summary>';
    if(UI.clOpen.home)d.open=true;
    det[0].before(d);det.forEach(e=>d.appendChild(e));
    d.addEventListener('toggle',()=>{UI.clOpen.home=d.open;});
  }
}
function clHow(){
  const main=document.querySelector('main');if(!main)return;
  [...main.querySelectorAll('p.hint')].forEach((p,i)=>{
    if(p.classList.contains('cl-hint')||p.closest('details')||p.textContent.length<150)return;
    const key=UI.tab+i,d=document.createElement('details');d.className='cl-how';
    d.innerHTML='<summary>ℹ️ Nasıl çalışır?</summary>';
    if(UI.clOpen[key])d.open=true;
    d.addEventListener('toggle',()=>{UI.clOpen[key]=d.open;});
    p.before(d);d.appendChild(p);
  });
}
{const _r=render;render=function(){_r.apply(this,arguments);try{clFix();if(UI.tab==='home')clHome();clHow();}catch(e){}};}
{const st=document.createElement('style');st.id='clcss';st.textContent=`
/* otomatik anahtar şeridi sadece ilgili yerlerde */
main[data-tab=char] .au2s,main[data-tab=quest] .au2s,main[data-tab=home] .au2s{display:none}
/* Depo: her kaynak bir kart satırı */
main[data-tab=store] .fold table,main[data-tab=store] .fold tbody{display:block;width:100%}
main[data-tab=store] .fold tr{display:grid;grid-template-columns:1fr auto;align-items:center;gap:6px 10px;padding:10px 0;border-bottom:1px solid var(--line)}
main[data-tab=store] .fold tr:last-child{border-bottom:0}
main[data-tab=store] .fold td{display:block;padding:0;border:0}
main[data-tab=store] .fold td.num{text-align:right;font-size:18px}
main[data-tab=store] .fold td.num::before{content:'Elinde: ';font-size:11px;font-weight:400;color:var(--tx2)}
main[data-tab=store] .fold td:nth-child(3){grid-column:1/3;display:grid;grid-template-columns:repeat(5,1fr);gap:5px}
main[data-tab=store] .fold td:nth-child(3) .act{margin:0;padding:9px 2px;font-size:12px;min-width:0}
main[data-tab=store] .fold td:nth-child(3) .act:not(.gold){background:#1f5fa8;border-color:#2b78cc}
/* Çalışma: kartlar tek sütun, düğmeler yan yana */
main[data-tab=work] .grid{grid-template-columns:1fr}
.cl-login .act{width:100%}
.cl-how{margin:4px 0 8px;font-size:12.5px}.cl-how summary{cursor:pointer;color:var(--tx2);padding:4px 0}.cl-how p{margin:4px 0}
.cl-det{margin:10px 0}.cl-det summary{cursor:pointer;padding:2px 0}.cl-det>section{margin-top:10px}
/* tüm sayfalar: koyu form alanları, rahat dokunma alanları */
main input:not([type=checkbox]):not([type=radio]):not([type=range]),main select,main textarea{background:var(--bg2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:9px 10px;font:inherit;font-size:14px;max-width:100%;box-sizing:border-box}
main input::placeholder,main textarea::placeholder{color:var(--tx2)}
main .act{min-height:38px}
main .act.sm{min-height:34px}
/* Günlük: dev boş kutu yerine makul yükseklik */
main[data-tab=log] .log.tall{min-height:0;height:auto;max-height:55vh;overflow:auto}
main[data-tab=log] textarea{height:180px}
/* Kontrol: otomatik iş satırları düzgün hizalı */
main[data-tab=ctl] .q{display:flex;flex-wrap:wrap;align-items:center;gap:4px 8px}
main[data-tab=ctl] .q .act{margin-left:auto}
/* uzun kart ızgaralarında okunurluk */
main .card h3{line-height:1.25}
main .hint{line-height:1.45}

`;document.head.appendChild(st);}
/* ===== 🤖 VEKİL: izin verdiğin alanlarda senin adına karar veren yapay zekâ =====
   Beyin sunucuda (botserver.js → agentRun). Burası: ayarlar, durum paylaşımı, emirlerin SENİN kurallarınla uygulanması,
   onay kutusu ve günlük. Her emir uygulanmadan önce burada yeniden doğrulanır; sunucu hiçbir zaman oyun durumunu doğrudan değiştirmez. */
const VK_DOM=[
 ['eco','💼','Ekonomi','Çalışma, üretim, pazar (alım-satım), seyahat, enerji içeceği'],
 ['write','✍️','Yazı ve mesaj','Genel sohbete mesaj, makale yazma'],
 ['elect','🗳️','Seçim ve parti','Aday olma, oy verme, kampanya'],
 ['war','⚔️','Savaş','Savaş ilanı ve vuruşlar (en riskli alan)'],
 ['dip','🏛️','Devlet ve diplomasi','Kanun teklifi, ambargo, ittifak teklifi, başkan politikası'],
 ['fac','🏭','Fabrika ve açık artırma','Stok toplama, deneyimi dolan fabrikayı yükseltme, açık artırmada bütçeli teklif']];
const VK_MODES=[['off','Kapalı'],['ask','Öner'],['auto','Otonom']];
const VK_DEF={on:0,modes:{eco:'off',write:'off',elect:'off',war:'off',dip:'off',fac:'off'},goal:'',label:1,cap:30};
const VK={cfg:null,ord:{},log:[],sv:{},busy:0,pollT:0,pubT:0,err:'',kill:null,loaded:0,cur:0};
const VK_DAY=86400e3,VK_TTL=12*3600e3;
function vkCfg(){
  if(!VK.cfg){let c=null;try{c=JSON.parse(localStorage.getItem('rr-vk'));}catch(e){}
    VK.cfg=Object.assign({},VK_DEF,c||{});VK.cfg.modes=Object.assign({},VK_DEF.modes,(c&&c.modes)||{});}
  return VK.cfg;
}
const vkOk=()=>!!(MP.ok&&MP.auth&&MP.uid());
async function vkSaveCfg(){
  const c=vkCfg();c.t=Date.now();
  try{localStorage.setItem('rr-vk',JSON.stringify(c));}catch(e){}
  if(vkOk()){try{await MP.fb('PUT','agent/'+MP.uid()+'/cfg',c);VK.err='';}catch(e){VK.err=String(e.message||e).slice(0,90);}}
}
async function vkLoad(){
  if(!vkOk()||VK.loaded)return;VK.loaded=1;
  try{const c=await MP.fb('GET','agent/'+MP.uid()+'/cfg');
    if(c&&typeof c==='object'){VK.cfg=Object.assign({},VK_DEF,c);VK.cfg.modes=Object.assign({},VK_DEF.modes,c.modes||{});try{localStorage.setItem('rr-vk',JSON.stringify(VK.cfg));}catch(e){}}
    else if(vkCfg().on)await vkSaveCfg();
  }catch(e){VK.err=String(e.message||e).slice(0,90);}
}
function vkMV(){const m=S.me;if(!m.vk)m.vk={d:0,spent:0,base:0,decl:0};return m.vk;}
function vkSpend(n){ // günlük harcama sınırı: günün ilk emrindeki paranın %cap'i
  const v=vkMV(),d=Math.floor(Date.now()/VK_DAY);
  if(v.d!==d){v.d=d;v.spent=0;v.decl=0;v.base=S.me.money;}
  const cap=Math.floor(v.base*Math.min(80,Math.max(5,+vkCfg().cap||30))/100);
  if(v.spent+n>cap)return false;v.spent+=n;return true;
}
/* ---- durum özeti (sunucudaki beyne gider; sır içermez) ---- */
function vkSnap(){
  const m=S.me,hr=homeReg(),r=S.regions[m.loc]||hr,s=hr.state,E=(typeof elOf==='function')?elOf(s):{},me=MP.uid();
  const ik=[];try{Object.keys(ITEMS).forEach(k=>{const I=ITEMS[k];if(I.needs&&!hasB('A',I.needs))return;const c=itemCost(k,1);if(c.money<=m.money)ik.push({k:k,n:I.n,para:c.money});});}catch(e){}
  return {t:Date.now(),n:m.name,lv:m.level,m:Math.round(m.money),en:Math.round(m.energy),sr:m.stor,pr:S.prices,loc:m.loc,locN:r.n,home:m.res,s:s,sN:(S.states[s]||{}).n||s,
    tr:m.travel?1:0,party:m.party||null,lead:(typeof isLeader==='function'&&isLeader())?1:0,pres:(typeof dipPres==='function'&&dipPres())?1:0,
    koruma:S.t<S.protectUntil?1:0,yara:Math.round(m.wound||0),
    komsu:r.adj.map(i=>({b:i,ad:S.regions[i].n,ulke:S.regions[i].state})),
    bolge:{ad:r.n,ulke:r.state,rezerv:{altin:Math.round(r.res.gold.c),petrol:Math.round(r.res.oil.c),maden:Math.round(r.res.ore.c)}},
    iliski:S.rel.A?Object.assign({},S.rel[s]||S.rel.A):{},
    savaslar:S.wars.filter(w=>w.state!=='done').slice(0,5).map(w=>({id:w.id,saldiran:w.att,savunan:w.def,bolge:w.region,tur:w.type,durum:w.state,benimDevletim:(w.att===s||w.def===s)?1:0})),
    fabrika:(m.facs||[]).slice(0,12).map(f=>({id:f.id,kay:f.res,sv:f.level,stok:Math.round(f.stock||0),xpDolu:(typeof facNeed==='function'&&(f.xp||0)>=facNeed(f.level))?1:0})),
    acikArt:(typeof AU!=='undefined'?Object.keys(AU.list||{}).filter(i=>auOpen(AU.list[i])&&AU.list[i].seller!==me).slice(0,6).map(i=>{const a=AU.list[i];return {id:i,tur:a.kind,fab:a.fac?{kay:a.fac.res,sv:a.fac.level}:null,min:a.min,teklif:a.bid?+a.bid.a:0,bitis_dk:Math.round((auEnd(a)-Date.now())/60000)};}):[]),
    uretilebilir:ik.slice(0,8),esya:m.items||{},
    secim:{asama:E.phase||'yok',bitis_dk:E.end?Math.round((+E.end-Date.now())/60000):null,baskanBenim:!!(E.pres&&E.pres.id===me),adayim:!!((E.cand||{})[me]),oyum:((E.votes||{})[me])||null},
    kanunlar:S.laws.filter(l=>l.status==='pending').slice(0,4).map(l=>l.txt)};
}
async function vkPublish(force){
  if(!vkOk()||!vkCfg().on)return;
  if(!force&&Date.now()-VK.pubT<10*60e3)return;VK.pubT=Date.now();
  try{await MP.fb('PUT','agent/'+MP.uid()+'/st',vkSnap());}catch(e){VK.err=String(e.message||e).slice(0,90);}
}
/* ---- emir açıklaması ---- */
const vkRN={gold:'altın',oil:'petrol',ore:'maden',uranium:'uranyum',diamonds:'elmas'};
function vkDesc(o){
  const a=o.a||{};
  switch(o.k){
    case 'work':return `⛏️ ${vkRN[a.r]||a.r} çalış (${a.n==='all'?'tüm enerjiyle':a.n+' kez'})`;
    case 'sell':return `💰 ${a.n==='all'?'tüm':a.n} ${vkRN[a.r]||a.r} sat (en az ${fmt(a.min)}₺)`;
    case 'buy':return `🛒 ${fmt(a.n)} ${vkRN[a.r]||a.r} al`;
    case 'craft':return `🔧 ${a.n} × ${(typeof ITEMS!=='undefined'&&ITEMS[a.k]?ITEMS[a.k].n:a.k)} üret`;
    case 'travel':return `🧳 ${(S.regions[a.to]||{}).n||('bölge '+a.to)} bölgesine git`;
    case 'drink':return '⚡ enerji içeceği iç';
    case 'say':return `💬 Sohbete yaz: “${a.m}”`;
    case 'article':return `📰 Makale yayımla: “${a.ti}”`;
    case 'elRun':return '🗳️ Seçimde aday ol (50.000₺)';
    case 'elVote':return '🗳️ Seçimde oy ver';
    case 'elCamp':return `📣 Kampanyaya ${fmt(a.v)}₺ harca`;
    case 'campaign':return '📣 Parti kampanyası yap (10.000₺)';
    case 'elPol':return `👑 Başkan politikası: ${a.k}`;
    case 'declare':return `⚔️ ${(S.regions[a.region]||{}).n||a.region} bölgesine savaş ilan et (${a.type})`;
    case 'hit':return '💥 Savaşta bir vuruş yap';
    case 'hitAll':return '💥 Enerji bitene kadar vur';
    case 'propose':return `🏛️ Kanun teklifi: ${a.kind==='tax'?'vergi oranları':a.kind==='treaty'?'anlaşma ('+a.g.state+', '+a.g.kind+')':'bina ('+a.g.b+')'}`;
    case 'facCollect':return '🏭 Fabrika stoklarını depoya al';
    case 'facUp':return '⬆️ Fabrikayı yükselt (deneyim doldu)';
    case 'auBid':return `🔨 Açık artırmada ${fmt(a.max)}₺ sınırına kadar teklif ver`;
    case 'dipEmb':return `🚫 ${a.t} devletine ambargo`;
    case 'dipPact':return `🤝 ${a.t} devletine ittifak teklifi`;
  }return o.k;
}
/* ---- emir uygulayıcıları: hepsi SENİN oyun kurallarınla çalışır; hata verirse emir "başarısız" olur ---- */
const VK_X={
  work(a){ // istenen kaynağın rezervi bittiyse, en kârlı diğer kaynağa geçer
    const n=a.n==='all'?60:+a.n,order=[a.r].concat(['gold','oil','ore'].filter(x=>x!==a.r).sort((x,y)=>(S.prices[y]*YIELD[y])-(S.prices[x]*YIELD[x])));
    let tot=0,err=null;const used=[];
    for(const r of order){let i=0;
      for(;tot<n;){const x=doWork(r);if(typeof x==='string'){err=x;break;}i++;tot++;}
      if(i)used.push(`${i}× ${vkRN[r]}`);
      if(tot>=n||!/rezer/i.test(String(err||'')))break;}
    if(!tot)throw err||'çalışılamadı';return `${used.join(', ')} çalışıldı`;},
  sell(a){if((+S.prices[a.r]||0)<+a.min)throw `fiyat düşük (${fmt(S.prices[a.r])}₺ < ${fmt(a.min)}₺)`;
    const b=S.me.money,r=sellRes(a.r,a.n==='all'?1e9:+a.n);if(typeof r==='string')throw r;return `+${fmt(S.me.money-b)}₺`;},
  buy(a){const p=+S.prices[a.r]||0;if(p>+a.max)throw 'fiyat yükseldi';if(!vkSpend(Math.ceil(p*a.n*1.2)))throw 'günlük harcama sınırı';
    const r=buyRes(a.r,+a.n);if(typeof r==='string')throw r;return `${fmt(a.n)} ${vkRN[a.r]} alındı`;},
  craft(a){const I=ITEMS[a.k];if(!I)throw 'bilinmeyen eşya';const c=itemCost(a.k,+a.n);if(!vkSpend(c.money))throw 'günlük harcama sınırı';
    const q=S.me.craftQ.length;ACT.craft({k:a.k,n:+a.n});if(S.me.craftQ.length<=q)throw 'üretilemedi (kaynak/bina yok)';return `${a.n} ${I.n} üretimde`;},
  travel(a){const r=S.regions[+a.to];if(!r)throw 'bölge yok';if(S.me.travel)throw 'zaten yoldasın';if(+a.to===S.me.loc)throw 'zaten orada';
    const h=r.moon?3:hopsTo(S.me.loc,+a.to);if(h>=99)throw 'yol yok';if(!vkSpend(r.moon?20000:500*h))throw 'günlük harcama sınırı';
    ACT.travel({to:+a.to});if(!S.me.travel)throw 'yola çıkılamadı';return `${r.n} yolunda`;},
  drink(){const e=S.me.energy;ACT.drink();if(S.me.energy<=e)throw 'içecek yok/enerji dolu';return 'enerji arttı';},
  async say(a){if(!MP.ok)throw 'giriş yok';if(MP.ban&&MP.ban.chat)throw 'susturuldun';if(Date.now()-(+vkMV().sayT||0)<3*3600e3)throw 'bekleme (3 saat)';
    const nm=S.me.name+(vkCfg().label===0?'':' 🤖'),key=Date.now()+'_ag'+MP.uid().slice(0,6);
    await MP.fb('PUT','chat/'+key,{u:nm,m:String(a.m).slice(0,160),t:Date.now(),uid:MP.uid(),ad:0,ag:1});vkMV().sayT=Date.now();S.me.msgs=(S.me.msgs||0)+1;return 'mesaj gönderildi';},
  async article(a){if(!MP.ok)throw 'giriş yok';if(MP.ban&&MP.ban.chat)throw 'susturuldun';if(Date.now()-(+S.me.artLast||0)<3*3600e3)throw 'bekleme (3 saat)';
    const id=Date.now()+'_'+MP.uid().slice(0,6);await MP.fb('PUT','articles/'+id,{uid:MP.uid(),an:S.me.name+(vkCfg().label===0?'':' 🤖'),ti:String(a.ti).slice(0,80),b:String(a.b).slice(0,3000),t:Date.now(),l:0,d:0,c:0,im:0,ag:1});
    S.me.artLast=Date.now();return 'makale yayımlandı';},
  async elRun(){if(S.me.money<EL_COST*1.2)throw 'para yetersiz';if(!vkSpend(EL_COST))throw 'günlük harcama sınırı';
    await ACT.elRun();const E=elOf(elState());if(!((E.cand||{})[elMeId()]))throw 'aday olunamadı (aşama/seviye)';return 'aday olundu';},
  async elVote(a){await ACT.elVote({id:a.id});const E=elOf(elState());if(((E.votes||{})[elMeId()])!==a.id)throw 'oy verilemedi';return 'oy verildi';},
  async elCamp(a){const b=S.me.money;if(!vkSpend(+a.v))throw 'günlük harcama sınırı';await ACT.elCamp({id:elMeId(),v:+a.v});if(S.me.money>=b)throw 'kampanya yapılamadı';return `${fmt(a.v)}₺ harcandı`;},
  campaign(){const b=S.me.money;if(!vkSpend(10000))throw 'günlük harcama sınırı';ACT.campaign();if(S.me.money>=b)throw 'kampanya yapılamadı (parti/bekleme)';return 'kampanya yapıldı';},
  async elPol(a){if(!(elIsPres(elState())))throw 'başkan değilsin';await ACT.elPol({k:a.k});return 'politika seçildi';},
  declare(a){const v=vkMV();if(v.decl>=1)throw 'günde en çok 1 savaş ilanı';if(S.me.level<5)throw 'seviye 5 gerekli';
    const n=S.laws.length;proposeLaw('war',{region:+a.region,type:a.type},'me');v.decl++;const l=S.laws[0];if(l&&l.status==='failed')throw 'ilan başarısız (koşul/bütçe)';return 'savaş teklifi/ilanı verildi';},
  hit(a){const h=S.me.hits;ACT.hit({w:+a.w});if(S.me.hits<=h)throw 'vurulamadı';return 'vuruş yapıldı';},
  hitAll(a){const h=S.me.hits;ACT.hitAll({w:+a.w});if(S.me.hits<=h)throw 'vurulamadı';return `${S.me.hits-h} vuruş`;},
  propose(a){if(S.me.level<5)throw 'seviye 5 gerekli';const g=a.g;
    if(S.laws.some(l=>l.status==='pending'&&l.kind===a.kind&&JSON.stringify(l.args)===JSON.stringify(g)))throw 'zaten oylamada';
    if(a.kind==='tax'&&Object.values(g).some(x=>isNaN(x)||x<0||x>40))throw 'oran sınır dışı';
    proposeLaw(a.kind,g,'me');return 'kanun teklifi verildi';},
  facCollect(){let n=0;(S.me.facs||[]).forEach(f=>{if(f.stock>=1){const b=f.stock;ACT.facCollect({id:f.id});if((f.stock||0)<b)n++;}});if(!n)throw 'toplanacak stok yok';return n+' fabrikadan alındı';},
  facUp(a){const f=(S.me.facs||[]).find(x=>x.id===+a.id);if(!f)throw 'fabrika yok';if((f.xp||0)<facNeed(f.level))throw 'deneyim dolmadı';
    const c=facCost(f.res,f.level+1),g=Math.ceil(c.gold*(f.hold?0.95:1)),mo=Math.ceil(c.money*(f.hold?0.95:1));
    if(!vkSpend(mo))throw 'günlük harcama sınırı';const l0=f.level;ACT.facUp({id:f.id});if(f.level<=l0)throw 'yükseltilemedi (altın/para yetersiz)';return 'seviye '+f.level;},
  async auBid(a){const x=AU.list[a.id];if(!x||!auOpen(x))throw 'açık artırma bitti';if(x.seller===g3uid())throw 'kendi ürünün';
    const cur=x.bid?+x.bid.a:0,np=Math.max(+x.min,Math.ceil(cur*1.05)+(cur?1:0));if(np>+a.max)throw 'fiyat sınırını aştı ('+fmt(np)+'₺)';
    if(x.bid&&x.bid.u===g3uid())throw 'en yüksek teklif zaten senin';if(!vkSpend(np))throw 'günlük harcama sınırı';
    const el=document.createElement('input');el.id='aub_'+a.id;el.value=np;el.style.display='none';document.body.appendChild(el);
    try{await ACT.auBid({id:a.id});}finally{el.remove();}
    if(!(x.bid&&x.bid.u===g3uid()))throw 'teklif verilemedi';return fmt(np)+'₺ teklif verildi';},
  async dipEmb(a){await ACT.dipEmb({t:a.t});return 'ambargo uygulandı';},
  async dipPact(a){await ACT.dipPact({t:a.t});return 'teklif gönderildi';}
};
async function vkSetOrd(id,patch){try{await MP.fb('PATCH','agent/'+MP.uid()+'/ord/'+id,patch);}catch(e){}if(VK.ord[id])Object.assign(VK.ord[id],patch);}
const vkWorth=()=>{const m=S.me;let v=m.money;for(const r of Object.keys(m.stor||{}))v+=(m.stor[r]||0)*(S.prices[r]||0)*0.9;return Math.round(v);};
async function vkLogAdd(id,o,ok,txt,dv){
  const rec={t:Date.now(),by:'cli',k:o.k,ok:ok?1:0,x:(vkDesc(o)+' → '+txt).slice(0,160)};if(typeof dv==='number'&&ok)rec.dv=dv;
  VK.log.unshift(Object.assign({id:id},rec));VK.log=VK.log.slice(0,60);
  try{await MP.fb('PUT','agent/'+MP.uid()+'/log/'+id,rec);}catch(e){}
}
async function vkRunOne(id,o){
  const c=vkCfg(),dom=VK_DOM.find(d=>d[0]===o.dom);
  let ok=false,txt='',w0=vkWorth();
  try{
    if(!c.on||!dom)throw 'vekil kapalı';
    if(VK.kill&&(VK.kill.all||VK.kill.ai))throw 'acil durum: yönetici otomasyonu durdurdu';
    if(c.modes[o.dom]==='off')throw 'bu alan kapalı';
    if(Date.now()-(+o.t||0)>VK_TTL)throw 'süresi doldu';
    const fn=VK_X[o.k];if(!fn)throw 'bilinmeyen emir';
    txt=await fn(o.a||{});ok=true;
  }catch(e){txt=String(e&&e.message||e);}
  const dv=vkWorth()-w0;
  await vkSetOrd(id,{st:ok?'done':(/süresi doldu/.test(txt)?'expired':'failed'),res:txt,t2:Date.now(),dv:ok?dv:0});
  await vkLogAdd(id,o,ok,txt,dv);
  if(ok){try{S.dirty=true;}catch(e){}}
}
async function vkPoll(force){
  if(!vkOk())return;
  if(!force&&Date.now()-VK.pollT<25e3)return;VK.pollT=Date.now();
  try{
    const u=MP.uid(),[ord,log,sv]=await Promise.all([MP.fb('GET','agent/'+u+'/ord'),MP.fb('GET','agent/'+u+'/log'),MP.fb('GET','agent/'+u+'/sv')]);
    try{VK.kill=await MP.fb('GET','cfg/kill');}catch(e){}
    VK.ord=ord||{};VK.sv=sv||{};
    const l=log||{};VK.log=Object.keys(l).sort().reverse().slice(0,40).map(k=>Object.assign({id:k},l[k]));
  }catch(e){VK.err=String(e.message||e).slice(0,90);return;}
  if(!vkCfg().on||VK.busy)return;
  VK.busy=1;
  try{
    const ids=Object.keys(VK.ord).sort().filter(k=>{const o=VK.ord[k];return o&&o.st==='approved'&&o.ex!=='srv-done';});
    for(const id of ids.slice(0,6)){await vkRunOne(id,VK.ord[id]);}
    if(ids.length){S.dirty=true;try{render();}catch(e){}}
  }finally{VK.busy=0;}
}
setInterval(()=>{try{if(document.hidden||!vkOk())return;if(!VK.loaded)vkLoad();if(!vkCfg().on)return;vkPublish(false);vkPoll(false);}catch(e){}},20000);
setTimeout(()=>{try{if(vkOk()){vkLoad().then(()=>{if(vkCfg().on){vkPublish(true);vkPoll(true);}});}}catch(e){}},6000);
/* ---- etkileşim ---- */
ACT.vkOn=()=>{const c=vkCfg();c.on=c.on?0:1;vkSaveCfg();if(c.on){vkPublish(true);vkPoll(true);}};
ACT.vkMode=d=>{vkCfg().modes[d.k]=d.m;vkSaveCfg();};
ACT.vkPreset=()=>{const c=vkCfg();c.on=1;c.modes={eco:'auto',write:'ask',elect:'ask',war:'ask',dip:'ask',fac:'auto'};vkSaveCfg();vkPublish(true);vkPoll(true);msg('Önerilen kurulum açıldı: ekonomi otonom, diğerleri onayına bağlı.','ok');};
ACT.vkStop=()=>{const c=vkCfg();c.on=0;vkSaveCfg();msg('Vekil durduruldu.','ok');};
ACT.vkGoal=()=>{const e=$('vkGoal');if(e){vkCfg().goal=e.value.trim().slice(0,300);vkSaveCfg();msg('Talimat kaydedildi.','ok');}S.dirty=false;};
ACT.vkLabel=()=>{const c=vkCfg();c.label=c.label===0?1:0;vkSaveCfg();};
ACT.vkCap=d=>{vkCfg().cap=+d.v;vkSaveCfg();};
ACT.vkRefresh=()=>{vkPublish(true);vkPoll(true);msg('Güncelleniyor…','info');};
ACT.vkYes=async d=>{const o=VK.ord[d.id];if(!o||o.st!=='pending')return;await vkSetOrd(d.id,{st:'approved'});S.dirty=false;await vkPoll(true);render();};
ACT.vkNo=async d=>{const o=VK.ord[d.id];if(!o||o.st!=='pending')return;await vkSetOrd(d.id,{st:'rejected'});await vkLogAdd(d.id,o,false,'reddettin');render();};
ACT.vkYesAll=async()=>{for(const id of Object.keys(VK.ord)){const o=VK.ord[id];if(o&&o.st==='pending'&&Date.now()-(+o.t||0)<VK_TTL)await vkSetOrd(id,{st:'approved'});}S.dirty=false;await vkPoll(true);render();};
ACT.vkNoAll=async()=>{for(const id of Object.keys(VK.ord)){const o=VK.ord[id];if(o&&o.st==='pending')await vkSetOrd(id,{st:'rejected'});}render();};
/* ---- sayfa ---- */
function tabVekil(){
  const c=vkCfg(),ok=vkOk(),now=Date.now();
  let h=`<div class="panel"><h2>🤖 Vekil</h2>
  <p class="hint">Vekil, izin verdiğin alanlarda senin adına karar verir. Kararları sunucudaki yapay zekâ hazırlar; sen oyunu açınca <b>senin kurallarınla</b> uygulanır. Her alanı ayrı ayrı <b>Kapalı</b>, <b>Öner</b> (sen onaylarsın) ya da <b>Otonom</b> (onaysız) yapabilirsin.</p>`;
  if(!ok)return h+`<div class="card"><p>Vekil için hesabına giriş yapmalısın.</p><div class="btns">${btn('🔑 Giriş yap','data-a="tab" data-t="net"','gold')}</div></div></div>`;
  if(VK.kill&&(VK.kill.all||VK.kill.ai))h+=`<div class="card" style="border-color:var(--red)"><p class="bad"><b>⛔ Acil durum:</b> yönetici otomasyonu geçici olarak durdurdu. Vekil şu an çalışmaz.</p></div>`;
  h+=`<div class="card glow"><div class="row" style="align-items:center;gap:10px"><b style="font-size:16px;flex:1">${c.on?'🟢 Vekil açık':'⚪ Vekil kapalı'}</b>${btn(c.on?'Durdur':'Aç','data-a="vkOn"',c.on?'danger':'gold')}</div>
  <p class="dim" style="margin:6px 0 0">${VK.sv&&VK.sv.t?`Sunucudaki son karar: ${fmtDur(now-VK.sv.t)} önce${VK.sv.note?' · “'+esc(VK.sv.note)+'”':''}`:'Sunucu henüz karar vermedi (birkaç saat sürebilir).'}</p>
  ${!c.on?`<div class="btns" style="margin-top:8px">${btn('✨ Önerilen kurulumla başla','data-a="vkPreset"','blue')}</div><p class="dim" style="margin:4px 0 0">Önerilen: ekonomi otonom; yazı, seçim, savaş ve devlet işleri senin onayına bağlı.</p>`:''}</div>`;
  const pend=Object.keys(VK.ord).sort().filter(k=>VK.ord[k]&&VK.ord[k].st==='pending'&&now-(+VK.ord[k].t||0)<VK_TTL);
  h+=`<h3 style="margin:14px 2px 6px">📥 Onay bekleyenler ${pend.length?`<span class="dim">· ${pend.length}</span>`:''}</h3>`;
  if(!pend.length)h+='<p class="dim">Onay bekleyen öneri yok.</p>';
  else{h+=`<div class="btns" style="margin-bottom:6px">${btn('✓ Hepsini onayla','data-a="vkYesAll"','gold sm')}${btn('✕ Hepsini reddet','data-a="vkNoAll"','sm')}</div>`;
    h+=pend.map(id=>{const o=VK.ord[id];return `<div class="card"><p style="margin:0"><b>${esc(vkDesc(o))}</b></p>${o.why?`<p class="dim" style="margin:3px 0 6px">${esc(o.why)}</p>`:''}<div class="btns">${btn('✓ Onayla',`data-a="vkYes" data-id="${id}"`,'gold sm')}${btn('✕ Reddet',`data-a="vkNo" data-id="${id}"`,'sm')}</div></div>`;}).join('');}
  const wait=Object.keys(VK.ord).filter(k=>VK.ord[k]&&VK.ord[k].st==='approved'&&now-(+VK.ord[k].t||0)<VK_TTL).length;
  if(wait)h+=`<p class="dim">⏳ ${wait} emir uygulanmayı bekliyor (birkaç saniye içinde).</p>`;
  const modesH=VK_DOM.map(d=>{const m=c.modes[d[0]]||'off';
    return `<div class="card"><b>${d[1]} ${d[2]}</b>${d[0]==='war'?' <span class="bad">· riskli</span>':''}<p class="dim" style="margin:3px 0 8px">${d[3]}</p>
    <div class="rr-tabs" style="position:static;margin:0">${VK_MODES.map(x=>`<button class="${m===x[0]?'on':''}" data-a="vkMode" data-k="${d[0]}" data-m="${x[0]}">${x[1]}</button>`).join('')}</div></div>`;}).join('');
  h+=`<h3 style="margin:14px 2px 6px">🎚️ Yetki alanları</h3>`+modesH;
  h+=`<h3 style="margin:14px 2px 6px">📝 Talimatın</h3><div class="card"><textarea id="vkGoal" rows="3" maxlength="300" placeholder="Örn: Ekonomiyi büyüt, savaştan kaçın, seçimde Anadolu için aday ol.">${esc(c.goal||'')}</textarea><div class="btns" style="margin-top:6px">${btn('Kaydet','data-a="vkGoal"','sm')}</div></div>`;
  h+=`<div class="card"><b>⚙️ Sınırlar</b><p class="dim" style="margin:4px 0 6px">Vekil günde en çok paranın bu kadarını harcayabilir:</p><div class="rr-tabs" style="position:static;margin:0">${[10,20,30,50].map(x=>`<button class="${(+c.cap||30)===x?'on':''}" data-a="vkCap" data-v="${x}">%${x}</button>`).join('')}</div>
  <div class="btns" style="margin-top:8px">${btn(c.label===0?'🤖 işareti: kapalı':'🤖 işareti: açık','data-a="vkLabel"','sm')}</div><p class="dim" style="margin:4px 0 0">İşaret açıkken Vekil'in yazdığı mesaj ve makalelerin yanında 🤖 görünür. Bağış/transfer emri hiç yoktur; sınırı aşan harcama reddedilir.</p></div>`;
  const L24=VK.log.filter(l=>now-(+l.t||0)<VK_DAY&&l.by==='cli'),okN=L24.filter(l=>l.ok).length,net=L24.reduce((a,l)=>a+(+l.dv||0),0);
  if(L24.length)h+=`<div class="card"><b>📊 Son 24 saat</b><p style="margin:4px 0 0">${L24.length} işlem · ${okN} başarılı · ${L24.length-okN} başarısız</p><p style="margin:2px 0 0">Net değer değişimi: <b class="${net>=0?'ok':'bad'}">${net>=0?'+':'−'}${fmt(Math.abs(net))}₺</b></p><p class="dim" style="margin:2px 0 0">Para + depodaki kaynakların değeri (satış fiyatıyla) hesaplanır. Alım-satım ve çalışma sonuçlarını içerir.</p></div>`;
  h+=`<h3 style="margin:14px 2px 6px">🧾 Vekil günlüğü</h3>`;
  h+=VK.log.length?VK.log.slice(0,15).map(l=>`<div class="card" style="padding:8px 10px"><p style="margin:0">${l.ok?'✅':'⚠️'} ${esc(l.x||l.k)}</p><p class="dim" style="margin:2px 0 0">${fmtDur(now-(+l.t||now))} önce · ${l.by==='srv'?'sunucu':'telefon'}</p></div>`).join(''):'<p class="dim">Henüz kayıt yok.</p>';
  h+=`<div class="btns" style="margin-top:10px">${btn('🔄 Şimdi yenile','data-a="vkRefresh"','sm')}</div>${VK.err?`<p class="bad">${esc(VK.err)}</p>`:''}</div>`;
  return h;
}
/* sekme kaydı + giriş noktaları */
TABX.vekil=tabVekil;
{const G=GROUPS.find(g=>g[0]==='home');if(G&&!G[2].some(t=>t[0]==='vekil')){const i=G[2].findIndex(t=>t[0]==='ai');G[2].splice(i<0?G[2].length:i+1,0,['vekil','🤖 Vekil']);}}
{const _t=rrTiles;rrTiles=function(){return _t.apply(this,arguments).replace(/(<button class="rr-tile" data-a="tab" data-t="ai">)/,`<button class="rr-tile" data-a="tab" data-t="vekil"><span>🤖</span><b>Vekil</b><small>${vkCfg().on?'açık':'senin yerine karar verir'}</small></button>$1`);};}
{const _p=rrProfRows;rrProfRows=function(){return _p.apply(this,arguments).replace('<div class="rr-tiles one">','<div class="rr-tiles one"><button class="rr-tile" data-a="tab" data-t="vekil"><span>🤖</span><b>Vekil</b><small>yapay zekâ senin yerine oynar</small></button>');};}
/* ===== Oyuncuyu tutan paket: "Sen yokken" özeti, seri koruması, yeni oyuncu rehberi ===== */
const RT={shown:0,open:false};
/* ---------- 1) SEN YOKKEN ÖZETİ ---------- */
function rtMark(){
  const m=S.me;if(!m||!S.t)return;
  m.away={t:Date.now(),money:Math.round(m.money),hits:m.hits||0,works:m.works||0,lv:m.level,logT:(S.log&&S.log[0]&&S.log[0].t)||0};
}
function rtSummary(){
  const m=S.me,a=m.away;if(!a||!a.t)return null;
  const gap=Date.now()-a.t;if(gap<20*60e3)return null;
  const rows=[];
  const dm=Math.round(m.money)-a.money;
  rows.push(['💰','Para',(dm>=0?'+':'−')+fmt(Math.abs(dm))+'₺ ('+fmt(m.money)+'₺ oldu)']);
  rows.push(['⚡','Enerji',Math.round(m.energy)+' (dolmuş olabilir; boşa gitmesin!)']);
  if((m.level||1)>(a.lv||1))rows.push(['⭐','Seviye','Seviye '+m.level+' oldun']);
  const lg=(S.log||[]).filter(x=>x.t>a.t);
  const bad=lg.filter(x=>x.c==='bad'||x.c==='warn').slice(0,4).map(x=>x.m||x.txt||'');
  const wars=(typeof nfWars==='function'?nfWars():[]);
  if(wars.length)rows.push(['⚔️','Savaş',wars.length+' aktif savaşın var — vurmayı unutma']);
  try{const s=elState(),E=elOf(s);
    if(E.phase==='vote'&&Date.now()<+E.end)rows.push(['🗳️','Seçim',nameOf(s)+' seçimi açık; bitişine '+fmtDur(+E.end-Date.now())]);
    else if(E.pres&&E.pres.id===MP.uid()&&E.phase==='term')rows.push(['👑','Görev','Başkanlık görevin sürüyor']);}catch(e){}
  try{if(vkCfg().on){const pend=Object.keys(VK.ord||{}).filter(k=>VK.ord[k]&&VK.ord[k].st==='pending').length;
    const done=(VK.log||[]).filter(x=>+x.t>a.t).length;
    rows.push(['🤖','Vekil',done?done+' işlem yaptı'+(pend?', '+pend+' emir onayını bekliyor':''):(pend?pend+' emir onayını bekliyor':'yeni işlem yok')]);}}catch(e){}
  return {gap:gap,rows:rows,bad:bad};
}
function rtDraw(){
  const root=document.getElementById('modal-root');if(!root)return;
  if(!RT.open){if(root.dataset.rt){root.innerHTML='';delete root.dataset.rt;}return;}
  const s=RT.sum;if(!s){RT.open=false;return;}
  root.innerHTML=`<div class="modal" data-a="rtClose"><div class="box" data-a="entNop" style="max-height:86vh;overflow:auto">
   <h2 style="margin:0 0 4px">👋 Hoş geldin!</h2><p class="dim" style="margin:0 0 10px">Son görüşmemizden ${fmtDur(s.gap)} geçti. Özet:</p>
   ${s.rows.map(r=>`<div class="card" style="padding:8px 10px;margin:5px 0"><p style="margin:0">${r[0]} <b>${r[1]}:</b> ${esc(r[2])}</p></div>`).join('')}
   ${s.bad.length?`<h3 style="margin:10px 0 4px">⚠️ Dikkat</h3>${s.bad.map(x=>`<p class="dim" style="margin:3px 0">• ${esc(x)}</p>`).join('')}`:''}
   <div class="btns" style="margin-top:12px">${btn('Tamam','data-a="rtClose"','gold')}${btn('📋 Görevler','data-a="rtQuest"','sm')}</div></div></div>`;
  root.dataset.rt=1;
}
ACT.rtClose=()=>{RT.open=false;rtMark();rtDraw();S.dirty=false;};
ACT.rtQuest=()=>{RT.open=false;rtMark();rtDraw();UI.tab='quest';};
function rtMaybe(){
  try{
    if(RT.open||!S.me||(typeof isBanned==='function'&&isBanned()))return;
    if(Date.now()-RT.shown<10*60e3)return;
    const s=rtSummary();if(!s){rtMark();return;}
    RT.shown=Date.now();RT.sum=s;RT.open=true;rtDraw();
  }catch(e){}
}
setTimeout(rtMaybe,2500);
document.addEventListener('visibilitychange',()=>{if(document.hidden)rtMark();else setTimeout(rtMaybe,600);});
window.addEventListener('pagehide',rtMark);
setInterval(()=>{try{if(!document.hidden&&!RT.open)rtMark();}catch(e){}},60000);
/* ---------- 2) SERİ KORUMASI: 1 gün kaçırırsan seri bozulmaz (kalkan) ---------- */
{
  const _si=streakInfo;
  streakInfo=function(){
    const m=S.me,k=dayKey(),s=m.streak||{last:'',n:0},r=_si();
    if(r.can&&s.n>0&&s.last){
      const y=new Date(Date.now()-864e5).toLocaleDateString('sv'),y2=new Date(Date.now()-2*864e5).toLocaleDateString('sv');
      if(s.last===y2&&s.last!==y&&(m.streakFz||0)>0){const n=s.n+1;return {can:true,n:n,day:((n-1)%7)+1,fz:1};}
    }
    return r;
  };
  const _dc=ACT.dailyClaim;
  ACT.dailyClaim=function(){
    const m=S.me,i=streakInfo();if(!i.can)return;
    const used=!!i.fz;if(used)m.streakFz=Math.max(0,(m.streakFz||0)-1);
    const before=m.streak?m.streak.n:0;
    // temel ödülü ver (n artışını kendimiz ayarlıyoruz)
    const r=streakReward(i.day);m.streak={last:dayKey(),n:i.n};m.money+=r.money;m.stor.gold=Math.min(storCap(),m.stor.gold+r.gold);m.energy=Math.min(150,m.energy+r.en);
    msg(`🎁 Giriş ödülü (${i.day}. gün): +${fmt(r.money)}₺${r.gold?` +${r.gold} altın`:''}${r.en?` +${r.en} enerji`:''}${used?' · 🛡️ seri kalkanı kullanıldı':''}`,'ok');
    if(i.day===7){m.streakFz=Math.min(2,(m.streakFz||0)+1);L('🛡️ 7 gün tamam: seri kalkanı kazandın (1 günü kaçırsan seri bozulmaz).','ok');}
  };
}
/* ---------- 3) YENİ OYUNCU REHBERİ ---------- */
const RT_STEPS=[
 ['⛏️','İlk işini yap','Çalış sekmesinden bir kaynağa dokun.',m=>(m.works||0)>=1,'data-a="tab" data-t="work"','Çalış'],
 ['💰','Kaynağını sat','Depo sekmesinden "Sat" de, paran artsın.',m=>(m.sells||0)>=1,'data-a="tab" data-t="store"','Depo'],
 ['🎓','Yeteneğini geliştir','Profil sekmesinde güç, eğitim veya dayanıklılığı çalıştır.',m=>!!m.learn||(m.str||0)>30||(m.edu||0)>30||(m.end||0)>30,'data-a="tab" data-t="char"','Profil'],
 ['🎁','Günlük ödülünü al','Her gün girersen ödül büyür.',m=>!!(m.streak&&m.streak.last),'data-a="dailyClaim"','Al'],
 ['🌐','Hesap aç','Hesabın her telefonda seninle gelir; sohbet ve seçime katılırsın.',m=>!!(MP&&MP.ok),'data-a="tab" data-t="net"','Hesap'],
 ['🤖','Vekil\'i keşfet','Yapay zekâ senin yerine karar versin (istersen).',m=>!!m.vkSeen,'data-a="tab" data-t="vekil"','Vekil']];
function rtOnb(){
  const m=S.me;if(!m||m.onbDone)return '';
  const st=RT_STEPS.map(s=>({s:s,ok:!!s[3](m)})),done=st.filter(x=>x.ok).length,all=done===st.length;
  const next=st.find(x=>!x.ok);
  let h=`<div class="panel"><div class="card glow"><h3 style="margin:0 0 4px">🚀 Başlangıç rehberi <span class="dim">· ${done}/${st.length}</span></h3>
   <div class="bar"><div style="width:${Math.round(done/st.length*100)}%;background:#3fb950"></div></div>`;
  h+=st.map(x=>`<div class="row" style="align-items:center;gap:8px;margin:6px 0;opacity:${x.ok?0.55:1}"><span style="font-size:18px">${x.ok?'✅':x.s[0]}</span><div style="flex:1;min-width:0"><b>${x.s[1]}</b><div class="dim" style="font-size:12px">${x.s[2]}</div></div>${x.ok?'':btn(x.s[5],x.s[4],(x===next?'gold':'')+' sm')}</div>`).join('');
  h+=all?`<div class="btns" style="margin-top:8px">${btn('🏆 Ödülü al: 50.000₺ + 10 altın','data-a="onbClaim"','gold')}</div>`:`<p class="dim" style="margin:6px 0 0">Hepsini bitirince 50.000₺ + 10 altın kazanırsın.</p>`;
  return h+'</div></div>';
}
ACT.onbClaim=()=>{const m=S.me;if(m.onbDone)return;if(!RT_STEPS.every(s=>s[3](m)))return;m.onbDone=1;m.money+=50000;m.stor.gold=Math.min(storCap(),m.stor.gold+10);msg('🏆 Başlangıç rehberi tamam: +50.000₺ +10 altın','ok');L('🏆 Başlangıç rehberini bitirdin: +50.000₺ ve +10 altın.','ok');};
{const _h=tabHome;tabHome=function(){return rtOnb()+_h.apply(this,arguments);};}
{const _r=render;render=function(){_r.apply(this,arguments);try{if(UI.tab==='vekil'&&S.me&&!S.me.vkSeen){S.me.vkSeen=1;}}catch(e){}};}
