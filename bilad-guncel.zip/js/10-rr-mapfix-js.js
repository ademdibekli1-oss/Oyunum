/* ===== rr_mapfix.js ===== */
/* ===== Harita renkleri: kalıcı, birbirinden ayırt edilebilir ===== */
const SC_K='rr-scol';
(function(){try{const d=JSON.parse(localStorage.getItem(SC_K)||'{}');Object.keys(d).forEach(k=>{if(/^#[0-9a-f]{6}$/i.test(d[k])&&S&&S.states&&S.states[k])SCOL[k]=d[k];});}catch(e){}})();
let scolLast='';
function scolSave(){try{const j=JSON.stringify(SCOL);if(j!==scolLast){scolLast=j;localStorage.setItem(SC_K,j);}}catch(e){}}
const scolRGB=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));
const scolDist=(a,b)=>{const x=scolRGB(a),y=scolRGB(b);return Math.hypot(x[0]-y[0],x[1]-y[1],x[2]-y[2]);};
/* iki devletin rengi birbirine çok yakınsa sonradan gelen (otomatik atanan) devletin rengi ayırt edilir hâle getirilir */
function scolSeparate(){let ch=0;const ks=Object.keys(S.states||{}).filter(k=>SCOL[k]);
  const fixed=new Set(['A','K','D','G','B','O','M','L','P']);
  ks.forEach(k=>{if(fixed.has(k))return;let t=0;while(t++<12&&ks.some(o=>o!==k&&scolDist(SCOL[k],SCOL[o])<55)){const [r,g,b]=scolRGB(SCOL[k]);const h=x=>('0'+Math.max(30,Math.min(235,x)).toString(16)).slice(-2);SCOL[k]='#'+h((r+70)%256)+h((g+130)%256)+h((b+190)%256);ch=1;}});
  if(ch&&typeof GEO!=='undefined'){GEO.inflK='';GEO.brdK='';}return ch;}
{const _r=render;render=function(){try{scolSeparate();scolSave();}catch(e){}return _r.apply(this,arguments);};}

/* ===== rr_events.js ===== */
/* ===== 🏆 ETKİNLİKLER: haftalık temalı etkinlik (otomatik), günün görevleri (gün gün artan ödül), yönetici etkinlikleri + sıralama + madalya.
   Akıllı oyuncular da katılır (sunucu puan yazar); birincinin ödülünü yönetici takdim eder. ===== */
const EVN={list:{},sc:{},t:0,busy:0,err:'',push:0};
const evnDay=()=>new Date(Date.now()+3*3600e3).toISOString().slice(0,10);
function evnWeekId(){const d=new Date(Date.now()+3*3600e3),t=Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()),y=new Date(Date.UTC(d.getUTCFullYear(),0,1)),w=Math.floor((t-y)/(7*864e5)+ (y.getUTCDay()||7)/7);return 'wk'+d.getUTCFullYear()+'w'+('0'+w).slice(-2);}
const EVN_THEMES=[
 {m:'gold',ic:'🥇',n:'Altına Hücum Haftası',d:'Bu hafta altın üret: işçi, fabrika, her yol serbest!',tiers:[[20,5000,0],[60,15000,2],[150,50000,10]],medal:'🥇'},
 {m:'oil',ic:'🛢️',n:'Petrol Fırtınası',d:'Petrol kuyuları yanıyor: en çok petrolü sen çıkar.',tiers:[[200,5000,0],[600,15000,2],[1500,50000,10]],medal:'🛢️'},
 {m:'ore',ic:'⛏️',n:'Maden Seferberliği',d:'Madenciler göreve: maden üret, ödülleri topla.',tiers:[[200,5000,0],[600,15000,2],[1500,50000,10]],medal:'⛏️'},
 {m:'work',ic:'💪',n:'Çalışkanlar Haftası',d:'En çok çalışan, en çok kazanır.',tiers:[[30,5000,0],[100,15000,2],[250,50000,10]],medal:'💪'},
 {m:'sell',ic:'🏪',n:'Büyük Pazar Haftası',d:'Pazarda en çok satış yapan tüccar kim?',tiers:[[20000,5000,0],[80000,15000,2],[250000,50000,10]],medal:'🏪'},
 {m:'craft',ic:'🔧',n:'Usta Zanaatkârlar',d:'Atölyeler çalışsın: eşya üret.',tiers:[[5,5000,0],[15,15000,2],[40,50000,10]],medal:'🔧'},
 {m:'hit',ic:'⚔️',n:'Cephe Haftası',d:'Savaşlarda vuruş yap, cephede parla.',tiers:[[10,5000,0],[40,15000,2],[100,50000,10]],medal:'⚔️'}];
const EVN_MN={gold:'altın',oil:'petrol',ore:'maden',work:'çalışma',sell:'₺ satış',craft:'üretim',hit:'vuruş'};
function evnTheme(){const w=evnWeekId(),n=+w.slice(-2)+ +w.slice(2,6)*52;return Object.assign({id:w},EVN_THEMES[n%EVN_THEMES.length]);}
/* günün görevleri: haftanın gününe göre ödül artar (Pzt x1 … Paz x2,5) */
function evnDaily(){const d=evnDay(),seed=+d.replace(/-/g,''),dow=(new Date(Date.now()+3*3600e3).getUTCDay()+6)%7,mult=1+dow*0.25;
  const pool=[['work',8,'çalış'],['gold',6,'altın üret'],['oil',60,'petrol üret'],['ore',60,'maden üret'],['sell',6000,'₺ değerinde sat'],['craft',2,'eşya üret'],['hit',4,'vuruş yap']];
  const a=seed%7,b=(seed*3+2)%7,c=(seed*5+4)%7,idx=[a,b===a?(b+1)%7:b,c===a||c===b?(c+2)%7:c];
  return idx.map((i,k)=>({m:pool[i][0],n:Math.round(pool[i][1]*(1+k*0.6)),t:pool[i][2],money:Math.round((2000+k*2500)*mult),gold:dow>=5?(k+1):0}));}
/* ---- sayaçlar ---- */
function evnMy(){const m=S.me;if(!m.evn)m.evn={};const e=m.evn,w=evnWeekId(),d=evnDay();
  if(e.w!==w){e.w=w;e.wv=0;e.wc=[0,0,0];e.wp=0;}if(e.d!==d){e.d=d;e.dv={};e.dc=[0,0,0];}if(!e.s)e.s={};if(!e.cl)e.cl={};return e;}
function evnCount(metric,n){n=+n;if(!(n>0))return;try{const e=evnMy(),th=evnTheme();
  if(th.m===metric){e.wv+=n;e.wp=1;}e.dv[metric]=(e.dv[metric]||0)+n;
  Object.keys(EVN.list).forEach(id=>{const ev=EVN.list[id],df=ev&&ev.def;if(df&&df.st!=='closed'&&df.m===metric&&Date.now()>=df.s&&Date.now()<=df.e){e.s[id]=(e.s[id]||0)+n;e.p=e.p||{};e.p[id]=1;}});
  e.push=1;}catch(x){}}
{const _dw=doWork;doWork=function(res){const r=_dw.apply(this,arguments);if(r&&typeof r==='object'){evnCount(res,r.amt);evnCount('work',1);}return r;};}
{const _sr=sellRes;sellRes=function(){const b=S.me.money,r=_sr.apply(this,arguments);if(typeof r!=='string'&&S.me.money>b)evnCount('sell',S.me.money-b);return r;};}
{const _fc=ACT.facCollect;ACT.facCollect=function(d){const f=(S.me.facs||[]).find(x=>x.id===+(d&&d.id));const b=f?S.me.stor[f.res]:0;const r=_fc.apply(this,arguments);if(f&&S.me.stor[f.res]>b)evnCount(f.res,S.me.stor[f.res]-b);return r;};}
{const _cr=ACT.craft;ACT.craft=function(){const q=(S.me.craftQ||[]).length;const r=_cr.apply(this,arguments);const n=(S.me.craftQ||[]).length-q;if(n>0)evnCount('craft',n);return r;};}
{const _h=ACT.hit,_ha=ACT.hitAll;ACT.hit=function(){const h=S.me.hits||0;const r=_h.apply(this,arguments);if((S.me.hits||0)>h)evnCount('hit',S.me.hits-h);return r;};ACT.hitAll=function(){const h=S.me.hits||0;const r=_ha.apply(this,arguments);if((S.me.hits||0)>h)evnCount('hit',S.me.hits-h);return r;};}
/* ---- ortak veri ---- */
const evnUid=()=>(typeof g3uid==='function'?g3uid():MP.uid());
async function evnPoll(force){if(!MP.ok||EVN.busy)return;if(!force&&Date.now()-EVN.t<45e3)return;EVN.t=Date.now();EVN.busy=1;
  try{const all=(await MP.fb('GET','events'))||{};const th=evnTheme();
    if(!all[th.id]||!all[th.id].def){const def={n:th.n,m:th.m,s:Date.now()-((new Date(Date.now()+3*3600e3).getUTCDay()+6)%7)*864e5,e:Date.now()+7*864e5,auto:1,tiers:th.tiers,medal:th.medal,d:th.d};
      try{await MP.fb('PUT','events/'+th.id+'/def',def);all[th.id]=Object.assign(all[th.id]||{},{def:def});}catch(e){}}
    EVN.list=all;EVN.err='';}catch(e){EVN.err=String(e.message||e).slice(0,90);}
  // kendi puanlarımı gönder
  try{const e=evnMy();if(e.push&&Date.now()-EVN.push>50e3){EVN.push=Date.now();e.push=0;const u=evnUid(),w=evnTheme();
    if(e.wp)await MP.fb('PUT','events/'+w.id+'/sc/'+u,{n:S.me.name,v:Math.round(e.wv),t:Date.now()});
    for(const id of Object.keys(e.p||{})){if(e.p[id]&&e.s[id]){await MP.fb('PUT','events/'+id+'/sc/'+u,{n:S.me.name,v:Math.round(e.s[id]),t:Date.now()});e.p[id]=0;}}}}catch(x){}
  EVN.busy=0;if(UI.tab==='etk')S.dirty=true;}
setInterval(()=>{try{if(!document.hidden&&MP.ok)evnPoll(false);}catch(e){}},30000);setTimeout(()=>{try{evnPoll(true);}catch(e){}},7000);
const evnLive=()=>Object.keys(EVN.list).map(id=>Object.assign({id:id},EVN.list[id])).filter(x=>x.def&&x.def.st!=='closed'&&x.def.e>Date.now()&&x.def.s<=Date.now()+1);
function evnOpenCount(){let n=0;try{const e=evnMy(),th=evnTheme();if(e.wc.some((c,i)=>!c&&e.wv>=th.tiers[i][0]))n++;
  evnDaily().forEach((q,i)=>{if(!evnMy().dc[i]&&(evnMy().dv[q.m]||0)>=q.n)n++;});}catch(x){}return n;}
/* ---- ödül alma ---- */
function evnGive(money,gold,medal,title){const m=S.me;if(money)m.money+=money;if(gold)m.stor.gold+=gold;if(medal){(m.medals=m.medals||[]).push({e:medal,t:title,w:Date.now()});if(m.medals.length>60)m.medals.shift();}}
ACT.evnTier=d=>{const e=evnMy(),th=evnTheme(),i=+d.i,t=th.tiers[i];if(!t||e.wc[i]||e.wv<t[0])return;e.wc[i]=1;evnGive(t[1],t[2],i===2?th.medal:null,th.n);msg(`🎉 ${th.n}: +${fmt(t[1])}₺${t[2]?' +'+t[2]+' altın':''}${i===2?' + '+th.medal+' madalya':''}`,'ok');S.dirty=true;};
ACT.evnDq=d=>{const e=evnMy(),q=evnDaily()[+d.i];if(!q||e.dc[+d.i]||(e.dv[q.m]||0)<q.n)return;e.dc[+d.i]=1;evnGive(q.money,q.gold);msg(`✅ Günün görevi: +${fmt(q.money)}₺${q.gold?' +'+q.gold+' altın':''}`,'ok');S.dirty=true;};
ACT.evnClaim=async d=>{const ev=EVN.list[d.id];if(!ev||!ev.win||ev.win.uid!==evnUid()||!ev.win.ok||ev.win.claimed)return;
  try{await MP.fb('PATCH','events/'+d.id+'/win',{claimed:1});ev.win.claimed=1;const rw=ev.def.rw||{};evnGive(+rw.money||0,+rw.gold||0,rw.medal||'🏅',ev.def.n);msg('🏅 Ödülün teslim edildi: '+(rw.txt||ev.def.n),'ok');S.dirty=true;}catch(e){msg('Alınamadı: '+String(e.message||e).slice(0,80));}};
/* ---- yönetici ---- */
ACT.evnNew=async()=>{const g=id=>(document.getElementById(id)||{}).value,n=String(g('evn_n')||'').replace(/[<>]/g,'').trim().slice(0,40),m=g('evn_m'),hrs=Math.max(1,Math.min(24*30,+g('evn_h')||48));
  if(!MP.ok)return msg('Önce giriş yap.');if(!isAdminUI())return msg('Yalnız yönetici.');if(n.length<3)return msg('Etkinlik adı yaz.');
  const def={n:n,m:m,s:Date.now(),e:Date.now()+hrs*3600e3,d:String(g('evn_d')||'').replace(/[<>]/g,'').slice(0,160),rw:{money:Math.max(0,+g('evn_rm')||0),gold:Math.max(0,+g('evn_rg')||0),medal:String(g('evn_rd')||'🏅').slice(0,2),txt:String(g('evn_rt')||'').replace(/[<>]/g,'').slice(0,60)}};
  const id='c'+Date.now().toString(36);try{await MP.fb('PUT','events/'+id+'/def',def);EVN.list[id]={def:def};msg('🏆 Etkinlik başlatıldı.','ok');S.dirty=true;evnPoll(true);}catch(e){msg('Yazılamadı (Firebase kuralları yayınlandı mı?): '+String(e.message||e).slice(0,70));}};
function evnRank(id){const sc=(EVN.list[id]||{}).sc||{};return Object.keys(sc).map(u=>Object.assign({u:u},sc[u])).sort((a,b)=>b.v-a.v);}
ACT.evnEnd=async d=>{if(!isAdminUI())return;const ev=EVN.list[d.id];if(!ev)return;const rk=evnRank(d.id),w=rk[0];
  try{await MP.fb('PATCH','events/'+d.id+'/def',{st:'closed'});ev.def.st='closed';
    if(w){const win={uid:w.u,n:w.n,v:w.v,bot:String(w.u).startsWith('bot_')?1:0};await MP.fb('PUT','events/'+d.id+'/win',win);ev.win=win;msg('🏁 Birinci: '+w.n+' ('+fmt(w.v)+'). Ödülü takdim edebilirsin.','ok');}else msg('Katılan olmadı.');S.dirty=true;}catch(e){msg(String(e.message||e).slice(0,80));}};
ACT.evnPresent=async d=>{if(!isAdminUI())return;const ev=EVN.list[d.id];if(!ev||!ev.win||ev.win.ok)return;const rw=ev.def.rw||{};
  try{await MP.fb('PATCH','events/'+d.id+'/win',{ok:1});ev.win.ok=1;
    if(ev.win.bot){const i=+String(ev.win.uid).replace('bot_','');if(typeof botSrvCmd==='function'&&S.botSrv){botSrvCmd({k:'gift',ids:[i],money:+rw.money||0,gold:+rw.gold||0});botSrvCmd({k:'medal',i:i,e:rw.medal||'🏅',t:ev.def.n});}ev.win.claimed=1;await MP.fb('PATCH','events/'+d.id+'/win',{claimed:1});msg('🏅 Ödül yapay zekâ oyuncuya verildi.','ok');}
    else msg('🏅 Ödül takdim edildi; kazanan oyuna girince teslim alır.','ok');S.dirty=true;}catch(e){msg(String(e.message||e).slice(0,80));}};
ACT.evnDel=async d=>{if(!isAdminUI())return;try{await MP.fb('DELETE','events/'+d.id);}catch(e){}delete EVN.list[d.id];S.dirty=true;};
/* ---- sayfa ---- */
function evnTierHtml(th,e){return th.tiers.map((t,i)=>{const got=e.wc[i],can=!got&&e.wv>=t[0];return `<div class="row" style="align-items:center;gap:8px;margin:5px 0"><div style="flex:1;min-width:0"><b>${i+1}. kademe</b> <span class="dim">${fmt(t[0])} ${EVN_MN[th.m]}</span><div class="dim" style="font-size:12px">+${fmt(t[1])}₺${t[2]?' · +'+t[2]+' altın':''}${i===2?' · '+th.medal+' madalya':''}</div></div>${got?'<span class="ok">✅ alındı</span>':btn(can?'Al':'Kilitli',`data-a="evnTier" data-i="${i}"`,'gold sm',!can)}</div>`;}).join('');}
function tabEtk(){
  evnPoll();const e=evnMy(),th=evnTheme(),me=evnUid(),dq=evnDaily(),adm=isAdminUI();
  const wk=EVN.list[th.id],end=wk&&wk.def?wk.def.e:Date.now()+7*864e5,rk=evnRank(th.id),myRank=rk.findIndex(x=>x.u===me)+1;
  let h=`<div class="panel"><h2>🏆 Etkinlikler</h2>
  <div class="card glow"><div class="row" style="align-items:center;gap:10px"><span style="font-size:34px">${th.ic}</span><div style="flex:1"><b style="font-size:16px">${th.n}</b><div class="dim" style="font-size:12px">${th.d} · bitişe ${fmtDur(Math.max(0,end-Date.now()))}</div></div></div>
   <p style="margin:8px 0 2px">İlerlemen: <b>${fmt(e.wv)}</b> ${EVN_MN[th.m]}${myRank?` · sıran <b>#${myRank}</b>`:''}</p>${bar(e.wv,th.tiers[2][0],'#f0c040')}${evnTierHtml(th,e)}
   ${rk.length?`<p class="dim" style="margin:8px 0 2px">🏅 İlk 5</p>${rk.slice(0,5).map((x,i)=>`<p style="margin:2px 0;font-size:13px">${['🥇','🥈','🥉','4.','5.'][i]} ${esc(x.n||'?')}${String(x.u).startsWith('bot_')?' 🤖':''} — ${fmt(x.v)}</p>`).join('')}`:''}</div>
  <h3 style="margin:14px 2px 6px">📅 Günün görevleri <span class="dim" style="font-size:12px">· ödüller gün gün artar</span></h3>
  ${dq.map((q,i)=>{const v=e.dv[q.m]||0,got=e.dc[i],can=!got&&v>=q.n;return `<div class="card" style="padding:9px 10px"><div class="row" style="align-items:center;gap:8px"><div style="flex:1;min-width:0"><b>${fmt(q.n)} ${esc(q.t)}</b><div class="dim" style="font-size:12px">${fmt(Math.min(v,q.n))}/${fmt(q.n)} · +${fmt(q.money)}₺${q.gold?' +'+q.gold+' altın':''}</div></div>${got?'<span class="ok">✅</span>':btn(can?'Al':'…',`data-a="evnDq" data-i="${i}"`,'gold sm',!can)}</div>${bar(v,q.n,'#3fb950')}</div>`;}).join('')}`;
  const live=evnLive().filter(x=>!x.def.auto);
  h+=`<h3 style="margin:14px 2px 6px">🎪 Özel etkinlikler</h3>`;
  if(!live.length)h+='<p class="dim">Şu an yönetici etkinliği yok.</p>';
  live.forEach(x=>{const d=x.def,r2=evnRank(x.id),mine=e.s[x.id]||0,rw=d.rw||{};h+=`<div class="card"><b>${esc(d.n)}</b><div class="dim" style="font-size:12px">${esc(d.d||'')} · ${EVN_MN[d.m]||d.m} · bitişe ${fmtDur(Math.max(0,d.e-Date.now()))}</div><p style="margin:4px 0">🎁 ${rw.money?fmt(rw.money)+'₺ ':''}${rw.gold?rw.gold+' altın ':''}${rw.medal||''} ${esc(rw.txt||'')}</p><p style="margin:2px 0">Puanın: <b>${fmt(mine)}</b></p>${r2.slice(0,3).map((y,i)=>`<p style="margin:2px 0;font-size:13px">${['🥇','🥈','🥉'][i]} ${esc(y.n||'?')}${String(y.u).startsWith('bot_')?' 🤖':''} — ${fmt(y.v)}</p>`).join('')}</div>`;});
  const done=Object.keys(EVN.list).map(id=>Object.assign({id:id},EVN.list[id])).filter(x=>x.def&&!x.def.auto&&(x.def.st==='closed'||x.def.e<=Date.now())).sort((a,b)=>b.def.e-a.def.e).slice(0,5);
  if(done.length){h+=`<h3 style="margin:14px 2px 6px">🏁 Biten etkinlikler</h3>`;done.forEach(x=>{const w=x.win;h+=`<div class="card" style="padding:9px 10px"><b>${esc(x.def.n)}</b> ${w?`<p style="margin:3px 0">🥇 ${esc(w.n)}${w.bot?' 🤖':''} — ${fmt(w.v)}${w.ok?' · 🏅 ödül takdim edildi':' · ödül bekliyor'}</p>`:'<p class="dim" style="margin:3px 0">Sonuç bekleniyor.</p>'}${w&&w.uid===me&&w.ok&&!w.claimed?btn('🏅 Ödülümü teslim al',`data-a="evnClaim" data-id="${x.id}"`,'gold sm'):''}${adm&&!x.def.st?btn('Bitir ve birinciyi belirle',`data-a="evnEnd" data-id="${x.id}"`,'sm'):''}${adm&&w&&!w.ok?btn('🏅 Ödülü takdim et',`data-a="evnPresent" data-id="${x.id}"`,'gold sm'):''}${adm?btn('Sil',`data-a="evnDel" data-id="${x.id}"`,'sm danger'):''}</div>`;});}
  const meds=(S.me.medals||[]).slice(-12).reverse();
  h+=`<h3 style="margin:14px 2px 6px">🎖️ Madalyalarım</h3>${meds.length?`<div class="card"><p style="margin:0;font-size:22px;letter-spacing:4px">${meds.map(x=>esc(x.e)).join(' ')}</p><p class="dim" style="margin:4px 0 0;font-size:12px">${meds.slice(0,3).map(x=>esc(x.t)).join(' · ')}</p></div>`:'<p class="dim">Henüz madalyan yok. Haftalık etkinliğin 3. kademesine ulaş!</p>'}`;
  if(adm){h+=`<h3 style="margin:14px 2px 6px">👑 Etkinlik yönetimi</h3><div class="card"><input id="evn_n" placeholder="Etkinlik adı (örn. Cuma Altın Yarışı)" maxlength="40" style="width:100%;margin:3px 0"><input id="evn_d" placeholder="Kısa açıklama" maxlength="160" style="width:100%;margin:3px 0">
   <div class="row" style="gap:6px;margin:3px 0"><select id="evn_m" style="flex:1">${Object.keys(EVN_MN).map(k=>`<option value="${k}">${EVN_MN[k]}</option>`).join('')}</select><input id="evn_h" type="number" value="48" placeholder="saat" style="width:80px"></div>
   <div class="row" style="gap:6px;margin:3px 0"><input id="evn_rm" type="number" placeholder="Ödül ₺" style="flex:1;min-width:0"><input id="evn_rg" type="number" placeholder="Ödül altın" style="flex:1;min-width:0"><input id="evn_rd" value="🏅" maxlength="2" style="width:56px;text-align:center"></div><input id="evn_rt" placeholder="Ödül notu (örn. Altın kupa)" maxlength="60" style="width:100%;margin:3px 0">
   <div class="btns">${btn('🏆 Etkinliği başlat','data-a="evnNew"','gold')}</div><p class="dim" style="font-size:12px">Akıllı oyuncular da katılır. Süre bitince "Bitir ve birinciyi belirle", sonra "Ödülü takdim et" de.</p></div>`;
   const act=Object.keys(EVN.list).map(id=>Object.assign({id:id},EVN.list[id])).filter(x=>x.def&&!x.def.auto&&x.def.st!=='closed'&&x.def.e>Date.now());
   act.forEach(x=>{h+=`<div class="card" style="padding:8px 10px"><b>${esc(x.def.n)}</b> <span class="dim">(sürüyor)</span><div class="btns">${btn('Şimdi bitir',`data-a="evnEnd" data-id="${x.id}"`,'sm')}${btn('Sil',`data-a="evnDel" data-id="${x.id}"`,'sm danger')}</div></div>`;});}
  if(EVN.err)h+=`<p class="bad">${esc(EVN.err)}</p>`;
  return h+'</div>';}
TABX.etk=tabEtk;
{const G=GROUPS.find(g=>g[0]==='home');if(G&&!G[2].some(t=>t[0]==='etk')){const i=G[2].findIndex(t=>t[0]==='quest');G[2].splice(i<0?G[2].length:i+1,0,['etk','🏆 Etkinlik']);}}

/* ===== rr_regart.js ===== */
/* ===== 🖼️ Bölge tanıtım görselleri: her bölge için bölgeye özgü (kaynak, kıyı, gelişmişlik, devlet rengi) otomatik tasarlanmış manzara.
   Yönetici isterse kendi fotoğrafını yükler (küçültülür, 'regimg/<id>' altında saklanır) ve herkes onu görür. ===== */
const RA={img:{},busy:{}};
function raRng(seed){let a=(seed*2654435761)>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
const raShade=(h,k)=>{const c=[1,3,5].map(i=>Math.max(0,Math.min(255,Math.round(parseInt(h.slice(i,i+2),16)*k))));return '#'+c.map(x=>('0'+x.toString(16)).slice(-2)).join('');};
function regArt(r){
  const R=raRng(r.id*7919+13),col=/^#[0-9a-f]{6}$/i.test(SCOL[r.state]||'')?SCOL[r.state]:'#4aa3ff',W=320,H=150;
  const gold=r.res&&r.res.gold&&r.res.gold.m>0,oil=r.res&&r.res.oil&&r.res.oil.m>0,ore=r.res&&r.res.ore&&r.res.ore.m>0,dev=Math.min(10,Math.max(1,(typeof devOf==='function'?devOf(r):3)));
  let s=`<svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block;border-radius:12px" preserveAspectRatio="xMidYMid slice">`;
  if(r.moon){
    s+=`<rect width="${W}" height="${H}" fill="#05070d"/>`;for(let i=0;i<60;i++)s+=`<circle cx="${R()*W}" cy="${R()*100}" r="${R()*1.1+.2}" fill="#fff" opacity="${.4+R()*.6}"/>`;
    s+=`<circle cx="250" cy="38" r="22" fill="#2b6cb0"/><circle cx="244" cy="34" r="9" fill="#38a169" opacity=".8"/><path d="M0 112 Q80 90 160 110 T320 104 V150 H0Z" fill="#8a8d93"/><path d="M0 128 Q90 112 170 128 T320 124 V150 H0Z" fill="#6c6f76"/>`;
    for(let i=0;i<7;i++){const x=R()*W,y=118+R()*26;s+=`<ellipse cx="${x}" cy="${y}" rx="${8+R()*14}" ry="${2+R()*3}" fill="#55585e"/>`;}
    return s+`<rect x="40" y="96" width="26" height="16" rx="8" fill="#e6edf3" opacity=".9"/><rect x="60" y="102" width="30" height="9" rx="3" fill="#9fb3c8"/></svg>`;}
  const sky=oil?['#2c1f2b','#e07a3f']:gold?['#26324d','#f3c969']:['#1b2f52','#7fb4e5'];
  s+=`<defs><linearGradient id="sk${r.id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${sky[0]}"/><stop offset="1" stop-color="${sky[1]}"/></linearGradient></defs><rect width="${W}" height="${H}" fill="url(#sk${r.id})"/>`;
  s+=`<circle cx="${60+R()*200}" cy="${34+R()*22}" r="${14+R()*6}" fill="${gold?'#ffe08a':'#fff3c4'}" opacity=".9"/>`;
  for(let i=0;i<3;i++)s+=`<ellipse cx="${R()*W}" cy="${14+R()*40}" rx="${24+R()*28}" ry="${5+R()*4}" fill="#fff" opacity=".13"/>`;
  const range=(base,amp,fill,n)=>{let d=`M0 ${H}`;let x=0;const st=W/n;for(let i=0;i<=n;i++){d+=` L${x.toFixed(1)} ${(base-R()*amp).toFixed(1)}`;x+=st;}return `<path d="${d} L${W} ${H}Z" fill="${fill}"/>`;};
  const mt=ore||gold?1:0.55;
  s+=range(96,58*mt+14,raShade(col,.38),9)+range(110,38*mt+10,raShade(col,.55),11);
  if(gold)for(let i=0;i<5;i++)s+=`<circle cx="${20+R()*280}" cy="${100+R()*20}" r="1.6" fill="#ffd34d"/>`;
  if(r.coast){s+=`<rect y="126" width="${W}" height="${H-126}" fill="#1c5d99"/>`;for(let i=0;i<9;i++)s+=`<path d="M${R()*W} ${130+R()*16} q6 -4 12 0" stroke="#9fd3ff" stroke-width="1" fill="none" opacity=".7"/>`;
    const bx=40+R()*220;s+=`<path d="M${bx} 128 h26 l-5 8 h-16z" fill="#f2f2f2"/><path d="M${bx+13} 128 v-14 l9 12z" fill="#fff"/>`;}
  else s+=`<path d="M0 124 Q80 112 160 124 T320 120 V150 H0Z" fill="${raShade(col,.7)}"/>`;
  if(oil)for(let i=0;i<2;i++){const x=40+R()*230;s+=`<path d="M${x} 126 l7 -26 l7 26z" fill="none" stroke="#1a1a1a" stroke-width="1.6"/><rect x="${x+3}" y="98" width="8" height="3" fill="#1a1a1a"/>`;}
  const n=Math.round(3+dev*1.6),bx0=r.coast?30:60;
  for(let i=0;i<n;i++){const w=8+R()*9,h=10+R()*(10+dev*5),x=bx0+i*((W-2*bx0)/n)+R()*4,y=124-h;s+=`<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" fill="#0d1520" opacity=".92"/>`;
    for(let j=0;j<h/6;j++)if(R()>.45)s+=`<rect x="${(x+2).toFixed(1)}" y="${(y+2+j*5.5).toFixed(1)}" width="2" height="2" fill="#ffd77a" opacity=".85"/>`;}
  s+=`<rect x="0" y="0" width="${W}" height="5" fill="${col}"/>`;
  return s+'</svg>';
}
async function raLoad(id){if(RA.img[id]!==undefined||RA.busy[id]||!MP.ok)return;RA.busy[id]=1;try{const v=await MP.fb('GET','regimg/'+id);RA.img[id]=(typeof v==='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(v))?v:null;}catch(e){RA.img[id]=null;}RA.busy[id]=0;if(UI.tab==='map'||UI.tab==='world'){S.dirty=true;}}
function raHero(r){const u=RA.img[r.id];if(u===undefined)raLoad(r.id);
  return `<div style="margin:6px 0">${u?`<img src="${u}" style="width:100%;border-radius:12px;display:block;max-height:200px;object-fit:cover" alt="${esc(r.n)}">`:regArt(r)}</div>`;}
function raResize(file,cb){const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,640/Math.max(im.width,im.height)),cv=document.createElement('canvas');cv.width=Math.round(im.width*k);cv.height=Math.round(im.height*k);cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);
  let q=0.65,u=cv.toDataURL('image/jpeg',q);while(u.length>120000&&q>0.3){q-=0.1;u=cv.toDataURL('image/jpeg',q);}cb(u.length<=140000?u:null);};im.onerror=()=>cb(null);im.src=fr.result;};fr.onerror=()=>cb(null);fr.readAsDataURL(file);}
document.addEventListener('change',e=>{const t=e.target;if(!t||t.id!=='raFile'||!t.files||!t.files[0])return;const id=+t.dataset.id;
  raResize(t.files[0],async u=>{if(!u)return msg('Görsel okunamadı.');try{await MP.fb('PUT','regimg/'+id,u);RA.img[id]=u;msg('🖼️ Bölge fotoğrafı yayınlandı.','ok');S.dirty=true;render();}catch(x){msg('Kaydedilemedi: '+String(x.message||x).slice(0,80));}});});
ACT.raDel=async d=>{try{await MP.fb('DELETE','regimg/'+d.id);}catch(e){}RA.img[+d.id]=null;S.dirty=true;};
{const _c=mxCityPage;mxCityPage=function(html,r){let h=_c.apply(this,arguments);try{
  const adm=isAdminUI(),ctl=adm?`<div class="btns" style="margin:0 0 6px"><label class="act sm" style="cursor:pointer;display:inline-block;padding:7px 10px;border:1px dashed var(--line2);border-radius:8px">🖼️ Fotoğraf yükle<input type="file" id="raFile" data-id="${r.id}" accept="image/*" style="display:none"></label>${RA.img[r.id]?btn('Fotoğrafı kaldır','data-a="raDel" data-id="'+r.id+'"','sm danger'):''}</div>`:'';
  h=h.replace('<div class="rr-hd">',raHero(r)+ctl+'<div class="rr-hd">');}catch(e){}return h;};}

/* ===== rr_flags.js ===== */
/* ===== 🏳️ Bayraklar (parti ve devlet) + "Hakkında" metinleri. Oyuncular kendi bayrağını tasarlar ya da küçük bir görsel yükler. ===== */
const FL={d:null,cur:null,back:'party'};
const FL_PAT=[['h','Yatay şerit'],['v','Dikey şerit'],['x','Haç'],['d','Çapraz'],['o','Daire'],['q','Dörtlü']];
const flHash=s=>{let h=7;for(const c of String(s))h=(h*31+c.charCodeAt(0))>>>0;return h;};
const flOk=c=>/^#[0-9a-f]{6}$/i.test(c||'');
function flDefault(name,col){const h=flHash(name),c0=flOk(col)?col:'#c0392b';return {t:'d',p:FL_PAT[h%FL_PAT.length][0],c:[c0,'#f5f5f5','#1d2733'],e:''};}
function flagSvg(f,w,h,round){
  w=w||60;h=h||40;f=f||{};
  if(f.t==='i'&&/^data:image\/(jpeg|png|webp);base64,/.test(f.u||''))return `<img src="${f.u}" width="${w}" height="${h}" style="object-fit:cover;border-radius:${round||4}px;border:1px solid var(--line2);flex:none" alt="">`;
  const c=(f.c||[]).map(x=>flOk(x)?x:'#888'),a=c[0]||'#c0392b',b=c[1]||'#f5f5f5',d=c[2]||'#1d2733';let g='';
  switch(f.p){
    case 'v':g=`<rect width="20" height="40" fill="${a}"/><rect x="20" width="20" height="40" fill="${b}"/><rect x="40" width="20" height="40" fill="${d}"/>`;break;
    case 'x':g=`<rect width="60" height="40" fill="${a}"/><rect x="16" width="9" height="40" fill="${b}"/><rect y="15.5" width="60" height="9" fill="${b}"/>`;break;
    case 'd':g=`<rect width="60" height="40" fill="${a}"/><polygon points="60,0 60,40 0,40" fill="${b}"/><polygon points="60,0 60,10 10,40 0,40 0,30 50,0" fill="${d}" opacity=".9"/>`;break;
    case 'o':g=`<rect width="60" height="40" fill="${a}"/><circle cx="30" cy="20" r="11" fill="${b}"/><circle cx="30" cy="20" r="5" fill="${d}"/>`;break;
    case 'q':g=`<rect width="60" height="40" fill="${a}"/><rect width="30" height="20" fill="${b}"/><rect x="30" y="20" width="30" height="20" fill="${b}"/>`;break;
    default:g=`<rect width="60" height="14" fill="${a}"/><rect y="13" width="60" height="14" fill="${b}"/><rect y="26" width="60" height="14" fill="${d}"/>`;}
  const em=f.e?`<text x="30" y="27.5" font-size="17" text-anchor="middle" style="paint-order:stroke" stroke="#0008" stroke-width=".6">${esc(String(f.e).slice(0,2))}</text>`:'';
  return `<svg width="${w}" height="${h}" viewBox="0 0 60 40" style="border-radius:${round||4}px;border:1px solid var(--line2);flex:none;display:block">${g}${em}</svg>`;
}
const flParty=pid=>{const p=(G3.party||{})[pid]||{};return p.flag||flDefault(p.n||pid,'#4aa3ff');};
const flState=s=>{const id=(((G3.gov||{})[s])||{}).ident||{};return id.flag||flDefault((S.states[s]||{}).n||s,SCOL[s]);};
const flAbout=(kind,id)=>kind==='party'?((G3.party||{})[id]||{}).about:((((G3.gov||{})[id])||{}).ident||{}).about;
const flCan=(kind,id)=>kind==='party'?(((G3.party||{})[id]||{}).o===g3uid()):(g3IsPres(id)||S.me.admin);
/* ---- editör sekmesi ---- */
ACT.flagEdit=d=>{FL.cur={k:d.k,id:d.id};const cur=d.k==='party'?flParty(d.id):flState(d.id);FL.d=JSON.parse(JSON.stringify(cur));if(!FL.d.c)FL.d.c=['#c0392b','#f5f5f5','#1d2733'];FL.back=UI.tab;
  const ab=flAbout(d.k,d.id)||'';FL.about=ab;UI.tab='flag';window.scrollTo(0,0);};
ACT.flagPat=d=>{FL.d={t:'d',p:d.p,c:(FL.d&&FL.d.c)||['#c0392b','#f5f5f5','#1d2733'],e:(FL.d&&FL.d.e)||''};};
ACT.flagInput=()=>{const el=id=>document.getElementById(id);if(!el('flc0'))return;const g=id=>(el(id)||{}).value;FL.d={t:'d',p:(FL.d&&FL.d.p)||'h',c:[g('flc0'),g('flc1'),g('flc2')].map(x=>flOk(x)?x:'#888888'),e:String(g('fle')||'').trim().slice(0,2)};FL.about=String(g('fla')||'').slice(0,300);S.dirty=true;};
ACT.flagSave=async()=>{
  if(!FL.cur)return;ACT.flagInput();const {k,id}=FL.cur;if(!MP.ok)return msg('Önce giriş yap.');if(!flCan(k,id))return msg('Bunu yalnızca parti başkanı / devlet başkanı yapabilir.');
  const about=String(FL.about||'').replace(/[<>]/g,'').trim().slice(0,300);
  try{
    if(k==='party'){await MP.fb('PATCH','party/'+id,{flag:FL.d,about:about});G3.party[id]=Object.assign(G3.party[id]||{},{flag:FL.d,about:about});}
    else{await MP.fb('PATCH','gov/'+id+'/ident',{flag:FL.d,about:about});const g=G3.gov[id]=G3.gov[id]||{};g.ident=Object.assign(g.ident||{},{flag:FL.d,about:about});}
    msg('🏳️ Kaydedildi.','ok');UI.tab=FL.back&&FL.back!=='flag'?FL.back:(k==='party'?'party':'state');S.dirty=true;
  }catch(e){msg(g3Err?g3Err(e):String(e.message||e));}
};
ACT.flagBack=()=>{UI.tab=FL.back&&FL.back!=='flag'?FL.back:'party';};
ACT.flagReset=()=>{if(!FL.cur)return;FL.d=flDefault(FL.cur.k==='party'?((G3.party[FL.cur.id]||{}).n||''):((S.states[FL.cur.id]||{}).n||''),SCOL[FL.cur.id]);S.dirty=true;};
function flResize(file,cb){const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const cv=document.createElement('canvas');cv.width=96;cv.height=64;const g=cv.getContext('2d');
  const k=Math.max(96/im.width,64/im.height),w=im.width*k,h=im.height*k;g.drawImage(im,(96-w)/2,(64-h)/2,w,h);
  let q=0.7,u=cv.toDataURL('image/jpeg',q);while(u.length>11000&&q>0.25){q-=0.1;u=cv.toDataURL('image/jpeg',q);}cb(u.length<=12000?u:null);};im.onerror=()=>cb(null);im.src=fr.result;};fr.onerror=()=>cb(null);fr.readAsDataURL(file);}
document.addEventListener('change',e=>{const t=e.target;if(!t||t.id!=='flFile'||!t.files||!t.files[0])return;
  flResize(t.files[0],u=>{if(!u)return msg('Görsel okunamadı ya da çok büyük.');FL.d={t:'i',u:u};S.dirty=true;render();});});
function tabFlag(){
  if(!FL.cur||!FL.d)return '<div class="panel"><p class="dim">Önce bir parti ya da devlet seç.</p></div>';
  const {k,id}=FL.cur,nm=k==='party'?((G3.party[id]||{}).n||'Parti'):((S.states[id]||{}).n||id),d=FL.d,c=d.c||['#c0392b','#f5f5f5','#1d2733'];
  return `<div class="panel"><h2>🏳️ ${esc(nm)} bayrağı</h2><div style="display:flex;justify-content:center;margin:8px 0">${flagSvg(d,180,120,8)}</div>
  ${d.t==='i'?'<p class="dim" style="text-align:center">Yüklediğin görsel kullanılıyor. Tasarımla değiştirmek için bir desen seç.</p>':''}
  <b>Desen</b><div class="btns" style="margin:4px 0 8px">${FL_PAT.map(p=>`<button class="${d.t!=='i'&&d.p===p[0]?'on':''} sm" data-a="flagPat" data-p="${p[0]}" style="padding:7px 10px;border-radius:8px;border:1px solid var(--line2);background:${d.t!=='i'&&d.p===p[0]?'var(--gold)':'var(--bg2)'};color:${d.t!=='i'&&d.p===p[0]?'#000':'var(--tx)'}">${p[1]}</button>`).join('')}</div>
  <b>Renkler ve amblem</b><div class="row" style="gap:8px;align-items:center;margin:6px 0"><input type="color" id="flc0" value="${c[0]}" data-chg="flagInput"><input type="color" id="flc1" value="${c[1]}" data-chg="flagInput"><input type="color" id="flc2" value="${c[2]}" data-chg="flagInput"><input id="fle" maxlength="2" value="${esc(d.e||'')}" placeholder="🦅" style="width:64px;text-align:center;font-size:20px" data-chg="flagInput"></div>
  <label class="act sm" style="cursor:pointer;display:inline-block;padding:7px 10px;border:1px dashed var(--line2);border-radius:8px">📷 Kendi görselini yükle<input type="file" id="flFile" accept="image/*" style="display:none"></label>
  <p class="dim" style="font-size:12px">Görsel küçültülür (96×64). Uygunsuz görseller yönetici tarafından kaldırılır.</p>
  <b>Hakkında</b><textarea id="fla" rows="3" maxlength="300" placeholder="${k==='party'?'Partinin amacı, ilkeleri, kimleri aradığı…':'Devletin kısa tanıtımı…'}" style="width:100%;margin-top:4px" data-chg="flagInput">${esc(FL.about||'')}</textarea>
  <div class="btns" style="margin-top:8px">${btn('💾 Kaydet','data-a="flagSave"','gold')}${btn('↺ Varsayılan','data-a="flagReset"','sm')}${btn('← Geri','data-a="flagBack"','sm')}</div></div>`;
}
TABX.flag=tabFlag;
/* ---- partiler: bayrak + hakkında ---- */
const flAboutHtml=(kind,id)=>{const a=flAbout(kind,id);return a?`<p style="margin:4px 0;font-size:13px">${esc(a)}</p>`:'';};
{const _g=g3PartyHtml;g3PartyHtml=function(){let h=_g.apply(this,arguments);try{
  const mine=g3PMine();
  if(mine){const fl=`<div style="display:flex;gap:10px;align-items:center;margin:4px 0">${flagSvg(flParty(mine.id),72,48,6)}<div style="flex:1;min-width:0"><b>Hakkında</b>${flAbout('party',mine.id)?flAboutHtml('party',mine.id):'<p class="dim" style="margin:4px 0;font-size:13px">Henüz bir tanıtım yazısı yok.</p>'}${flCan('party',mine.id)?btn('✏️ Bayrak ve hakkında','data-a="flagEdit" data-k="party" data-id="'+mine.id+'"','sm blue'):''}</div></div>`;
    h=h.replace('<h2>🎗️ '+esc(mine.n)+'</h2>','<h2>🎗️ '+esc(mine.n)+'</h2>'+fl);}
  Object.keys(G3.party||{}).forEach(id=>{const p=G3.party[id];if(mine&&id===mine.id)return;
    const key=`<p>👑 ${esc(p.on||'—')} · 👥 ${g3PMembers(Object.assign({id:id},p)).length} üye</p>`;
    h=h.replace(key,`<div style="display:flex;gap:8px;align-items:center">${flagSvg(flParty(id),54,36,5)}<div style="flex:1;min-width:0">${key}</div></div>${flAboutHtml('party',id)}`);});
  }catch(e){}return h;};}
/* ---- devlet sayfası: bayrak + hakkında ---- */
{const _s=pgState;pgState=function(k){let h=_s.apply(this,arguments);try{
  h=h.replace(/<div class="rr-em"[^>]*>[^<]*<\/div>/,flagSvg(flState(k),64,43,6));
  const ab=flAbout('state',k),can=flCan('state',k);
  const blk=`${ab?`<div class="card" style="margin:6px 0"><b>ℹ️ Hakkında</b><p style="margin:4px 0">${esc(ab)}</p></div>`:''}${can?`<div class="btns" style="margin:4px 0">${btn('🏳️ Bayrak ve hakkında','data-a="flagEdit" data-k="state" data-id="'+k+'"','sm blue')}</div>`:''}`;
  h=h.replace('<div class="rr-tiles">',blk+'<div class="rr-tiles">');}catch(e){}return h;};}

/* ===== rr_advisor.js ===== */
/* ===== 🧠 DANIŞMAN: anahtarsız "Komuta Masası". Oyun durumunu tarar, öncelik sırasıyla yapılacakları gösterir (Ana Sayfa'nın tepesinde).
   Vekil ile ORTAK MASA: danışman öneri üretir, Vekil (izin verdiğin alanlarda) bu önerilere bakar; ikisi ayrı kalır, fikir alışverişi yapar. ===== */
const ADV={list:[]};
const advKeep=()=>Object.assign({min:{gold:5,oil:30,ore:30},hi:0.7},(typeof vkCfg==='function'&&vkCfg().keep)||{});
function advRules(){
  const m=S.me,L=[];if(!m||!m.stor)return L;
  const P=(pri,ic,t,why,a,lab,vk)=>L.push({pri:pri,ic:ic,t:t,why:why||'',a:a,lab:lab||'Git',vk:vk||null});
  const tabA=k=>`data-a="tab" data-t="${k}"`,K=advKeep(),cap=(typeof storCap==='function')?storCap():100,ec=energyCost();
  try{const si=streakInfo();if(si.can)P(5,'🎁','Günlük ödülün hazır',si.n+'. gün — seriyi bozma','data-a="tab" data-t="quest"','Görevlere git');}catch(e){}
  try{if(m.energy>=ec*3&&!m.travel)P(m.energy>=95?5:3,'⚡','Enerjin '+Math.round(m.energy)+' — çalışma zamanı','Boşa taşan enerji kayıptır',tabA('work'),'Çalış',{k:'work',a:{r:'gold',n:'all'},dom:'eco'});}catch(e){}
  ['gold','oil','ore'].forEach(r=>{const have=m.stor[r]||0,mn=K.min[r]||0;
    if(have<mn)P(have<=0?5:4,'📦',({gold:'Altın',oil:'Petrol',ore:'Maden'})[r]+' deposu '+(have<=0?'boş':'azalıyor')+' ('+Math.floor(have)+'/'+mn+')','Üretim ya da alımla doldur',tabA('work'),'Çalış',{k:'work',a:{r:r,n:'all'},dom:'eco'});
    else if(have>cap*K.hi&&(S.prices[r]||0)>=PRICE0[r]*0.9)P(3,'💰',({gold:'Altın',oil:'Petrol',ore:'Maden'})[r]+' deposu dolmak üzere','Fiyat iyi: fazlayı sat',tabA('store'),'Sat',{k:'sell',a:{r:r,n:Math.floor(have-cap*0.5),min:Math.floor(PRICE0[r]*0.9)},dom:'eco'});});
  try{if(!(m.craftQ||[]).length)P(3,'🔧','Üretim hattın boş','Bekleyen işin yok',tabA('craft'),'Üret');}catch(e){}
  try{const fs=m.facs||[];if(fs.some(f=>f.stock>=1))P(2,'🏭','Fabrikalarda toplanmayı bekleyen stok var','',`data-a="advCollect"`,'Topla',{k:'facCollect',a:{},dom:'fac'});
    if(typeof facNeed==='function'&&fs.some(f=>(f.xp||0)>=facNeed(f.level)))P(3,'⬆️','Bir fabrikanın deneyimi doldu','Altınla yükseltebilirsin',tabA('fac'),'Yükselt');}catch(e){}
  try{if(!m.learn)P(2,'📚','Öğrenme boşta','Kuvvet/eğitim/dayanıklılık eğitimi başlat',tabA('char'),'Başlat');}catch(e){}
  try{const w=(S.wars||[]).find(w=>w.state==='on'&&(w.att==='A'||w.def==='A'));if(w)P(5,'⚔️','Savaş sürüyor: '+(S.regions[w.region]||{}).n,'Vuruşların devletine yarar',tabA('war'),'Vur');}catch(e){}
  try{const E=elOf(elState()),me=elMeId();if(E.phase==='vote'&&!((E.votes||{})[me]))P(4,'🗳️','Seçimde oy vermedin','Bitişe '+Math.round((+E.end-Date.now())/60000)+' dk',tabA('elect'),'Oy ver');}catch(e){}
  try{const qb=questBadge();if(qb>0)P(3,'📋',qb+' görev ödülü bekliyor','',tabA('quest'),'Al');}catch(e){}
  try{if(typeof evtOpenCount==='function'&&evtOpenCount()>0)P(4,'🏆','Aktif etkinlik var','Ödüller için puan topla',tabA('evt'),'Etkinlik');}catch(e){}
  try{if(typeof VK!=='undefined'){const pend=Object.values(VK.ord||{}).filter(o=>o&&o.st==='pending').length;if(pend)P(4,'🤖','Vekil '+pend+' öneri için onayını bekliyor','',tabA('vekil'),'Bak');}}catch(e){}
  try{const left=(+S.protectUntil||0)-S.t;if(left>0&&left<3600e3)P(2,'🛡️','Korunman 1 saatten kısa sürede bitiyor','',tabA('war'),'Bak');}catch(e){}
  L.sort((a,b)=>b.pri-a.pri);ADV.list=L;return L;
}
ACT.advCollect=()=>{(S.me.facs||[]).forEach(f=>{if(f.stock>=1)ACT.facCollect({id:f.id});});};
ACT.advVk=async d=>{const it=ADV.list[+d.i];if(!it||!it.vk)return;
  if(typeof vkCfg!=='function'||!vkCfg().on)return msg('Vekil kapalı: Vekil sekmesinden açabilirsin.');
  const o=Object.assign({t:Date.now()},it.vk);await vkRunOne('adv'+Date.now(),o);const l=VK.log[0];msg(l?(l.ok?'🤖 Vekil: ':'🤖 Vekil yapamadı: ')+l.x:'Vekil çalıştı.',l&&l.ok?'ok':'warn');S.dirty=true;};
function advRow(it,i,vk){return `<div class="card" style="padding:9px 10px;border-left:4px solid ${it.pri>=5?'var(--red,#e5534b)':it.pri>=4?'var(--gold)':'var(--line2)'}"><div class="row" style="align-items:center;gap:8px"><span style="font-size:22px">${it.ic}</span><div style="flex:1;min-width:0"><b style="font-size:14px">${esc(it.t)}</b>${it.why?`<div class="dim" style="font-size:12px">${esc(it.why)}</div>`:''}</div>${btn(it.lab,it.a,'sm gold')}${vk&&it.vk?btn('🤖','data-a="advVk" data-i="'+i+'"','sm blue'):''}</div></div>`;}
function advHome(){const L=advRules();if(!L.length)return `<div class="panel"><div class="card glow"><b>🧠 Danışman</b><p class="dim" style="margin:4px 0 0">Şu an acil bir iş yok, her şey yolunda. 👍</p></div></div>`;
  const top=L.slice(0,3);
  return `<div class="panel"><div class="row" style="align-items:center"><b style="flex:1">🧠 Danışman · ${L.length} öneri</b>${btn('Tümü','data-a="tab" data-t="ai"','sm')}</div>${top.map((it,i)=>advRow(it,i,false)).join('')}</div>`;}
function advPanel(){const L=advRules(),c=(typeof vkCfg==='function')?vkCfg():{on:0},sv=(typeof VK!=='undefined'&&VK.sv)||{},lg=(typeof VK!=='undefined'?VK.log:[]).slice(0,3);
  return `<div class="panel"><h2>🧠 Komuta Masası</h2><p class="hint">Danışman oyunu senin için tarar ve öncelik sırasına dizer. 🤖 düğmesi, işi <b>Vekil'e devreder</b> (Vekil açıksa ve o alana izin verdiysen). Danışman fikir verir, Vekil uygular; ikisi ortak masada konuşur.</p>
  ${L.length?L.map((it,i)=>advRow(it,i,true)).join(''):'<div class="al ok">Şu an yapılacak acil bir iş yok. 👍</div>'}
  <div class="card" style="margin-top:8px"><b>🤝 Ortak masa — Vekil</b><p class="dim" style="margin:3px 0">${c.on?'🟢 Vekil açık':'⚪ Vekil kapalı'}${sv.note?' · son kararı: “'+esc(sv.note)+'”':''}</p>${lg.length?lg.map(l=>`<p style="margin:2px 0;font-size:13px">${l.ok?'✅':'⚠️'} ${esc(l.x||l.k)}</p>`).join(''):'<p class="dim" style="margin:2px 0">Vekil henüz bir şey yapmadı.</p>'}<div class="btns">${btn('🤖 Vekil ayarları','data-a="tab" data-t="vekil"','sm')}</div></div></div>`;}
{const _t=tabAI;tabAI=function(){return advPanel()+'<h3 style="margin:14px 2px 6px">💬 Danışmana sor (isteğe bağlı, kendi API anahtarınla)</h3>'+_t.apply(this,arguments).replace('<h2>🧠 Danışman</h2>','');};}
{const _h=tabHome;tabHome=function(){let h=_h.apply(this,arguments);try{return advHome()+h;}catch(e){return h;}};}
/* Vekil'in durumuna danışmanın masası eklenir: sunucudaki karar verici bunları görür */
if(typeof vkSnap==='function'){const _s=vkSnap;vkSnap=function(){const o=_s.apply(this,arguments);try{o.masa=advRules().slice(0,6).map(x=>x.t);}catch(e){}return o;};}
TABX.ai=tabAI;

/* ===== rr_keep.js ===== */
/* ===== 🤖 Vekil: DEPO ve ÜRETİM BAKIMI. Depo ve üretim hatları boş kalmasın; fazlalık satılsın.
   Yalnızca Vekil açıkken ve "Ekonomi" alanı OTONOM ise çalışır; harcamalar Vekil'in günlük sınırına tabidir. ===== */
const VKK={t:0,busy:0,last:''};
const vkKeepCfg=()=>{const c=vkCfg();if(!c.keep)c.keep={on:1,min:{gold:5,oil:30,ore:30},hi:0.7};if(c.keep.on===undefined)c.keep.on=1;return c.keep;};
async function vkKeepRun(force){
  if(VKK.busy)return;const c=vkCfg(),K=vkKeepCfg();
  if(!c.on||c.modes.eco!=='auto'||!K.on)return;if(VK.kill&&(VK.kill.all||VK.kill.ai))return;
  if(!force&&Date.now()-VKK.t<60e3)return;VKK.t=Date.now();VKK.busy=1;
  const done=[],m=S.me,cap=storCap();
  const step=async(name,fn)=>{try{const r=await fn();if(r)done.push(r);}catch(e){}};
  try{
    // 1) fabrika stoklarını depoya al
    if((m.facs||[]).some(f=>f.stock>=1))await step('fac',()=>VK_X.facCollect());
    // 2) enerji varsa çalış: önce en boş depoyu doldur, yoksa en kârlı kaynağa
    if(!m.travel&&m.energy>=energyCost()){
      const need=['gold','oil','ore'].map(r=>[r,(K.min[r]||0)-(m.stor[r]||0)]).sort((a,b)=>b[1]-a[1]);
      const r=need[0][1]>0?need[0][0]:'gold';
      await step('work',()=>VK_X.work({r:r,n:'all'}));
    }
    // 3) fazla stoğu sat (depo %70'i aşarsa %50'ye kadar); fiyat çok düşükse satma
    for(const r of ['gold','oil','ore']){const have=m.stor[r]||0;
      if(have>cap*K.hi&&(S.prices[r]||0)>=PRICE0[r]*0.9){await step('sell',()=>VK_X.sell({r:r,n:Math.floor(have-cap*0.5),min:Math.floor(PRICE0[r]*0.9)}));}}
    // 4) üretim hattı boşsa üret (bütçe sınırlı)
    if(!(m.craftQ||[]).length){const cand=(vkSnap().uretilebilir||[]).filter(x=>x.para>0).sort((a,b)=>b.para-a.para)[0];
      if(cand)await step('craft',()=>VK_X.craft({k:cand.k,n:1}));}
    // 5) depo hâlâ asgarinin altındaysa ve enerji yoksa pazardan tamamla (fiyat makulse)
    for(const r of ['gold','oil','ore']){const lack=(K.min[r]||0)-(m.stor[r]||0);
      if(lack>0&&m.energy<energyCost()&&(S.prices[r]||0)<=PRICE0[r]*1.3){await step('buy',()=>VK_X.buy({r:r,n:Math.ceil(lack),max:Math.ceil(S.prices[r]*1.2)}));}}
  }finally{VKK.busy=0;}
  if(done.length){VKK.last=done.join(' · ');const id='k'+Date.now();
    VK.log.unshift({id:id,t:Date.now(),by:'cli',k:'keep',ok:1,x:'🧰 Bakım: '+VKK.last});VK.log=VK.log.slice(0,60);S.dirty=true;try{render();}catch(e){}}
}
setInterval(()=>{try{if(!document.hidden)vkKeepRun(false);}catch(e){}},30000);
setTimeout(()=>{try{vkKeepRun(true);}catch(e){}},9000);
ACT.vkKeepOn=()=>{const K=vkKeepCfg();K.on=K.on?0:1;vkSaveCfg();S.dirty=true;};
ACT.vkKeepMin=d=>{const K=vkKeepCfg();K.min[d.r]=Math.max(0,+d.v);vkSaveCfg();S.dirty=true;};
ACT.vkKeepNow=()=>{vkKeepRun(true);msg('Bakım çalıştı.','ok');};
{const _t=tabVekil;tabVekil=function(){let h=_t.apply(this,arguments);const K=vkKeepCfg(),c=vkCfg(),act=c.on&&c.modes.eco==='auto';
  const mins=['gold','oil','ore'].map(r=>`<div class="row" style="align-items:center;gap:6px;margin:4px 0"><span style="width:70px">${({gold:'🥇 Altın',oil:'🛢️ Petrol',ore:'⛏️ Maden'})[r]}</span>${[0,5,30,100,300].map(v=>`<button class="${(K.min[r]||0)===v?'on':''} sm" data-a="vkKeepMin" data-r="${r}" data-v="${v}" style="padding:5px 9px;border-radius:8px;border:1px solid var(--line2);background:${(K.min[r]||0)===v?'var(--gold)':'var(--bg2)'};color:${(K.min[r]||0)===v?'#000':'var(--tx)'}">${v}</button>`).join('')}</div>`).join('');
  const card=`<div class="card glow" style="margin-top:10px"><b>🧰 Depo ve üretim bakımı</b> ${K.on?'<span class="ok">açık</span>':'<span class="dim">kapalı</span>'}
  <p class="dim" style="margin:4px 0">Vekil depoyu ve üretim hatlarını boş bırakmaz: fabrika stoklarını toplar, enerjin varsa çalışır, depo %70'i aşınca fazlayı satar, üretim hattı boşsa üretim başlatır. ${act?'':'<b>Çalışması için Vekil açık ve Ekonomi alanı "Otonom" olmalı.</b>'}</p>
  <p class="dim" style="margin:6px 0 0">Depoda en az tutulacak miktar:</p>${mins}
  <div class="btns">${btn(K.on?'⏸ Bakımı kapat':'▶ Bakımı aç','data-a="vkKeepOn"',K.on?'danger sm':'gold sm')}${btn('Şimdi çalıştır','data-a="vkKeepNow"','sm')}</div>${VKK.last?`<p class="dim" style="margin:6px 0 0">Son bakım: ${esc(VKK.last)}</p>`:''}</div>`;
  return h.replace('<h3 style="margin:14px 2px 6px">🎚️ Yetki alanları</h3>',card+'<h3 style="margin:14px 2px 6px">🎚️ Yetki alanları</h3>');};}
TABX.vekil=tabVekil;

/* ===== rr_parl.js ===== */
/* ===== 🏛️ Meclis: her koltuk etkileşimli. Koltuklar parti renklerine göre boyanır; dokununca milletvekilinin kim olduğu görünür. ===== */
const PARL={sel:null};
function parlLayout(){const a=A();if(!a.parlSize)return null;const st=seatsOf(),N=a.parlSize,rows=4,rad=[],seats=[];let tot=0;
  const ps=a.parties.slice().sort((x,y)=>(st[y.id]||0)-(st[x.id]||0)).filter(p=>(st[p.id]||0)>0);
  for(let r=0;r<rows;r++)rad.push(70+r*26);const sum=rad.reduce((x,y)=>x+y,0);
  rad.forEach((R,r)=>{const n=r===rows-1?N-tot:Math.round(N*R/sum);tot+=n;for(let k=0;k<n;k++){const an=Math.PI*(n===1?.5:k/(n-1));seats.push({a:an,x:150-R*Math.cos(an),y:130-R*Math.sin(an)});}});
  seats.sort((p,q)=>p.a-q.a);
  const roster=g3Roster(),byP={};roster.forEach(x=>{(byP[x.p]=byP[x.p]||[]).push(x);});
  const cols={};let i=0;
  ps.forEach((p,pi)=>{const c=p.id==='me'?'#58a6ff':PCOL2[pi%PCOL2.length];cols[p.id]=c;const L=byP[p.id]||[];
    for(let k=0;k<st[p.id]&&i<seats.length;k++,i++){const m=L[k]||null;seats[i].p=p;seats[i].c=c;seats[i].m=m;}});
  return {seats:seats,ps:ps,st:st,cols:cols,N:N};
}
ACT.parlSeat=d=>{PARL.sel=(PARL.sel===+d.i)?null:+d.i;};
function parlInfo(L){const s=L.seats[PARL.sel];if(!s)return `<p class="dim" style="font-size:12px;margin:6px 0 0">Bir koltuğa dokun: milletvekilini göreceksin.</p>`;
  if(!s.p)return `<div class="card" style="margin:8px 0 0"><b>Boş koltuk</b><p class="dim" style="margin:3px 0 0">Bu sandalyenin sahibi yok.</p></div>`;
  const m=s.m,me=m&&m.id&&m.id===g3uid(),sp=s.p.id==='me'?S.me.spid:s.p.id,fl=(typeof flagSvg==='function'&&sp&&G3.party[sp])?flagSvg(flParty(sp),44,29,4):'';
  return `<div class="card glow" style="margin:8px 0 0"><div class="row" style="align-items:center;gap:10px"><span style="width:14px;height:14px;border-radius:50%;background:${s.c};flex:none"></span><div style="flex:1;min-width:0"><b style="font-size:15px">${m?esc(m.n):'Milletvekili'}${me?' <span class="owner">sen</span>':''}</b><div class="dim" style="font-size:12px">${esc(s.p.n)} · ${m&&m.real?'🧑 gerçek oyuncu':'🤖 yapay zekâ milletvekili'} · koltuk #${PARL.sel+1}</div></div>${fl}</div>
   <p style="margin:6px 0 0;font-size:13px">Maaş: ${fmt(g3Sal(g3St(),'mp'))}₺/gün${typeof flAbout==='function'&&sp&&flAbout('party',sp)?' · “'+esc(flAbout('party',sp))+'”':''}</p>
   ${m&&m.real&&m.id&&!me?`<div class="btns" style="margin-top:6px">${typeof eLink==='function'?'':''}${btn('👤 Profili aç',`data-a="ent" data-k="player" data-id="${esc(m.id)}"`,'sm blue')}</div>`:''}</div>`;}
hemiCard2=function(){const L=parlLayout();if(!L)return '';
  const svg=L.seats.map((q,j)=>`<circle data-a="parlSeat" data-i="${j}" cx="${q.x.toFixed(1)}" cy="${q.y.toFixed(1)}" r="${(L.N>100?3.6:4.8)+(PARL.sel===j?1.6:0)}" fill="${q.c||'#30363d'}" stroke="${PARL.sel===j?'#fff':(q.m&&q.m.id&&q.m.id===g3uid()?'#f0c040':'none')}" stroke-width="${PARL.sel===j?1.6:1.2}" style="cursor:pointer"/>`).join('');
  return `<div class="card"><h3>Meclis dağılımı</h3><svg viewBox="0 0 300 140" style="width:100%;height:auto;touch-action:manipulation">${svg}</svg>
   <p class="dim" style="font-size:12px;margin:4px 0">${L.ps.map(p=>`<span style="color:${L.cols[p.id]}">●</span> ${esc(p.n)} ${L.st[p.id]}`).join(' · ')}</p>${parlInfo(L)}</div>`;};

/* ===== rr_dedupe.js ===== */
/* ================= TEK EV KURALI =================
   Her özellik yalnızca bir yerde yaşar; başka yerler ona yönlendirir.
   - Kontrol (ctl)  → Ekonomi › Otomatik
   - Etkinlik (etk) → Ana Sayfa › Görevler (aynı sayfa)
   - Danışman/Vekil (ai/vekil) → Profil › Yardımcılar
   - İstatistik     → Profil (üst çubuktaki 📊 ile açılır), Devlet sekmesinden çıktı
   - Yapay zekâ oyuncu sayısı → yalnızca Yönetim › Yapay Zekâ
   - Profil üst çubuğundaki ✉ ve ⚙ kalktı (aynı şeyler sayfadaki kartlarda)
   - Ana Sayfa'daki ikinci kutu kümesi (Devlet ve diğerleri) kalktı; tek kısayol şeridi kaldı */
(function(){
  /* 1) Menü yerleşimi */
  try{
    const home=GROUPS.find(g=>g[0]==='home'),gov=GROUPS.find(g=>g[0]==='gov'),prof=GROUPS.find(g=>g[0]==='prof');
    if(home)home[2]=home[2].filter(t=>t[0]!=='etk');
    if(gov)gov[2]=gov[2].filter(t=>t[0]!=='stats');
    if(prof&&!prof[2].some(t=>t[0]==='stats'))prof[2].push(['stats','İstatistik','hid']);
    if(prof)['ai','vekil'].forEach(k=>{if(!prof[2].some(t=>t[0]===k))prof[2].push([k,k==='ai'?'Danışman':'Vekil','hid']);});
  }catch(e){console.warn('dedupe groups',e);}

  /* 2) Eski adresler yeni yere yönlendirilir */
  {const _r=render;render=function(){
    const R={ctl:'auto',etk:'quest'};
    if(R[UI.tab])UI.tab=R[UI.tab];
    else if(UI.tab==='ai'||UI.tab==='vekil'){UI.helpSub=UI.tab;UI.tab='help';}
    return _r.apply(this,arguments);
  };}

  /* 3) Görevler sayfası: Etkinlik içinde (tek sayfa) */
  {const _q=tabQuest;tabQuest=function(){
    let h=_q.apply(this,arguments),ev='';
    try{ev=tabEtk();}catch(e){console.warn('etk in quest',e);}
    const mark='<div class="panel"><h2>📋 Bugünün görevleri</h2>',i=h.indexOf(mark);
    ev=ev.replace('📅 Günün görevleri','📅 Etkinlik günlük görevleri');
    h=i>=0?h.slice(0,i)+ev+h.replace(mark,'<div class="panel"><h2>📋 Günlük görevler</h2>').slice(i):h+ev;
    return h;
  };TABX.quest=tabQuest;}
  {const _qb=questBadge;questBadge=function(){let n=_qb.apply(this,arguments)||0;try{n+=evnOpenCount()||0;}catch(e){}return n;};}

  /* 4) Yönetici paneli: yapay zekâ oyuncu kartı yalnız Yapay Zekâ sayfasında */
  {const _a=tabAdm;tabAdm=function(){
    let h=_a.apply(this,arguments);
    h=h.replace(/<div class="card [^"]*"><h3>🤖 Yapay zekâ oyuncular<\/h3>[^]*?<\/div>\s*(?=<div class="card )/,
      `<div class="card"><h3>🤖 Yapay zekâ oyuncular</h3><p class="dim">Sayı, sunucu ve ekleme geçmişi tek yerde.</p><div class="btns">${btn('Yapay Zekâ sayfasına git','data-a="tab" data-t="bots"','sm gold')}</div></div>`);
    return h;
  };TABX.adm=tabAdm;}

  /* 5) Üst çubuk: Profil'de ✉ ve ⚙ kalkar (kartlar zaten sayfada) */
  {const _b=rrBarHtml;rrBarHtml=function(){
    return _b.apply(this,arguments)
      .replace('<button class="rb-b" data-a="tab" data-t="msg" aria-label="Mesajlar">✉</button>','<button class="rb-b" data-a="rrSearch" aria-label="Ara">🔍</button>')
      .replace('<button class="rb-b" data-a="tab" data-t="set" aria-label="Ayarlar">⚙</button>','');
  };}

  /* 6) Ana Sayfa: ikinci kutu kümesi kalktı */
  {rrTiles=function(){return '';};}

  /* 7) Bağış: tek sayfa (Ekonomi › Bağış). Devlet sayfasındaki form oraya yönlendirir */
  ACT.giveTo=d=>{if(d&&d.k)UI.dnTo=d.k;UI.tab='give';};
  {const _pg=pgState;pgState=function(){
    let h=_pg.apply(this,arguments);
    return h.replace(/(<details class="rr-acc" data-ak="give"[^>]*><summary>[^<]*<\/summary><div class="rr-accb">)([^]*?)(<\/div><\/details>)/,(all,a,body,z)=>{
      const k=(body.match(/id="dnTo" value="([^"]*)"/)||[])[1]||'A';
      return a+'<p class="hint">Bağış tek yerde: Ekonomi › Bağış. Buradan açarsan hedef olarak bu devlet seçili gelir.</p><div class="btns">'+btn('🎁 Bağış sayfasını aç','data-a="giveTo" data-k="'+k+'"','gold sm')+'</div>'+z;});
  };}

  /* 8) Harita: Diplomasi ve Bölge uzmanlığı yalnız Devlet sayfasında */
  {const _m=tabMap;tabMap=function(){
    let h=_m.apply(this,arguments),cut=false;
    ['🤝 Diplomasi','📍 Bölge uzmanlığı'].forEach(t=>{
      const a=h.indexOf('<div class="panel"><h2>'+t+'</h2>');if(a<0)return;
      const b=h.indexOf('<div class="panel">',a+10);h=h.slice(0,a)+(b<0?'':h.slice(b));cut=true;});
    if(cut)h+='<div class="panel"><h2>🤝 Diplomasi ve bölge uzmanlığı</h2><p class="hint">Hediye, anlaşma ve bölge uzmanlığı tek yerde: Devlet sayfası.</p><div class="btns">'+btn('🏛️ Devlet sayfasını aç','data-a="tab" data-t="state"','gold sm')+'</div></div>';
    return h;};}
})();

/* ===== rr_tidy.js ===== */
/* ===== rr_tidy.js — TOPLAMA: açılır-kapanır bölümler + "Ne nerede?" haritası =====
   1) Uzun sayfalardaki her bölüm (başlığına dokununca) açılır/kapanır; seçimin hatırlanır.
      Uzun sayfalarda (Otomatik, Ayarlar, Yönetim…) ilk bölüm dışındakiler kapalı başlar.
   2) Rehber'in en üstünde "Ne nerede?" listesi: her sekme ne işe yarar, dokununca oraya gider. */
(function(){
  const st=document.createElement('style');
  st.textContent='.fold-h{cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:8px}.fold-h::after{content:"▾";font-size:13px;opacity:.7}.fold-h.shut::after{content:"▸"}.fold-h.shut{margin-bottom:0}';
  document.head.appendChild(st);
  const LONG={auto:1,set:1,adm:1,bots:1,guard:1,ops:1};
  function tidyFold(){
    const m=document.getElementById('main');if(!m)return;
    const tab=UI.tab;UI.fold=UI.fold||{};
    [...m.children].filter(p=>p.classList&&p.classList.contains('panel')).forEach((p,i)=>{
      const h=p.firstElementChild;if(!h||h.tagName!=='H2'||p.dataset.fold)return;
      const title=h.textContent.trim();if(!title||p.textContent.length<350)return;
      p.dataset.fold='1';
      const key=tab+'|'+title,body=document.createElement('div');body.className='fold-body';
      while(h.nextSibling)body.appendChild(h.nextSibling);p.appendChild(body);
      const open=key in UI.fold?UI.fold[key]:!(LONG[tab]&&i>0);
      h.classList.add('fold-h');if(!open){h.classList.add('shut');body.style.display='none';}
      h.addEventListener('click',e=>{if(e.target.closest('button,a,input,select,textarea'))return;
        const o=body.style.display==='none';body.style.display=o?'':'none';h.classList.toggle('shut',!o);UI.fold[key]=o;});
    });
  }
  {const _r=render;render=function(){const x=_r.apply(this,arguments);try{tidyFold();}catch(e){console.warn('tidyFold',e);}return x;};}

  const MAP=[
   ['🏠 Ana Sayfa',[['home','Ana Sayfa','Bugün ne yapmalıyım, hızlı eylemler, bölgen ve kısayollar.'],['quest','Görevler','Günlük giriş ödülü, günlük/haftalık görevler, başarımlar ve etkinlikler.'],['log','Günlük','Son olan her şeyin kaydı.']]],
   ['🗺️ Harita',[['world','Harita','Dünya haritası: kim nereye hâkim; nüfus, altın, petrol, endeks gibi katmanlar.'],['map','Şehirler','Devletlere göre şehir listesi; şehir seç, bilgisini gör, geliştir.']]],
   ['⛏️ Ekonomi',[['work','Çalış','Enerji harcayıp altın, petrol, maden üret.'],['auto','Otomatik','Sen yokken çalışma/savaş ve diğer otomasyonlar (parayla alınır).'],['fac','Fabrika','Fabrikaların ve holdingin.'],['auc','Açık artırma','Fabrika vb. teklif usulü alım-satım (giriş gerekir).'],['store','Depo','Kaynakları al-sat, yatırımlar.'],['mkt','Pazar','Oyuncu pazarı: kendi fiyatına sat.'],['craft','Üretim','Ara mamul ve eşya üretim hatları.'],['bank','Banka','Mevduat ve kredi.'],['give','Bağış','Devlet bütçesine, şehre, cephanelik ve ara mamul bağışı.']]],
   ['🏛️ Devlet',[['state','Devlet','Bütçe, vergi, yasalar, devlet adı/rengi/bayrağı ve en altta SAVAŞ İLANI (önce devlet, sonra bölge seç).'],['party','Parti','Parti kur/katıl, kampanya yap.'],['elect','Seçim','Başkanlık seçimi (giriş gerekir).'],['leader','Başkan','Başkan paneli ve darbe (sadece başkan/yönetici).'],['cities','Vali','Yönettiğin şehirler (sadece vali/başkan).']]],
   ['⚔️ Savaş',[['war','Savaş','Devletinin savaşları: vur, eşya kullan; antrenman savaşı (risksiz).'],['sw','Ortak','Gerçek oyuncular arası: bölgeye vali ol, savaş aç (giriş gerekir).'],['spy','Casus','Diğer devletlerin gücünü öğren.'],['dip','Diplomasi','Devletlerle ilişki, hediye, pakt (giriş gerekir).']]],
   ['👥 Topluluk',[['art','Makaleler','Yazı yaz/oku, beğen, yorum yap.'],['paper','Gazete','Gazeteler ve dünya haberleri.'],['chat','Sohbet','Genel, parti ve özel mesaj.'],['ally','İttifak','İttifak kur/katıl.'],['lb','Sıralama','Seviye, servet, hasar sıralaması.']]],
   ['👤 Profil',[['char','Profil','Karakter, yetenekler, arkadaş daveti.'],['msg','Mesajlarım','Özel mesajlar ve parti sohbeti.'],['help','Yardımcılar','Vekil (sen yokken senin adına iş yapar) ve Danışman (öneri verir).'],['set','Ayarlar','Ses, titreşim, tema, yazı boyutu, bildirim, yedek, devlet temaları.'],['guide','Rehber','Bu sayfa.'],['net','Hesap','Giriş/kayıt ve bulut kaydı.']]],
   ['👑 Yönetim (yöneticiye)',[['yon','Yönetim','Yönetici araçlarının tek kapısı.'],['adm','Panel','Oyuncular, vergi, toplu hediye, duyuru, olay, sezon.'],['bots','Yapay Zekâ','Yapay zekâ oyuncular, sunucu modu.'],['guard','Güvenlik','Tarama, hile tespiti, ekonomi dengesi.'],['ops','Yönetim Merkezi','Acil durum, ekip, canlı ayarlar, denetim kaydı.'],['vcodes','Kodlar','E-posta doğrulama kodları.']]]];
  function mapPanel(){
    return '<div class="panel"><h2>🧭 Ne nerede?</h2><p class="hint">Her özelliğin tek bir evi var. Satıra dokununca oraya gidersin.</p>'+
      MAP.map(g=>`<details class="card"><summary><b>${g[0]}</b></summary><div style="margin-top:6px">${g[1].map(t=>`<div class="row" style="align-items:flex-start"><button class="act sm" data-a="tab" data-t="${t[0]}" style="min-width:96px">${t[1]}</button><span class="dim" style="flex:1">${t[2]}</span></div>`).join('')}</div></details>`).join('')+'</div>';
  }
  {const _g=tabGuide;tabGuide=function(){return mapPanel()+_g.apply(this,arguments);};if(typeof TABX!=='undefined'&&TABX.guide)TABX.guide=tabGuide;}
})();

/* ===== Giriş kapısı + e-posta doğrulama kodu, İngilizce, ek temalar, sabit yönetici düğmesi, kayan ana sayfa kutuları ===== */
const GT_K='rr-gate';
const gtGet=()=>{try{return localStorage.getItem(GT_K);}catch(e){return null;}};
const gtSet=v=>{try{localStorage.setItem(GT_K,v);}catch(e){}};
/* ---------- İngilizce (kelime listesi; çevrilmeyenler Türkçe kalır) ---------- */
const EN={'Ana Sayfa':'Home','Karakter':'Character','Çalış':'Work','Üretim':'Craft','Depo':'Storage','Depo/Pazar':'Storage/Market','Pazar':'Market','Bölgeler':'Regions','Harita':'Map','Şehirler':'Cities','Dünya':'World','Devlet':'State','Parti':'Party','Seçim':'Election','Savaş':'War','Gazete':'Gazette','Sohbet':'Chat','Ayarlar':'Settings','Rehber':'Guide','Hesap':'Account','Profil':'Profile','Mesajlar':'Messages','Bağış':'Donate','İstatistik':'Statistics','Görevler':'Quests','Fabrika':'Factory','Açık artırma':'Auction','Vekil':'Proxy','Danışman':'Advisor','Yönetici paneli':'Admin panel','Yapay zekâ':'AI','Güvenlik':'Security','Yönetim Merkezi':'Control center','Başkan':'President','Vali':'Governor','Diplomasi':'Diplomacy','İttifak':'Alliance','Ordu':'Army','Altın':'Gold','Petrol':'Oil','Maden':'Ore','Uranyum':'Uranium','Elmas':'Diamonds','Enerji':'Energy','Seviye':'Level','Para':'Money','Giriş yap':'Log in','Kayıt ol':'Sign up','Çıkış yap':'Log out','Şifre':'Password','Kullanıcı adı':'Username','E-posta':'E-mail','Doğrulama kodu':'Verification code','Doğrula':'Verify','Kod gönder':'Send code','Misafir olarak devam et':'Continue as guest','Günlük ödül':'Daily reward','Almaya hazır!':'Ready to claim!','Öğrenme':'Learning','Tema':'Theme','Koyu':'Dark','Açık':'Light','Dil':'Language','Sat':'Sell','Al':'Buy','Kaydet':'Save','İptal':'Cancel','Onayla':'Confirm','Reddet':'Reject','Teklif ver':'Place bid','Yükselt':'Upgrade','Depoya al':'Collect','Holdinge kat':'Join holding','Holding':'Holding','Bildirimler':'Notifications','Ara':'Search','Geri':'Back','Yardım':'Help','Menü':'Menu','Tüm ayrıntılar':'All details','Devlet ve diğerleri':'State & more','Çalışma':'Work','Yönetici':'Admin','Doğrulama kodları':'Verification codes','Ana sayfa':'Home','Sınır yok':'No limit','Vur':'Strike','Satın al':'Buy','Yenile':'Refresh','Sil':'Delete','Kapat':'Close','Evet':'Yes','Hayır':'No','Durdur':'Stop','Aç':'On','Kapalı':'Off','Öner':'Suggest','Otonom':'Autonomous','Yetki alanları':'Permissions','Talimatın':'Your instructions','Sınırlar':'Limits','Vekil günlüğü':'Proxy log','Onay bekleyenler':'Awaiting approval','Hepsini onayla':'Approve all','Hepsini reddet':'Reject all','İşçi deneyimi':'Worker experience','Deneyim dolmadı':'Experience not full'};
const ENK=Object.keys(EN).sort((a,b)=>b.length-a.length);
const isEN=()=>{try{return JSON.parse(localStorage.getItem('bm_prefs')||'{}').lang==='en';}catch(e){return false;}};
function gtTr(t){const s=t.trim();if(!s)return t;if(EN[s])return t.replace(s,EN[s]);
  let o=t,ch=0;for(const k of ENK){if(k.length>3&&o.indexOf(k)>=0){o=o.split(k).join(EN[k]);ch=1;}}return ch?o:t;}
function gtWalk(root){if(!root)return;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null);const L=[];let n;while((n=w.nextNode())){const p=n.parentNode;if(!p||/^(SCRIPT|STYLE|TEXTAREA|INPUT)$/.test(p.nodeName))continue;L.push(n);}
  L.forEach(n=>{const v=gtTr(n.nodeValue);if(v!==n.nodeValue)n.nodeValue=v;});}
function gtLangInit(){if(!isEN())return;document.documentElement.lang='en';let busy=0;
  const run=()=>{if(busy)return;busy=1;try{gtWalk(document.body);}finally{busy=0;}};
  new MutationObserver(()=>{setTimeout(run,0);}).observe(document.body,{childList:true,subtree:true,characterData:true});run();}
ACT.setLang=d=>{PREF.lang=d.l;prefSave();location.reload();};
/* ---------- ek temalar ---------- */
const GT_TH={ocean:'--bg0:#06121c;--bg1:#0b1d2b;--bg2:#10273a;--bg3:#173449;--bg4:#1d4059;--line:#1f3d55;--line2:#2d5675;--gold:#5cc8ff',
 forest:'--bg0:#07120b;--bg1:#0c1d12;--bg2:#12281a;--bg3:#193523;--bg4:#20432c;--line:#21402b;--line2:#32603f;--gold:#9be37a',
 royal:'--bg0:#0f0818;--bg1:#190d29;--bg2:#221238;--bg3:#2d1a4b;--bg4:#3a2360;--line:#3b2560;--line2:#563a8a;--gold:#f0c24b',
 desert:'--bg0:#1a1208;--bg1:#271b0d;--bg2:#33240f;--bg3:#42301a;--bg4:#533d22;--line:#554023;--line2:#7a5c33;--gold:#ffb347'};
{const _pa=prefApply;prefApply=function(){_pa.apply(this,arguments);const c=document.documentElement;Object.keys(GT_TH).forEach(k=>c.classList.toggle('th-'+k,PREF.theme===k));};}
{const _ts=tabSettings;tabSettings=function(){let h=_ts.apply(this,arguments);const b=(k,t)=>`<button class="${PREF.theme===k?'on':''}" data-a="gtTheme" data-k="${k}">${t}</button>`;
  const card=`<div class="card"><b>🎨 Daha fazla tema</b><div class="btns" style="margin-top:6px">${b('ocean','🌊 Okyanus')}${b('forest','🌲 Orman')}${b('royal','👑 Saray')}${b('desert','🏜️ Çöl')}</div></div><div class="card"><b>🌐 Dil / Language</b><div class="btns" style="margin-top:6px"><button class="${!isEN()?'on':''}" data-a="setLang" data-l="tr">Türkçe</button><button class="${isEN()?'on':''}" data-a="setLang" data-l="en">English</button></div><p class="dim" style="margin:4px 0 0">English: menus and common buttons are translated; some texts stay Turkish.</p></div>`;
  return h.replace(/<\/div>\s*$/,card+'</div>');};}
ACT.gtTheme=d=>{PREF.theme=d.k;prefSave();prefApply();S.dirty=true;render();};
{const st=document.createElement('style');st.textContent=Object.keys(GT_TH).map(k=>`html.th-${k}{${GT_TH[k]}}`).join('')+
`.gt-strip{display:flex;gap:8px;overflow-x:auto;padding:2px 2px 8px;margin:0 -2px;-webkit-overflow-scrolling:touch;scrollbar-width:none}.gt-strip::-webkit-scrollbar{display:none}
.gt-chip{flex:0 0 auto;min-width:76px;background:var(--bg2);border:1px solid var(--line);border-radius:12px;padding:8px 10px;text-align:center;color:var(--tx);font-family:inherit;cursor:pointer}.gt-chip span{display:block;font-size:22px}.gt-chip b{display:block;font-size:12px;margin-top:2px}.gt-chip small{display:block;font-size:10px;color:var(--tx2)}.gt-chip:active{transform:scale(.95)}
#gtgate{position:fixed;inset:0;z-index:99999;background:radial-gradient(circle at 50% 0,var(--bg3),var(--bg0) 70%);display:flex;align-items:center;justify-content:center;padding:16px;overflow:auto}
#gtgate .gb{width:100%;max-width:380px;background:var(--bg1);border:1px solid var(--line2);border-radius:16px;padding:20px;color:var(--tx)}#gtgate h1{margin:0 0 4px;font-size:22px;color:var(--gold)}#gtgate input{width:100%;box-sizing:border-box;margin:5px 0;padding:12px;border-radius:10px;border:1px solid var(--line2);background:var(--bg2);color:var(--tx);font-size:16px}
#gtgate button.g{width:100%;padding:12px;margin-top:8px;border-radius:10px;border:1px solid var(--line2);background:var(--bg2);color:var(--tx);font-size:15px;cursor:pointer}#gtgate button.p{background:var(--gold);color:#000;border-color:var(--gold);font-weight:700}#gtgate .er{color:#ff6b6b;font-size:13px;min-height:18px}#gtgate .tb{display:flex;gap:6px;margin:10px 0}#gtgate .tb button{flex:1;padding:9px;border-radius:9px;border:1px solid var(--line2);background:var(--bg2);color:var(--tx)}#gtgate .tb button.on{background:var(--gold);color:#000}`;document.head.appendChild(st);}
/* ---------- ana sayfa: dokununca sekmeye giden kayan kutular ---------- */
function gtStrip(){const m=S.me,T=[['char','👤','Karakter','sv. '+m.level],['work','⛏️','Çalış',Math.floor(m.energy)+' enerji'],['craft','🔧','Üretim',''],['fac','🏭','Fabrika',(m.facs||[]).length+' adet'],['auc','🔨','Açık artırma',''],['store','🏦','Depo',fmt(m.money)+'₺'],['war','⚔️','Savaş',''],['state','🏛️','Devlet',''],['party','🎗️','Parti',''],['elect','🗳️','Seçim',''],['world','🗺️','Harita',''],['paper','📰','Gazete',''],['quest','📋','Görevler',(typeof questBadge==='function'&&questBadge()>0)?questBadge()+' ödül':''],['help','🤖','Yardımcılar',(typeof advRules==='function')?advRules().length+' öneri':'']];
  return `<div class="gt-strip">${T.map(t=>`<button class="gt-chip" data-a="tab" data-t="${t[0]}"><span>${t[1]}</span><b>${t[2]}</b><small>${t[3]}</small></button>`).join('')}</div>`;}
{const _h=tabHome;tabHome=function(){let h=_h.apply(this,arguments);try{return gtStrip()+h;}catch(e){return h;}};}
/* ---------- sabit yönetici düğmesi (🔔 gibi) ---------- */
const GT_ADM=[['adm','👑','Yönetici paneli'],['vcodes','🔑','Doğrulama kodları'],['bots','🤖','Yapay zekâ'],['guard','🛡️','Güvenlik'],['ops','🏛️','Yönetim Merkezi'],['fac','🔨','Açık artırma (yönetici)']];
{const _b=rrBarHtml;rrBarHtml=function(){let h=_b.apply(this,arguments);if(!isAdminUI())return h;
  h=h.replace('<button class="rb-b" data-a="bell"','<button class="rb-b" data-a="gtAdm" aria-label="Yönetici">👑</button><button class="rb-b" data-a="bell"');
  if(UI.gtAdm)h+=`<div id="rrmenu">${GT_ADM.map(t=>`<button data-a="tab" data-t="${t[0]==='fac'?'auc':t[0]}">${t[1]} ${t[2]}</button>`).join('')}</div>`;return h;};}
ACT.gtAdm=()=>{UI.gtAdm=!UI.gtAdm;UI.rrMenu=false;S.dirty=true;render();};
{const _t=ACT.tab;ACT.tab=function(d){UI.gtAdm=false;return _t.apply(this,arguments);};}
/* ---------- doğrulama kodları (yönetici ekranı) ---------- */
const VC={list:null,err:''};
async function vcLoad(){try{VC.list=(await MP.fb('GET','verify'))||{};VC.err='';}catch(e){VC.err=String(e.message||e);VC.list={};}S.dirty=true;render();}
ACT.vcLoad=()=>vcLoad();
ACT.vcDel=async d=>{try{await MP.fb('DELETE','verify/'+d.id);}catch(e){}vcLoad();};
function tabVcodes(){
  if(!isAdminUI())return '<div class="panel"><div class="al warn">Bu ekran yalnızca yönetici hesabına açıktır.</div></div>';
  if(VC.list===null&&MP.ok)vcLoad();
  const L=VC.list||{},ids=Object.keys(L).sort((a,b)=>(+L[b].t||0)-(+L[a].t||0));
  return `<div class="panel"><h2>🔑 Doğrulama kodları</h2><p class="hint">Kayıt olan oyuncuların e-posta doğrulama kodları burada görünür. Oyuncuya kodu sen iletirsin (gerçek e-posta gönderimi yok). Doğrulananlar ✅ ile işaretlenir.</p>
  <div class="btns">${btn('🔄 Yenile','data-a="vcLoad"','sm')}</div>${VC.err?`<p class="bad">${esc(VC.err)}</p>`:''}
  ${ids.length?ids.map(id=>{const v=L[id];return `<div class="card"><b>${esc(v.n||'?')}</b> · ${esc(v.em||'')}<p style="margin:4px 0;font-size:22px;letter-spacing:4px;color:var(--gold)">${v.ok?'✅ doğrulandı':esc(String(v.code))}</p><p class="dim" style="margin:0">${fmtDur(Date.now()-(+v.t||Date.now()))} önce</p><div class="btns">${btn('Sil',`data-a="vcDel" data-id="${id}"`,'sm')}</div></div>`;}).join(''):'<p class="dim">Henüz kayıt yok.</p>'}</div>`;}
TABX.vcodes=tabVcodes;
{const G=GROUPS.find(g=>g[0]==='prof');if(G&&!G[2].some(t=>t[0]==='vcodes'))G[2].push(['vcodes','🔑 Kodlar','adm']);}
/* ---------- giriş kapısı ---------- */
const GT={mode:'login',step:'form',code:'',err:'',busy:0,em:''};
function gtClose(v){gtSet(v);const e=document.getElementById('gtgate');if(e)e.remove();try{S.dirty=true;render();}catch(x){}}
function gtDraw(){
  let g=document.getElementById('gtgate');if(!g){g=document.createElement('div');g.id='gtgate';document.body.appendChild(g);}
  const inp=(id,ph,ty)=>`<input id="${id}" type="${ty||'text'}" placeholder="${ph}" autocomplete="off" autocapitalize="none">`;
  let b;
  if(GT.step==='code')b=`<h1>📧 Doğrulama</h1><p class="dim">${esc(GT.em)} için bir kod hazırlandı. Kodu yönetici sana iletir; aldığında aşağıya yaz.</p>${inp('gtC','6 haneli kod','tel')}<div class="er">${esc(GT.err)}</div><button class="g p" data-g="chk">Doğrula</button><button class="g" data-g="resend">Yeni kod iste</button><button class="g" data-g="guest">Sonra doğrularım, misafir devam et</button>`;
  else b=`<h1>⚔️ Bilâd-ı Mütenâfise</h1><p class="dim" style="margin:0 0 6px">Oyuna girmek için hesabınla giriş yap.</p><div class="tb"><button class="${GT.mode==='login'?'on':''}" data-g="m-login">Giriş yap</button><button class="${GT.mode==='register'?'on':''}" data-g="m-register">Kayıt ol</button></div>${GT.mode==='register'?inp('gtN','Oyuncu adı')+inp('gtE','E-posta','email'):inp('gtE','Kullanıcı adı veya e-posta')}${inp('gtP','Şifre (en az 6)','password')}<div class="er">${GT.busy?'Bağlanıyor…':esc(GT.err)}</div><button class="g p" data-g="go">${GT.mode==='login'?'Giriş yap':'Kayıt ol ve kod al'}</button><button class="g" data-g="guest">Misafir olarak devam et</button><p class="dim" style="font-size:12px;margin:8px 0 0">${isEN()?'':''}Dil: <a href="#" data-g="en" style="color:var(--gold)">English</a> · <a href="#" data-g="tr" style="color:var(--gold)">Türkçe</a></p>`;
  g.innerHTML=`<div class="gb">${b}</div>`;
}
async function gtSendCode(){
  const code=String(100000+Math.floor(Math.random()*900000));GT.code=code;
  try{await MP.fb('PUT','verify/'+MP.uid(),{em:GT.em,n:(MP.cfg&&MP.cfg.name)||'',code:code,t:Date.now()});}catch(e){GT.err='Kod yöneticiye iletilemedi: '+String(e.message||e).slice(0,80);}
}
async function gtGo(){
  const v=id=>((document.getElementById(id)||{}).value||'').trim(),user=v('gtE'),pass=(document.getElementById('gtP')||{}).value||'';
  if(!user||!pass){GT.err='Alanları doldur.';return gtDraw();}
  if(GT.mode==='register'&&user.indexOf('@')<1){GT.err='Kayıt için geçerli bir e-posta gir.';return gtDraw();}
  GT.busy=1;GT.err='';gtDraw();
  try{
    const old=MP.cfg||{};MP.cfg={key:old.key||DEF_KEY,url:old.url||DEF_URL,name:(v('gtN')||user.split('@')[0]||old.name||'Oyuncu').slice(0,20)};
    await MP.account(GT.mode,user,pass);MP.saveCfg();await MP.connect();
    if(!MP.ok)throw new Error(MP.err||'Bağlanılamadı');
    GT.busy=0;
    if(GT.mode==='register'){GT.em=user.toLowerCase();await gtSendCode();GT.step='code';return gtDraw();}
    return gtClose('ok');
  }catch(e){GT.busy=0;GT.err=String(e.message||e).replace(/EMAIL_EXISTS/,'Bu hesap zaten var').replace(/INVALID_LOGIN_CREDENTIALS|INVALID_PASSWORD|EMAIL_NOT_FOUND/,'Kullanıcı veya şifre hatalı');gtDraw();}
}
document.addEventListener('click',async e=>{const t=e.target.closest&&e.target.closest('#gtgate [data-g]');if(!t)return;e.preventDefault();const a=t.dataset.g;
  if(a==='m-login'||a==='m-register'){GT.mode=a.slice(2);GT.err='';gtDraw();}
  else if(a==='go')gtGo();
  else if(a==='guest')gtClose('guest');
  else if(a==='en'||a==='tr'){PREF.lang=a;prefSave();location.reload();}
  else if(a==='resend'){await gtSendCode();GT.err=GT.err||'Yeni kod hazırlandı.';gtDraw();}
  else if(a==='chk'){const c=((document.getElementById('gtC')||{}).value||'').trim();
    if(c&&c===GT.code){try{await MP.fb('PATCH','verify/'+MP.uid(),{ok:1});}catch(x){}try{S.me.verified=1;}catch(x){}gtClose('ok');}else{GT.err='Kod yanlış.';gtDraw();}}
},true);
function gtMaybe(){
  const v=gtGet();if(v)return;
  if(navigator.webdriver&&!window.__gateTest)return; // otomatik testlerde kapı kapalı
  if(MP.auth&&MP.auth.user){gtSet('ok');return;}
  gtDraw();
}
window.addEventListener('load',()=>{setTimeout(()=>{try{gtLangInit();prefApply();gtMaybe();}catch(e){}},600);});
window.addEventListener('unhandledrejection',function(ev){
  var m=document.getElementById('alerts');if(!m)return;
  var d=document.createElement('div');d.className='al warn';
  d.textContent='⚠️ Hata: '+String(ev.reason&&ev.reason.message||ev.reason).slice(0,160);
  m.appendChild(d);setTimeout(function(){d.remove();},12000);
});

if('serviceWorker' in navigator&&/^https?:/.test(location.protocol)){
  window.addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){});});
}

try{init();}catch(e){var m=document.getElementById("main");if(m)m.innerHTML="<pre style=\"white-space:pre-wrap;color:#f85149\">Hata: "+String(e&&e.stack||e)+"</pre>";}
window.addEventListener("error",function(ev){var m=document.getElementById("alerts");if(m&&!m.dataset.err){m.dataset.err=1;m.innerHTML+="<div class=\"al bad\">Hata: "+ev.message+"</div>";}});
