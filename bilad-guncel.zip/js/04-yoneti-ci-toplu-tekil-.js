/* ================= YÖNETİCİ: toplu/tekil hediye + kaynak başına vergi ================= */
const TAXK=['gold','oil','ore','uranium','diamonds'];
function taxFor(r){ // pazar vergisi (yüzde), kaynağa özel
  if(typeof MP==='undefined')return 0;const x=MP.rates&&MP.rates[r];
  return (typeof x==='number'&&x>=0&&x<=90)?x:MP.rate;
}
function prodTaxFor(r){const x=typeof MP!=='undefined'&&MP.pt&&MP.pt[r];return (typeof x==='number'&&x>0&&x<=90)?x/100:0;} // kazanç (üretim) vergisi oranı
ACT.admTaxSave=async()=>{
  const rates={},pt={};let bad=false;
  TAXK.forEach(k=>{const a=+($('tm_'+k)||{}).value,b=+($('tp_'+k)||{}).value;if(isNaN(a)||a<0||a>90||isNaN(b)||b<0||b>90)bad=true;rates[k]=a;pt[k]=b;});
  if(bad)return msg('Oranlar 0–90 arasında olmalı.');
  try{await MP.fb('PUT','cfg/taxRes',rates);await MP.fb('PUT','cfg/prodTax',pt);MP.rates=rates;MP.pt=pt;msg('✅ Vergi oranları kaydedildi.','ok');}catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
ACT.admGiftBulk=async()=>{
  const tg=($('gbT')||{}).value||'players',money=Math.max(0,Math.floor(+($('gbMoney')||{}).value||0)),gold=Math.max(0,Math.floor(+($('gbGold')||{}).value||0)),note=(($('gbMsg')||{}).value||'').slice(0,80);
  if(!money&&!gold)return msg('Para veya altın miktarı gir.');
  if(money>1e9||gold>1e6)return msg('Miktar çok büyük.');
  const pl=Object.keys(MP.players||{}).filter(id=>id!==MP.uid()),on=pl.filter(id=>Date.now()-(+MP.players[id].seen||0)<5*60e3);
  const ids=tg==='online'?on:(tg==='bots'?[]:pl),doBots=tg==='bots'||tg==='all';
  const nb=doBots?(S.bots||[]).length:0;
  if(!ids.length&&!nb)return msg('Bu hedefte kimse yok.');
  if(!confirm(`${ids.length} oyuncu + ${nb} yapay zekâ — her birine ${money?fmt(money)+'₺ ':''}${gold?gold+' altın':''} gönderilecek. Onaylıyor musun?`))return;
  let ok=0;
  for(const id of ids){try{await MP.fb('POST','gifts/'+id,{money:money,gold:gold,msg:note});ok++;}catch(e){}}
  if(doBots){if(S.botSrv)botSrvCmd({k:'gift',ids:null,money:money,gold:gold});else{(S.bots||[]).forEach(b=>{b.m+=money;b.g+=gold;});}}
  msg(`🎁 ${ok} oyuncuya ${doBots?'ve '+nb+' yapay zekâya ':''}gönderildi.`,'ok');S.dirty=true;
};
const _admX=adminExtra;
adminExtra=function(){
  const inp='style="width:100%;padding:7px;background:var(--bg3);color:var(--tx);border:1px solid var(--line);border-radius:5px;margin:3px 0"';
  const rt=k=>(MP.rates&&typeof MP.rates[k]==='number')?MP.rates[k]:MP.rate,pt=k=>(MP.pt&&typeof MP.pt[k]==='number')?MP.pt[k]:0;
  let h=`<div class="panel"><h2>🎁 Toplu hediye</h2><div class="card"><select id="gbT" ${inp}><option value="players">Tüm oyuncular</option><option value="online">Çevrimiçi oyuncular (son 5 dk)</option><option value="bots">Tüm yapay zekâlar</option><option value="all">Herkes (oyuncular + yapay zekâ)</option></select>
   <div class="row" style="margin:4px 0"><input type="number" id="gbMoney" min="0" placeholder="Para (₺)"><input type="number" id="gbGold" min="0" placeholder="Altın"><input type="text" id="gbMsg" maxlength="80" placeholder="Not" style="flex:1;padding:6px"></div>${btn('Gönder','data-a="admGiftBulk"','gold')}
   <p class="hint">Tek kişiye göndermek için aşağıdaki oyuncu tablosundan birini seç, "Hediye gönder" kartını kullan. Yapay zekâlar için de aynısı geçerli.</p></div></div>
   <div class="panel"><h2>💸 Vergi ayarları (kaynak başına)</h2><div class="card"><p class="hint"><b>Pazar vergisi</b>: o kaynağın alım-satımında kesilir. <b>Kazanç vergisi</b>: oyuncu ve yapay zekânın o kaynaktan ürettiği (çalışma, fabrika) miktardan kesilir ve değeri sana yazılır. Oranlar yüzdedir (0–90).</p>
   <table><tr><th align=left>Kaynak</th><th>Pazar %</th><th>Kazanç %</th></tr>${TAXK.map(k=>`<tr><td>${RES_I[k]} ${RES_N[k]}</td><td><input type="number" id="tm_${k}" min="0" max="90" value="${rt(k)}" style="width:64px"></td><td><input type="number" id="tp_${k}" min="0" max="90" value="${pt(k)}" style="width:64px"></td></tr>`).join('')}</table>
   ${btn('Kaydet','data-a="admTaxSave"','gold')}</div></div>`;
  return h+_admX();
};
/* ================= YAPAY ZEKÂ OYUNCULAR (binlerce; yönetici istemcisinde çalışır) ================= */
let BOTAGG={st:{},party:{},reg:[]};
const FN=['Kemal','Aylin','Barış','Defne','Emre','Selin','Tolga','Zeynep','Murat','Ceren','Onur','Elif','Cem','Deniz','Burak','Ece','Kaan','Melis','Yusuf','Naz'];
const SN=['Yılmaz','Kaya','Demir','Şahin','Çelik','Aydın','Arslan','Doğan','Kurt','Özdemir','Aksoy','Polat','Erdem','Koç','Güneş','Tekin','Bulut','Yıldız','Aslan','Karaca'];
let SMARTN={}; // akıllı oyuncuların özel isimleri (sunucudan gelir)
const botName=i=>SMARTN[i]||FN[i%20]+' '+SN[Math.floor(i/20)%20]+(i>=400?' '+(Math.floor(i/400)+1):'');
const BKEY={gold:'g',oil:'o',ore:'k'};
function botParty(){const ps=A().parties,t=ps.reduce((x,p)=>x+Math.max(1,p.supp),0);let r=Math.random()*t;for(const p of ps){r-=Math.max(1,p.supp);if(r<=0)return p.id;}return ps[0].id;}
function mkBot(i){
  const r=Math.random;const NR=(typeof REG0!=='undefined')?REG0.length:37;let reg;if(r()<0.05)reg=21+(r()<0.5?0:1);else if(NR>37&&r()<0.6)reg=37+Math.floor(r()*(NR-37));else{reg=r()<0.4?23+Math.floor(r()*14):Math.floor(r()*21);}
  return {i:i,r:reg,s:30,e:30,d:30,w:0,m:15000+Math.floor(r()*30000),g:0,o:0,k:0,t:0,p:'',a:r()*10*MIN,c:r()*30*MIN,l:(2+r()*5)*HOUR,v:(6+r()*18)*HOUR,j:Date.now(),x:'Yeni katıldı',xt:Date.now()};
}
function botSetCount(n,src){
  if(S.botSrv&&src!=='pull'&&typeof botSrvCmd==='function'){botSrvCmd({k:'count',n:Math.max(0,Math.min(5000,n|0))});return;}
  S.bots=S.bots||[];n=Math.max(0,Math.min(5000,n|0));const before=S.bots.length;S.botN=n;
  while(S.bots.length<n)S.bots.push(mkBot(S.bots.length));
  while(S.bots.length>n)S.bots.pop();
  if(!n)BOTAGG={st:{},party:{},reg:[]};
  if(n!==before){S.botLog=S.botLog||[];S.botLog.unshift({t:Date.now(),d:n-before,n:n,k:src||'elle'});if(S.botLog.length>100)S.botLog.pop();S.dirty=true;}
}
const botLv=b=>1+Math.floor(b.w/40);
const botById=id=>{id=String(id);if(id.indexOf('bot_')!==0||!S.bots)return null;return S.bots[+id.slice(4)]||null;};
function botEv(b,m,p){ // son hareketi her zaman kaydet; akışa örnekleyerek yaz
  b.x=m;b.xt=Date.now();
  const N=(S.bots||[]).length||1;
  if(!(b.i<10)&&Math.random()>(p===undefined?1:p)*Math.min(1,25/N))return;
  S.botFeed=S.botFeed||[];S.botFeed.unshift({t:Date.now(),u:botName(b.i),i:b.i,m:m,b:1});if(S.botFeed.length>300)S.botFeed.pop();
}
const r1=x=>Math.round(x*10)/10;
function botAutoGrow(){
  const g=S.botAuto;if(!g||!g.on)return;
  const per=Math.max(1,+g.h||24)*HOUR,k=Math.floor((Date.now()-(g.last||Date.now()))/per);
  if(k<1)return;
  g.last=(g.last||Date.now())+k*per;
  const room=Math.max(0,Math.min(5000,+g.cap||0)-(S.bots||[]).length),add=Math.min(room,Math.max(0,(+g.n||0)*k));
  if(add>0)botSetCount((S.bots||[]).length+add,'otomatik');
}
function botsTick(ms){
  if(!S.me||!S.me.admin){return;}
  if(S.botSrv)return; // sunucu modu: yapay zekâlar GitHub sunucusunda çalışıyor
  botAutoGrow();
  if(!S.bots||!S.bots.length){return;}
  const N=S.bots.length,f=Math.min(1,40/N),a=A(),regs=S.regions,rate=(typeof MP!=='undefined'?MP.rate:5)/100;
  const agg={st:{},party:{},reg:new Array(regs.length).fill(0)};
  const RS=['gold','oil','ore'];
  for(const b of S.bots){
    const reg=regs[b.r],st=reg.state;
    const x=agg.st[st]||(agg.st[st]={n:0,str:0});x.n++;x.str+=b.s;agg.reg[b.r]++;
    if(st==='A'){if(!b.p||!a.parties.some(q=>q.id===b.p))b.p=botParty();agg.party[b.p]=(agg.party[b.p]||0)+1;}else b.p='';
    b.a+=ms;b.c+=ms;b.l-=ms;b.v-=ms;
    let n=0;
    while(b.a>=10*MIN&&n<40){b.a-=10*MIN;n++;
      let rs=RS[b.i%3];if(reg.res[rs].c<=0)rs=RS.slice().sort((p,q)=>reg.res[q].m-reg.res[p].m)[0];
      let amt=(3+botLv(b)*0.05+b.s*0.12)*YIELD[rs]*(0.7+Math.random()*0.6)*(1+reg.idx.d*0.02)*((b.au||0)>Date.now()?1.25:1);
      if(st==='A'){const tx=amt*a.tax[rs]/100;a.budget[rs]+=tx;amt-=tx;}
      {const pr=(typeof prodTaxFor==='function')?prodTaxFor(rs):0;if(pr>0){const pu=amt*pr,v=Math.floor(pu*S.prices[rs]*0.9);amt-=pu;b.t+=v;S.me.money+=v;S.adm.collected+=v;}}
      const k=BKEY[rs];b[k]=Math.min(2000*(1+b.d/100),b[k]+amt);b.w++;b.x='çalışıyor · '+RES_N[rs]+' üretti';b.xt=Date.now();}
    let m=0;
    while(b.c>=30*MIN&&m<20){b.c-=30*MIN;m++;
      for(const rs of RS){const k=BKEY[rs],have=Math.floor(b[k]);
        if(have>=(rs==='gold'?3:40)){const g0=Math.floor(S.prices[rs]*0.9*have),t=Math.floor(g0*taxFor(rs)/100);
          b.m+=g0-t;b.t+=t;b[k]-=have;S.me.money+=t;S.adm.collected+=t;
          S.prices[rs]*=1-have*0.0003*f/Math.max(1,PRICE0[rs]/100);S.prices[rs]=Math.max(S.prices[rs],PRICE0[rs]*0.5);
          botEv(b,`pazara sattı · ${RES_N[rs]} ×${have}`,0.4);}}
      if(Math.random()<0.25){const rs=RS[Math.floor(Math.random()*3)],q=rs==='gold'?1:10,c=Math.ceil(S.prices[rs]*1.1*q);
        if(b.m>c*2){const t=Math.floor(c*taxFor(rs)/100);b.m-=c+t;b.t+=t;S.me.money+=t;S.adm.collected+=t;b[BKEY[rs]]+=q;
          S.prices[rs]*=1+q*0.0003*f/Math.max(1,PRICE0[rs]/100);botEv(b,`pazardan aldı · ${RES_N[rs]} ×${q}`,0.4);}}
      if(typeof botAuto==='function')botAuto(b,rate);
      b.m=r1(b.m);b.g=r1(b.g);b.o=r1(b.o);b.k=r1(b.k);
    }
    if(b.l<=0){b.l=(2+Math.random()*5)*HOUR;const k=['s','e','d'][Math.floor(Math.random()*3)];if(b[k]<90){b[k]++;botEv(b,`${PERKS[{s:'str',e:'edu',d:'end'}[k]]} ${b[k]} seviyesine ulaştı`,1);}}
    if(b.v<=0){b.v=(6+Math.random()*18)*HOUR;const adj=reg.adj;
      if(adj.length){const same=adj.filter(j=>regs[j].state===st),pool=(same.length&&Math.random()<0.7)?same:adj;const to=pool[Math.floor(Math.random()*pool.length)];
        if(!(regs[to].state!==st&&relTo('A',regs[to].state)<-60&&st==='A')){b.r=to;botEv(b,`${regs[to].n} bölgesine taşındı`,1);}}}
  }
  BOTAGG=agg;
}
function botRow(b){
  const reg=S.regions[b.r];
  return {id:'bot_'+b.i,bot:true,name:botName(b.i),lv:botLv(b),xp:b.w%40,money:Math.round(b.m),str:b.s,edu:b.e,end:b.d,energy:100,
    loc:reg.n,res:reg.n,party:b.p?((A().parties.find(p=>p.id===b.p)||{}).n||''):'',role:'Vatandaş (YZ) · '+nameOf(reg.state),
    stor:{gold:b.g,oil:b.o,ore:b.k,uranium:0,diamonds:0},items:{},facs:0,works:b.w,hits:0,learn:'',paper:'',tax:Math.round(b.t),seen:Date.now(),admin:false,j:b.j,x:b.x,xt:b.xt,au:(b.au||0)>Date.now(),rid:b.r,st:reg.state};
}
function botRows(limit){return (S.bots||[]).slice().sort((x,y)=>y.m-x.m).slice(0,limit||25).map(botRow);}
function botRowById(id){const b=botById(id);return b?botRow(b):null;}
ACT.botCount=d=>{const n=d&&d.n!==undefined?+d.n:+($('botN')||{}).value;if(isNaN(n)||n<0||n>5000)return msg('0–5000 arası bir sayı gir.');botSetCount(n);msg(`🤖 ${n} yapay zekâ oyuncu aktif.`,'ok');};

ACT.botAdd=d=>{const n=+d.n;if(!n)return;const cur=(S.bots||[]).length,to=Math.max(0,Math.min(5000,cur+n));if(to===cur)return msg(n>0?'Üst sınır 5000.':'Zaten 0.');botSetCount(to);msg(`🤖 ${n>0?'+':''}${n} → toplam ${to} yapay zekâ oyuncu.`,'ok');};
ACT.botAutoSet=d=>{const g=S.botAuto||(S.botAuto={on:false,n:25,cap:1000,h:24,last:Date.now()});
  g.n=Math.max(1,Math.min(500,+($('autoN')||{}).value||g.n));g.cap=Math.max(1,Math.min(5000,+($('autoCap')||{}).value||g.cap));g.h=Math.max(1,Math.min(168,+($('autoH')||{}).value||g.h));
  if(d&&d.on!==undefined){g.on=d.on==='1';g.last=Date.now();}
  if(S.botSrv&&typeof botSrvPushCfg==='function')botSrvPushCfg(true).catch(()=>{});
  msg(g.on?`🤖 Otomatik büyüme açık: her ${g.h} saatte +${g.n} (üst sınır ${g.cap}).`:'Otomatik büyüme kapalı.','ok');};
function botMigrate(){ // eski sürüm kayıtlarındaki yapay zekâ oyuncuları yeni biçime çevir
  if(!S.bots)S.bots=[];
  const bad=S.bots.some(b=>typeof b.r!=='number'||!S.regions[b.r]||typeof b.m!=='number');
  if(bad){const n=S.botN||S.bots.length||0;S.bots=[];if(S.me&&S.me.admin&&n)botSetCount(n);}
}
/* ================= YAPAY ZEKÂ İZLEME PANELİ (yalnızca yönetici) ================= */
const BP={page:0,q:'',st:'',reg:'',sort:'m',sel:null};
const BP_PER=20;
const BP_SORT={m:['Para',b=>b.m],w:['İş sayısı',b=>b.w],t:['Ödediği vergi',b=>b.t],xt:['Son hareket',b=>b.xt||0],j:['Eklenme',b=>b.j||0]};
function bpChange(el){
  const k=el.dataset.bp;
  if(k==='q')BP.q=String(el.value||'').trim().toLowerCase();
  else BP[k]=el.value;
  if(k==='st'){BP.reg='';}
  BP.page=0;
}
ACT.botPage=d=>{BP.page=Math.max(0,BP.page+(+d.d||0));};
ACT.botPick=d=>{BP.sel=+d.i;};
ACT.botReg=d=>{BP.reg=String(d.r);BP.st='';BP.page=0;['bpSt','bpReg'].forEach(i=>{const e=$(i);if(e)e.value=i==='bpReg'?BP.reg:'';});};
ACT.botClear=()=>{BP.q='';BP.st='';BP.reg='';BP.page=0;['bpQ','bpSt','bpReg'].forEach(i=>{const e=$(i);if(e)e.value='';});};
const agoT=t=>{if(!t)return '—';const s=Math.max(0,(Date.now()-t)/1000);return s<90?'az önce':s<3600?Math.round(s/60)+' dk önce':s<86400?Math.round(s/3600)+' sa önce':Math.round(s/86400)+' gün önce';};
function botParts(){
  const bots=S.bots||[],regs=S.regions;
  const st={},rg=regs.map(()=>({n:0,m:0})),pt={};let wealth=0,tax=0,lv=0,today=0;
  const d0=new Date();d0.setHours(0,0,0,0);
  bots.forEach(b=>{
    const r=regs[b.r];if(!r)return;
    const x=st[r.state]||(st[r.state]={n:0,s:0,m:0});x.n++;x.s+=b.s;x.m+=b.m;
    rg[b.r].n++;rg[b.r].m+=b.m;wealth+=b.m;tax+=b.t;lv+=botLv(b);
    if(b.p)pt[b.p]=(pt[b.p]||0)+1;
    if((b.j||0)>=d0.getTime())today++;
  });
  return {st:st,rg:rg,pt:pt,wealth:wealth,tax:tax,avgLv:bots.length?lv/bots.length:0,today:today};
}
function tabBots(){
  if(MP.role!=='admin'&&!(S.me&&S.me.admin))return '<div class="panel"><h2>🤖 Yapay zekâ</h2><p class="dim">Bu bölüm yalnızca yöneticiye açıktır.</p></div>';
  const bots=S.bots||[],N=bots.length,P=botParts(),regs=S.regions;
  const inp='style="width:100%;padding:7px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px;margin:3px 0"';
  const g=S.botAuto||{on:false,n:25,cap:1000,h:24};
  let h=`<div class="panel"><h2>🤖 Yapay zekâ oyuncular</h2><div class="grid">
  ${card('Toplam',`<div class="big">${fmt(N)}</div><p class="dim">Üst sınır 5.000 · bugün eklenen <b>${fmt(P.today)}</b></p>`)}
  ${card('Toplam servet',`<div class="big">${fmt(P.wealth)}₺</div><p class="dim">Ortalama seviye ${f1(P.avgLv)}</p>`)}
  ${card('Ödenen vergi',`<div class="big">${fmt(P.tax)}₺</div><p class="dim">Yöneticiye (pazar vergisi)</p>`)}
  </div>
  <div class="card" style="margin-top:8px"><h3>➕ Yapay zekâ ekle / çıkar</h3>
  <div class="btns">${[10,50,100,250,500].map(n=>btn('+'+n,`data-a="botAdd" data-n="${n}"`,'gold')).join('')}${[-10,-50,-100].map(n=>btn(String(n),`data-a="botAdd" data-n="${n}"`,'danger sm')).join('')}</div>
  <div class="row" style="margin:8px 0 0"><input type="number" id="botN" min="0" max="5000" value="${N}" style="width:90px">${btn('Toplamı ayarla','data-a="botCount"','sm')}</div>
  <p class="hint">Yapay zekâlar bölgelere dağılır, çalışır, pazarda alıp satar, partilere girer ve devletlerin gücünü belirler. <b>Yalnızca yönetici hesabıyla oyun açıkken</b> çalışırlar; kapalıyken geçen süre (en fazla 3 gün) oyun açılınca işlenir.</p></div>
  <div class="card"><h3>🔁 Otomatik büyüme ${g.on?'<span class="ok">(açık)</span>':'<span class="dim">(kapalı)</span>'}</h3>
  <p class="dim">Oyun oturana kadar kendiliğinden yapay zekâ eklenir.</p>
  <div class="row" style="margin:4px 0"><label>Her <input type="number" id="autoH" min="1" max="168" value="${g.h}" style="width:60px"> saatte</label><label>+<input type="number" id="autoN" min="1" max="500" value="${g.n}" style="width:60px"></label><label>üst sınır <input type="number" id="autoCap" min="1" max="5000" value="${g.cap}" style="width:70px"></label></div>
  <div class="btns">${btn(g.on?'Kapat':'Aç',`data-a="botAutoSet" data-on="${g.on?0:1}"`,g.on?'danger':'gold')}${btn('Ayarı kaydet','data-a="botAutoSet"','sm')}</div></div>
  </div>`;
  // ekleme geçmişi
  const lg=S.botLog||[];
  h+=`<div class="panel"><h2>🧾 Ekleme geçmişi</h2>${lg.length?`<table><tr><th align=left>Zaman</th><th>Değişim</th><th>Toplam</th><th align=left>Nasıl</th></tr>${lg.slice(0,12).map(l=>`<tr><td>${fmtT(l.t)}</td><td class="num ${l.d>0?'ok':'bad'}">${l.d>0?'+':''}${l.d}</td><td class="num">${fmt(l.n)}</td><td class="dim">${l.k}</td></tr>`).join('')}</table>`:'<p class="dim">Henüz kayıt yok.</p>'}</div>`;
  if(!N)return h+'<div class="panel"><p class="dim">Henüz yapay zekâ oyuncu yok. Yukarıdan ekleyin.</p></div>';
  // devlet ve bölge dağılımı
  h+=`<div class="panel"><h2>🗺️ Kim nerede?</h2><table><tr><th align=left>Devlet</th><th>YZ</th><th>%</th><th>Ort. güç</th><th>Servet</th></tr>`;
  Object.keys(P.st).sort((a,b)=>P.st[b].n-P.st[a].n).forEach(k=>{const x=P.st[k];h+=`<tr><td>${esc(nameOf(k))}</td><td class="num"><b>${fmt(x.n)}</b></td><td class="num">${Math.round(x.n/N*100)}</td><td class="num">${f1(x.s/x.n)}</td><td class="num">${fmt(x.m)}₺</td></tr>`;});
  h+=`</table><div style="overflow-x:auto;margin-top:8px"><table><tr><th align=left>Bölge</th><th align=left>Devlet</th><th>YZ</th><th>Servet</th><th></th></tr>`;
  regs.map((r,i)=>({r:r,i:i,x:P.rg[i]})).sort((a,b)=>b.x.n-a.x.n).forEach(o=>{h+=`<tr><td>${esc(o.r.n)}${o.r.moon?' 🌙':''}</td><td class="dim">${esc(nameOf(o.r.state))}</td><td class="num"><b>${fmt(o.x.n)}</b></td><td class="num">${fmt(o.x.m)}₺</td><td>${o.x.n?btn('Listele',`data-a="botReg" data-r="${o.i}"`,'sm'):''}</td></tr>`;});
  h+='</table></div>';
  const pk=Object.keys(P.pt);
  if(pk.length)h+=`<p class="hint" style="margin-top:8px">Parti dağılımı: ${pk.map(id=>{const p=A().parties.find(q=>q.id===id);return `<b>${esc(p?p.n:id)}</b> ${fmt(P.pt[id])}`;}).join(' · ')}</p>`;
  h+='</div>';
  // liste
  let list=bots.filter(b=>{
    const r=regs[b.r];if(!r)return false;
    if(BP.st&&r.state!==BP.st)return false;
    if(BP.reg!==''&&String(b.r)!==BP.reg)return false;
    if(BP.q&&botName(b.i).toLowerCase().indexOf(BP.q)<0&&String(b.x||'').toLowerCase().indexOf(BP.q)<0)return false;
    return true;});
  const sk=BP_SORT[BP.sort]||BP_SORT.m;list.sort((a,b)=>sk[1](b)-sk[1](a));
  const pages=Math.max(1,Math.ceil(list.length/BP_PER));BP.page=Math.min(BP.page,pages-1);
  const stOpts=['<option value="">Tüm devletler</option>'].concat(Object.keys(STATE_N).map(k=>`<option value="${k}" ${BP.st===k?'selected':''}>${esc(STATE_N[k])}</option>`)).join('');
  const rgOpts=['<option value="">Tüm bölgeler</option>'].concat(regs.map((r,i)=>`<option value="${i}" ${BP.reg===String(i)?'selected':''}>${esc(r.n)}</option>`)).join('');
  const soOpts=Object.keys(BP_SORT).map(k=>`<option value="${k}" ${BP.sort===k?'selected':''}>Sırala: ${BP_SORT[k][0]}</option>`).join('');
  h+=`<div class="panel"><h2>📋 Yapay zekâ listesi (${fmt(list.length)})</h2>
  <input type="text" id="bpQ" data-chg="bp" data-bp="q" ${inp} placeholder="İsim ya da hareket ara, sonra Enter" value="${esc(BP.q)}">
  <div class="row" style="margin:0"><select data-chg="bp" data-bp="st" id="bpSt">${stOpts}</select><select data-chg="bp" data-bp="reg" id="bpReg">${rgOpts}</select><select data-chg="bp" data-bp="sort" id="bpSort">${soOpts}</select></div>
  <div style="overflow-x:auto"><table><tr><th align=left>İsim</th><th>Sv</th><th>Para</th><th align=left>Konum</th><th align=left>Son hareket</th></tr>`;
  list.slice(BP.page*BP_PER,(BP.page+1)*BP_PER).forEach(b=>{const r=regs[b.r];
    h+=`<tr style="${BP.sel===b.i?'background:#1a2330':''}"><td><button class="act sm" data-a="botPick" data-i="${b.i}">${esc(botName(b.i))}</button></td><td class="num">${botLv(b)}</td><td class="num">${fmt(b.m)}</td><td>${esc(r.n)}<div class="dim">${esc(nameOf(r.state))}</div></td><td>${esc(b.x||'—')}<div class="dim">${agoT(b.xt)}</div></td></tr>`;});
  h+=`</table></div><div class="btns" style="margin-top:8px;align-items:center">${btn('◀','data-a="botPage" data-d="-1"','sm',BP.page<=0)}<span class="dim">${BP.page+1} / ${pages}</span>${btn('▶','data-a="botPage" data-d="1"','sm',BP.page>=pages-1)}${(BP.q||BP.st||BP.reg!=='')?btn('Filtreyi temizle','data-a="botClear"','sm'):''}</div></div>`;
  // seçili bot
  const sb=BP.sel!==null?bots[BP.sel]:null;
  if(sb&&regs[sb.r]){
    const r=regs[sb.r],ev=(S.botFeed||[]).filter(e=>e.i===sb.i).slice(0,10),pa=sb.p?(A().parties.find(q=>q.id===sb.p)||{}).n:'';
    h+=`<div class="panel"><h2>🔍 ${esc(botName(sb.i))}</h2><div class="grid">
    ${card('Karakter',`<p>Seviye ${botLv(sb)} · ${fmt(sb.w)} kez çalıştı</p><p>Güç ${sb.s} · Eğitim ${sb.e} · Dayanıklılık ${sb.d}</p><p class="dim">Eklendi: ${sb.j?fmtT(sb.j):'—'}</p>`)}
    ${card('Konum',`<p><b>${esc(r.n)}</b></p><p>${esc(nameOf(r.state))}</p><p>Parti: ${esc(pa||'—')}</p>`)}
    ${card('Varlık',`<p>💰 ${fmt(sb.m)}₺</p><p class="dim">🥇 ${f1(sb.g)} · 🛢️ ${f1(sb.o)} · ⛏️ ${f1(sb.k)}</p><p>Vergi: ${fmt(sb.t)}₺</p>`)}
    ${card('Son hareket',`<p><b>${esc(sb.x||'—')}</b></p><p class="dim">${agoT(sb.xt)}</p>`)}
    </div>${ev.length?`<div class="log" style="margin-top:8px;height:auto;max-height:160px">${ev.map(e=>`<div>[${new Date(e.t).toLocaleTimeString('tr-TR')}] ${esc(e.m)}</div>`).join('')}</div>`:''}</div>`;
  }
  // canlı akış
  const fd=(S.botFeed||[]).slice(0,60);
  h+=`<div class="panel"><h2>📡 Son yapay zekâ hareketleri</h2><div class="log tall" style="height:40vh">${fd.map(e=>`<div>[${new Date(e.t).toLocaleTimeString('tr-TR')}] <b>${esc(e.u)}</b> ${esc(e.m)}</div>`).join('')||'<div class="dim">Henüz hareket yok (birkaç dakika bekleyin).</div>'}</div></div>`;
  return h;
}
/* ================= SUNUCU MODU: yapay zekâlar GitHub Actions ile 7/24 çalışır ================= */
const BS={last:0,srvT:0,err:'',busy:false};
const BSF=['i','r','s','e','d','w','m','g','o','k','t','a','c','l','v','j','x','xt','au'];
const bsToArr=b=>BSF.map(k=>b[k]===undefined?0:b[k]);
const bsToObj=a=>{const o={};BSF.forEach((k,i)=>o[k]=a[i]);o.p='';return o;};
async function botSrvPushCfg(on){
  const a=A(),g=S.botAuto||{on:false,n:25,cap:1000,h:24};
  const pr={};['gold','oil','ore'].forEach(k=>pr[k]=Math.round(S.prices[k]*100)/100);
  await MP.fb('PUT','botsrv/cfg',{on:!!on,rate:MP.rate,taxRes:MP.rates||null,prodTax:MP.pt||null,prices:pr,
    stateTax:{gold:a.tax.gold,oil:a.tax.oil,ore:a.tax.ore},regState:S.regions.map(r=>r.state),auto:{on:!!g.on,n:+g.n||0,cap:+g.cap||0,h:+g.h||24}});
}
async function botSrvPull(){
  if(!MP.ok||BS.busy)return;BS.busy=true;BS.last=Date.now();
  try{
    const st=await MP.fb('GET','botsrv/state');
    if(st&&st.b){
      const arr=JSON.parse(st.b),agg={st:{},party:{},reg:new Array(S.regions.length).fill(0)};
      S.bots=arr.map(bsToObj);S.botN=S.bots.length;BS.srvT=+st.t||0;
      S.bots.forEach(b=>{const reg=S.regions[b.r];if(!reg)return;const stt=reg.state,x=agg.st[stt]||(agg.st[stt]={n:0,str:0});x.n++;x.str+=b.s;agg.reg[b.r]++;
        if(stt==='A'){if(!A().parties.some(q=>q.id===b.p))b.p=botParty();agg.party[b.p]=(agg.party[b.p]||0)+1;}});
      BOTAGG=agg;
    }
    const acc=await MP.fb('GET','botsrv/acc');
    if(acc){
      const c=S.botSrvClaimed=S.botSrvClaimed||{money:0,b:{gold:0,oil:0,ore:0}};
      const dm=(+acc.money||0)-c.money;
      if(dm>0){S.me.money+=dm;S.adm.collected+=dm;L(`🤖 Sunucudaki yapay zekâlardan vergi geliri: +${fmt(dm)}₺`,'ok');}
      c.money=+acc.money||0;
      ['gold','oil','ore'].forEach(k=>{const v=+((acc.b||{})[k])||0,d=v-(c.b[k]||0);if(d>0)A().budget[k]+=d;c.b[k]=v;});
    }
    BS.err='';
  }catch(e){BS.err=String(e.message||e).slice(0,120);}
  BS.busy=false;S.dirty=true;
}
async function botSrvTick(){
  if(!S.botSrv||!MP.ok)return;
  const gap=UI.tab==='bots'?2*60e3:10*60e3;
  if(Date.now()-BS.last>gap){await botSrvPull();try{await botSrvPushCfg(true);}catch(e){}}
}
async function botSrvCmd(c){
  if(!MP.ok)return msg('Önce giriş yap.');
  try{await MP.fb('POST','botsrv/cmd',c);msg('📨 Komut sunucuya iletildi; bir sonraki turda (en geç 15 dk) uygulanır.','ok');}catch(e){msg(rulesHint(e));}
}
ACT.botSrvOn=async()=>{
  if(!MP.ok||MP.role!=='admin')return msg('Sunucu modu için yönetici hesabıyla giriş yap.');
  try{
    if(!confirm('Yapay zekâlar artık sunucuda çalışacak. Önce GitHub tarafı kurulmuş olmalı (Hesap › Rehber). Açılsın mı?'))return;
    const now=Date.now();
    await MP.fb('PUT','botsrv/state',{v:1,t:now,n:(S.bots||[]).length,al:now,b:JSON.stringify((S.bots||[]).map(bsToArr))});
    S.botSrvClaimed=null;S.botSrv=true;await botSrvPushCfg(true);
    const acc=await MP.fb('GET','botsrv/acc');if(acc)S.botSrvClaimed={money:+acc.money||0,b:{gold:+((acc.b||{}).gold)||0,oil:+((acc.b||{}).oil)||0,ore:+((acc.b||{}).ore)||0}};
    msg('☁️ Sunucu modu açıldı. Sunucu ilk turunda (≤15 dk) çalışmaya başlar.','ok');
  }catch(e){S.botSrv=false;msg(rulesHint(e));}
  S.dirty=true;
};
ACT.botSrvOff=async()=>{
  try{await botSrvPull();await botSrvPushCfg(false);}catch(e){}
  S.botSrv=false;S.dirty=true;msg('Sunucu modu kapatıldı; yapay zekâlar yeniden bu telefonda çalışır.','ok');
};
ACT.botSrvPull=async()=>{await botSrvPull();try{await botSrvPushCfg(true);}catch(e){}msg('Sunucudan güncel durum alındı.','ok');};
const _tabBotsSrv=tabBots;
tabBots=function(){
  let h=_tabBotsSrv();
  if(MP.role!=='admin'&&!(S.me&&S.me.admin))return h;
  const on=!!S.botSrv,ago=BS.srvT?Math.max(0,Math.round((Date.now()-BS.srvT)/60000)):null,stale=on&&ago!==null&&ago>45;
  const c=`<div class="panel"><h2>☁️ Sunucu modu (7/24)</h2><div class="card ${on?'glow':''}"><p>Durum: <b class="${on?'ok':'dim'}">${on?'açık':'kapalı'}</b>${on&&ago!==null?` · sunucu son çalışma: <b class="${stale?'bad':'ok'}">${ago} dk önce</b>`:''}</p>
   ${stale?'<div class="al warn">Sunucu 45 dakikadan uzun süredir çalışmamış. GitHub Actions kurulu ve etkin mi? (Actions sekmesine bak)</div>':''}${BS.err?`<div class="al bad">${esc(BS.err)}</div>`:''}
   <p class="dim">Açıkken yapay zekâlar telefonun kapalıyken de GitHub sunucusunda ilerler (15 dakikada bir). Vergi gelirleri sen girince hesabına yazılır.</p>
   <div class="btns">${on?btn('Şimdi çek','data-a="botSrvPull"','sm')+btn('Sunucu modunu kapat','data-a="botSrvOff"','danger sm'):btn('Sunucu modunu aç','data-a="botSrvOn"','gold')}</div></div></div>`;
  const i=h.indexOf('<div class="panel"><h2>🧾');
  return i>0?h.slice(0,i)+c+h.slice(i):h+c;
};
/* ================= ORTAK BAŞKANLIK SEÇİMİ (oyuncular + yapay zekâlar, Firebase) =================
   Sunucu (botserver.js) her ülkede: 24 saat seçim → 48 saat görev. Adaylar yapay zekâlar ve oyunculardır.
   Başkan: bir politika seçer (ülkede yaşayanlara küçük bonus), duyuru yazar, günlük ödenek alır. */
const EL={d:{},last:0,busy:false,err:'',view:null};
const EL_POL={
  kalkinma:{n:'Kalkınma',i:'⛏️',d:'Ülkede yaşayanların çalışma verimi +%5',kind:'work',v:0.05},
  ordu:{n:'Ordu',i:'⚔️',d:'Ülkede yaşayanların savaş hasarı +%5',kind:'war',v:0.05},
  egitim:{n:'Eğitim',i:'🎓',d:'Ülkede yaşayanlar %10 daha hızlı öğrenir',kind:'learn',v:0.10}
};
const EL_COST=50000,EL_MINLV=5,EL_SALARY=40000; // aday olma bedeli, günlük başkan ödeneği
const elState=()=>{try{return homeReg().state;}catch(e){return 'A';}};
const elOf=s=>EL.d[s]||{};
function elBonus(kind){
  const s=elState(),E=elOf(s),P=EL_POL[E.pol];let b=0;
  if(P&&E.pres&&E.phase==='term'&&P.kind===kind)b+=P.v;
  const D=E.dec;if(D&&D.ok===true&&+D.until>Date.now()&&typeof EL_DEC!=='undefined'){const X=EL_DEC[D.k];if(X&&X.kind===kind)b+=X.v;}
  if(kind==='work'&&typeof dipBonus==='function')b+=dipBonus(s);
  return Math.max(-0.2,b);
}
const elMeId=()=>MP.uid();
const elIsPres=s=>{const E=elOf(s);return !!(E.pres&&!E.pres.bot&&E.pres.id===elMeId()&&E.phase==='term');};
async function elPoll(force){
  if(!MP.ok||EL.busy)return;
  if(!force&&Date.now()-EL.last<60e3)return;
  EL.busy=true;EL.last=Date.now();
  try{
    EL.d=(await MP.fb('GET','elect'))||{};EL.dip=(await MP.fb('GET','dip'))||{};EL.err='';
    const m=S.me,s=elState(),E=EL.d[s]||{};
    m.elSeen=m.elSeen||{};
    const key=s+':'+(E.cycle||0)+':'+(E.phase||'');
    if(E.phase&&m.elSeen[s]!==key){
      const first=m.elSeen[s]===undefined;m.elSeen[s]=key;
      if(!first||E.phase==='vote'){
        if(E.phase==='vote')toast(`🗳️ ${nameOf(s)}'da başkanlık seçimi başladı! Oy ver ya da aday ol (Savaşlar › Başkanlık).`,'ok');
        else if(E.pres){const me=E.pres.id===elMeId();toast(me?`🗳️ Seçimi kazandın: ${nameOf(s)} başkanısın!`:`🗳️ ${nameOf(s)}'ın yeni başkanı: ${E.pres.n}${E.pres.bot?' (yapay zekâ)':''}`,'ok');}
        S.dirty=true;
      }
    }
    // başkan günlük ödeneği
    if(elIsPres(s)&&typeof g3Claim!=='function'){
      const last=Math.max(m.elPay||0,+E.pres.t||0),now=Date.now(),hrs=Math.min(48,Math.max(0,(now-last)/3600e3));
      if(hrs>0.05){const g=EL_SALARY/24*hrs;m.money+=g;m.elPay=now;if(g>=1000)L(`🗳️ Başkanlık ödeneği: +${fmt(g)}₺`,'ok');S.dirty=true;}
    }
    S.dirty=true;
  }catch(e){EL.err=rulesHint(e);}
  EL.busy=false;
}
if(typeof MP!=='undefined'&&typeof MP.sync==='function'){const _s1=MP.sync;MP.sync=async function(){const r=await _s1.apply(this,arguments);try{elPoll();}catch(e){}return r;};}

const elCands=E=>Object.keys(E.cand||{}).map(id=>Object.assign({id:id},E.cand[id]));
const elVotesFor=(E,id)=>Object.keys(E.votes||{}).filter(u=>E.votes[u]===id).length;
ACT.elView=d=>{EL.view=d.s;};
ACT.elRefresh=()=>{elPoll(true);};
ACT.elRun=async()=>{
  const m=S.me,s=elState(),E=elOf(s),me=elMeId();
  if(!MP.ok)return msg('Önce giriş yap (Profil › Hesap).');
  if(E.phase!=='vote'||Date.now()>=+E.end)return msg('Şu an seçim yok.');
  if(m.level<EL_MINLV)return msg(`Aday olmak için seviye ${EL_MINLV} gerekli.`);
  if((E.cand||{})[me])return msg('Zaten adaysın.');
  if(m.money<EL_COST)return msg(`Aday olmak ${fmt(EL_COST)}₺.`);
  try{await MP.fb('PUT','elect/'+s+'/cand/'+me,{n:m.name,lv:m.level,camp:0,t:Date.now(),bot:0});
    m.money-=EL_COST;L(`🗳️ ${nameOf(s)} başkanlığına aday oldun (−${fmt(EL_COST)}₺).`,'ok');msg('Aday oldun!','ok');await elPoll(true);}
  catch(e){msg(elHint(e));}
  S.dirty=true;
};
const elHint=e=>{const m=String(e&&e.message||e);return /401|403|ermission/i.test(m)?'Sunucu işlemi reddetti: seçim aşaması/süresi ya da kampanya sınırı olabilir. Sorun sürerse güncel Firebase kural dosyasını yayınla.':rulesHint(e);};
ACT.elWithdraw=async()=>{
  const s=elState(),me=elMeId();
  try{await MP.fb('DELETE','elect/'+s+'/cand/'+me);msg('Adaylıktan çekildin.','ok');await elPoll(true);}catch(e){msg(elHint(e));}
  S.dirty=true;
};
ACT.elVote=async d=>{
  const s=elState(),E=elOf(s),me=elMeId();
  if(!MP.ok)return msg('Önce giriş yap (Profil › Hesap).');
  if(E.phase!=='vote'||Date.now()>=+E.end)return msg('Seçim bitti.');
  if(S.me.level<EL_MINLV-3)return msg('Oy vermek için seviye 2 gerekli.');
  try{await MP.fb('PUT','elect/'+s+'/votes/'+me,d.id);if(!EL.d[s].votes)EL.d[s].votes={};EL.d[s].votes[me]=d.id;msg('Oyun kaydedildi.','ok');}
  catch(e){msg(elHint(e));}
  S.dirty=true;
};
ACT.elCamp=async d=>{
  const s=elState(),E=elOf(s),v=Math.max(0,Math.min(100000,+d.v||0)),m=S.me;
  if(E.phase!=='vote')return msg('Seçim yok.');
  if(!v||m.money<v)return msg('Yetersiz para.');
  try{const cur=+(await MP.fb('GET','elect/'+s+'/cand/'+d.id+'/camp'))||0;
    if(cur>=1000000)return msg('Bu adayın kampanya bütçesi doldu.');
    const nv=Math.min(1000000,cur+v);
    await MP.fb('PUT','elect/'+s+'/cand/'+d.id+'/camp',nv);m.money-=v;
    L(`🗳️ Kampanyaya ${fmt(v)}₺ bağışladın.`,'ok');msg('Destek verildi.','ok');await elPoll(true);}
  catch(e){msg(elHint(e));}
  S.dirty=true;
};
ACT.elPol=async d=>{
  const s=elState();
  if(!elIsPres(s))return msg('Başkan sen değilsin.');
  try{await MP.fb('PUT','elect/'+s+'/pol',d.k);EL.d[s].pol=d.k;msg('Politika güncellendi.','ok');}catch(e){msg(elHint(e));}
  S.dirty=true;
};
ACT.elMsg=async()=>{
  const s=elState(),t=String((($('elMsgTxt')||{}).value)||'').trim().slice(0,100);
  if(!elIsPres(s))return msg('Başkan sen değilsin.');
  try{await MP.fb('PUT','elect/'+s+'/msg',t);EL.d[s].msg=t;msg('Duyuru yayınlandı.','ok');}catch(e){msg(elHint(e));}
  S.dirty=true;
};

function elPresCard(s,E){
  const P=E.pres,pol=EL_POL[E.pol];
  if(!P)return card('👑 Başkan',`<p class="dim">Bu ülkede henüz seçilmiş bir başkan yok.</p>`);
  const mine=P.id===elMeId()&&!P.bot;
  return card(`👑 ${esc(nameOf(s))} Başkanı`,`<p style="font-size:17px"><b>${esc(P.n)}</b> ${P.bot?'<span class="owner">🤖 yapay zekâ</span>':'<span class="owner">👤 oyuncu</span>'}${mine?' <span class="owner">sen</span>':''}</p>
   <p class="dim">%${+P.pct||0} oyla seçildi · görev bitişi ${E.phase==='term'?cd(+E.end):'—'}</p>
   ${pol?`<p>${pol.i} <b>${pol.n} politikası</b><br><span class="dim">${pol.d}</span></p>`:''}
   ${E.msg?`<p>📣 “${esc(E.msg)}”</p>`:''}`,'glow');
}
function elMineControls(s,E){
  if(!elIsPres(s))return '';
  return card('🎖️ Başkan paneli',`<p class="hint">Politikanı seç: ülkede yaşayan herkese uygulanır. Duyurun Ana Sayfa'da görünür. Günlük ödenek: ${fmt(EL_SALARY)}₺.</p>
   <div class="btns">${Object.keys(EL_POL).map(k=>btn(`${EL_POL[k].i} ${EL_POL[k].n}`,`data-a="elPol" data-k="${k}"`,E.pol===k?'gold':'')).join('')}</div>
   <div class="row"><input type="text" id="elMsgTxt" maxlength="100" placeholder="Duyuru (100 karakter)" value="${esc(E.msg||'')}" style="flex:1;padding:8px;background:var(--bg3);color:var(--tx);border:1px solid var(--line);border-radius:6px;font-size:16px">${btn('Yayınla','data-a="elMsg"','blue')}</div>`);
}
function elVoteCard(s,E){
  const me=elMeId(),ids=elCands(E),myVote=(E.votes||{})[me],isCand=!!(E.cand||{})[me],over=Date.now()>=+E.end;
  let h=`<p>Seçim bitişine <b>${cd(+E.end)}</b>. Oylar bitince sunucu sayar (en geç 15 dakika sonra).</p>`;
  if(!ids.length)h+=`<p class="dim">Henüz aday yok.</p>`;
  else h+=`<table><tr><th>Aday</th><th>Sv</th><th>Kampanya</th><th>Oy</th><th></th></tr>`+ids.map(c=>`<tr><td>${c.bot?'🤖':'👤'} ${esc(c.n)}${c.id===me?' <span class="owner">sen</span>':''}</td><td class="num">${+c.lv||'-'}</td><td class="num">${fmt(+c.camp||0)}₺</td><td class="num">${elVotesFor(E,c.id)}</td>
    <td>${btn(myVote===c.id?'✓ Oyun':'Oy ver',`data-a="elVote" data-id="${c.id}"`,myVote===c.id?'gold':'',over)}${btn('+10.000₺',`data-a="elCamp" data-id="${c.id}" data-v="10000"`,'sm',over)}</td></tr>`).join('')+`</table>`;
  h+=`<p class="hint">Her oyuncunun oyu, yapay zekâların oylarından çok daha ağır sayılır. Kampanya bağışı adayın desteğini artırır (adaya yapay zekâların oyları da kampanyaya göre dağılır).</p>`;
  h+=`<div class="btns">${isCand?btn('Adaylıktan çekil','data-a="elWithdraw"','danger'):btn(`🏛️ Aday ol (${fmt(EL_COST)}₺)`,'data-a="elRun"','gold',over||S.me.level<EL_MINLV||S.me.money<EL_COST)}</div>
   ${S.me.level<EL_MINLV?`<p class="dim">Aday olmak için seviye ${EL_MINLV} gerekir.</p>`:''}`;
  return card('🗳️ Seçim sürüyor',h,'glow');
}
function tabElect(){
  if(!MP.ok)return `<div class="panel"><h2>🗳️ Başkanlık</h2><div class="card"><p>Ortak seçim için önce giriş yap (Profil › Hesap).</p></div></div>`;
  const mys=elState(),s=EL.view||mys,E=elOf(s);
  if(!EL.last)elPoll(true);
  let h=`<div class="panel"><h2>🗳️ Başkanlık Seçimi</h2>
   <div class="btns">${['A','B','D','G','K','L','M','O','P'].map(k=>btn(esc(nameOf(k))+(k===mys?' 🏠':''),`data-a="elView" data-s="${k}"`,k===s?'gold':'sm')).join('')}${btn('🔄','data-a="elRefresh"','sm')}</div>`;
  if(EL.err)h+=`<div class="card"><p class="bad">${esc(EL.err)}</p></div>`;
  if(!E.phase)h+=card('Henüz seçim yok',`<p class="dim">Seçimleri sunucu yönetir. Sunucu modu açıkken ve ülkede yapay zekâ varken her ülkede otomatik seçim başlar (24 saat seçim, 7 gün görev).</p>`);
  else{
    h+=elPresCard(s,E);
    if(s===mys)h+=elMineControls(s,E);
    if(E.phase==='vote')h+=(s===mys?elVoteCard(s,E):card('🗳️ Seçim sürüyor',`<p>Bitişine ${cd(+E.end)}. Oy vermek ve aday olmak için o ülkede ikamet etmelisin (Harita › şehir › Yerleş).</p><p class="dim">Adaylar: ${elCands(E).map(c=>esc(c.n)).join(', ')||'—'}</p>`));
    else h+=card('⏳ Sonraki seçim',`<p>Yeni seçim: ${cd(+E.end)}</p>`);
    if(E.last&&E.last.top)h+=card(`📊 Son seçim sonucu (#${E.last.cycle})`,`<table>${E.last.top.map((x,i)=>`<tr><td>${i+1}.</td><td>${x.bot?'🤖':'👤'} ${esc(x.n)}</td><td class="num">${fmt(x.tot)} puan</td><td class="num dim">${x.rv} oyuncu oyu</td></tr>`).join('')}</table>`);
  }
  return h+`<div class="card"><h3>Nasıl çalışır?</h3><p class="dim">Her ülkede 24 saatlik seçim yapılır, kazanan 7 gün başkan olur. Adaylar yapay zekâlar ve oyunculardır. Başkan bir politika seçer: kalkınma (çalışma +%5), ordu (savaş hasarı +%5) ya da eğitim (öğrenme %10 hızlı). Etki ülkede yaşayan herkese uygulanır. Başkan günlük ${fmt(EL_SALARY)}₺ ödenek alır.</p></div></div>`;
}
// sekmeyi savaşlar grubuna ekle
(function(){const g=GROUPS.find(x=>x[0]==='war');if(g&&!g[2].some(t=>t[0]==='elect'))g[2].push(['elect','🗳️ Başkanlık']);})();
// sekme tablosuna kaydol: render() içindeki fn tablosu 'elect' bilmediği için tabElect'i 'adm' benzeri bir yedek ile bağla
// Ana Sayfa kartı + Devlet sekmesine ortak başkan özeti
function elHomeCard(){
  if(!MP.ok)return '';
  const s=elState(),E=elOf(s);if(!E.phase)return '';
  let h='';
  if(E.phase==='vote'&&Date.now()<+E.end)h+=`<div class="card glow"><h3>🗳️ ${esc(nameOf(s))} seçimi sürüyor</h3><p>Bitişine ${cd(+E.end)} · ${elCands(E).length} aday</p><div class="btns">${btn('Oy ver / aday ol','data-a="tab" data-t="elect"','gold')}</div></div>`;
  else if(E.pres)h+=`<div class="card"><h3>👑 ${esc(nameOf(s))} Başkanı</h3><p><b>${esc(E.pres.n)}</b> ${E.pres.bot?'🤖':'👤'}${EL_POL[E.pol]?` · ${EL_POL[E.pol].i} ${EL_POL[E.pol].n}`:''}</p>${E.msg?`<p>📣 “${esc(E.msg)}”</p>`:''}<div class="btns">${btn('Başkanlık','data-a="tab" data-t="elect"','sm')}</div></div>`;
  return h;
}
if(typeof tabHome==='function'){const _th1=tabHome;tabHome=function(){return _th1()+elHomeCard();};}
if(typeof tabState==='function'){const _tst=tabState;tabState=function(){
  const E=elOf('A');let x='';
  if(MP.ok&&E.pres)x=`<div class="panel"><div class="card"><h3>🗳️ Ortak başkan (seçimle gelen)</h3><p><b>${esc(E.pres.n)}</b> ${E.pres.bot?'🤖':'👤'}${EL_POL[E.pol]?` · ${EL_POL[E.pol].i} ${EL_POL[E.pol].n}`:''}</p><div class="btns">${btn('Başkanlık seçimi','data-a="tab" data-t="elect"','sm')}</div></div></div>`;
  return x+_tst();};}
/* ================= ÜLKE KARARLARI + DİPLOMASİ + İTTİFAK TURNUVASI ================= */
const EL_DEC={
  sefer:{n:'Seferberlik',i:'⚔️',kind:'war',v:0.10,d:'Savaş hasarı +%10 (24 saat)'},
  calis:{n:'Çalışma haftası',i:'⛏️',kind:'work',v:0.10,d:'Çalışma verimi +%10 (24 saat)'},
  egitim:{n:'Eğitim seferberliği',i:'🎓',kind:'learn',v:0.20,d:'Öğrenme %20 hızlı (24 saat)'}
};
const DEC_VOTE=6*3600e3,DEC_FX=24*3600e3,PACT_LEN=3*86400e3,PACT_BONUS=0.03,EMB_MALUS=0.05;
const DIP_STATES=['A','B','D','G','K','L','M','O','P'];
function dipPact(a,b){const P=((EL.dip||{}).pact)||{};const x=(P[a]||{})[b],y=(P[b]||{})[a];return Math.max(x&&+x.acc||0,y&&+y.acc||0);}
function dipPend(a,b){const x=((((EL.dip||{}).pact)||{})[a]||{})[b];return (x&&!x.acc&&+x.exp>Date.now())?x:null;}
function dipEmb(f,t){const x=((((EL.dip||{}).emb)||{})[f]||{})[t];return (x&&+x.until>Date.now())?x:null;}
function dipBonus(s){
  let b=0;
  DIP_STATES.forEach(o=>{if(o===s)return;if(dipPact(s,o)>Date.now())b+=PACT_BONUS;if(dipEmb(o,s))b-=EMB_MALUS;});
  return b;
}
/* ---- eylemler ---- */
const dipPres=()=>elIsPres(elState());
ACT.decNew=async d=>{
  const s=elState(),E=elOf(s),now=Date.now();
  if(!dipPres())return msg('Başkan sen değilsin.');
  if(!EL_DEC[d.k])return;
  if(E.dec&&now<=+E.dec.end+12*3600e3)return msg('Önceki karardan 12 saat sonra yeni karar önerebilirsin.');
  try{await MP.fb('PUT','elect/'+s+'/dec',{k:d.k,start:now,end:now+DEC_VOTE,by:elMeId()});await MP.fb('DELETE','elect/'+s+'/decv');
    msg('Karar oylamaya sunuldu (6 saat).','ok');await elPoll(true);}catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
ACT.decVote=async d=>{
  const s=elState(),E=elOf(s);
  if(!E.dec||E.dec.ok!==undefined||Date.now()>=+E.dec.end)return msg('Oylama bitti.');
  try{await MP.fb('PUT','elect/'+s+'/decv/'+elMeId(),d.v);(E.decv=E.decv||{})[elMeId()]=d.v;msg('Oyun kaydedildi.','ok');}catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
ACT.dipEmb=async d=>{
  const s=elState(),now=Date.now();
  if(!dipPres())return msg('Başkan sen değilsin.');
  const old=(((EL.dip||{}).emb||{})[s]||{})[d.t];
  if(old&&+old.until>now-12*3600e3)return msg('Bu ülkeye yeni ambargo için bekle (önceki bittikten 12 saat sonra).');
  try{await MP.fb('PUT','dip/emb/'+s+'/'+d.t,{t:now,until:now+86400e3});msg(`${nameOf(d.t)} ülkesine 24 saat ambargo uygulandı.`,'ok');await elPoll(true);}catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
ACT.dipLift=async d=>{
  const s=elState();if(!dipPres())return msg('Başkan sen değilsin.');
  try{await MP.fb('DELETE','dip/emb/'+s+'/'+d.t);msg('Ambargo kaldırıldı.','ok');await elPoll(true);}catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
ACT.dipPact=async d=>{
  const s=elState(),now=Date.now();
  if(!dipPres())return msg('Başkan sen değilsin.');
  const old=((((EL.dip||{}).pact||{})[s])||{})[d.t];
  if(old&&+old.exp>now)return msg('Zaten bekleyen bir teklifin var.');
  try{await MP.fb('PUT','dip/pact/'+s+'/'+d.t,{t:now,exp:now+86400e3});msg('İttifak teklifi gönderildi (24 saat geçerli).','ok');await elPoll(true);}catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
ACT.dipAcc=async d=>{
  const s=elState(),now=Date.now();
  if(!dipPres())return msg('Başkan sen değilsin.');
  try{await MP.fb('PUT','dip/pact/'+d.x+'/'+s+'/acc',now+PACT_LEN);msg(`${nameOf(d.x)} ile 3 günlük ittifak kuruldu.`,'ok');await elPoll(true);}catch(e){msg(rulesHint(e));}
  S.dirty=true;
};
/* ---- kartlar ---- */
function decCard(s,E){
  const D=E.dec,mys=elState(),mine=(s===mys),now=Date.now();
  let h='';
  if(D&&D.ok===undefined&&now<+D.end){
    const X=EL_DEC[D.k]||{n:D.k,i:'📜',d:''},my=(E.decv||{})[elMeId()];
    const ys=Object.keys(E.decv||{}).filter(u=>E.decv[u]==='y').length,ns=Object.keys(E.decv||{}).filter(u=>E.decv[u]==='n').length;
    h+=`<p>${X.i} <b>${esc(X.n)}</b> kararı oylamada. Bitişine ${cd(+D.end)}</p><p class="dim">${esc(X.d)} · oyuncu oyları: ${ys} evet / ${ns} hayır</p>`+
      (mine?`<div class="btns">${btn(my==='y'?'✓ Evet':'Evet','data-a="decVote" data-v="y"',my==='y'?'gold':'')}${btn(my==='n'?'✓ Hayır':'Hayır','data-a="decVote" data-v="n"',my==='n'?'danger':'')}</div>`:'');
  }else if(D&&D.ok===true&&+D.until>now){
    const X=EL_DEC[D.k]||{n:D.k,i:'📜',d:''};h+=`<p>${X.i} <b>${esc(X.n)}</b> yürürlükte: ${esc(X.d)}. Bitişine ${cd(+D.until)}</p>`;
  }else if(D&&D.ok===false&&now<+D.end+12*3600e3){h+=`<p class="dim">Son karar reddedildi.</p>`;}
  if(!h)h='<p class="dim">Şu an oylanan bir karar yok.</p>';
  if(mine&&elIsPres(s)&&!(D&&D.ok===undefined&&now<+D.end)&&!(D&&now<=+D.end+12*3600e3)){
    h+=`<p class="hint">Karar öner: 6 saat oylanır, yapay zekâların oyları da sayılır. Kabul edilirse 24 saat yürürlükte.</p><div class="btns">${Object.keys(EL_DEC).map(k=>btn(`${EL_DEC[k].i} ${EL_DEC[k].n}`,`data-a="decNew" data-k="${k}"`,'')).join('')}</div>`;
  }
  return card('📜 Ülke kararı',h);
}
function dipCard(){
  const mys=elState(),pres=dipPres(),now=Date.now();
  const rows=DIP_STATES.filter(o=>o!==mys&&((EL.d||{})[o]||{}).pres).map(o=>{
    const pact=dipPact(mys,o),eOut=dipEmb(mys,o),eIn=dipEmb(o,mys),inc=dipPend(o,mys),out=dipPend(mys,o),st=[];
    if(pact>now)st.push(`🤝 ittifak (${cd(pact)})`);
    if(eOut)st.push(`⛔ senin ambargon (${cd(+eOut.until)})`);
    if(eIn)st.push(`🚫 sana ambargo (${cd(+eIn.until)})`);
    if(inc)st.push('📨 teklif geldi');
    if(out)st.push('⏳ teklifin bekliyor');
    if(!st.length)st.push('<span class="dim">normal</span>');
    const bs=[];
    if(pres){
      if(inc)bs.push(btn('Kabul',`data-a="dipAcc" data-x="${o}"`,'gold sm'));
      if(pact<=now&&!out&&!inc)bs.push(btn('İttifak öner',`data-a="dipPact" data-t="${o}"`,'sm'));
      if(eOut)bs.push(btn('Ambargoyu kaldır',`data-a="dipLift" data-t="${o}"`,'sm'));
      else if(pact<=now)bs.push(btn('Ambargo',`data-a="dipEmb" data-t="${o}"`,'danger sm'));
    }
    return `<tr><td><b>${esc(nameOf(o))}</b><br><small>${st.join(' · ')}</small></td><td>${bs.join(' ')}</td></tr>`;
  });
  let h=`<p class="hint">İttifak: iki ülkede de çalışma +%3 (3 gün). Ambargo: hedef ülkede yaşayanların çalışması −%5 (24 saat). Başkanlar karar verir; yapay zekâ başkanlar da kendiliğinden anlaşma kurar.</p>`;
  if(!rows.length)return card('🌐 Diplomasi',h+'<p class="dim">Henüz başka ülkede başkan yok.</p>');
  return card('🌐 Diplomasi',h+'<table>'+rows.join('')+'</table>');
}
const _tel=tabElect;
tabElect=function(){
  let h=_tel();
  if(!MP.ok)return h;
  const mys=elState(),s=EL.view||mys,E=elOf(s);
  if(!E.phase)return h;
  return h+'<div class="panel">'+(E.pres?decCard(s,E):'')+(s===mys?'<div class="card"><p style="margin:0">🌐 Diplomasi artık <b>Savaş › Diplomasi</b> sayfasında. <button class="act sm blue" data-a="tab" data-t="dip">Aç</button></p></div>':'')+'</div>';
};
/* ================= İTTİFAK TURNUVASI (haftalık) =================
   Geçen haftanın ittifakları, üyelerinin verdiği toplam hasara göre sıralanır; ilk 3 ittifakın hasar veren üyelerine ödül. */
const TR={prize:[{m:500000,g:8,b:'🥇'},{m:250000,g:4,b:'🥈'},{m:120000,g:2,b:'🥉'}],busy:false,last:0,res:null};
async function trPoll(){
  if(!MP.ok||TR.busy||Date.now()-TR.last<5*60e3||typeof AL==='undefined')return;
  TR.busy=true;TR.last=Date.now();
  try{
    wkState();const pw=wkNo()-1,m=S.me,me=MP.uid();
    const d=(await MP.fb('GET','wk/'+pw))||{},al=AL.list||{};
    const rows=Object.keys(al).filter(i=>al[i]&&al[i].n).map(i=>{
      let sc=0,act=0;Object.keys(al[i].m||{}).forEach(u=>{const x=d[u];if(x&&+x.wd>0){sc+=+x.wd;act++;}});
      return {id:i,n:al[i].n,sc:sc,act:act};}).filter(x=>x.sc>0).sort((a,b)=>b.sc-a.sc);
    TR.res={w:pw,rows:rows};
    if(m.trPaid!==pw&&!m.admin&&Date.now()>=(wkEnd()-WK_MS)+24*3600e3){
      m.trPaid=pw;
      const my=alMy(),mine=d[me];
      if(my&&mine&&+mine.wd>0){
        const i=rows.findIndex(x=>x.id===my.id);
        if(i>=0&&i<3){const p=TR.prize[i];m.money+=p.m;m.stor.gold=Math.min(storCap(),m.stor.gold+p.g);m.badges=m.badges||[];m.badges.push({k:'tr'+(i+1),w:pw});
          L(`${p.b} İttifakın "${esc(my.n)}" geçen haftanın turnuvasında ${i+1}. oldu! +${fmt(p.m)}₺ +${p.g} altın.`,'ok');toast(`${p.b} İttifak turnuvasında ${i+1}. olduk! +${fmt(p.m)}₺`,'ok');}
      }
    }
    S.dirty=true;
  }catch(e){}
  TR.busy=false;
}
if(typeof MP!=='undefined'&&typeof MP.sync==='function'){const _s2=MP.sync;MP.sync=async function(){const r=await _s2.apply(this,arguments);try{trPoll();}catch(e){}return r;};}
if(typeof tabAlly==='function'){const _ta=tabAlly;tabAlly=function(){
  let h=_ta();
  if(!MP.ok)return h;
  const R=TR.res;
  let c=`<div class="card"><h3>🏆 Haftalık ittifak turnuvası</h3><p class="hint">Her hafta ittifaklar, üyelerinin verdiği toplam savaş hasarıyla yarışır. İlk 3 ittifakın hasar veren üyeleri ödül alır: 🥇 ${fmt(TR.prize[0].m)}₺ + ${TR.prize[0].g} altın, 🥈 ${fmt(TR.prize[1].m)}₺ + ${TR.prize[1].g}, 🥉 ${fmt(TR.prize[2].m)}₺ + ${TR.prize[2].g}. Sonuçlar hafta başında kesinleşir.</p>`;
  if(R&&R.rows.length)c+=`<p class="dim">Geçen hafta:</p><table>${R.rows.slice(0,5).map((x,i)=>`<tr><td>${['🥇','🥈','🥉','4.','5.'][i]}</td><td>${esc(x.n)}</td><td class="num">${fmt(x.sc)} hasar</td><td class="num dim">${x.act} üye</td></tr>`).join('')}</table>`;
  else c+='<p class="dim">Geçen hafta için veri yok ya da hâlâ toplanıyor.</p>';
  c+='</div>';
  const k=h.lastIndexOf('</div>');
  return k>0?h.slice(0,k)+c+h.slice(k):h+c;
};}
if(typeof BADGES!=='undefined'){BADGES.push({id:'tr1',i:'🛡️',n:'Turnuva şampiyonu ittifak',f:m=>(m.badges||[]).some(b=>b.k==='tr1')},{id:'tr2',i:'🎖️',n:'Turnuva ikincisi ittifak',f:m=>(m.badges||[]).some(b=>b.k==='tr2')},{id:'tr3',i:'🎗️',n:'Turnuva üçüncüsü ittifak',f:m=>(m.badges||[]).some(b=>b.k==='tr3')});}
/* ================= CEPHE HATTI'NDAN ALINANLAR: yedek, müzayede, SİHA, ücretsiz vuruş, cephe mesafesi ================= */
/* --- SİHA (hava eşyası) --- */
ITEMS.siha={n:'SİHA',i:'🛰️',type:'air',money:9000,ore:50,oil:40,time:7*MIN,dmg:1.2};
try{Object.keys(ITEMS).forEach(k=>{if(S.me.items[k]===undefined)S.me.items[k]=0;});}catch(e){}

/* --- Ücretsiz saatlik vuruş + cepheye uzaklık cezası --- */
const FH_MS=HOUR;
let __hw=null,__hinfo=null;
const _hitDmg0=hitDamage;
hitDamage=function(item){
  let d=_hitDmg0(item);
  try{const w=__hw;if(w){const r=S.regions[w.region];if(r&&!r.moon&&S.me.loc!==undefined){const h=Math.min(6,hopsTo(S.me.loc,r.id));if(h>1){const f=1/(1+0.12*(h-1));d*=f;if(__hinfo)__hinfo.far=Math.round((1-f)*100);}}}}catch(e){}
  return d;
};
const _doHit0=doHit;
doHit=function(wid,item){
  const m=S.me,w=S.wars.find(x=>x.id===wid);
  const free=(S.t-(m.fhAt||0))>=FH_MS,orig=m.energy;
  if(free&&m.energy<10)m.energy=10;
  __hw=w||null;__hinfo={far:0,free:false};
  const r=_doHit0(wid,item);
  __hw=null;
  if(typeof r==='number'){if(free){m.energy=orig;m.fhAt=S.t;__hinfo.free=true;}}
  else if(free)m.energy=orig;
  return r;
};
ACT.hit=d=>{
  const r=doHit(+d.w,d.item||null);
  if(typeof r==='string')return msg(r);
  const i=__hinfo||{};
  msg(`💥 ${fmt(r)} hasar!${i.free?' 🎁 saatlik ücretsiz vuruş':''}${i.far?` · 📍 cephe uzak: −%${i.far} (cepheye yaklaş)`:''}`,'ok');
};

/* --- Fabrika müzayedesi --- */
const AUC_AI=['Altay Holding','Borealis','Kızıltaş A.Ş.','Atlas Madencilik','Tuna Enerji','Bora Ltd','Çınar Grup'];
function aucNext(){return Math.max(0,(S.me.nextAuc||0)-S.t);}
function aucTick(){
  const m=S.me;if(!m||!m.facs)return;
  const a=m.auc;
  if(a){
    // yapay zekâ teklif verir
    const p=Math.min(0.9,(S.t-(a.lt||S.t))/(5*MIN)*0.6);a.lt=S.t;
    if(a.end>S.t&&a.price<a.level*18&&Math.random()<p){
      if(a.lead==='sen'){m.stor.gold+=a.paid||0;a.paid=0;L(`🔨 Müzayedede teklifin geçildi: ${RES_N[a.res]} fabrikası. Altının iade edildi.`,'warn');}
      a.price=Math.ceil(a.price*1.1)+1;a.lead=pick(AUC_AI);
    }
    if(S.t>=a.end){
      m.auc=null;m.nextAuc=S.t+20*MIN;
      if(a.lead==='sen'){
        const r=S.regions[a.region];
        if(m.facs.length<facSlots()&&r&&!m.facs.some(f=>f.region===a.region&&f.res===a.res)){
          m.facs.push({id:S.seq++,res:a.res,region:a.region,owner:r.state,level:a.level,stock:0});
          L(`🏆 Müzayedeyi kazandın: ${r.n} ${RES_N[a.res]} fabrikası (seviye ${a.level}).`,'ok');
        }else{m.stor.gold+=a.paid||0;L('Müzayede kazanıldı ama fabrika yeri/limiti uygun değil; altının iade edildi.','warn');}
      }else L(`🔨 Müzayede bitti: fabrikayı ${a.lead} aldı.`,'info');
    }
    return;
  }
  if(S.t<(m.nextAuc||0))return;
  const cand=[];regOf('A').forEach(r=>{if(r.moon)return;['gold','oil','ore'].forEach(k=>{if(r.res[k].m>0&&r.res[k].c>0&&!m.facs.some(f=>f.region===r.id&&f.res===k))cand.push([r.id,k]);});});
  if(!cand.length){m.nextAuc=S.t+HOUR;return;}
  const c=pick(cand),lv=3+flr(Math.random()*6);
  m.auc={res:c[1],region:c[0],level:lv,price:lv*5,lead:'ai',paid:0,end:S.t+15*MIN,lt:S.t};
}
const _int_c=integrate;
integrate=function(ms){_int_c(ms);try{aucTick();}catch(e){}};
ACT.aucBid=()=>{
  const m=S.me,a=m.auc;if(!a)return;
  if(a.lead==='sen')return msg('En yüksek teklif sende.','info');
  if(m.facs.length>=facSlots())return msg('Fabrika sınırına ulaştın.');
  const np=a.lead==='ai'?a.price:Math.ceil(a.price*1.1)+1;
  if(m.stor.gold<np)return msg(`${np} altın gerekir (depoda ${f1(m.stor.gold)}).`);
  m.stor.gold-=np;a.paid=np;a.price=np;a.lead='sen';msg(`Teklif verildi: ${np} altın.`,'ok');
};
function aucCard(){
  const m=S.me,a=m.auc;
  if(!a)return card('🔨 Fabrika müzayedesi',`<p class="dim">Yüksek seviyeli fabrikalar altınla satılır. Sonraki müzayede: ~${Math.ceil(aucNext()/MIN)} dk.</p>`);
  const r=S.regions[a.region],np=a.lead==='ai'?a.price:Math.ceil(a.price*1.1)+1;
  return card('🔨 Fabrika müzayedesi',`<div style="display:flex;justify-content:space-between;gap:8px"><span>${RES_I[a.res]} ${RES_N[a.res]} · ${esc(r.n)} · <b>seviye ${a.level}</b><div class="dim">Kalan ${fmtDur(a.end-S.t)} · en yüksek teklif: ${a.lead==='ai'?'yok':a.lead==='sen'?'sen':esc(a.lead)}</div></span><b>${a.price} 🥇</b></div>
  <div class="btns">${btn(`Teklif ver (${np} altın)`,'data-a="aucBid"','gold',a.lead==='sen')}</div><p class="dim">Kazanırsan fabrika direkt senin olur. Teklifin geçilirse altının iade edilir.</p>`);
}
function _append(h,c){const k=h.lastIndexOf('</div>');return k>0?h.slice(0,k)+c+h.slice(k):h+c;}
if(typeof tabCraft==='function'){const _tc=tabCraft;tabCraft=function(){return _append(_tc(),aucCard());};}

/* --- Kayıt yedeği (export / import) --- */
function bkText(){const c=Object.assign({},S);delete c.dirty;delete c.live;return btoa(unescape(encodeURIComponent(JSON.stringify(c))));}
ACT.bkExport=()=>{
  const t=bkText(),e=document.getElementById('bkTxt');if(e){e.value=t;try{e.focus();e.select();}catch(x){}}
  try{navigator.clipboard.writeText(t).then(()=>msg('Yedek kopyalandı. Bir yere yapıştırıp sakla.','ok'),()=>msg('Metni elle kopyala (kutuda seçili).','info'));}catch(x){msg('Metni elle kopyala (kutuda seçili).','info');}
};
ACT.bkImport=()=>{
  const e=document.getElementById('bkTxt');if(!e||!e.value.trim())return msg('Önce yedek metnini kutuya yapıştır.');
  try{
    const o=JSON.parse(decodeURIComponent(escape(atob(e.value.trim()))));
    if(!o||o.v!==2||!o.regions||!o.me||typeof o.me.money!=='number')throw 0;
    if(!confirm('Mevcut ilerlemen bu yedekle DEĞİŞTİRİLECEK. Devam edilsin mi?'))return;
    window.__noSave=true;localStorage.setItem(SAVE,JSON.stringify(o));location.reload();
  }catch(x){msg('Geçersiz yedek metni.');}
};
if(typeof tabSettings==='function'){const _ts=tabSettings;tabSettings=function(){
  return _append(_ts(),card('💾 Kayıt yedeği',`<p class="dim">İlerlemeni metin olarak yedekle; telefon değiştirirsen veya tarayıcı verisi silinirse buradan geri yükle.</p><textarea id="bkTxt" rows="3" style="width:100%" placeholder="Yedek metni burada görünür / buraya yapıştır"></textarea><div class="btns">${btn('📋 Yedeği kopyala','data-a="bkExport"','sm')}${btn('📥 Yedeği yükle','data-a="bkImport"','sm')}</div>`));
};}
/* ================= CEPHE HATTI'NDAN TAŞINANLAR (2): ev yatırımları, harita katmanları, dünya kartı, meclis çizimi, otomatik savaş modu ================= */
/* --- ev yatırımları: spor salonu, kütüphane, atölye (Yatırımlar sekmesinde görünür) --- */
INV.gym={i:'🏋️',n:'Spor salonu',d:'Her seviye savaş hasarı +%2',max:10,cost:l=>50000*Math.pow(1.7,l)};
INV.lib={i:'📚',n:'Kütüphane',d:'Her seviye öğrenme süresi −%2',max:10,cost:l=>50000*Math.pow(1.7,l)};
INV.ws={i:'🔧',n:'Atölye',d:'Her seviye silah/eşya üretim maliyeti −%2',max:10,cost:l=>50000*Math.pow(1.7,l)};
const _hd2=hitDamage;hitDamage=function(item){return _hd2(item)*(1+0.02*invL('gym'));};
const _lt2=learnTimeMs;learnTimeMs=function(k,g){return _lt2(k,g)*(1-0.02*invL('lib'));};
if(typeof itemCost==='function'){const _ic2=itemCost;itemCost=function(k,n){const c=_ic2(k,n),f=1-0.02*invL('ws'),o={};for(const x in c)o[x]=c[x]*f;return o;};}
/* --- harita veri katmanları --- */
const LAYS=[['o','Devlet'],['pop','Nüfus (yapay zekâ)'],['d','Gelişmişlik endeksi'],['h','Tıp endeksi'],['m','Askeri endeks'],['e','Eğitim endeksi'],['dev','Şehir seviyesi'],['gold','Altın rezervi'],['oil','Petrol rezervi'],['ore','Maden rezervi'],['uranium','Uranyum rezervi'],['diamonds','Elmas rezervi'],['war','Savaşlar']];
function layVal(r,k){const agg=(typeof BOTAGG!=='undefined')?BOTAGG:{reg:[]};
  if(k==='pop')return agg.reg[r.id]||0;if(k==='war')return S.wars.some(q=>q.state!=='done'&&q.region===r.id)?1:0;
  if(k==='dev')return (typeof devOf==='function')?devOf(r):0;
  if(RES.includes(k))return r.res[k].m;return (r.idx&&r.idx[k])||0;}
function lyColor(r){const k=UI.lay||'o';if(k==='o')return SCOL[r.state]||'#888';
  let mx=1;S.regions.forEach(q=>{const v=layVal(q,k);if(v>mx)mx=v;});const t=Math.min(1,layVal(r,k)/mx);
  return `hsl(${Math.round(220-t*180)},70%,${Math.round(30+t*28)}%)`;}
ACT.lay=d=>{UI.lay=d.v;};
function laySel(){const k=UI.lay||'o';let mx=0;if(k!=='o')S.regions.forEach(q=>{const v=layVal(q,k);if(v>mx)mx=v;});
  return `<div class="card"><div class="row" style="margin:2px 0"><select id="laySel" onchange="ACT.lay({v:this.value});S.dirty=true;render&&render()">${LAYS.map(l=>`<option value="${l[0]}" ${k===l[0]?'selected':''}>Veri: ${l[1]}</option>`).join('')}</select></div>${k==='o'?'':`<p class="hint">Mavi = düşük, kırmızı/turuncu = yüksek (en yüksek: ${fmt(mx)}).</p>`}</div>`;}
const _tw2=tabWorld;tabWorld=function(){const h=_tw2();return h.replace('<div id="wmWrap"',laySel()+'<div id="wmWrap"');};
/* --- dünya kartı (Ana Sayfa) --- */
function worldCard2(){const agg=(typeof BOTAGG!=='undefined')?BOTAGG:{reg:[]},pop=(agg.reg||[]).reduce((a,b)=>a+(b||0),0),wars=S.wars.filter(w=>w.state==='on').length,sts=Object.keys(STATE_N).filter(s=>regOf(s).length).length;
  const c=(t,v,a)=>`<div class="card" ${a||''} style="text-align:center;padding:8px 4px;margin:0;cursor:pointer"><div class="dim" style="font-size:12px">${t}</div><b>${v}</b></div>`;
  return `<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:8px 0">${c('Nüfus',fmt(pop),'data-a="tab" data-t="world"')}${c('Savaş',wars,'data-a="tab" data-t="war"')}${c('Devlet',sts,'data-a="tab" data-t="state"')}${c('Şehir',S.regions.length,'data-a="tab" data-t="map"')}</div>`;}
if(typeof tabHome==='function'){const _th2=tabHome;tabHome=function(){return _th2().replace('<h2>🏠 Ana Sayfa</h2>','<h2>🏠 Ana Sayfa</h2>'+worldCard2());};}
/* --- meclis yarım daire --- */
const PCOL2=['#f0c040','#58a6ff','#ff6b5e','#3fb950','#b48cff','#7fe0e0','#e67e22','#8b949e'];
function hemiCard2(){const a=A();if(!a.parlSize)return '';const st=seatsOf(),ps=a.parties.slice().sort((x,y)=>(st[y.id]||0)-(st[x.id]||0)).filter(p=>(st[p.id]||0)>0),N=a.parlSize,rows=4,rad=[],seats=[];let tot=0;
  for(let r=0;r<rows;r++)rad.push(70+r*26);const sum=rad.reduce((x,y)=>x+y,0);
  rad.forEach((R,r)=>{const n=r===rows-1?N-tot:Math.round(N*R/sum);tot+=n;for(let k=0;k<n;k++){const an=Math.PI*(n===1?.5:k/(n-1));seats.push({a:an,x:150-R*Math.cos(an),y:130-R*Math.sin(an)});}});
  seats.sort((p,q)=>p.a-q.a);const col=[];let i=0;ps.forEach((p,pi)=>{for(let k=0;k<st[p.id]&&i<seats.length;k++)col[i++]=p.id==='me'?'#58a6ff':PCOL2[pi%PCOL2.length];});
  return `<div class="card"><h3>Meclis dağılımı</h3><svg viewBox="0 0 300 140" style="width:100%;height:auto">${seats.map((q,j)=>`<circle cx="${q.x.toFixed(1)}" cy="${q.y.toFixed(1)}" r="${N>100?3.2:4.2}" fill="${col[j]||'#30363d'}"/>`).join('')}</svg><p class="dim" style="font-size:12px">${ps.map((p,pi)=>`<span style="color:${p.id==='me'?'#58a6ff':PCOL2[pi%PCOL2.length]}">●</span> ${esc(p.n)} ${st[p.id]}`).join(' · ')}</p></div>`;}
if(typeof tabParty==='function'){const _tp2=tabParty;tabParty=function(){return _tp2().replace(/(<h2>🗳️ Meclis[^<]*<\/h2>)/,'$1'+hemiCard2());};}
/* --- otomatik savaş modu --- */
ACT.autoMode=d=>{auOf().mode=d.v;};
if(typeof tabAuto==='function'){const _ta2=tabAuto;tabAuto=function(){const a=auOf(),h=_ta2();
  return h.replace('<h3>Ayarlar</h3>',`<h3>Ayarlar</h3><div class="btns">${btn('⚔️ Maksimum vuruş','data-a="autoMode" data-v="max"',a.mode==='hourly'?'sm':'sm gold')}${btn('🎁 Saatte bir (ücretsiz vuruş)','data-a="autoMode" data-v="hourly"',a.mode==='hourly'?'sm gold':'sm')}</div><p class="dim" style="font-size:12px">Saatte bir modu yalnızca saatlik ücretsiz vuruşu kullanır; enerjin harcanmaz.</p>`);};}
/* ================= ETKİLEŞİM: isimlere dokun → bilgi kartı (şehir, devlet, kişi, parti, ittifak) ================= */
const ENT={stack:[],cur:null,idx:null,idxT:0};
const ekey=(k,id)=>k+':'+id;
const eLink=(k,id,label)=>`<a class="lk" data-a="ent" data-k="${k}" data-id="${esc(String(id))}">${label===undefined?esc(entName(k,id)):label}</a>`;
function entName(k,id){
  if(k==='city')return (S.regions[+id]||{}).n||'?';
  if(k==='state')return nameOf(id);
  if(k==='party'){const p=A().parties.find(x=>x.id===id);return p?p.n:'?';}
  if(k==='ally'){const a=AL.list[id];return a?a.n:'?';}
  if(k==='player'){const r=entPlayerRow(id);return r?r.name:'?';}
  return '?';
}
/* oyuncu verisi: kendin, gerçek oyuncular (Firebase), sıralama satırları, yapay zekâ oyuncular */
function entPlayerRow(id){
  const me=(typeof MP!=='undefined'&&MP.ok&&MP.uid)?MP.uid():null;
  if(id==='me'||(me&&id===me)){const s=(typeof MP!=='undefined'&&MP.summary)?MP.summary():{};return Object.assign({id:id,self:true},s,{name:S.me.name,lv:S.me.level});}
  const p=(MP.players||{})[id];if(p)return Object.assign({id:id},p);
  if(typeof botRowById==='function'&&/^bot_/.test(id)){const b=botRowById(id);if(b)return b;}
  const l=(LB.rows||[]).find(x=>x.id===id);if(l)return Object.assign({},l,{id:id,partial:true});
  return null;
}
/* isim → varlık dizini (otomatik bağlantı için) */
function entIndex(){
  if(ENT.idx&&Date.now()-ENT.idxT<2500)return ENT.idx;
  const map={},add=(n,k,id)=>{n=String(n||'').replace(/^🤖\s*/,'').trim();if(n.length<3||map[n])return;map[n]=[k,id];};
  S.regions.forEach(r=>add(r.n,'city',r.id));
  Object.keys(S.states).forEach(s=>add(S.states[s].n,'state',s));
  A().parties.forEach(p=>add(p.n,'party',p.id));
  try{for(const id in AL.list)add(AL.list[id].n,'ally',id);}catch(e){}
  const me=(typeof MP!=='undefined'&&MP.ok&&MP.uid)?MP.uid():null;
  try{for(const id in (MP.players||{}))if(id!==me)add(MP.players[id].name,'player',id);}catch(e){}
  try{(LB.rows||[]).forEach(r=>{if(r.id!==me&&r.id!=='me')add(r.name,'player',r.id);});}catch(e){}
  try{if(typeof botRows==='function')botRows(60).forEach(b=>add(b.name,'player',b.id));}catch(e){}
  const names=Object.keys(map).sort((a,b)=>b.length-a.length);
  let re=null;
  if(names.length)re=new RegExp('(?<![\\p{L}\\p{N}_])(?:'+names.map(n=>n.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')+')(?![\\p{L}\\p{N}_])','gu');
  ENT.idx={map:map,re:re};ENT.idxT=Date.now();return ENT.idx;
}
const SKIP_TAGS=/^(A|BUTTON|SELECT|OPTION|TEXTAREA|INPUT|SCRIPT|STYLE|H1|H2|SUMMARY|TH|LABEL|PRE|SVG|CANVAS)$/;
function linkify(root){
  if(!root)return;
  const ix=entIndex();if(!ix.re)return;
  const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null),hits=[];
  let n;while((n=w.nextNode())){
    const t=n.nodeValue;if(!t||t.length<3)continue;
    let p=n.parentNode,bad=false;
    while(p&&p!==root){if(p.nodeType===1&&(SKIP_TAGS.test(p.tagName)||p.hasAttribute('data-a')||p.classList.contains('nolk'))){bad=true;break;}p=p.parentNode;}
    if(!bad)hits.push(n);
  }
  hits.forEach(node=>{
    const t=node.nodeValue;ix.re.lastIndex=0;
    let m,last=0,frag=null;
    while((m=ix.re.exec(t))){
      const e=ix.map[m[0]];if(!e)continue;
      frag=frag||document.createDocumentFragment();
      if(m.index>last)frag.appendChild(document.createTextNode(t.slice(last,m.index)));
      const a=document.createElement('a');a.className='lk';a.dataset.a='ent';a.dataset.k=e[0];a.dataset.id=String(e[1]);a.textContent=m[0];frag.appendChild(a);
      last=m.index+m[0].length;
    }
    if(frag){if(last<t.length)frag.appendChild(document.createTextNode(t.slice(last)));node.parentNode.replaceChild(frag,node);}
  });
}
{const _ar=(typeof afterRender==='function')?afterRender:null;
 afterRender=function(){if(_ar)_ar.apply(this,arguments);try{linkify($('main'));}catch(e){}};}

/* ---- pencere ---- */
const eRow=(a,b)=>`<tr><td class="dim">${a}</td><td class="num">${b}</td></tr>`;
function entCity(id){
  const r=S.regions[+id];if(!r)return '<p>Bulunamadı.</p>';
  const m=S.me,c=critOf(r.id),here=m.loc===r.id,home=m.res===r.id,K=c&&CRIT_KINDS.find(x=>x[0]===c.k);
  const wars=S.wars.filter(w=>w.state!=='done'&&w.region===r.id);
  const pls=Object.keys(MP.players||{}).filter(u=>MP.players[u].loc===r.n||MP.players[u].res===r.n).slice(0,12);
  const botN=((typeof BOTAGG!=='undefined'&&BOTAGG.reg&&BOTAGG.reg[r.id])||0);
  const bl=Object.keys(BUILD).filter(k=>(r.b[k]||0)>0);
  const hops=hopsTo(m.loc,r.id);
  let h=`<p>${eLink('state',r.state)}${r.coast?' · 🌊 kıyı':''}${r.moon?' · 🌙 Ay':''}${here?' · 📍 buradasın':''}${home?' · 🏠 ikametin':''}${c?` · ⭐ ${K[2]} şehri`:''}</p>
   <table>${eRow('👥 Nüfus',fmt(cityPop(r)))}${eRow('📊 İndeks','❤️'+r.idx.h+' 🎖️'+r.idx.m+' 🎓'+r.idx.e+' 🏘️'+r.idx.d)}${eRow('🏙️ Geliştirme','sv '+devOf(r)+'/10')}${eRow('🧑‍🤝‍🧑 Oyuncu',pls.length+' gerçek · ~'+botN+' YZ')}</table>
   <p class="dim">⛏️ ${RES.filter(k=>r.res[k].m>0).map(k=>`${RES_I[k]} ${fmt(r.res[k].c)}/${fmt(r.res[k].m)}`).join(' · ')||'kaynak yok'}</p>
   <p>🏗️ ${bl.length?bl.map(k=>`${BUILD[k].i} ${BUILD[k].n}×${r.b[k]}`).join(' · '):'<span class="dim">bina yok</span>'}</p>`;
  if(wars.length)h+=wars.map(w=>`<p class="bad">⚔️ ${eLink('state',w.att)} → ${eLink('state',w.def)} (${WTYPE[w.type]}) · ${w.state==='prep'?'başlamasına '+cd(w.start):'bitişine '+cd(w.end)}</p>`).join('');
  if(pls.length)h+=`<p>Burada: ${pls.map(u=>eLink('player',u)).join(', ')}</p>`;
  h+=`<p class="dim">Komşular: ${r.adj.map(j=>eLink('city',j)).join(', ')}</p>`;
  h+=`<div class="btns">${btn('📋 Şehir sayfası',`data-a="entGo" data-k="city" data-id="${r.id}"`,'blue sm')}${here?'':btn(`🧳 Git (${r.moon?'2sa':hops>=99?'yol yok':hops*20+'dk'})`,`data-a="entTravel" data-id="${r.id}"`,'sm',!!m.travel||(hops>=99&&!r.moon))}</div>`;
  return h;
}
function entState(k){
  const s=S.states[k];if(!s)return '<p>Bulunamadı.</p>';
  const regs=regOf(k),wars=atWar(k),rel=Math.round(relTo('A',k));
  const pop=regs.reduce((a,r)=>a+cityPop(r),0);
  let h=`<table>${eRow('🏛️ Rejim',esc(s.gov||'—'))}${eRow('👤 Lider',esc(k==='A'&&s.leaderMe?S.me.name:(s.leader||'—')))}${eRow('🏙️ Şehir',regs.length)}${eRow('👥 Nüfus',fmt(pop))}${eRow('🎖️ Askeri güç',f1(powerOf(k)))}${k==='A'?'':eRow('🤝 İlişki',`<b class="${rel>20?'ok':rel<-20?'bad':'warn'}">${rel}</b>`)}</table>
   <p>🏙️ ${regs.map(r=>eLink('city',r.id)).join(', ')||'—'}</p>`;
  if(wars.length)h+=wars.map(w=>`<p class="bad">⚔️ ${eLink('state',w.att)} → ${eLink('state',w.def)} · ${eLink('city',w.region)}</p>`).join('');
  if(k==='A'&&s.parties){const st=seatsOf();h+=`<p class="dim">Meclis: ${s.parties.map(p=>`${eLink('party',p.id)} ${st[p.id]||0}`).join(' · ')}</p>`;}
  h+=`<div class="btns">${k==='A'?btn('🏛️ Devlet sayfası','data-a="entGo" data-k="state" data-id="A"','blue sm'):btn('🕵️ İstihbarat','data-a="entGo" data-k="spy" data-id="'+k+'"','sm')}</div>`;
  return h;
}
function entPlayer(id){
  const r=entPlayerRow(id);if(!r)return '<p>Oyuncu bilgisi bulunamadı.</p>';
  const ago=r.seen?Math.max(0,Date.now()-r.seen):null;
  const city=n=>{const c=S.regions.find(x=>x.n===n);return c?eLink('city',c.id):esc(n||'—');};
  const pty=r.party?(A().parties.find(p=>p.n===r.party)):null;
  let h=`<p class="dim">${esc(r.role||r.rank||'')}${r.admin?' 👑':''}${r.bot?' · 🤖 yapay zekâ':''}${r.self?' · (sen)':''}</p>
   <table>${eRow('⭐ Seviye',r.lv)}${r.str!==undefined?eRow('💪 Güç / 🎓 Eğitim / 🫀 Dayanıklılık',r.str+' / '+r.edu+' / '+r.end):''}${r.money!==undefined?eRow('💰 Servet',fmt(r.money)+'₺'):''}
   ${r.loc?eRow('📍 Bulunduğu şehir',city(r.loc)):''}${r.res?eRow('🏠 İkamet',city(r.res)):''}${r.party!==undefined?eRow('🗳️ Parti',pty?eLink('party',pty.id):(esc(r.party)||'partisiz')):''}
   ${r.paper?eRow('📰 Gazete',esc(r.paper)):''}${r.works!==undefined?eRow('⛏️ Çalışma / ⚔️ vuruş / 🏭 fabrika',r.works+' / '+(r.hits||0)+' / '+(r.facs||0)):''}${r.tax!==undefined?eRow('🧾 Ödediği vergi',fmt(r.tax)+'₺'):''}${r.dmg!==undefined?eRow('💥 Verilen hasar',fmt(r.dmg)):''}
   ${ago!==null?eRow('🕒 Son görülme',ago<90000?'<b class="ok">çevrimiçi</b>':fmtDur(ago)+' önce'):''}</table>`;
  if(r.partial)h+='<p class="hint">Ayrıntılı bilgi için oyuncunun giriş yapmış olması gerekir.</p>';
  if(!r.self&&!r.bot&&MP.ok)h+=`<div class="btns">${btn('💬 Mesaj gönder',`data-a="entDm" data-id="${esc(id)}" data-name="${esc(r.name)}"`,'blue sm')}</div>`;
  if(S.me.admin||MP.role==='admin')h+=`<div class="btns">${btn('👑 Yönetici panelinde aç',`data-a="entAdm" data-id="${esc(id)}"`,'gold sm')}</div>`;
  return h;
}
function entParty(id){
  const a=A(),p=a.parties.find(x=>x.id===id);if(!p)return '<p>Bulunamadı.</p>';
  const st=seatsOf(),mem=Object.keys(MP.players||{}).filter(u=>MP.players[u].party===p.n).slice(0,15);
  let h=`<table>${eRow('👤 Lider',esc(p.leaderName||'—'))}${eRow('🪑 Sandalye',(st[p.id]||0)+' / '+a.parlSize)}${eRow('👥 Üye',fmt(p.members||0))}${eRow('📈 Destek',(p.supp!==undefined?f1(p.supp)+'%':'—'))}${eRow('🏛️ İktidar',a.rulingParty===p.id?'<b class="ok">evet</b>':'hayır')}</table>`;
  if(mem.length)h+=`<p>Üyeler: ${mem.map(u=>eLink('player',u)).join(', ')}</p>`;
  h+=`<div class="btns">${btn('🗳️ Parti sayfası','data-a="entGo" data-k="party"','blue sm')}${S.me.party?'':btn('Katıl',`data-a="joinParty" data-p="${p.id}"`,'sm',S.me.level<5)}</div>`;
  return h;
}
function entAlly(id){
  const a=AL.list[id];if(!a)return '<p>Bulunamadı.</p>';
  const ms=Object.keys(a.m||{});
  return `<table>${eRow('👑 Kurucu',a.o?eLink('player',a.o,esc(a.on||'?')):esc(a.on||'?'))}${eRow('⭐ Seviye',+a.lv||0)}${eRow('💰 Kasa',fmt(+a.bank||0)+'₺')}${eRow('👥 Üye',ms.length)}</table>
   <p>${ms.slice(0,20).map(u=>eLink('player',u,esc(a.m[u]))).join(', ')}</p>
   <div class="btns">${btn('🛡️ İttifak sayfası','data-a="entGo" data-k="ally"','blue sm')}</div>`;
}
const ENT_I={city:'🏙️',state:'🏳️',player:'👤',party:'🗳️',ally:'🛡️'};
function entDraw(){
  const c=ENT.cur;if(!c){$('modal-root').innerHTML='';return;}
  let body='';
  try{body=({city:entCity,state:entState,player:entPlayer,party:entParty,ally:entAlly}[c.k]||(()=>'<p>?</p>'))(c.id);}catch(e){body='<p class="bad">Bilgi alınamadı: '+esc(String(e&&e.message||e))+'</p>';}
  const root=$('modal-root');
  root.innerHTML=`<div class="modal" data-a="entClose"><div class="box" data-a="entNop" style="max-height:86vh;overflow:auto"><div class="btns" style="justify-content:space-between;margin-bottom:6px">${ENT.stack.length?btn('← Geri','data-a="entBack"','sm'):'<span></span>'}${btn('✕ Kapat','data-a="entClose"','sm')}</div>
   <h3 class="nolk">${ENT_I[c.k]||''} ${esc(entName(c.k,c.id))}</h3>${body}</div></div>`;
  linkify(root.querySelector('.box'));
}
ACT.ent=d=>{if(ENT.cur)ENT.stack.push(ENT.cur);if(ENT.stack.length>20)ENT.stack.shift();ENT.cur={k:d.k,id:d.id};entDraw();S.dirty=false;};
ACT.entBack=()=>{ENT.cur=ENT.stack.pop()||null;entDraw();S.dirty=false;};
ACT.entClose=()=>{ENT.cur=null;ENT.stack=[];entDraw();S.dirty=false;};
ACT.entNop=()=>{S.dirty=false;};
ACT.entGo=d=>{
  const k=d.k;ENT.cur=null;ENT.stack=[];entDraw();
  if(k==='city')ACT.goCity({id:d.id});else if(k==='state')UI.tab='state';else if(k==='party')UI.tab='party';else if(k==='ally')UI.tab='ally';else if(k==='spy')UI.tab='spy';
  window.scrollTo(0,0);
};
ACT.entTravel=d=>{ENT.cur=null;ENT.stack=[];entDraw();ACT.travel({to:d.id});};
ACT.entDm=d=>{ENT.cur=null;ENT.stack=[];entDraw();if(typeof ACT.dmOpen==='function')ACT.dmOpen({id:d.id,name:d.name});UI.tab='msg';window.scrollTo(0,0);};
ACT.entAdm=d=>{ENT.cur=null;ENT.stack=[];entDraw();MP.sel=d.id;UI.tab='adm';window.scrollTo(0,0);};
/* modal açıkken canlı verileri tazele (savaş geri sayımı, çevrimiçi durumu) */
setInterval(()=>{try{if(ENT.cur&&document.querySelector('#modal-root .box[data-a="entNop"]')){const bx=document.querySelector('#modal-root .box');const st=bx.scrollTop;entDraw();const b2=document.querySelector('#modal-root .box');if(b2)b2.scrollTop=st;}}catch(e){}},5000);

/* ---- Ana Sayfa: Rival Regions tarzı dokunulabilir kutucuklar ---- */
function homeTiles2(){
  const m=S.me,r=myReg(),hr=homeReg(),st=hr.state,regs=regOf(st),a=S.states[st];
  const t=(ic,tt,v,attr)=>`<div class="card" ${attr} style="text-align:center;padding:8px 4px;margin:0;cursor:pointer"><div class="dim" style="font-size:12px">${tt}</div><b>${ic} ${v}</b></div>`;
  const seats=(st==='A')?(seatsOf()[(myParty()||{}).id]||0):'—';
  const ws=S.wars.filter(w=>w.state==='on'&&(w.att===st||w.def===st)).length;
  return `<div class="dim" style="margin-top:6px">${eLink('city',hr.id,'Bu senin bölgen: '+esc(hr.n))}</div>
   <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:6px 0">${t('👥','Nüfus',fmt(cityPop(hr)),`data-a="ent" data-k="city" data-id="${hr.id}"`)}${t('🏗️','Bina',Object.keys(BUILD).reduce((x,k)=>x+(hr.b[k]||0),0),`data-a="goCity" data-id="${hr.id}"`)}${t('🗳️','Parti',A().parties.length,'data-a="tab" data-t="party"')}${t('🏭','Fabrika',m.facs.length,'data-a="tab" data-t="craft"')}</div>
   <div class="dim">${eLink('state',st,'Devlet: '+esc(nameOf(st)))}</div>
   <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:6px 0">${t('🏛️','Meclis',(a&&a.parlSize)||'—','data-a="tab" data-t="party"')}${t('🏙️','Şehir',regs.length,'data-a="tab" data-t="map"')}${t('⚔️','Savaş',ws,'data-a="tab" data-t="war"')}${t('🎖️','Güç',f1(powerOf(st)),`data-a="ent" data-k="state" data-id="${st}"`)}</div>`;
}
if(typeof tabHome==='function'){const _th3=tabHome;tabHome=function(){return _th3().replace(/(<\/div>\s*<div class="card glow">)/,'$1').replace('<h2>🏠 Ana Sayfa</h2>','<h2>🏠 Ana Sayfa</h2>'+homeTiles2());};}
/* ================= ÖZEL GÖREVLER (Rival Regions esinli): Geri Sayım, Evliya Çelebi, Devri Âlem, Emekçi Kahraman, Bölge Ziyareti ================= */
const RQ_TRAVEL_NEED=2*HOUR,RQ_TOUR_N=6,RQ_TOUR_T=80*HOUR,RQ_COUNT_WIN=5*MIN;
function rqS(){
  const m=S.me;m.rq=m.rq||{};const q=m.rq;
  q.geri=q.geri||{n:0,last:0};
  q.evl=q.evl||{ms:0,day:'',done:false};
  q.tour=q.tour||null;
  q.emek=q.emek||{days:[],last:m.works||0,claimed:''};
  q.visit=q.visit||null;
  return q;
}
const rqDay=()=>(typeof dayKey==='function'?dayKey():new Date().toISOString().slice(0,10));
function rqTourNew(){
  const q=rqS(),m=S.me,pool=S.regions.filter(r=>!r.moon).map(r=>r.id).sort(()=>Math.random()-0.5).slice(0,RQ_TOUR_N);
  q.tour={start:S.t,end:S.t+RQ_TOUR_T,targets:pool,seen:{}};
}
function rqVisitNew(){
  const q=rqS(),m=S.me,c=S.regions.filter(r=>!r.moon&&r.id!==m.loc);
  q.visit={to:c[Math.floor(Math.random()*c.length)].id};
}
let _rqT=0,_rqLast=0;
function rqTick(){
  if(!S||!S.me)return;
  const now=Date.now();if(now-_rqT<2000)return;const dt=_rqLast?Math.min(now-_rqLast,60e3):0;_rqT=now;_rqLast=now;
  const m=S.me,q=rqS(),d=rqDay();
  // Evliya Çelebi: gün içinde yolda geçen süre
  if(q.evl.day!==d){q.evl={ms:0,day:d,done:false};}
  if(m.travel&&!q.evl.done)q.evl.ms+=dt;
  // Devri âlem
  if(!q.tour||(q.tour.end<=S.t&&!q.tour.done))rqTourNew();
  if(!q.tour.done&&!m.travel&&q.tour.targets.includes(m.loc)&&!q.tour.seen[m.loc]){q.tour.seen[m.loc]=1;toast('🌍 Devri Âlem: '+S.regions[m.loc].n+' ziyaret edildi ('+Object.keys(q.tour.seen).length+'/'+RQ_TOUR_N+')','ok');S.dirty=true;}
  // Bölge ziyareti
  if(!q.visit)rqVisitNew();
  if(q.visit&&!m.travel&&m.loc===q.visit.to&&!q.visit.ok){q.visit.ok=true;S.dirty=true;}
  // Emekçi kahraman: art arda çalışılan günler
  if((m.works||0)>q.emek.last){q.emek.last=m.works||0;if(q.emek.days[q.emek.days.length-1]!==d)q.emek.days.push(d);if(q.emek.days.length>14)q.emek.days.shift();}
}
function rqStreak(){
  const q=rqS(),ds=q.emek.days;if(!ds.length)return 0;
  const key=t=>new Date(t).toLocaleDateString('sv');let n=0,t=Date.now();
  if(!ds.includes(key(t)))t-=864e5;
  while(ds.includes(key(t))){n++;t-=864e5;}
  return n;
}
if(typeof questTick==='function'){const _qt0=questTick;questTick=function(){_qt0.apply(this,arguments);try{rqTick();}catch(e){}};}
/* Geri Sayım Hasarı: savaşın son 5 dakikasında (elle) vuruş → kalıcı +1 kuvvet (günde bir kez) */
let _inAuto=false;
if(typeof autoRun==='function'){const _ar0=autoRun;autoRun=function(){_inAuto=true;try{return _ar0.apply(this,arguments);}finally{_inAuto=false;}};}
if(typeof doHit==='function'){const _dh0=doHit;doHit=function(wid,item){
  const w=S.wars.find(x=>x.id===+wid),res=_dh0.apply(this,arguments);
  try{if(typeof res!=='string'&&w&&w.state==='on'&&w.end-S.t<=RQ_COUNT_WIN&&!_inAuto){
    const g=rqS().geri;if(S.t-g.last>=DAY){g.last=S.t;g.n++;S.me.str++;L('⏱️ Geri Sayım Hasarı! Savaşın son dakikalarında vurdun: kuvvet +1 (kalıcı).','ok');toast('⏱️ Geri Sayım ödülü: Kuvvet +1','ok');}}}catch(e){}
  return res;};}
ACT.rqClaim=d=>{
  const m=S.me,q=rqS(),k=d.k,gold=n=>{m.stor.gold=Math.min(storCap(),m.stor.gold+n);};
  if(k==='evl'){if(!q.evl.done&&q.evl.ms>=RQ_TRAVEL_NEED){q.evl.done=true;m.end++;msg('🧳 Evliya Çelebi: dayanıklılık +1 (kalıcı)!','ok');L('🧳 Evliya Çelebi madalyası: dayanıklılık +1.','ok');}}
  else if(k==='tour'){const t=q.tour;if(t&&!t.done&&Object.keys(t.seen).length>=RQ_TOUR_N){t.done=true;gold(16);m.money+=100000;msg('🌍 Devri Âlem tamam: +16 altın +100.000₺','ok');L('🌍 80 Saatte Devri Âlem tamamlandı: +16 altın.','ok');setTimeout(()=>{try{if(S.me.rq.tour&&S.me.rq.tour.done){S.me.rq.tour=null;}}catch(e){}},0);}}
  else if(k==='emek'){const d0=rqDay();if(q.emek.claimed!==d0&&rqStreak()>=5){q.emek.claimed=d0;m.energy=Math.min(150,m.energy+60);gold(5);msg('⛏️ Emekçi Kahraman: +60 enerji +5 altın','ok');L('⛏️ Emekçi Kahraman: 5 gün üst üste çalıştın.','ok');q.emek.days=[];}}
  else if(k==='visit'){if(q.visit&&q.visit.ok){gold(3);m.money+=20000;msg('📍 Bölge ziyareti: +3 altın +20.000₺','ok');q.visit=null;rqVisitNew();}}
};
function rqRow(ic,t,desc,cur,max,btnHtml){return `<div class="card"><h3>${ic} ${t}</h3><p class="dim">${desc}</p>${max?bar(Math.min(cur,max),max,cur>=max?'#3fb950':undefined):''}${btnHtml||''}</div>`;}
function rqCard(){
  const q=rqS(),m=S.me,d=rqDay();
  const tr=q.tour,seen=tr?Object.keys(tr.seen).length:0,vs=q.visit,st=rqStreak();
  let h='<div class="panel"><h2>🌟 Özel görevler</h2><div class="grid">';
  h+=rqRow('⏱️','Geri Sayım Hasarı','Bir savaşın <b>son 5 dakikasında</b> elle vuruş yap (otomatik mod sayılmaz): kalıcı <b>kuvvet +1</b>. Günde bir kez.',0,0,`<p>Bu görevi <b>${q.geri.n}</b> kez yaptın.${S.t-q.geri.last<DAY?` <span class="dim">Yeniden: ${cd(q.geri.last+DAY)}</span>`:''}</p>`);
  h+=rqRow('🧳','Evliya Çelebi','Bir günde en az <b>2 saat</b> bölgeler arasında yolculuk et: kalıcı <b>dayanıklılık +1</b>.',q.evl.ms,RQ_TRAVEL_NEED,`<p class="dim">${fmtDur(Math.min(q.evl.ms,RQ_TRAVEL_NEED))} / ${fmtDur(RQ_TRAVEL_NEED)}${q.evl.done?' · bugün alındı ✓':''}</p>${btn(q.evl.done?'Bugün alındı ✓':'Ödülü al','data-a="rqClaim" data-k="evl"','gold sm',q.evl.done||q.evl.ms<RQ_TRAVEL_NEED)}`);
  if(tr)h+=rqRow('🌍','80 Saatte Devri Âlem',`Şu şehirlerin hepsini <b>${fmtDur(Math.max(0,tr.end-S.t))}</b> içinde ziyaret et: ${tr.targets.map(i=>`<span class="${tr.seen[i]?'ok':''}">${tr.seen[i]?'✅ ':''}${eLink('city',i)}</span>`).join(', ')}. Ödül: <b>16 altın</b>.`,seen,RQ_TOUR_N,`<p class="dim">${seen}/${RQ_TOUR_N}</p>${btn('Ödülü al','data-a="rqClaim" data-k="tour"','gold sm',seen<RQ_TOUR_N)}`);
  h+=rqRow('⛏️','Emekçi Kahraman','<b>5 gün üst üste</b> çalış: +60 enerji ve +5 altın.',Math.min(st,5),5,`<p class="dim">Seri: ${st} gün ${[0,1,2,3,4].map(i=>i<st?'✅':'⬜').join('')}</p>${btn('Ödülü al','data-a="rqClaim" data-k="emek"','gold sm',st<5||q.emek.claimed===d)}`);
  if(vs){const r=S.regions[vs.to];h+=rqRow('📍','Bölgeyi ziyaret et',`Şuraya git: ${eLink('city',vs.to)} (${esc(nameOf(r.state))}). Ödül: <b>3 altın + 20.000₺</b>.`,vs.ok?1:0,1,`${btn(vs.ok?'Ödülü al':(m.loc===vs.to?'Ulaştın…':'Yoldaş: şehri aç'),vs.ok?'data-a="rqClaim" data-k="visit"':`data-a="ent" data-k="city" data-id="${vs.to}"`,vs.ok?'gold sm':'sm')}`);}
  return h+'</div></div>';
}
if(typeof tabQuest==='function'){const _tq3=tabQuest;tabQuest=function(){return _tq3()+rqCard();};}
