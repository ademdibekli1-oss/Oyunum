/* ================= BAŞLAT ================= */
function offlineModal(since,secs){
  const items=S.log.filter(l=>l.t>since).reverse();
  $('modal-root').innerHTML=`<div class="modal"><div class="box"><h3>⏰ Siz yokken (${fmtDur(secs*1000)})</h3><div class="log tall">${items.map(l=>`<div class="${l.c}">[${fmtT(l.t)}] ${esc(l.m)}</div>`).join('')||'<div class="dim">Önemli bir şey olmadı.</div>'}</div><button class="act" onclick="this.closest('.modal').remove()">Tamam</button></div></div>`;
}
function init(){
  MP.loadCfg();S=load()||newState();S.adm=S.adm||{claimed:{},collected:0};S.bots=S.bots||[];if(typeof botMigrate==='function')botMigrate();S.me.taxPaid=S.me.taxPaid||0;
  const real=Date.now(),away=clamp(real-(S.savedReal||real),0,S.me.admin?7*DAY:OFFLINE_CAP);
  S.live=false;const since=S.t;
  if(away>2*MIN)advance(S.t+away);
  S.live=true;S.savedReal=real;
  if(away>2*MIN)offlineModal(since,away/1000);
  S.dirty=false;render();
  let last=Date.now();
  setInterval(()=>{const n=Date.now(),dt=(n-last)*SPEED;last=n;advance(S.t+dt);
    if(S.dirty){bgRender();}else{tickUI();alerts();}},1000);
  setInterval(save,10000);mpWrap();if(MP.cfg)MP.connect();setInterval(()=>MP.sync(),15000);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)save();});
  window.addEventListener('pagehide',save);
}
/* ================= DÜNYA HARİTASI — kara/deniz/konum verisi harita.js dosyasından gelir ================= */
// harita.js yüklenemezse oyun yine çalışır (harita boş görünür, Şehirler listesi etkilenmez).
const HM=(typeof HARITA!=='undefined'&&HARITA&&HARITA.land)?HARITA:{ver:0,land:[],water:[],reg:REG0.map((r,i)=>r[3]?null:[-165+(i%15)*23,62-Math.floor(i/15)*13])};
const LAND=HM.land,WATER=HM.water,REG_LL=HM.reg;
// Doğal Dünya (Natural Earth 1) izdüşümü
function proj(lon,lat){
  const l=lon*Math.PI/180,p=lat*Math.PI/180,p2=p*p,p4=p2*p2;
  const x=l*(0.8707-0.131979*p2+p4*(-0.013791+p4*(0.003971*p2-0.001529*p4)));
  const y=p*(1.007226+p2*(0.015085+p4*(-0.044475+0.028874*p2-0.005916*p4)));
  return [x*160+500,-y*160+260];
}
const GEO_W=1000,GEO_H=520;
// bölge kimliği → [boylam, enlem] (ay üsleri için null)
const MOON_XY=[[0.30,0.5],[0.70,0.5]]; // ay kutusu içi oransal konumlar
const GEO={land:null,water:null,pts:[],cells:[]};
function geoInit(){
  if(GEO.land)return;
  GEO.land=new Path2D();LAND.forEach(poly=>{poly.forEach((p,i)=>{const q=proj(p[0],p[1]);i?GEO.land.lineTo(q[0],q[1]):GEO.land.moveTo(q[0],q[1]);});GEO.land.closePath();});
  GEO.water=new Path2D();WATER.forEach(poly=>{poly.forEach((p,i)=>{const q=proj(p[0],p[1]);i?GEO.water.lineTo(q[0],q[1]):GEO.water.moveTo(q[0],q[1]);});GEO.water.closePath();});
  GEO.pts=REG_LL.map(ll=>ll?proj(ll[0],ll[1]):null);
  // Voronoi hücreleri (yarım düzlem kırpma)
  const ids=GEO.pts.map((p,i)=>p?i:-1).filter(i=>i>=0);
  GEO.cells=[];
  ids.forEach(i=>{
    let poly=[[0,0],[GEO_W,0],[GEO_W,GEO_H],[0,GEO_H]];const a=GEO.pts[i];
    ids.forEach(j=>{if(j===i||!poly.length)return;const b=GEO.pts[j];
      const mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2,nx=b[0]-a[0],ny=b[1]-a[1];
      const d=p=>(p[0]-mx)*nx+(p[1]-my)*ny; // <=0: i tarafı
      const out=[];
      for(let k=0;k<poly.length;k++){const P=poly[k],Q=poly[(k+1)%poly.length],dp=d(P),dq=d(Q);
        if(dp<=0)out.push(P);
        if((dp<0&&dq>0)||(dp>0&&dq<0)){const t=dp/(dp-dq);out.push([P[0]+(Q[0]-P[0])*t,P[1]+(Q[1]-P[1])*t]);}}
      poly=out;});
    GEO.cells[i]=poly;});
}
/* ================= DÜNYA HARİTASI SEKMESİ ================= */
const SCOL={A:'#f0c040',K:'#4aa3ff',D:'#ff6b5e',G:'#3fb950',B:'#b48cff',O:'#7fe0e0',M:'#ff9f43',L:'#e84393',P:'#00cec9'};
const WM={cv:null,ctx:null,w:0,h:0,dpr:1,sig:'',ptrs:new Map(),moved:0,pinch:0};
UI.wv={k:1,tx:0,ty:0,init:false};UI.wsel=null;
const MOONBOX=()=>({x:8,y:WM.h-62,w:132,h:54});
function wmInit(){
  if(WM.cv)return;
  const cv=document.createElement('canvas');cv.style.cssText='display:block;touch-action:none;width:100%;cursor:grab';
  WM.cv=cv;WM.ctx=cv.getContext('2d');
  cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);WM.ptrs.set(e.pointerId,{x:e.offsetX,y:e.offsetY});WM.moved=0;if(WM.ptrs.size===2)WM.pinch=wmPinchDist();});
  cv.addEventListener('pointermove',e=>{
    const p=WM.ptrs.get(e.pointerId);if(!p)return;const nx=e.offsetX,ny=e.offsetY;
    if(WM.ptrs.size===1){UI.wv.tx+=nx-p.x;UI.wv.ty+=ny-p.y;WM.moved+=Math.abs(nx-p.x)+Math.abs(ny-p.y);p.x=nx;p.y=ny;wmClamp();wmDraw(true);}
    else if(WM.ptrs.size===2){p.x=nx;p.y=ny;const d=wmPinchDist(),pts=[...WM.ptrs.values()];
      if(WM.pinch>0&&d>0)wmZoomAt((pts[0].x+pts[1].x)/2,(pts[0].y+pts[1].y)/2,d/WM.pinch);WM.pinch=d;WM.moved+=10;}});
  const up=e=>{const had=WM.ptrs.has(e.pointerId);WM.ptrs.delete(e.pointerId);
    if(had&&WM.ptrs.size===0&&WM.moved<8){const id=wmHit(e.offsetX,e.offsetY);if(id!==null){UI.wsel=id;S.dirty=true;render();}}};
  cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',e=>{WM.ptrs.delete(e.pointerId);});
  cv.addEventListener('wheel',e=>{e.preventDefault();wmZoomAt(e.offsetX,e.offsetY,e.deltaY<0?1.25:0.8);},{passive:false});
  window.addEventListener('resize',()=>{if(UI.tab==='world')wmFit();});
}
const wmPinchDist=()=>{const p=[...WM.ptrs.values()];return p.length<2?0:Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y);};
function wmClamp(){const v=UI.wv,s=WM.w/1000*v.k;v.tx=clamp(v.tx,WM.w-1000*s-60,60);v.ty=clamp(v.ty,WM.h-GEO_H*s-60,60);}
function wmZoomAt(cx,cy,f){const v=UI.wv,nk=clamp(v.k*f,0.8,14),r=nk/v.k;v.tx=cx-(cx-v.tx)*r;v.ty=cy-(cy-v.ty)*r;v.k=nk;wmClamp();wmDraw(true);}
function wmView(mode){
  geoInit();const v=UI.wv,s0=WM.w/1000;
  if(mode==='all'){v.k=1;v.tx=0;v.ty=(WM.h-430*s0)/2-30*s0;}
  else{const p=GEO.pts[UI.wsel!==null&&GEO.pts[UI.wsel]?UI.wsel:0];v.k=3.2;v.tx=WM.w/2-p[0]*s0*v.k;v.ty=WM.h/2-p[1]*s0*v.k;}
  wmClamp();wmDraw(true);
}
function wmFit(){
  const wrap=$('wmWrap');if(!wrap||!WM.cv)return;
  const w=Math.max(280,Math.min(1100,wrap.clientWidth||340)),h=Math.round(Math.max(w*0.5,Math.min(w*0.8,320)));
  if(w===WM.w&&h===WM.h&&UI.wv.init){wmDraw(true);return;}
  WM.w=w;WM.h=h;WM.dpr=Math.min(2,window.devicePixelRatio||1);
  WM.cv.width=w*WM.dpr;WM.cv.height=h*WM.dpr;WM.cv.style.height=h+'px';
  if(!UI.wv.init){UI.wv.init=true;wmView('all');}else{wmClamp();wmDraw(true);}
}
function afterRender(){
  if(UI.tab!=='world')return;
  wmInit();const wrap=$('wmWrap');if(wrap){wrap.appendChild(WM.cv);wmFit();}
}
function wmPos(id){const p=GEO.pts[id],v=UI.wv,s=WM.w/1000*v.k;
  if(p)return [p[0]*s+v.tx,p[1]*s+v.ty];
  const b=MOONBOX(),f=MOON_XY[id-21];return [b.x+b.w*f[0],b.y+b.h*0.62];}
function wmHit(x,y){
  geoInit();let best=null,bd=22;
  S.regions.forEach(r=>{const q=wmPos(r.id),d=Math.hypot(q[0]-x,q[1]-y);if(d<bd){bd=d;best=r.id;}});
  return best;
}
function wmDraw(force){
  if(!WM.cv||!document.body.contains(WM.cv)||!WM.w)return;
  geoInit();
  const v=UI.wv,s=WM.w/1000*v.k;
  const agg=(typeof BOTAGG!=='undefined')?BOTAGG:{reg:[],st:{}};
  const sig=[S.regions.map(r=>r.state+(agg.reg[r.id]||0)).join(','),S.wars.filter(w=>w.state!=='done').map(w=>w.id+w.state[0]).join(','),UI.wsel,S.me.loc,S.me.res,(typeof SW!=='undefined'?SW.sig:''),v.k.toFixed(2),Math.round(v.tx),Math.round(v.ty),WM.w,WM.h].join('|');
  if(!force&&sig===WM.sig)return;WM.sig=sig;
  const c=WM.ctx,w=WM.w,h=WM.h;
  c.setTransform(WM.dpr,0,0,WM.dpr,0,0);c.fillStyle='#08121c';c.fillRect(0,0,w,h);
  // enlem/boylam ızgarası
  c.save();c.translate(v.tx,v.ty);c.scale(s,s);
  c.lineWidth=0.5/s;c.strokeStyle='#ffffff10';
  for(let lat=-60;lat<=80;lat+=20){c.beginPath();for(let lon=-180;lon<=180;lon+=10){const q=proj(lon,lat);lon===-180?c.moveTo(q[0],q[1]):c.lineTo(q[0],q[1]);}c.stroke();}
  for(let lon=-180;lon<=180;lon+=30){c.beginPath();for(let lat=-60;lat<=80;lat+=10){const q=proj(lon,lat);lat===-60?c.moveTo(q[0],q[1]):c.lineTo(q[0],q[1]);}c.stroke();}
  c.fillStyle='#1c2a37';c.fill(GEO.land);c.lineWidth=0.8/s;c.strokeStyle='#37506a';c.stroke(GEO.land);
  // etki alanları: devlet renkleri bir kez çizilir, durum değişmedikçe hazır resim kullanılır
  const R=95,ids=S.regions.filter(r=>GEO.pts[r.id]).map(r=>r.id);
  const ik=S.regions.map(r=>r.state).join('')+'|'+Object.keys(SCOL).sort().map(k=>k+SCOL[k]).join('');   // renk değişince önbellek yenilenir
  if(!GEO.infl||GEO.inflK!==ik){
    if(!GEO.infl){GEO.infl=document.createElement('canvas');GEO.infl.width=2000;GEO.infl.height=1040;}
    const g=GEO.infl.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,2000,1040);g.scale(2,2);g.save();g.clip(GEO.land);
    if(HM.cf){g.fillStyle='#000';HM.cf.forEach(cc=>{g.beginPath();cc[1].forEach(r=>{r.forEach((p,k)=>{const q=proj(p[0],p[1]);k?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]);});g.closePath();});g.fillStyle=(SCOL[cc[0]]||'#888');g.fill();});}
    ids.forEach(i=>{if(HM.cf&&HM.rs&&HM.rs[i]===S.regions[i].state)return;const cell=GEO.cells[i],p=GEO.pts[i];if(!cell||cell.length<3)return;
      g.save();g.beginPath();cell.forEach((q,k)=>k?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.closePath();g.clip();
      g.beginPath();g.arc(p[0],p[1],R,0,6.2832);g.fillStyle=(SCOL[S.regions[i].state]||'#888');g.fill();g.restore();});
    g.restore();GEO.inflK=ik;}
  c.save();c.globalAlpha=0.55;c.drawImage(GEO.infl,0,0,1000,1040/2);c.restore();   // katmanı tek seferde saydamlaştır: üst üste binen bölgeler koyulaşmaz, renkler sabit kalır
  c.save();c.clip(GEO.land);
  // sınırlar (komşu bulma bir kez hesaplanır)
  if(HM.cf){
    c.lineJoin='round';
    const dr=(L,lw,col)=>{c.beginPath();L.forEach(ch=>ch.forEach((p,k)=>{const q=proj(p[0],p[1]);k?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]);}));c.lineWidth=lw/s;c.strokeStyle=col;c.stroke();};
    if(!GEO.bnd){GEO.bnd=[];ids.forEach(i=>{const cell=GEO.cells[i],p=GEO.pts[i];const L=[];if(cell)for(let k=0;k<cell.length;k++){const P=cell[k],Q=cell[(k+1)%cell.length],mx=(P[0]+Q[0])/2,my=(P[1]+Q[1])/2;
      if(Math.hypot(mx-p[0],my-p[1])>R)continue;
      let nx=-(Q[1]-P[1]),ny=Q[0]-P[0];const l=Math.hypot(nx,ny)||1;nx/=l;ny/=l;if(nx*(mx-p[0])+ny*(my-p[1])<0){nx=-nx;ny=-ny;}
      const tx=mx+nx*1.5,ty=my+ny*1.5;let bj=-1,bd=1e9;ids.forEach(j=>{const d=Math.hypot(GEO.pts[j][0]-tx,GEO.pts[j][1]-ty);if(d<bd){bd=d;bj=j;}});
      if(bj===i||bj<0)continue;L.push([P,Q,bj]);}GEO.bnd[i]=L;});}
    // beyaz devlet sınırı: gerçek sınır çizgileri, ele geçirilmiş bölgelerin içinde gizlenir; yerine yeni sahibin hücre kenarı çizilir
    if(!GEO.brd||GEO.brdK!==ik){
      const con=ids.filter(i=>HM.rs&&HM.rs[i]!==S.regions[i].state),cs={};con.forEach(i=>cs[i]=1);
      const skip=(x,y)=>{if(!con.length)return false;let bj=-1,bd=1e9;ids.forEach(j=>{const d=Math.hypot(GEO.pts[j][0]-x,GEO.pts[j][1]-y);if(d<bd){bd=d;bj=j;}});return bd<R&&cs[bj]===1;};
      const mk=L=>{const out=[];L.forEach(ch=>{let a=null;ch.forEach(p=>{const q=proj(p[0],p[1]);if(a&&!skip((a[0]+q[0])/2,(a[1]+q[1])/2))out.push([a[0],a[1],q[0],q[1]]);a=q;});});return out;};
      const ed=[];con.forEach(i=>{(GEO.bnd[i]||[]).forEach(e=>{if(S.regions[e[2]].state!==S.regions[i].state)ed.push([e[0][0],e[0][1],e[1][0],e[1][1]]);});});
      ids.forEach(i=>{if(cs[i])return;(GEO.bnd[i]||[]).forEach(e=>{if(cs[e[2]]&&S.regions[e[2]].state!==S.regions[i].state)ed.push([e[0][0],e[0][1],e[1][0],e[1][1]]);});});
      GEO.brd={bc:mk(HM.bc),bs:mk(HM.bs),ed:ed};GEO.brdK=ik;}
    const ds=(L,lw,col)=>{c.beginPath();L.forEach(q=>{c.moveTo(q[0],q[1]);c.lineTo(q[2],q[3]);});c.lineWidth=lw/s;c.strokeStyle=col;c.lineCap='round';c.stroke();};
    ds(GEO.brd.bc,0.5,'#ffffff30');ds(GEO.brd.bs,1.8,'#ffffffcc');ds(GEO.brd.ed,1.8,'#ffffffcc');
  }else{
  if(!GEO.bnd){GEO.bnd=[];ids.forEach(i=>{const cell=GEO.cells[i],p=GEO.pts[i];const L=[];if(cell)for(let k=0;k<cell.length;k++){const P=cell[k],Q=cell[(k+1)%cell.length],mx=(P[0]+Q[0])/2,my=(P[1]+Q[1])/2;
      if(Math.hypot(mx-p[0],my-p[1])>R)continue;
      let nx=-(Q[1]-P[1]),ny=Q[0]-P[0];const l=Math.hypot(nx,ny)||1;nx/=l;ny/=l;if(nx*(mx-p[0])+ny*(my-p[1])<0){nx=-nx;ny=-ny;}
      const tx=mx+nx*1.5,ty=my+ny*1.5;let bj=-1,bd=1e9;ids.forEach(j=>{const d=Math.hypot(GEO.pts[j][0]-tx,GEO.pts[j][1]-ty);if(d<bd){bd=d;bj=j;}});
      if(bj===i||bj<0)continue;L.push([P,Q,bj]);}GEO.bnd[i]=L;});}
  ids.forEach(i=>{const L=GEO.bnd[i];if(!L)return;const si=S.regions[i].state;
    L.forEach(e=>{const diff=S.regions[e[2]].state!==si;
      c.beginPath();c.moveTo(e[0][0],e[0][1]);c.lineTo(e[1][0],e[1][1]);c.lineWidth=(diff?1.8:0.5)/s;c.strokeStyle=diff?'#ffffffcc':'#ffffff22';c.stroke();});});
  }
  c.restore();
  c.fillStyle='#08121c';c.fill(GEO.water);c.lineWidth=0.6/s;c.strokeStyle='#37506a';c.stroke(GEO.water);
  // komşuluk çizgileri
  c.lineWidth=0.7/s;c.strokeStyle='#ffffff33';c.setLineDash([3/s,3/s]);
  EDGES.forEach(e=>{const a=GEO.pts[e[0]],b=GEO.pts[e[1]];if(a&&b){c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke();}});
  c.setLineDash([]);
  // savaş okları
  S.wars.filter(x=>x.state!=='done').forEach(x=>{const t=GEO.pts[x.region];if(!t)return;
    let bp=null,bd=1e9;regOf(x.att).forEach(r=>{const p=GEO.pts[r.id];if(p){const d=Math.hypot(p[0]-t[0],p[1]-t[1]);if(d<bd){bd=d;bp=p;}}});
    if(bp){c.beginPath();c.moveTo(bp[0],bp[1]);c.lineTo(t[0],t[1]);c.lineWidth=2/s;c.strokeStyle=x.state==='on'?'#ff3b30':'#ff9500';c.setLineDash([6/s,4/s]);c.stroke();c.setLineDash([]);}});
  c.restore();
  // devlet adları
  if(s<1.6){c.textAlign='center';c.font='bold 11px system-ui';
    Object.keys(STATE_N).forEach(st=>{const rs=regOf(st).filter(r=>GEO.pts[r.id]);if(!rs.length)return;
      let x=0,y=0;rs.forEach(r=>{const q=wmPos(r.id);x+=q[0];y+=q[1];});x/=rs.length;y/=rs.length;
      c.lineWidth=3;c.strokeStyle='#08121cdd';c.strokeText(STATE_N[st].split(' ')[0].toUpperCase(),x,y-16);c.fillStyle=SCOL[st];c.fillText(STATE_N[st].split(' ')[0].toUpperCase(),x,y-16);});}
  // ay kutusu
  const mb=MOONBOX();c.fillStyle='#0d1823';c.strokeStyle='#37506a';c.lineWidth=1;c.beginPath();c.roundRect?c.roundRect(mb.x,mb.y,mb.w,mb.h,8):c.rect(mb.x,mb.y,mb.w,mb.h);c.fill();c.stroke();
  c.fillStyle='#8b949e';c.font='10px system-ui';c.textAlign='left';c.fillText('🌙 AY',mb.x+8,mb.y+14);
  // işaretçiler
  S.regions.forEach(r=>{
    const [x,y]=wmPos(r.id);if(x<-30||y<-30||x>w+30||y>h+30)return;
    const pop=agg.reg[r.id]||0,zf=Math.max(0.42,Math.min(1,s*1.6)),rad=(5+Math.min(8,Math.sqrt(pop)*0.22))*zf,sel=UI.wsel===r.id;
    const war=S.wars.some(q=>q.state!=='done'&&q.region===r.id);
    if(war){c.beginPath();c.arc(x,y,rad+5,0,6.2832);c.lineWidth=2;c.strokeStyle='#ff3b30';c.stroke();}
    c.beginPath();c.arc(x,y,rad,0,6.2832);c.fillStyle=(typeof lyColor==='function'?lyColor(r):(SCOL[r.state]||'#888'));c.fill();c.lineWidth=sel?3:Math.max(0.8,1.5*zf);c.strokeStyle=sel?'#ffffff':'#08121c';c.stroke();
    if(typeof SW!=='undefined'&&SW.regs[r.id]){const o=SW.regs[r.id].o;c.beginPath();c.moveTo(x,y-rad-2);c.lineTo(x,y-rad-14);c.lineWidth=1.5;c.strokeStyle='#fff';c.stroke();c.beginPath();c.moveTo(x,y-rad-14);c.lineTo(x+9,y-rad-10);c.lineTo(x,y-rad-6);c.closePath();c.fillStyle=swHue(o);c.fill();}
    if(S.me.res===r.id){c.beginPath();c.arc(x,y,rad+3,0,6.2832);c.lineWidth=1.5;c.strokeStyle='#ffffff';c.stroke();}
    if(S.me.loc===r.id){c.font='13px system-ui';c.textAlign='center';c.fillStyle='#fff';c.fillText('📍',x,y-rad-3);}
    if(sel){const nm=r.moon?r.n.replace('Ay Üssü ',''):r.n;c.font='11px system-ui';c.textAlign='center';c.lineWidth=3;c.strokeStyle='#08121ccc';c.strokeText(nm,x,y+rad+12);c.fillStyle='#e6edf3';c.fillText(nm,x,y+rad+12);}
  });
}
function tabWorld(){
  const m=S.me,agg=(typeof BOTAGG!=='undefined')?BOTAGG:{reg:[],st:{},party:{}};
  const id=UI.wsel!==null?UI.wsel:m.loc,r=S.regions[id];
  let h=`<div class="panel"><h2>🌍 Dünya haritası — kim nereye hâkim</h2>
  <div id="wmWrap" style="border:1px solid #2a3542;border-radius:8px;overflow:hidden;background:#08121c"></div>
  <div class="btns"><button class="act sm" data-a="mapZoom" data-d="in">＋</button><button class="act sm" data-a="mapZoom" data-d="out">－</button><button class="act sm blue" data-a="mapZoom" data-d="all">🌍 Tüm dünya</button><button class="act sm gold" data-a="mapZoom" data-d="home">🎯 Seçili bölgeye yakınlaş</button></div>
  <p class="hint">Sürükle: kaydır · iki parmak / tekerlek: yakınlaş · bölgeye dokun: ayrıntı. Daire büyüklüğü o bölgedeki yapay zekâ nüfusunu, beyaz sınırlar devlet sınırlarını, kırmızı halka savaşı gösterir.</p>`;
  const bl=Object.keys(r.b).filter(k=>r.b[k]>0).map(k=>`${BUILD[k].i}${BUILD[k].n} ${r.b[k]}`).join(' · ')||'Bina yok';
  const here=m.loc===r.id,hops=hopsTo(m.loc,r.id);
  h+=`<div class="card glow"><h3><a class="lk" data-a="goCity" data-id="${r.id}">${esc(r.n)}</a> <span class="owner" style="background:${SCOL[r.state]}33;color:${SCOL[r.state]}">${esc(nameOf(r.state))}</span></h3>
  <p>❤️${r.idx.h} 🎖️${r.idx.m} 🎓${r.idx.e} 🏘️${r.idx.d}${r.coast?' · 🌊 kıyı':''}${r.moon?' · 🌙 Ay':''} · Nüfus (yapay zekâ): <b>${fmt(agg.reg[r.id]||0)}</b></p>
  ${(typeof SW!=='undefined'&&SW.regs[r.id])?`<p>🏛️ Vali: <b style="color:${swHue(SW.regs[r.id].o)}">${esc(SW.regs[r.id].on)}</b></p>`:''}
  <p class="dim">${RES.filter(k=>r.res[k].m>0).map(k=>`${RES_I[k]}${fmt(r.res[k].c)}/${fmt(r.res[k].m)}`).join(' ')||'Kaynak yok'}</p><p>${bl}</p>
  <div class="btns">${here?btn('🏠 Buraya yerleş','data-a="resid"','',m.res===r.id||r.moon):btn(`🧳 Git (${r.moon?'30dk':hops*5+'dk'})`,`data-a="travel" data-to="${r.id}"`,'',!!m.travel||(hops>=99&&!r.moon))}</div></div>`;
  h+=`<h2 style="margin-top:12px">Devletler</h2><div style="overflow-x:auto"><table><tr><th align=left>Devlet</th><th>Bölge</th><th>Nüfus</th><th>Güç</th><th>Durum</th></tr>`;
  Object.keys(STATE_N).forEach(st=>{const rs=regOf(st);const wr=atWar(st);
    h+=`<tr><td><span style="color:${SCOL[st]}">●</span> ${esc(STATE_N[st])}${st==='A'?' (sen)':''}</td><td class="num">${rs.length}</td><td class="num">${fmt((agg.st[st]||{}).n||0)}</td><td class="num">${fmt(powerOf(st))}</td><td class="${wr.length?'bad':'dim'}">${rs.length?(wr.length?'⚔️ savaşta':'barış'):'yıkıldı'}</td></tr>`;});
  h+='</table></div>';
  const ps=A().parties.map(p=>[p,(agg.party||{})[p.id]||0]).filter(x=>x[1]>0);
  if(ps.length)h+=`<p class="hint">Anadolu'daki yapay zekâ vatandaşların parti dağılımı: ${ps.map(x=>`${esc(x[0].n)} ${fmt(x[1])}`).join(' · ')}</p>`;
  return h+'</div>';
}
ACT.mapZoom=d=>{
  if(!WM.w)return;
  if(d.d==='in')wmZoomAt(WM.w/2,WM.h/2,1.5);else if(d.d==='out')wmZoomAt(WM.w/2,WM.h/2,1/1.5);
  else wmView(d.d);
  S.dirty=false;
};

const RANKS=[[0,'Nefer'],[5e3,'Onbaşı'],[2e4,'Çavuş'],[8e4,'Teğmen'],[3e5,'Yüzbaşı'],[1e6,'Binbaşı'],[4e6,'Kaymakam'],[1.5e7,'Miralay'],[6e7,'Mirliva'],[2.5e8,'Ferik'],[1e9,'Müşir']];
function rankName(){const d=S.me.dmg||0;let n=RANKS[0][1];RANKS.forEach(r=>{if(d>=r[0])n=r[1];});return n;}
/* ================= ÇOK OYUNCULU / YÖNETİCİ (Firebase REST) ================= */
const MPK='rrmp_cfg';
const DEF_KEY='AIzaSyAIiq1id4NzzuYS8JXnIFaSfRjqutf8fIg',DEF_URL='https://oyun-f483d-default-rtdb.europe-west1.firebasedatabase.app';
const MP={cfg:null,auth:null,role:'player',owner:null,rate:5,ok:false,err:'',connecting:false,
  players:{},feed:[],sel:null,q:[],lastSync:0,busy:false};
const RULES_BLOCK=`    "rrgame": {
      "cfg": {
        ".read": "auth != null",
        "owner": { ".write": "auth != null && !data.exists() && newData.val() === auth.uid" },
        "taxRate": { ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid" },
        "announce": { ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid" },
        "event": { ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid" },
        "season": { ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid" },
        "taxRes": { ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid" },
        "prodTax": { ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid" }
      },
      "bans": {
        ".read": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid",
        "$uid": {
          ".read": "auth != null && auth.uid === $uid",
          ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid"
        }
      },
      "players": {
        ".read": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid",
        "$uid": { ".write": "auth != null && auth.uid === $uid && !root.child('rrgame/bans/' + auth.uid + '/ban').exists()" }
      },
      "board": {
        ".read": "auth != null",
        ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid",
        "$uid": { ".write": "auth != null && auth.uid === $uid && !root.child('rrgame/bans/' + auth.uid + '/ban').exists()" }
      },
      "feed": {
        ".read": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid",
        ".write": "auth != null"
      },
      "gifts": {
        "$uid": {
          ".read": "auth != null && auth.uid === $uid",
          "$g": { ".write": "auth != null && ((root.child('rrgame/cfg/owner').val() === auth.uid && !data.exists()) || (auth.uid === $uid && !newData.exists()))" }
        }
      },
      "chat": {
        ".read": "auth != null",
        ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid",
        "$m": {
          ".write": "auth != null && ((!data.exists() && newData.child('uid').val() === auth.uid && !root.child('rrgame/bans/' + auth.uid + '/chat').exists() && !root.child('rrgame/bans/' + auth.uid + '/ban').exists()) || (data.exists() && !newData.exists() && root.child('rrgame/cfg/owner').val() === auth.uid))",
          ".validate": "newData.hasChildren(['u','m','t','uid']) && newData.child('m').isString() && newData.child('m').val().length > 0 && newData.child('m').val().length <= 200"
        }
      },
      "pchat": {
        "$pid": {
          ".read": "auth != null",
          "$m": {
            ".write": "auth != null && ((!data.exists() && newData.child('uid').val() === auth.uid && !root.child('rrgame/bans/' + auth.uid + '/chat').exists() && !root.child('rrgame/bans/' + auth.uid + '/ban').exists()) || (data.exists() && !newData.exists() && root.child('rrgame/cfg/owner').val() === auth.uid))",
            ".validate": "newData.hasChildren(['u','m','t','uid']) && newData.child('m').isString() && newData.child('m').val().length > 0 && newData.child('m').val().length <= 200"
          }
        }
      },
      "dm": {
        "$pair": {
          ".read": "auth != null && $pair.contains(auth.uid)",
          "$m": {
            ".write": "auth != null && $pair.contains(auth.uid) && !data.exists() && newData.child('uid').val() === auth.uid && !root.child('rrgame/bans/' + auth.uid + '/chat').exists() && !root.child('rrgame/bans/' + auth.uid + '/ban').exists()",
            ".validate": "newData.hasChildren(['u','m','t','uid']) && newData.child('m').isString() && newData.child('m').val().length > 0 && newData.child('m').val().length <= 200"
          }
        }
      },
      "dminbox": {
        "$uid": {
          ".read": "auth != null && auth.uid === $uid",
          "$from": { ".write": "auth != null && $from === auth.uid" }
        }
      },
      "world": {
        ".read": "auth != null",
        "regions": {
          "$i": {
            ".write": "auth != null && !root.child('rrgame/bans/' + auth.uid + '/ban').exists() && ((!data.exists() && newData.child('o').val() === auth.uid) || (data.exists() && data.child('o').val() === auth.uid) || (newData.child('w').exists() && root.child('rrgame/world/wars/' + newData.child('w').val() + '/win').val() === newData.child('o').val() && (root.child('rrgame/world/wars/' + newData.child('w').val() + '/i').val() + '') === $i))"
          }
        },
        "wars": {
          "$id": {
            ".write": "auth != null && !root.child('rrgame/bans/' + auth.uid + '/ban').exists() && !data.exists() && newData.child('a').val() === auth.uid",
            ".validate": "newData.hasChildren(['i','a','d','t0','t1','dA','dD'])",
            "dA": { ".write": "auth != null && !root.child('rrgame/bans/' + auth.uid + '/ban').exists() && now >= root.child('rrgame/world/wars/' + $id + '/t0').val() && now <= root.child('rrgame/world/wars/' + $id + '/t1').val() + 5000 && newData.val() > data.val()" },
            "dD": { ".write": "auth != null && !root.child('rrgame/bans/' + auth.uid + '/ban').exists() && now >= root.child('rrgame/world/wars/' + $id + '/t0').val() && now <= root.child('rrgame/world/wars/' + $id + '/t1').val() + 5000 && newData.val() > data.val()" },
            "ps": { "$uid": { ".write": "auth != null && auth.uid === $uid && now >= root.child('rrgame/world/wars/' + $id + '/t0').val() && now <= root.child('rrgame/world/wars/' + $id + '/t1').val() + 5000" } },
            "win": { ".write": "auth != null && !data.exists() && now > root.child('rrgame/world/wars/' + $id + '/t1').val() && (newData.val() === root.child('rrgame/world/wars/' + $id + '/a').val() || newData.val() === root.child('rrgame/world/wars/' + $id + '/d').val())" }
          }
        }
      },
      "market": {
        ".read": "auth != null",
        "$id": {
          ".write": "auth != null && ((!data.exists() && newData.child('s').val() === auth.uid && !root.child('rrgame/bans/' + auth.uid + '/ban').exists()) || (data.exists() && !newData.exists() && ((data.child('s').val() === auth.uid && !root.child('rrgame/claims/' + $id).exists()) || root.child('rrgame/claims/' + $id + '/b').val() === auth.uid)))",
          ".validate": "newData.hasChildren(['s','sn','r','q','p','t']) && newData.child('q').isNumber() && newData.child('q').val() > 0 && newData.child('q').val() <= 1000000 && newData.child('p').isNumber() && newData.child('p').val() > 0 && (newData.child('r').val() === 'gold' || newData.child('r').val() === 'oil' || newData.child('r').val() === 'ore' || newData.child('r').val() === 'uranium' || newData.child('r').val() === 'diamonds' || newData.child('r').val() === 'tank' || newData.child('r').val() === 'fighter' || newData.child('r').val() === 'bomber' || newData.child('r').val() === 'ship' || newData.child('r').val() === 'battleship' || newData.child('r').val() === 'missile' || newData.child('r').val() === 'moontank' || newData.child('r').val() === 'station' || newData.child('r').val() === 'siha')"
        }
      },
      "claims": {
        "$id": {
          ".read": "auth != null",
          ".write": "auth != null && !data.exists() && newData.child('b').val() === auth.uid && root.child('rrgame/market/' + $id).exists() && root.child('rrgame/market/' + $id + '/s').val() !== auth.uid && newData.child('tot').isNumber() && newData.child('tot').val() <= root.child('rrgame/market/' + $id + '/p').val() * root.child('rrgame/market/' + $id + '/q').val() + 1"
        }
      },
      "settle": {
        "$uid": {
          ".read": "auth != null && auth.uid === $uid",
          "$k": { ".write": "auth != null && ((!data.exists() && newData.exists() && ((!newData.child('kind').exists() && newData.child('amt').isNumber() && newData.child('amt').val() > 0 && root.child('rrgame/claims/' + $k + '/b').val() === auth.uid && newData.child('amt').val() <= root.child('rrgame/claims/' + $k + '/tot').val() + 1) || (newData.child('kind').val() === 'areq' && $uid === root.child('rrgame/cfg/owner').val() && newData.child('from').val() === auth.uid && newData.child('amt').isNumber()) || ((newData.child('kind').val() === 'agrant' || newData.child('kind').val() === 'arej') && root.child('rrgame/cfg/owner').val() === auth.uid))) || (auth.uid === $uid && !newData.exists()))" }
        }
      },
      "alliances": {
        ".read": "auth != null",
        "$id": {
          ".write": "auth != null && !root.child('rrgame/bans/' + auth.uid + '/ban').exists() && ((!data.exists() && newData.child('o').val() === auth.uid) || (data.exists() && data.child('o').val() === auth.uid))",
          ".validate": "newData.hasChildren(['n','o']) && newData.child('n').isString() && newData.child('n').val().length >= 3 && newData.child('n').val().length <= 24",
          "m": { "$uid": { ".write": "auth != null && !root.child('rrgame/bans/' + auth.uid + '/ban').exists() && auth.uid === $uid && newData.isString() || (auth.uid === $uid && !newData.exists())" } },
          "bank": { ".write": "auth != null && root.child('rrgame/alliances/' + $id + '/m/' + auth.uid).exists() && newData.isNumber() && newData.val() > data.val()" }
        }
      },
      "achat": {
        "$id": {
          ".read": "auth != null && root.child('rrgame/alliances/' + $id + '/m/' + auth.uid).exists()",
          "$m": {
            ".write": "auth != null && root.child('rrgame/alliances/' + $id + '/m/' + auth.uid).exists() && !data.exists() && newData.child('uid').val() === auth.uid && !root.child('rrgame/bans/' + auth.uid + '/chat').exists()",
            ".validate": "newData.hasChildren(['u','m','t','uid']) && newData.child('m').isString() && newData.child('m').val().length > 0 && newData.child('m').val().length <= 200"
          }
        }
      },
      "wk": {
        "$w": {
          ".read": "auth != null",
          "$uid": { ".write": "auth != null && auth.uid === $uid && !root.child('rrgame/bans/' + auth.uid + '/ban').exists()" }
        }
      },
      "articles": {
        ".read": "auth != null",
        "$id": {
          ".write": "auth != null && !root.child('rrgame/bans/' + auth.uid + '/ban').exists() && ((!data.exists() && newData.child('uid').val() === auth.uid) || (data.exists() && !newData.exists() && (data.child('uid').val() === auth.uid || root.child('rrgame/cfg/owner').val() === auth.uid)))",
          ".validate": "newData.hasChildren(['uid','an','ti','b','t']) && newData.child('ti').isString() && newData.child('ti').val().length >= 3 && newData.child('ti').val().length <= 80 && newData.child('b').isString() && newData.child('b').val().length >= 20 && newData.child('b').val().length <= 3000",
          "l": { ".write": "auth != null && newData.isNumber() && (newData.val() === data.val() + 1 || newData.val() === data.val() - 1)" },
          "d": { ".write": "auth != null && newData.isNumber() && (newData.val() === data.val() + 1 || newData.val() === data.val() - 1)" },
          "c": { ".write": "auth != null && newData.isNumber() && newData.val() === data.val() + 1" }
        }
      },
      "aimg": {
        "$id": {
          ".read": "auth != null",
          ".write": "auth != null && ((!data.exists() && root.child('rrgame/articles/' + $id + '/uid').val() === auth.uid) || (data.exists() && !newData.exists() && (root.child('rrgame/articles/' + $id + '/uid').val() === auth.uid || root.child('rrgame/cfg/owner').val() === auth.uid || !root.child('rrgame/articles/' + $id).exists())))",
          ".validate": "newData.isString() && newData.val().length < 200000 && newData.val().beginsWith('data:image/')"
        }
      },
      "areact": {
        "$id": {
          "$uid": {
            ".read": "auth != null && auth.uid === $uid",
            ".write": "auth != null && auth.uid === $uid && (!newData.exists() || newData.val() === 1 || newData.val() === -1)"
          }
        }
      },
      "acom": {
        "$id": {
          ".read": "auth != null",
          "$k": {
            ".write": "auth != null && ((!data.exists() && newData.child('uid').val() === auth.uid && !root.child('rrgame/bans/' + auth.uid + '/chat').exists() && !root.child('rrgame/bans/' + auth.uid + '/ban').exists()) || (data.exists() && !newData.exists() && (data.child('uid').val() === auth.uid || root.child('rrgame/cfg/owner').val() === auth.uid)))",
            ".validate": "newData.hasChildren(['u','m','t','uid']) && newData.child('m').isString() && newData.child('m').val().length > 0 && newData.child('m').val().length <= 300"
          }
        }
      },
      "botsrv": {
        ".read": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid",
        ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid"
      },
      "elect": {
        ".read": "auth != null",
        "$s": {
          ".write": "auth != null && root.child('rrgame/cfg/owner').val() === auth.uid",
          "cand": {
            "$id": {
              ".write": "auth != null && ((auth.uid === $id && root.child('rrgame/elect/' + $s + '/phase').val() === 'vote' && now < root.child('rrgame/elect/' + $s + '/end').val() && !data.exists() && newData.exists()) || (auth.uid === $id && data.exists() && !newData.exists()))",
              ".validate": "newData.hasChildren(['n', 'lv', 'camp', 't']) && newData.child('n').isString() && newData.child('n').val().length <= 40 && (data.exists() || newData.child('camp').val() === 0)",
              "camp": {
                ".write": "auth != null && root.child('rrgame/elect/' + $s + '/phase').val() === 'vote' && data.exists() && newData.isNumber() && newData.val() >= data.val() && newData.val() <= data.val() + 300000 && newData.val() <= 1000000",
                ".validate": "newData.isNumber()"
              }
            }
          },
          "votes": {
            "$u": {
              ".write": "auth != null && auth.uid === $u && root.child('rrgame/elect/' + $s + '/phase').val() === 'vote' && now < root.child('rrgame/elect/' + $s + '/end').val() && (!newData.exists() || root.child('rrgame/elect/' + $s + '/cand/' + newData.val()).exists())",
              ".validate": "newData.isString()"
            }
          },
          "dec": {
            ".write": "auth != null && root.child('rrgame/elect/' + $s + '/pres/id').val() === auth.uid && newData.exists() && !newData.child('ok').exists() && !newData.child('until').exists() && (newData.child('k').val() === 'sefer' || newData.child('k').val() === 'calis' || newData.child('k').val() === 'egitim') && newData.child('end').val() <= now + 21660000 && (!data.exists() || now > data.child('end').val() + 43200000)"
          },
          "decv": {
            ".write": "auth != null && !root.child('rrgame/bans/' + auth.uid + '/ban').exists() && !newData.exists() && root.child('rrgame/elect/' + $s + '/pres/id').val() === auth.uid",
            "$u": {
              ".write": "auth != null && auth.uid === $u && root.child('rrgame/elect/' + $s + '/dec/end').val() > now && !root.child('rrgame/elect/' + $s + '/dec/ok').exists() && (newData.val() === 'y' || newData.val() === 'n')"
            }
          },
          "pol": {
            ".write": "auth != null && root.child('rrgame/elect/' + $s + '/pres/id').val() === auth.uid && (newData.val() === 'kalkinma' || newData.val() === 'ordu' || newData.val() === 'egitim')"
          },
          "msg": {
            ".write": "auth != null && root.child('rrgame/elect/' + $s + '/pres/id').val() === auth.uid && newData.isString() && newData.val().length <= 100"
          }
        }
      },
      "dip": {
        ".read": "auth != null",
        "emb": {
          "$from": {
            "$to": {
              ".write": "auth != null && $from !== $to && root.child('rrgame/elect/' + $from + '/pres/id').val() === auth.uid && (!newData.exists() || (newData.hasChildren(['t', 'until']) && newData.child('until').val() <= now + 86460000 && (!data.exists() || data.child('until').val() < now - 43200000)))"
            }
          }
        },
        "pact": {
          "$a": {
            "$b": {
              ".write": "auth != null && $a !== $b && root.child('rrgame/elect/' + $a + '/pres/id').val() === auth.uid && newData.hasChildren(['t', 'exp']) && !newData.child('acc').exists() && newData.child('exp').val() <= now + 86460000 && (!data.exists() || data.child('exp').val() < now)",
              "acc": {
                ".write": "auth != null && root.child('rrgame/elect/' + $b + '/pres/id').val() === auth.uid && root.child('rrgame/dip/pact/' + $a + '/' + $b + '/exp').val() > now && !data.exists() && newData.isNumber() && newData.val() <= now + 259260000"
              }
            }
          }
        }
      },
      "invites": {
        "$inv": {
          ".read": "auth != null && (auth.uid === $inv || root.child('rrgame/cfg/owner').val() === auth.uid)",
          "$u": {
            ".write": "auth != null && auth.uid === $u && $inv !== auth.uid && !data.exists() && newData.exists()",
            ".validate": "newData.hasChildren(['n','t'])"
          }
        }
      },
      "saves": {
        "$uid": {
          ".read": "auth != null && auth.uid === $uid",
          ".write": "auth != null && auth.uid === $uid"
        }
      }
    }`;
const FULL_RULES='{\n  "rules": {\n'+RULES_BLOCK+'\n  }\n}';
MP.loadCfg=()=>{try{const d=JSON.parse(localStorage.getItem(MPK)||'null');if(d){MP.cfg=d.cfg;MP.auth=d.auth;}}catch(e){}};
MP.saveCfg=()=>{try{localStorage.setItem(MPK,JSON.stringify({cfg:MP.cfg,auth:MP.auth}));}catch(e){}};
MP.token=async()=>{
  const a=MP.auth;if(a&&a.idToken&&Date.now()<a.exp-60000)return a.idToken;
  if(a&&a.refresh){
    try{const r=await fetch('https://securetoken.googleapis.com/v1/token?key='+MP.cfg.key,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=refresh_token&refresh_token='+encodeURIComponent(a.refresh)});
      const j=await r.json();if(j.id_token){MP.auth={uid:j.user_id,idToken:j.id_token,refresh:j.refresh_token,exp:Date.now()+(+j.expires_in)*1000};MP.saveCfg();return MP.auth.idToken;}}catch(e){}
  }
  throw new Error('Giriş yapılmadı: kullanıcı adı ve şifrenle giriş yap ya da kayıt ol.');
};
MP.fb=async(method,path,body,query)=>{
  const t=await MP.token();
  const u=MP.cfg.url.replace(/\/+$/,'')+'/rrgame/'+path+'.json?'+(query?query+'&':'')+'auth='+encodeURIComponent(t);
  const r=await fetch(u,{method:method,headers:body!==undefined?{'Content-Type':'application/json'}:undefined,body:body!==undefined?JSON.stringify(body):undefined});
  if(!r.ok){let m='';try{m=(await r.json()).error||'';}catch(e){}throw new Error('Sunucu '+r.status+(m?': '+m:'')+(r.status===401?' (kurallar eklenmemiş olabilir)':''));}
  return r.json();
};
MP.uid=()=>MP.auth&&MP.auth.uid;
MP.mail=u=>{u=String(u||'').trim().toLowerCase();return u.indexOf('@')>0?u:u.replace(/[^a-z0-9._-]/g,'')+'@bilad.example.com';};
MP.idt=async(ep,body)=>{
  const r=await fetch('https://identitytoolkit.googleapis.com/v1/accounts:'+ep+'?key='+MP.cfg.key,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const j=await r.json();
  if(!j.idToken){const m=(j.error&&j.error.message)||'';
    throw new Error(/EMAIL_EXISTS/.test(m)?'Bu kullanıcı adı alınmış.':/INVALID_LOGIN|INVALID_PASSWORD|EMAIL_NOT_FOUND|INVALID_CREDENTIAL/.test(m)?'Kullanıcı adı ya da şifre hatalı.':/WEAK_PASSWORD/.test(m)?'Şifre en az 6 karakter olmalı.':/OPERATION_NOT_ALLOWED|CONFIGURATION_NOT_FOUND/.test(m)?'Firebase\'de Email/Password girişi kapalı (Authentication → Sign-in method → Email/Password → Etkinleştir).':'Giriş başarısız: '+(m||'bilinmeyen'));}
  return j;
};
MP.setAuth=(j,user)=>{MP.auth={uid:j.localId,idToken:j.idToken,refresh:j.refreshToken,exp:Date.now()+(+j.expiresIn)*1000,user:user};MP.saveCfg();};
MP.account=async(mode,user,pass)=>{   // mode: login | register | link
  user=String(user||'').trim().toLowerCase();
  if(user.indexOf('@')>0){if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(user))throw new Error('Geçerli bir e-posta gir.');}
  else if(!/^[a-z0-9._-]{3,20}$/.test(user))throw new Error('Kullanıcı adı 3-20 karakter olmalı (harf, rakam, . _ -) ya da bir e-posta gir.');
  if(String(pass||'').length<6)throw new Error('Şifre en az 6 karakter olmalı.');
  const email=MP.mail(user);let j;
  if(mode==='link'){const t=await MP.token();j=await MP.idt('update',{idToken:t,email:email,password:pass,returnSecureToken:true});j.localId=j.localId||MP.uid();}
  else j=await MP.idt(mode==='register'?'signUp':'signInWithPassword',{email:email,password:pass,returnSecureToken:true});
  MP.setAuth(j,user);
};
/* bulut kaydı: hesap hangi telefonda açılırsa oyun devam eder */
MP.cloudSnap=()=>{const c=Object.assign({},S);delete c.dirty;delete c.live;c.savedReal=Date.now();return JSON.stringify(c);};
MP.cloudSave=async(force)=>{
  if(!MP.ok||!MP.auth||S.mpUid!==MP.uid())return;
  const gap=(S.me&&S.me.admin)?120000:45000;
  if(!force&&Date.now()-(MP.lastCloud||0)<gap)return;
  MP.lastCloud=Date.now();
  await MP.fb('PUT','saves/'+MP.uid(),{t:Date.now(),d:MP.cloudSnap()});
};
MP.cloudPull=async()=>{   // girişten sonra: bu hesabın bulut kaydı varsa sor, yükle
  const uid=MP.uid();if(!uid)return;
  if(S.mpUid===uid)return;
  let c=null;try{c=await MP.fb('GET','saves/'+uid);}catch(e){}
  if(c&&c.d){
    if(confirm('Bu hesabın bulutta kayıtlı oyunu var. Yüklensin mi?\n\nTamam: bulut kaydını yükle (bu telefondaki oyun silinir)\nİptal: bu telefondaki oyunu bu hesaba bağla')){
      try{const o=JSON.parse(c.d);o.mpUid=uid;localStorage.setItem(SAVE,JSON.stringify(o));window.__noSave=true;location.reload();return 'reload';}catch(e){MP.err='Bulut kaydı okunamadı.';}
    }
  }
  S.mpUid=uid;save();
};
MP.connect=async()=>{
  if(!MP.cfg||!MP.cfg.key||!MP.cfg.url)return;
  MP.connecting=true;MP.err='';
  try{
    await MP.token();
    MP.owner=await MP.fb('GET','cfg/owner');
    const r=await MP.fb('GET','cfg/taxRate');MP.rate=(typeof r==='number'&&r>=0&&r<=90)?r:5;
    MP.role=(MP.owner&&MP.owner===MP.uid())?'admin':'player';
    MP.ok=true;
    if(await MP.cloudPull()==='reload')return;
    if(MP.role==='admin'){MP.makeAdmin();if(S.botN===undefined)botSetCount(6);}
    S.me.name=MP.cfg.name||S.me.name;
    await MP.sync();
  }catch(e){MP.ok=false;MP.err=String(e.message||e);}
  MP.connecting=false;S.dirty=true;
};
MP.claim=async()=>{
  try{
    if(!MP.ok)await MP.connect();
    if(!MP.ok)return;
    if(MP.owner&&MP.owner!==MP.uid())return MP.err='Bu dünyanın zaten bir yöneticisi var.';
    await MP.fb('PUT','cfg/owner',MP.uid());await MP.fb('PUT','cfg/taxRate',MP.rate);
    MP.owner=MP.uid();MP.role='admin';MP.makeAdmin();toast('👑 Artık yöneticisin (game master).','ok');
  }catch(e){MP.err=String(e.message||e);}
  S.dirty=true;
};
MP.makeAdmin=()=>{
  const m=S.me;if(m.admin)return;
  m.admin=true;if(!S.botN&&S.botN!==0)botSetCount(6);m.str=m.edu=m.end=100;m.level=Math.max(m.level,100);m.energy=100;m.money=Math.max(m.money,1e9);
  RES.forEach(r=>m.stor[r]=Math.max(m.stor[r],100000));m.learn=null;
  L('👑 Yönetici (game master) olarak atandın: tüm yetenekler dolu, enerji harcamazsın. Pazar vergileri sana ödenir.','ok');
};
MP.summary=()=>{
  const m=S.me,p=S.parties?null:null,a=A(),pt=a.parties.find(x=>x.id===m.party);
  return {name:m.name,lv:m.level,xp:Math.round(m.xp),money:Math.round(m.money),str:m.str,edu:m.edu,end:m.end,
    energy:Math.round(m.energy),loc:myReg().n,res:homeReg().n,party:pt?pt.n:'',role:roleName(),
    stor:Object.fromEntries(RES.map(r=>[r,Math.round(m.stor[r]*10)/10])),items:Object.assign({},m.items),
    facs:m.facs.length,works:m.works||0,hits:m.hits||0,learn:m.learn?PERKS[m.learn.perk]:'',paper:m.paper?m.paper.name:'',
    tax:Math.round(m.taxPaid||0),seen:Date.now(),admin:!!m.admin};
};
MP.sync=async()=>{
  if(!MP.ok||MP.busy)return;MP.busy=true;
  try{
    const uid=MP.uid();
    await MP.fb('PUT','players/'+uid,MP.summary());
    try{await MP.cloudSave();}catch(e){}
    try{await adminSync();}catch(e){}
    // olay akışı
    const ev=MP.q.splice(0,30);
    if(ev.length){const o={};ev.forEach((e,i)=>o[e.t+'_'+uid.slice(0,5)+'_'+i]=e);await MP.fb('PATCH','feed',o);}
    // vergi oranı (oyuncu)
    const r=await MP.fb('GET','cfg/taxRate');if(typeof r==='number'&&r>=0&&r<=90)MP.rate=r;
    // hediyeler
    const g=await MP.fb('GET','gifts/'+uid);
    if(g&&typeof g==='object'){for(const id in g){const x=g[id];
      if(x){if(+x.money>0)S.me.money+=+x.money;if(+x.gold>0)S.me.stor.gold=Math.min(storCap(),S.me.stor.gold+ +x.gold);
        L(`🎁 Yöneticiden hediye: ${x.money?fmt(x.money)+'₺ ':''}${x.gold?x.gold+' altın ':''}${x.msg?'— '+String(x.msg).slice(0,80):''}`,'ok');}
      await MP.fb('DELETE','gifts/'+uid+'/'+id);}S.dirty=true;}
    if(MP.role==='admin'){
      const pl=await MP.fb('GET','players');MP.players=pl||{};
      try{await admBansLoad();}catch(e){}
      const fd=await MP.fb('GET','feed',undefined,'orderBy=%22%24key%22&limitToLast=120');
      MP.feed=fd?Object.keys(fd).sort().reverse().map(k=>fd[k]):[];
      let got=0;S.adm=S.adm||{claimed:{},collected:0};
      for(const id in MP.players){if(id===uid)continue;const t=+MP.players[id].tax||0,c=S.adm.claimed[id]||0;
        if(t>c){got+=t-c;S.adm.claimed[id]=t;}else if(t<c)S.adm.claimed[id]=t;}
      if(got>0){S.me.money+=got;S.adm.collected+=got;L(`💰 Pazar vergisi geliri: +${fmt(got)}₺`,'ok');}
      if(typeof botSrvTick==='function')await botSrvTick();
      S.dirty=true;
    }
    if(typeof socialSync==='function')await socialSync();
    MP.lastSync=Date.now();MP.err='';
  }catch(e){MP.err=String(e.message||e);}
  MP.busy=false;
  if(['net','adm'].includes(UI.tab))S.dirty=true;
};
MP.ev=(m)=>{if(!MP.ok)return;MP.q.push({t:Date.now(),u:S.me.name,m:m});if(MP.q.length>80)MP.q.shift();};

/* eylemleri izle: durum imzası değiştiyse olay akışına yaz */
const MP_LBL={work:'çalıştı',workAll:'çalıştı (tüm enerji)',buy:'pazardan aldı',sell:'pazara sattı',craft:'üretim başlattı',facBuild:'fabrika kurdu',facUp:'fabrika yükseltti',
  learn:'öğrenmeye başladı',boost:'güçlendirici kullandı',travel:'yola çıktı',resid:'ikamet değiştirdi',createParty:'parti kurdu',joinParty:'partiye katıldı',leaveParty:'partiden ayrıldı',
  campaign:'kampanya yaptı',vote:'oy kullandı',propose:'kanun teklif etti',lobby:'lobi yaptı',hit:'savaşta vurdu',hitAll:'savaşta vurdu (tüm enerji)',declare:'savaş ilan etti',paperCreate:'gazete kurdu',paperPost:'makale yazdı',drink:'enerji içti',minister:'bakanlık değiştirdi'};
const mpSig=()=>{const m=S.me;return JSON.stringify([m.money,m.stor,m.items,m.learn&&m.learn.perk,m.boost&&m.boost.end,m.travel&&m.travel.to,m.res,m.party,S.laws.length,m.hits,m.works,m.facs.length,m.paper&&m.paper.posts,m.craftQ.length,m.votedFor,m.lastCamp,m.energy]);};
function mpWrap(){
  Object.keys(MP_LBL).forEach(k=>{const f=ACT[k];if(!f)return;
    ACT[k]=function(d){d=d||{};const a=mpSig();const r=f(d);if(mpSig()!==a){
      const det=[d.r?RES_N[d.r]:'',d.k?(ITEMS[d.k]||{n:d.k}).n:'',d.p&&PERKS[d.p]?PERKS[d.p]:'',d.n&&d.n!=='all'?'×'+d.n:'',d.n==='all'?'hepsini':'',d.to!==undefined&&S.regions[+d.to]?S.regions[+d.to].n:''].filter(Boolean).join(' ');
      MP.ev(`${MP_LBL[k]}${det?' · '+det:''}`);}return r;};});
}

/* ---- eylemler ---- */
ACT.mpConnect=()=>{
  const g=id=>(($(id)||{}).value||'').trim();
  const old=MP.cfg||{};
  MP.cfg={key:g('mpKey')||old.key,url:g('mpUrl')||old.url,name:(g('mpName')||old.name||'Oyuncu').slice(0,20)};
  if(!MP.cfg.key||!/^https:\/\//.test(MP.cfg.url))return msg('apiKey ve https:// ile başlayan databaseURL gerekli.');
  MP.saveCfg();MP.connect();
};
MP.doAuth=async(mode)=>{
  const g=id=>(($(id)||{}).value||'').trim();
  const old=MP.cfg||{};
  MP.cfg={key:g('mpKey')||old.key||DEF_KEY,url:g('mpUrl')||old.url||DEF_URL,name:(g('mpName')||String(g('mpUser')||'').split('@')[0]||old.name||'Oyuncu').slice(0,20)};
  MP.err='';MP.connecting=true;S.dirty=true;render();
  try{
    await MP.account(mode,g('mpUser'),($('mpPass')||{}).value||'');
    MP.saveCfg();MP.connecting=false;
    if(mode==='link'){S.mpUid=MP.uid();save();toast('Hesabın şifreyle korundu: artık her telefondan girebilirsin.','ok');}
    await MP.connect();
  }catch(e){MP.err=String(e.message||e);}
  MP.connecting=false;S.dirty=true;render();
};
ACT.mpLogin=()=>{MP.doAuth('login');};
ACT.mpOwner=async()=>{   // e-postayla kayıt ol + yönetici ol (tek adım)
  const g=id=>(($(id)||{}).value||'').trim();
  const em=g('mpUser').toLowerCase();
  if(em.indexOf('@')<1){MP.err='Yönetici hesabı için gerçek bir e-posta adresi yaz (şifreni unutursan buraya sıfırlama gelir).';S.dirty=true;render();return;}
  if(!confirm('Bu e-postayla YÖNETİCİ (game master) hesabı kurulacak. Yalnızca bir kez yapılır; sonra her telefondan bu e-posta ve şifreyle girersin. Devam?'))return;
  await MP.doAuth('register');
  if(MP.ok&&MP.role!=='admin'){
    if(MP.owner&&MP.owner!==MP.uid()){MP.err='Bu oyunun zaten bir yöneticisi var. Yönetici sensen "Giriş yap"ı kullan.';}
    else await MP.claim();
  }
  S.dirty=true;render();
};
ACT.mpForgot=async()=>{
  const em=((($('mpUser')||{}).value)||'').trim().toLowerCase();
  if(em.indexOf('@')<1){MP.err='Şifre sıfırlama yalnızca e-postayla açılan hesaplarda çalışır. E-postanı kullanıcı kutusuna yaz.';S.dirty=true;render();return;}
  try{
    const c=MP.cfg||{key:DEF_KEY};
    const r=await fetch('https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key='+(c.key||DEF_KEY),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({requestType:'PASSWORD_RESET',email:em})});
    const j=await r.json();
    if(j.error)throw new Error(/EMAIL_NOT_FOUND/.test(j.error.message)?'Bu e-postayla hesap yok.':j.error.message);
    msg('📧 Şifre sıfırlama bağlantısı e-postana gönderildi (spam klasörüne de bak).','ok');
  }catch(e){MP.err=String(e.message||e);S.dirty=true;render();}
};
ACT.mpRegister=()=>{MP.doAuth('register');};
ACT.mpLink=()=>{MP.doAuth('link');};
ACT.mpLogout=async()=>{
  if(!confirm('Çıkış yapılsın mı? Oyunun hesabında bulutta durur; başka telefonda aynı kullanıcı adıyla devam edebilirsin.'))return;
  try{await MP.cloudSave(true);}catch(e){}
  MP.ok=false;MP.auth=null;MP.role='player';MP.saveCfg();S.mpUid=null;save();msg('Çıkış yapıldı.','ok');S.dirty=true;render();
};
ACT.mpOff=()=>{try{MP.cloudSave(true);}catch(e){}MP.ok=false;MP.cfg=null;MP.auth=null;MP.role='player';try{localStorage.removeItem(MPK);}catch(e){}msg('Bağlantı kesildi (oyun yerelde devam eder).','ok');};
ACT.mpClaim=()=>{MP.claim();};
ACT.mpSync=()=>{MP.sync();};
ACT.mpCopy=()=>{
  let ok=false;
  try{const t=document.createElement('textarea');t.value=FULL_RULES;t.style.cssText='position:fixed;left:0;top:0;opacity:0';document.body.appendChild(t);t.focus();t.select();t.setSelectionRange(0,t.value.length);ok=document.execCommand('copy');t.remove();}catch(e){}
  if(ok){msg('Kurallar kopyalandı.','ok');return;}
  try{if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(FULL_RULES).then(()=>msg('Kurallar kopyalandı.','ok'),()=>rulesModal());return;}}catch(e){}
  rulesModal();
};
function rulesModal(){
  $('modal-root').innerHTML=`<div class="modal"><div class="box"><h3>Firebase kuralları</h3><p class="hint">Metne dokun, tümünü seç ve kopyala (basılı tut → Tümünü seç → Kopyala). Sonra Firebase'de Tüzük sekmesine yapıştır.</p><textarea id="rulesTa" readonly style="width:100%;height:46vh;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:6px;font-size:11px;font-family:monospace;padding:8px">${esc(FULL_RULES)}</textarea><div class="btns"><button class="act" onclick="var t=document.getElementById('rulesTa');t.focus();t.select();t.setSelectionRange(0,t.value.length);try{document.execCommand('copy')}catch(e){}">Tümünü seç</button><button class="act danger" onclick="this.closest('.modal').remove()">Kapat</button></div></div></div>`;
}
ACT.mpTax=async()=>{
  const v=+($('mpRate')||{}).value;if(isNaN(v)||v<0||v>90)return msg('Oran 0–90 arasında olmalı.');
  try{await MP.fb('PUT','cfg/taxRate',v);MP.rate=v;msg('Vergi oranı %'+v+' yapıldı.','ok');}catch(e){msg(String(e.message));}S.dirty=true;render();
};
ACT.mpSel=d=>{MP.sel=d.id;};
ACT.mpGift=async()=>{
  const id=MP.sel;if(!id)return msg('Önce bir oyuncu seç.');
  const money=+($('gfMoney')||{}).value||0,gold=+($('gfGold')||{}).value||0,m=(($('gfMsg')||{}).value||'').slice(0,80);
  if(money<=0&&gold<=0)return msg('Para veya altın miktarı gir.');
  const bt=botById(id);if(bt&&S.botSrv){botSrvCmd({k:'gift',ids:[bt.i],money:Math.max(0,money),gold:Math.max(0,gold)});return;}
  if(bt){bt.m+=Math.max(0,money);bt.g+=Math.max(0,gold);return msg('🎁 Yapay zekâ oyuncuya verildi.','ok');}
  try{await MP.fb('POST','gifts/'+id,{money:money,gold:gold,msg:m});msg('🎁 Hediye gönderildi.','ok');}catch(e){msg(String(e.message));}
};
ACT.mpClearFeed=async()=>{try{await MP.fb('DELETE','feed');MP.feed=[];msg('Olay akışı temizlendi.','ok');}catch(e){msg(String(e.message));}S.dirty=true;render();};

/* ---- sekmeler ---- */
const ago=t=>{const s=Math.max(0,(Date.now()-t)/1000);return s<90?'çevrimiçi':s<3600?Math.round(s/60)+' dk önce':s<86400?Math.round(s/3600)+' sa önce':Math.round(s/86400)+' gün önce';};
function tabNet(){
  const c=MP.cfg||{key:DEF_KEY,url:DEF_URL,name:S.me.name};
  const inp='style="width:100%;padding:8px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px;margin:4px 0"';
  let h=`<div class="panel"><h2>⚙️ Hesap ve bağlantı</h2>
  <div class="card"><p>Durum: ${MP.connecting?'bağlanıyor…':MP.ok?`<b class="ok">bağlı</b> · rol: <b>${MP.role==='admin'?'👑 Yönetici':'Oyuncu'}</b> · pazar vergisi %${MP.rate}`:'<b class="dim">bağlı değil (tek başına oynuyorsun)</b>'}</p>
  ${MP.err?`<p class="bad">${esc(MP.err)}</p>`:''}
  <label>Oyuncu adın (oyunda görünen)</label><input type="text" id="mpName" ${inp} value="${esc(c.name||'')}" maxlength="20">
  ${MP.auth&&MP.auth.user?`<p>Hesap: <b>${esc(MP.auth.user)}</b> ${MP.role==='admin'?'👑':''}</p>`:`<div class="card"><h3>${MP.auth?'Hesabını şifreyle koru':'Hesap'}</h3>${MP.auth?'<p class="dim">Bu telefondaki bağlantı şifresiz (anonim). Kullanıcı adı ve şifre koyarsan yönetici/oyuncu hakların kaybolmaz ve her telefondan girebilirsin.</p>':'<p class="dim">Kullanıcı adı ve şifre ile giriş yap; hesabın ve oyunun her telefonda seninle gelir.</p>'}
  <label>Kullanıcı adı ya da e-posta</label><input type="text" id="mpUser" ${inp} autocapitalize="off" autocomplete="username" spellcheck="false" maxlength="80">
  <label>Şifre</label><input type="password" id="mpPass" ${inp} autocomplete="current-password">
  <div class="btns">${MP.auth?btn('🔒 Hesabı koru','data-a="mpLink"','gold'):btn('Giriş yap','data-a="mpLogin"','blue')+btn('Kayıt ol (oyuncu)','data-a="mpRegister"')+btn('👑 Yönetici hesabı kur','data-a="mpOwner"','gold')+btn('Şifremi unuttum','data-a="mpForgot"','sm')}</div><p class="hint">Yönetici hesabını bir kez <b>e-postayla</b> kur; sonra her telefondan aynı e-posta ve şifreyle girersin. Şifreni unutursan e-postana sıfırlama gelir.</p></div>`}
  <div class="btns">${MP.auth&&MP.auth.user&&!MP.ok?btn('Bağlan','data-a="mpConnect"','blue'):''}${MP.ok&&MP.role!=='admin'&&!MP.owner?btn('👑 Yönetici ol (ilk kişi)','data-a="mpClaim"','gold'):''}${MP.ok?btn('Şimdi eşitle','data-a="mpSync"'):''}${MP.auth&&MP.auth.user?btn('Çıkış','data-a="mpLogout"'):''}${MP.cfg?btn('Bağlantıyı kes','data-a="mpOff"','danger'):''}</div></div>
  <details class="card"><summary>⚙️ Gelişmiş (sunucu ayarı ve kurulum)</summary>
  <label>Firebase apiKey</label><input type="text" id="mpKey" ${inp} value="${esc(c.key)}" autocapitalize="off" spellcheck="false">
  <label>databaseURL</label><input type="text" id="mpUrl" ${inp} value="${esc(c.url)}" placeholder="https://....firebasedatabase.app" autocapitalize="off" spellcheck="false">
  <div class="card"><h3>Kurulum (bir kez)</h3><p>1) Firebase konsolunda <b>Authentication → Sign-in method → Email/Password</b> girişini aç (Anonymous gerekmez).<br>2) <b>Realtime Database → Kurallar</b> bölümündeki her şeyi sil, aşağıdaki "Kuralları kopyala" ile kopyalanan metni yapıştır ve Yayınla (bu veritabanı yalnızca bu oyun için).<br>3) Yönetici sen olacaksan önce sen kayıt olup "Yönetici ol"a bas; yönetici hesabı kaybolduysa Realtime Database'de <b>rrgame → cfg → owner</b> düğümünü silip yeniden "Yönetici ol" de; diğerleri sonra bağlansın. Aynı apiKey ve databaseURL'yi oyunculara ver.</p>
  <div class="btns">${btn('Kuralları kopyala','data-a="mpCopy"','gold')}</div><pre style="font-size:10px;max-height:200px;overflow:auto;background:#06090d;padding:8px;border-radius:6px;white-space:pre-wrap">${esc(FULL_RULES)}</pre>
  <p class="hint">Not: istemci tabanlı olduğu için bilgisayar bilen bir oyuncu kendi verisini değiştirebilir; arkadaş oyunu için yeterlidir.</p></details>
  </div>`;
  return h;
}
function tabAdm(){
  const rows=Object.keys(MP.players).map(id=>Object.assign({id:id},MP.players[id])).sort((a,b)=>b.seen-a.seen).concat(botRows(25));
  const on=rows.filter(r=>Date.now()-r.seen<90000).length;
  let h=`<div class="panel"><h2>👑 Game Master Paneli</h2><div class="grid">
  ${card('🤖 Yapay zekâ oyuncular',`<div class="row" style="margin:4px 0"><input type="number" id="botN" min="0" max="5000" value="${S.botN||0}" style="width:90px"></div><div class="btns">${btn('Uygula','data-a="botCount"','gold')}${[100,500,1000,2500,5000].map(n=>btn(n,`data-a="botCount" data-n="${n}"`,'sm')).join('')}</div><p class="dim">Şu an ${fmt(S.botN||0)} · Bölgelere dağılır, partiye girer, çalışır, vergi öder, devletlerin gücünü belirler.</p>`)}
  ${card('💰 Vergi geliri',`<div class="big">${fmt(S.adm?S.adm.collected:0)}₺</div><p class="dim">Tüm oyuncuların pazar işlemlerinden</p>`)}
  ${card('👥 Oyuncular',`<div class="big">${rows.length}</div><p>${on} çevrimiçi</p>`)}
  ${card('📊 Pazar vergisi',`<div class="row" style="margin:4px 0"><input type="number" id="mpRate" min="0" max="90" value="${MP.rate}"> <span>%</span></div>${btn('Oranı kaydet','data-a="mpTax"','gold')}<p class="dim">Her alım ve satımda oyuncudan kesilir.</p>`)}
  </div></div><div class="panel"><h2>Oyuncular</h2><div style="overflow-x:auto"><table><tr><th align=left>Oyuncu</th><th>Sv</th><th>💰</th><th>🥇</th><th>Güç/Eği/Day</th><th>Konum</th><th>Vergi</th><th>Durum</th></tr>`;
  rows.forEach(r=>{h+=`<tr style="${MP.sel===r.id?'background:#1a2330':''}"><td><button class="act sm ${r.admin?'gold':''}" data-a="mpSel" data-id="${r.id}">${r.bot?'🤖 ':''}${esc(r.name)}${r.admin?' 👑':''}</button></td><td class="num">${r.lv}</td><td class="num">${fmt(r.money)}</td><td class="num">${f1(r.stor?r.stor.gold:0)}</td><td class="num">${r.str}/${r.edu}/${r.end}</td><td>${esc(r.loc||'')}</td><td class="num">${fmt(r.tax||0)}</td><td class="${Date.now()-r.seen<90000?'ok':'dim'}">${ago(r.seen)}</td></tr>`;});
  h+=`</table></div>${rows.length?'':'<p class="dim">Henüz oyuncu yok. Oyunculara apiKey + databaseURL ver.</p>'}</div>`;
  const s=MP.players[MP.sel]||botRowById(MP.sel);
  if(s){h+=`<div class="panel"><h2>🔍 ${esc(s.name)}</h2><div class="grid">
    ${card('Karakter',`<p>Seviye ${s.lv} (${s.xp} xp) · ${esc(s.role||'')}</p><p>Güç ${s.str} · Eğitim ${s.edu} · Dayanıklılık ${s.end}</p><p>Enerji ${s.energy} · Öğreniyor: ${esc(s.learn||'—')}</p>`)}
    ${card('Konum',`<p>Şu an: ${esc(s.loc)}</p><p>İkamet: ${esc(s.res)}</p><p>Parti: ${esc(s.party||'—')} · Gazete: ${esc(s.paper||'—')}</p>`)}
    ${card('Depo',`<p>💰 ${fmt(s.money)}₺</p><p class="dim">${RES.map(r=>`${RES_I[r]} ${f1((s.stor||{})[r]||0)}`).join(' · ')}</p><p class="dim">${Object.keys(s.items||{}).filter(k=>s.items[k]>0).map(k=>`${ITEMS[k].i} ${s.items[k]}`).join(' · ')||'Eşya yok'}</p>`)}
    ${card('Etkinlik',`<p>İş: ${s.works} · Savaş vuruşu: ${s.hits} · Fabrika: ${s.facs}</p><p>Ödediği vergi: <b>${fmt(s.tax||0)}₺</b></p>`)}
    </div><div class="card" style="margin-top:8px"><h3>🎁 Hediye gönder</h3><div class="row" style="margin:4px 0"><input type="number" id="gfMoney" min="0" placeholder="Para"><input type="number" id="gfGold" min="0" placeholder="Altın"><input type="text" id="gfMsg" placeholder="Not" maxlength="80" style="flex:1;padding:6px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px"></div>${btn('Gönder','data-a="mpGift"','gold')}</div></div>`;}
  h+=`<div class="panel"><h2>📡 Canlı olay akışı</h2><div class="log tall">${MP.feed.concat(S.botFeed||[]).sort((a,b)=>b.t-a.t).slice(0,150).map(e=>`<div>[${new Date(e.t).toLocaleTimeString('tr-TR')}] <b>${e.b?'🤖 ':''}${esc(e.u||'?')}</b> ${esc(e.m)}</div>`).join('')||'<div class="dim">Henüz olay yok.</div>'}</div><div class="btns" style="margin-top:8px">${btn('Akışı temizle','data-a="mpClearFeed"','danger')}</div></div>`;
  if(typeof adminExtra==='function')h+=adminExtra();
  return h;
}

/* ================= SOHBET + OYUNCU PAZARI (Firebase) ================= */
const CHAT={msgs:[],err:'',last:0,sig:'',lastSend:0,unread:0,ch:'g',dm:null,inbox:{},dmUnread:0,gen:[]};
const MK={list:[],err:'',last:0,sig:'',busy:false};
function chatSeen(){try{return localStorage.getItem('rrchat_seen')||'';}catch(e){return '';}}
function chatMark(k){try{localStorage.setItem('rrchat_seen',k);}catch(e){}}
const rulesHint=e=>{const m=String(e&&e.message||e);if(!/401|403|ermission/i.test(m))return m;
  const mine=(typeof MP!=='undefined'&&MP.uid&&MP.uid())||'?',ow=(typeof MP!=='undefined'&&MP.owner)||'?';
  const own=(ow!=='?'&&mine!=='?'&&ow!==mine)?' ⚠️ Bu hesap dünyanın yöneticisi DEĞİL (kayıtlı yönetici: '+String(ow).slice(0,6)+'…, bu hesap: '+String(mine).slice(0,6)+'…). Yönetici hesabınla giriş yapmalısın.':' Yönetici hesabı doğru; kurallar bu veritabanında yayınlanmamış. Veritabanı: '+String((MP.cfg&&MP.cfg.url)||'').replace(/^https?:\/\//,'').slice(0,40);
  return 'Reddedildi ('+m.slice(0,60)+').'+own;};
const pairKey=(a,b)=>[a,b].sort().join('_');
function chatPath(ch){
  ch=ch||CHAT.ch;
  if(ch==='p'&&S.me.party)return 'pchat/'+S.me.party;
  if(ch==='d'&&CHAT.dm)return 'dm/'+pairKey(MP.uid(),CHAT.dm.id);
  return 'chat';
}
function dmSeen(){try{return JSON.parse(localStorage.getItem('rrdm_seen')||'{}');}catch(e){return {};}}
function dmMark(peer,t){try{const o=dmSeen();o[peer]=t;localStorage.setItem('rrdm_seen',JSON.stringify(o));}catch(e){}}
async function chatPoll(){
  if(!MP.ok)return;CHAT.last=Date.now();
  try{
    const onTab=UI.tab==='chat'||UI.tab==='msg',path=onTab?chatPath():'chat';
    const d=await MP.fb('GET',path,undefined,'orderBy=%22%24key%22&limitToLast=60');
    const keys=d?Object.keys(d).sort():[];const arr=keys.map(k=>Object.assign({k:k},d[k]));CHAT.err='';
    const last=keys.length?keys[keys.length-1]:'';
    if(onTab&&CHAT.ch==='d'&&CHAT.dm)dmMark(CHAT.dm.id,Date.now());
    if(onTab){CHAT.msgs=arr;if(path==='chat'){if(last)chatMark(last);CHAT.unread=0;}}
    else{CHAT.gen=arr;const sn=chatSeen();CHAT.unread=keys.filter(k=>k>sn).length;if(!sn&&last)chatMark(last),CHAT.unread=0;}
    // özel mesaj kutusu
    let dmu=0;try{const ib=await MP.fb('GET','dminbox/'+MP.uid())||{};CHAT.inbox=ib;const sn=dmSeen();
      Object.keys(ib).forEach(p=>{if(!(sn[p]>=ib[p].t)&&!(onTab&&CHAT.ch==='d'&&CHAT.dm&&CHAT.dm.id===p))dmu++;});}catch(e){}
    CHAT.dmUnread=dmu;
    const sig=path+keys.length+':'+last+':'+CHAT.unread+':'+dmu;
    if(sig!==CHAT.sig){CHAT.sig=sig;S.dirty=true;}
  }catch(e){CHAT.err=rulesHint(e);if(UI.tab==='chat'||UI.tab==='msg')S.dirty=true;}
}
async function mkPoll(){
  if(!MP.ok)return;MK.last=Date.now();
  try{
    const d=await MP.fb('GET','market');
    MK.list=d?Object.keys(d).map(k=>Object.assign({id:k},d[k])).filter(x=>x&&x.r&&x.q>0&&x.p>0).sort((a,b)=>a.p-b.p):[];MK.err='';
    const sig=MK.list.map(x=>x.id+x.q+x.p).join(',');if(sig!==MK.sig){MK.sig=sig;if(UI.tab==='mkt')S.dirty=true;}
  }catch(e){MK.err=rulesHint(e);if(UI.tab==='mkt')S.dirty=true;}
}
const mIt=r=>!RES.includes(r)&&!!ITEMS[r];
const mi=r=>RES.includes(r)?{i:RES_I[r],n:RES_N[r]}:(ITEMS[r]?{i:ITEMS[r].i,n:ITEMS[r].n}:{i:'📦',n:String(r)});
const mstk=r=>mIt(r)?((S.me.items||{})[r]||0):S.me.stor[r];
const mstkAdd=(r,n)=>{if(mIt(r)){S.me.items=S.me.items||{};S.me.items[r]=(S.me.items[r]||0)+n;}else S.me.stor[r]+=n;};
async function settleFlush(){ // bekleyen ödemeleri (alıcı → satıcı) gönder
  const q=S.me.psettle||[];if(!q.length||!MP.ok)return;
  for(const x of q.slice()){try{await MP.fb('PUT','settle/'+x.to+'/'+x.id,{amt:x.amt,r:x.r,q:x.q,bn:x.bn,t:x.t,kind:x.kind,sku:x.sku,from:x.from});S.me.psettle=S.me.psettle.filter(y=>y.id!==x.id);}catch(e){}}
}
async function settleCollect(){ // satıcı: gelen ödemeleri tahsil et
  if(!MP.ok)return;
  try{
    const d=await MP.fb('GET','settle/'+MP.uid());if(!d||typeof d!=='object')return;
    S.me.settled=S.me.settled||{};
    for(const k in d){const x=d[k];if(!x)continue;
      if(!S.me.settled[k]&&x.kind&&typeof autoHandle==='function'){autoHandle(k,x);S.me.settled[k]=1;S.dirty=true;}
      else if(!S.me.settled[k]){
        const tax=S.me.admin?0:Math.floor(x.amt*(RES.includes(x.r)?taxFor(x.r):MP.rate)/100);
        S.me.money+=x.amt-tax;S.me.taxPaid=(S.me.taxPaid||0)+tax;S.me.settled[k]=1;
        L(`🛒 ${x.bn||'Bir oyuncu'} senden ${x.q} ${mi(x.r).n} aldı: +${fmt(x.amt-tax)}₺${tax?` (vergi ${fmt(tax)}₺)`:''}`,'ok');S.dirty=true;}
      try{await MP.fb('DELETE','settle/'+MP.uid()+'/'+k);}catch(e){}}
    const ks=Object.keys(S.me.settled);if(ks.length>300)ks.slice(0,150).forEach(k=>delete S.me.settled[k]);
  }catch(e){}
}
async function socialSync(){if(typeof lbPush==='function')await lbPush();await settleFlush();await settleCollect();if(typeof swPoll==='function')await swPoll();if(typeof allyPoll==='function')await allyPoll();if(typeof wkReward==='function')await wkReward();if(UI.tab!=='chat'&&Date.now()-CHAT.last>25000)await chatPoll();}
function socialTick(){
  if(!MP.ok)return;
  if((UI.tab==='chat'||UI.tab==='msg')&&Date.now()-CHAT.last>(CHAT.last?4000:0))chatPoll();
  if((UI.tab==='sw'||UI.tab==='world')&&typeof swPoll==='function'&&Date.now()-SW.last>5000)swPoll();
  if(UI.tab==='art'&&typeof artPoll==='function'&&Date.now()-AR.last>8000)artPoll();
  if(UI.tab==='ally'&&typeof allyPoll==='function'&&Date.now()-AL.last>5000)allyPoll();
  if(UI.tab==='mkt'&&Date.now()-MK.last>6000){mkPoll();settleCollect();}
}
/* ---- eylemler ---- */
ACT.chatSend=async()=>{
  const el=$('chatMsg');const m=((el&&el.value)||'').trim().slice(0,200);
  if(!MP.ok)return msg('Önce Profil › Hesap bölümünden giriş yap.');if(!m)return;
  if(MP.ban&&MP.ban.chat&&!S.me.admin)return msg('Yönetici seni susturdu.');
  if(CHAT.ch==='d'&&!CHAT.dm)return msg('Önce mesajlaşacağın kişiyi seç.');
  if(CHAT.ch==='p'&&!S.me.party)return msg('Parti sohbeti için bir partiye katıl.');
  if(Date.now()-CHAT.lastSend<1500)return msg('Biraz yavaş.');CHAT.lastSend=Date.now();
  const key=Date.now()+'_'+MP.uid().slice(0,6),body={u:S.me.name,m:m,t:Date.now(),uid:MP.uid(),ad:S.me.admin?1:0};
  if(S.me.admin&&CHAT.ch==='g'&&($('chatAnn')||{}).checked)body.a=1;
  const path=chatPath();if(el)el.value='';
  try{
    await MP.fb('PUT',path+'/'+key,body);S.me.msgs=(S.me.msgs||0)+1;
    if(CHAT.ch==='d')await MP.fb('PUT','dminbox/'+CHAT.dm.id+'/'+MP.uid(),{u:S.me.name,t:Date.now()});
    CHAT.msgs.push(Object.assign({k:key},body));if(CHAT.ch==='g')chatMark(key);S.dirty=true;render();}
  catch(e){msg(rulesHint(e));if(el)el.value=m;}
};
ACT.chatCh=d=>{CHAT.ch=d.c;CHAT.msgs=[];CHAT.last=0;CHAT.sig='';if(d.c==='d'&&!LB.rows.length&&typeof lbPoll==='function')lbPoll();};
ACT.dmOpen=d=>{
  const id=d.id||($('dmPick')||{}).value;if(!id)return;
  const row=(LB.rows||[]).find(r=>r.id===id),ib=CHAT.inbox[id];
  CHAT.dm={id:id,name:d.name||(row&&row.name)||(ib&&ib.u)||'Oyuncu'};CHAT.ch='d';CHAT.msgs=[];CHAT.last=0;CHAT.sig='';dmMark(id,Date.now());
};
ACT.dmBack=()=>{CHAT.dm=null;CHAT.msgs=[];};
ACT.chatDel=async d=>{try{await MP.fb('DELETE',chatPath()+'/'+d.k);CHAT.msgs=CHAT.msgs.filter(x=>x.k!==d.k);S.dirty=true;render();}catch(e){msg(rulesHint(e));}};
ACT.chatClear=async()=>{if(!S.me.admin)return;try{await MP.fb('DELETE','chat');CHAT.msgs=[];S.dirty=true;render();msg('Sohbet temizlendi.','ok');}catch(e){msg(rulesHint(e));}};
ACT.mkSell=async()=>{
  if(!MP.ok)return msg('Önce Profil › Hesap bölümünden giriş yap.');
  const r=($('mkRes')||{}).value,q=Math.floor(+($('mkQty')||{}).value),p=+($('mkPrice')||{}).value;
  if(!RES.includes(r)&&!ITEMS[r])return msg('Kaynak ya da eşya seç.');if(!(q>=1))return msg('Miktar en az 1 olmalı.');if(!(p>0))return msg('Birim fiyat gir.');
  if(mstk(r)<q)return msg(`Yeterli ${mi(r).n} yok.`);
  if(MK.list.filter(x=>x.s===MP.uid()).length>=8)return msg('En fazla 8 ilanın olabilir.');
  const id=Date.now()+'_'+MP.uid().slice(0,6);
  mstkAdd(r,-q);
  try{await MP.fb('PUT','market/'+id,{s:MP.uid(),sn:S.me.name,r:r,q:q,p:Math.round(p*100)/100,t:Date.now()});
    MK.list.push({id:id,s:MP.uid(),sn:S.me.name,r:r,q:q,p:Math.round(p*100)/100,t:Date.now()});MK.list.sort((a,b)=>a.p-b.p);
    MP.ev(`pazara ilan koydu · ${mi(r).n} ×${q} @ ${fmt(p)}₺`);msg('İlan verildi.','ok');}
  catch(e){mstkAdd(r,q);msg(rulesHint(e));}
  S.dirty=true;render();
};
ACT.mkCancel=async d=>{
  const x=MK.list.find(y=>y.id===d.id);if(!x||x.s!==MP.uid())return;
  try{await MP.fb('DELETE','market/'+x.id);mstkAdd(x.r,x.q);MK.list=MK.list.filter(y=>y.id!==x.id);msg('İlan geri çekildi.','ok');}
  catch(e){msg('İlan zaten satılmış olabilir; ödeme kısa süre içinde gelir.');mkPoll();}
  S.dirty=true;render();
};
ACT.mkBuy=async d=>{
  const x=MK.list.find(y=>y.id===d.id);if(!x)return msg('İlan bulunamadı.');
  if(!MP.ok)return;if(x.s===MP.uid())return msg('Kendi ilanını alamazsın.');
  const total=Math.round(x.q*x.p);
  if(S.me.money<total)return msg(`Yetersiz para (${fmt(total)}₺).`);
  if(!mIt(x.r)&&S.me.stor[x.r]+x.q>storCap())return msg('Depon bu miktarı almaya yetmiyor.');
  try{await MP.fb('PUT','claims/'+x.id,{b:MP.uid(),bn:S.me.name,t:Date.now(),tot:total});}
  catch(e){MK.list=MK.list.filter(y=>y.id!==x.id);S.dirty=true;render();return msg(/401|403|ermission/i.test(e.message)?'Bu ilan başkası tarafından alındı ya da geri çekildi.':rulesHint(e));}
  S.me.money-=total;mstkAdd(x.r,x.q);
  S.me.psettle=S.me.psettle||[];S.me.psettle.push({to:x.s,id:x.id,amt:total,r:x.r,q:x.q,bn:S.me.name,t:Date.now()});
  MK.list=MK.list.filter(y=>y.id!==x.id);
  L(`🛒 ${x.sn} oyuncusundan ${x.q} ${mi(x.r).n} aldın (−${fmt(total)}₺).`,'ok');MP.ev(`${x.sn} oyuncusundan satın aldı · ${mi(x.r).n} ×${x.q} (${fmt(total)}₺)`);
  try{await MP.fb('DELETE','market/'+x.id);}catch(e){}
  settleFlush();S.dirty=true;render();
};
/* ---- sekmeler ---- */
function tabChat(){
  let h=`<div class="panel"><h2>💬 Sohbet</h2>`;
  if(!MP.ok)return h+'<div class="al warn">Sohbet için Profil › Hesap bölümünden giriş yap.</div></div>';
  const m=S.me;
  if(CHAT.ch==='p'&&!m.party)CHAT.ch='g';
  h+=`<div class="btns" style="margin-bottom:8px">${btn('🌍 Genel','data-a="chatCh" data-c="g"',CHAT.ch==='g'?'gold':'')}${m.party?btn('🗳️ Parti','data-a="chatCh" data-c="p"',CHAT.ch==='p'?'gold':''):''}${btn('✉️ Özel'+(CHAT.dmUnread?` (${CHAT.dmUnread})`:''),'data-a="chatCh" data-c="d"',CHAT.ch==='d'?'gold':'')}</div>`;
  if(CHAT.err)h+=`<div class="al bad">${esc(CHAT.err)}</div>`;
  if(CHAT.ch==='d'&&!CHAT.dm){
    const sn=dmSeen(),ib=Object.keys(CHAT.inbox).map(k=>Object.assign({id:k},CHAT.inbox[k])).sort((a,b)=>b.t-a.t);
    const others=(LB.rows||[]).filter(r=>r.id!==MP.uid()&&!r.adm||(r.adm&&r.id!==MP.uid()));
    h+=`<div class="card"><h3>Yeni özel mesaj</h3><div class="row">${sel('dmPick',[['','Kişi seç…']].concat(others.map(r=>[r.id,r.name+' (Sv '+r.lv+')'])),'')}${btn('Aç','data-a="dmOpen"','blue')}</div>${others.length?'':'<p class="dim">Henüz başka oyuncu görünmüyor (Sosyal › Sıralama sekmesini bir kez aç).</p>'}</div>`;
    h+='<h2 style="margin-top:10px">Konuşmalar</h2>';
    if(!ib.length)h+='<p class="dim">Henüz özel mesajın yok.</p>';
    ib.forEach(x=>{h+=`<div class="q"><b>${esc(x.u)}</b> ${sn[x.id]>=x.t?'':'<span class="owner" style="background:#da3633;color:#fff">yeni</span>'} <small class="dim">${new Date(x.t).toLocaleString('tr-TR')}</small> ${btn('Aç',`data-a="dmOpen" data-id="${x.id}" data-name="${esc(x.u)}"`,'sm')}</div>`;});
    return h+'</div>';
  }
  if(CHAT.ch==='d')h+=`<div class="btns">${btn('← Konuşmalar','data-a="dmBack"','sm')}<b style="padding:6px">✉️ ${esc(CHAT.dm.name)}</b></div>`;
  if(CHAT.ch==='p')h+=`<p class="dim">Parti kanalı: ${esc(myParty()?myParty().n:'')} üyeleri</p>`;
  h+=`<div class="log tall" id="chatBox">${CHAT.msgs.map(x=>`<div class="${x.a?'warn':''}">[${new Date(x.t).toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'})}] ${x.a?'📢 ':''}<b style="color:${x.ad?'#f0c040':(x.uid===MP.uid()?'#3fb950':'#58a6ff')}">${esc(x.u)}${x.ad?' 👑':''}</b>: ${esc(x.m)}${S.me.admin&&CHAT.ch!=='d'?` <button class="act sm danger" data-a="chatDel" data-k="${x.k}">sil</button>`:''}</div>`).join('')||'<div class="dim">Henüz mesaj yok.</div>'}</div>
  <div class="row" style="margin-top:8px"><input type="text" id="chatMsg" maxlength="200" placeholder="Mesaj yaz…" style="flex:1;padding:9px;background:#06090d;color:#c9d1d9;border:1px solid #2a3542;border-radius:5px">${btn('Gönder','data-a="chatSend"','blue')}</div>`;
  if(S.me.admin&&CHAT.ch==='g')h+=`<div class="btns"><label><input type="checkbox" id="chatAnn"> 📢 Duyuru olarak gönder</label>${btn('Sohbeti temizle','data-a="chatClear"','danger sm')}</div>`;
  return h+'<p class="hint">Mesajlar birkaç saniyede bir yenilenir. Küfür ve reklam yasak; yönetici genel ve parti mesajlarını silebilir. Özel mesajları yalnızca iki taraf okuyabilir.</p></div>';
}
function tabMkt(){
  const m=S.me;
  let h=`<div class="panel"><h2>🛒 Oyuncu pazarı</h2>`;
  if(!MP.ok)return h+'<div class="al warn">Oyuncu pazarı için Profil › Hesap bölümünden giriş yap.</div></div>';
  if(MK.err)h+=`<div class="al bad">${esc(MK.err)}</div>`;
  h+=`<p class="hint">Oyuncular kaynaklarını kendi fiyatıyla satar. Satışta %${MP.rate} pazar vergisi satıcıdan kesilir (yöneticiye gider). İlan verince kaynak emanete alınır; geri çekersen iade edilir. İlanlar bütün lot halinde satın alınır.</p>
  <div class="card"><h3>Yeni ilan</h3><div class="row" style="margin:4px 0">${sel('mkRes',RES.map(r=>[r,`${RES_I[r]} ${RES_N[r]} (depoda ${f1(m.stor[r])})`]).concat(Object.keys(ITEMS).map(k=>[k,`${ITEMS[k].i} ${ITEMS[k].n} (eşya · ${(m.items||{})[k]||0})`])))}<input type="number" id="mkQty" min="1" placeholder="Miktar"><input type="number" id="mkPrice" min="0" step="any" placeholder="Birim fiyat ₺"></div><p class="dim">Devlet pazarı fiyatı: ${RES.map(r=>`${RES_I[r]}${fmt(S.prices[r])}₺`).join(' ')}</p>${btn('İlan ver','data-a="mkSell"','gold')}</div>`;
  const mine=MK.list.filter(x=>x.s===MP.uid()),others=MK.list.filter(x=>x.s!==MP.uid());
  if(mine.length){h+='<h2 style="margin-top:12px">İlanların</h2>';mine.forEach(x=>{h+=`<div class="q">${mi(x.r).i} ${x.q} ${mi(x.r).n} × ${fmt(x.p)}₺ = <b>${fmt(x.q*x.p)}₺</b> ${btn('Geri çek',`data-a="mkCancel" data-id="${x.id}"`,'sm danger')}</div>`;});}
  h+='<h2 style="margin-top:12px">Satıştaki ilanlar</h2>';
  if(!others.length)h+='<p class="dim">Şu an başka oyuncudan ilan yok.</p>';
  others.forEach(x=>{const t=Math.round(x.q*x.p);h+=`<div class="q">${mi(x.r).i} <b>${x.q} ${mi(x.r).n}</b> × ${fmt(x.p)}₺ = <b>${fmt(t)}₺</b><br><small>${esc(x.sn)} · ${S.prices[x.r]?`devlet fiyatı ${fmt(S.prices[x.r])}₺ ${x.p<S.prices[x.r]?'<span class="ok">(ucuz)</span>':'<span class="bad">(pahalı)</span>'}`:'eşya'}</small> ${btn('Satın al',`data-a="mkBuy" data-id="${x.id}"`,'sm blue',m.money<t)}</div>`;});
  return h+'</div>';
}
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='chatMsg'){e.preventDefault();ACT.chatSend();}});
/* ================= VALİLİK, DARBE, SIRALAMA ================= */
const LB={rows:[],sort:'lv',last:0,err:'',sig:'',per:'all'};
const WK_MS=7*DAY,WK_OFF=4*DAY; // hafta Pazartesi (UTC) başlar
const wkNo=()=>Math.floor((Date.now()-WK_OFF)/WK_MS);
const wkEnd=()=>(wkNo()+1)*WK_MS+WK_OFF;
function wkState(){
  const m=S.me,w=wkNo();
  if(m.wk&&m.wk.w!==w){m.wkPub={w:m.wk.w,wm:Math.round(m.money)-m.wk.money,wd:Math.round(m.dmg||0)-m.wk.dmg};m.wkPubDone=0;}
  if(!m.wk||m.wk.w!==w)m.wk={w:w,lv:m.level,money:Math.round(m.money),dmg:Math.round(m.dmg||0),tax:Math.round(m.taxPaid||0)};
  return m.wk;
}
function wkGain(){const b=wkState(),m=S.me;return {w:b.w,wl:m.level-b.lv,wm:Math.round(m.money)-b.money,wd:Math.round(m.dmg||0)-b.dmg,wt:Math.round(m.taxPaid||0)-b.tax};}
ACT.lbPer=d=>{LB.per=d.p;LB.sort=d.p==='wk'?'wm':'lv';};
/* ---- vali: bölge hazinesi ---- */
function powerTick(h){
  const a=A();
  regOf('A').forEach(r=>{if(r.gov!=='me')return;
    const inc=r.idx.d*3000*(a.tax.inc/100)*(1+0.1*levelB(r,'house')),take=Math.min(a.budget.money,inc*0.4*h);
    if(take>0){a.budget.money-=take;r.treas=(r.treas||0)+take;}});
}
const myGovs=()=>regOf('A').filter(r=>r.gov==='me');
ACT.govAppoint=d=>{
  if(!isLeader())return msg('Yalnızca başkan vali atayabilir.');
  const r=S.regions[+d.id];if(!r||r.state!=='A')return;
  if(myGovs().length>=3)return msg('En fazla 3 bölgenin valisi olabilirsin.');
  r.gov='me';r.treas=r.treas||0;L(`🏙️ ${r.n} bölgesine vali olarak atandın.`,'ok');
};
ACT.govDismiss=d=>{const r=S.regions[+d.id];if(!r||r.gov!=='me')return;r.gov=null;L(`${r.n} valiliğinden ayrıldın.`,'info');};
ACT.govFund=d=>{const r=S.regions[+d.id];if(!r||r.gov!=='me')return;if(S.me.money<100000)return msg('Yetersiz para.');S.me.money-=100000;r.treas=(r.treas||0)+100000;msg('Bölge hazinesine 100.000₺ aktarıldı.','ok');};
ACT.govBuild=d=>{
  const r=S.regions[+d.id];if(!r||r.gov!=='me'||r.state!=='A')return msg('Bu bölgenin valisi değilsin.');
  const b=($('govB_'+r.id)||{}).value;if(!BUILD[b])return;
  if(r.bq.length>=3)return msg('İnşaat sırası dolu.');
  const c=Math.floor(buildCost(r,b)*0.6);if((r.treas||0)<c)return msg(`Bölge hazinesi yetersiz (${fmt(c)}₺).`);
  r.treas-=c;const st=r.bq.length?r.bq[r.bq.length-1].end:S.t;r.bq.push({b:b,start:st,end:st+buildTime(r,b)});
  L(`🏗️ ${r.n}: ${BUILD[b].n} inşaatı vali kararıyla başladı.`,'ok');
};
function govPanel(){
  const a=A(),regs=regOf('A');
  let h=`<div class="panel"><h2>🏙️ Valilikler</h2><p class="hint">Başkan bölgelere vali atar. Vali, bölgenin gelirinin %40'ını bölge hazinesinde biriktirir (devlet bütçesinden ayrılır), meclis oylaması beklemeden bina yaptırır ve inşaat %40 ucuza gelir. Hazineye kendi paranı da bağışlayabilirsin.</p><div class="grid">`;
  regs.forEach(r=>{
    const mine=r.gov==='me';
    h+=card(esc(r.n)+(mine?' <span class="owner">valisin</span>':''),
      `<p>Vali: ${mine?'<b>Sen</b>':'Yapay zekâ'}${mine?` · Hazine: <b>${fmt(r.treas||0)}₺</b>`:''}</p>`+
      (mine?`<div class="row" style="margin:4px 0">${sel('govB_'+r.id,Object.keys(BUILD).map(b=>[b,`${BUILD[b].i} ${BUILD[b].n} (${fmt(Math.floor(buildCost(r,b)*0.6))}₺)`]))}</div><div class="btns">${btn('İnşa ettir',`data-a="govBuild" data-id="${r.id}"`,'blue')}${btn('Bağış 100.000₺',`data-a="govFund" data-id="${r.id}"`,'gold sm',S.me.money<100000)}${btn('Valilikten ayrıl',`data-a="govDismiss" data-id="${r.id}"`,'danger sm')}</div>`
       :(isLeader()?btn('Kendimi vali ata',`data-a="govAppoint" data-id="${r.id}"`,'gold sm'):'<p class="dim">Başkan atar.</p>')));
  });
  return h+'</div></div>'+coupPanel();
}
/* ---- darbe ---- */
function coupChance(){
  const m=S.me,a=A(),tot=a.parties.reduce((x,p)=>x+Math.max(0,p.supp),0)||1,mp=a.parties.find(p=>p.id===m.party);
  const share=mp?Math.max(0,mp.supp)/tot:0;
  const army=regOf('A').reduce((x,r)=>x+r.idx.m,0)/Math.max(1,regOf('A').length);
  return clamp(0.06+Math.min(0.25,(m.dmg||0)/4e6)+share*0.5+Math.min(0.05,(m.paper?m.paper.subs:0)/8000)+(m.level>=30?0.05:0)-Math.max(0,army-5)*0.015,0.04,0.65);
}
ACT.coup=()=>{
  const m=S.me,a=A();
  if(isLeader())return msg('Zaten devletin başındasın.');
  if(m.level<10)return msg('Darbe için seviye 10 gerekli.');if(!m.party)return msg('Darbe için bir partide olmalısın.');
  if(m.jail>S.t)return msg('Hapistesin.');if(S.t<(m.coupCd||0))return msg(`Yeni girişim için ${fmtDur(m.coupCd-S.t)} bekle.`);
  if(a.gov==='dictatorship'&&false)return;
  if(m.money<250000)return msg('Darbe için 250.000₺ gerekli.');
  if(!confirm('Darbe girişimi: 250.000₺ harcanır, başarısız olursan hapse düşersin. Devam?'))return;
  m.money-=250000;m.coupCd=S.t+24*HOUR;const p=coupChance();
  if(Math.random()<p){
    a.leaderMe=true;a.leader=m.name;a.rulingParty=m.party;a.warScore=0;
    news(`⚔️ DARBE! ${m.name} iktidarı ele geçirdi.`);L(`⚔️ Darbe başarılı! ${nameOf('A')} artık senin yönetiminde.`,'ok');addXP(200);
    A().parties.forEach(q=>{if(q.id!==m.party)q.supp*=0.9;});
  }else{
    const loss=Math.floor(m.money*0.2);m.money-=loss;m.jail=S.t+3*HOUR;
    news(`🚨 ${m.name} darbe girişiminde yakalandı.`);L(`🚨 Darbe başarısız! ${fmt(loss)}₺ el konuldu, 3 saat hapistesin.`,'bad');
  }
};
function coupPanel(){
  const m=S.me;
  let h='<div class="panel"><h2>⚔️ Darbe</h2><div class="card">';
  if(isLeader())return h+'<p>Zaten iktidardasın.</p></div></div>';
  h+=`<p class="hint">Seçimi beklemeden iktidarı almaya çalışırsın. Başarı şansı rütben, partinin gücü, gazete abonelerin ve ordunun gücüne bağlıdır. Başarısız olursan paranın %20'si el konur ve 3 saat hapse girersin.</p>
  <p>Tahmini başarı şansın: <b>%${Math.round(coupChance()*100)}</b> · Maliyet: 250.000₺ · Şartlar: seviye 10, bir partiye üyelik</p>`;
  if(m.jail>S.t)h+=`<p class="bad">Hapistesin: ${cd(m.jail)}</p>`;
  else if(S.t<(m.coupCd||0))h+=`<p class="dim">Yeni girişim: ${cd(m.coupCd)}</p>`;
  h+=btn('⚔️ Darbe girişimi','data-a="coup"','danger',m.level<10||!m.party||m.money<250000||m.jail>S.t||S.t<(m.coupCd||0));
  return h+'</div></div>';
}
/* ---- sıralama tablosu ---- */
async function lbPush(){
  if(!MP.ok)return;
  try{await MP.fb('PUT','board/'+MP.uid(),Object.assign({name:S.me.name,lv:S.me.level,money:Math.round(S.me.money),dmg:Math.round(S.me.dmg||0),rank:rankName(),tax:Math.round(S.me.taxPaid||0),adm:S.me.admin?1:0,seen:Date.now()},wkGain()));}catch(e){}
}
async function lbPoll(){
  if(!MP.ok)return;LB.last=Date.now();
  try{
    const d=await MP.fb('GET','board');const rows=d?Object.keys(d).map(k=>Object.assign({id:k},d[k])):[];
    LB.rows=rows;LB.err='';const sig=rows.length+':'+rows.map(r=>r.lv+'/'+r.money).join(',');if(sig!==LB.sig){LB.sig=sig;if(UI.tab==='lb')S.dirty=true;}
  }catch(e){LB.err=/401|403|ermission/i.test(e.message)?'Firebase kuralları güncel değil: Profil › Hesap bölümünden "Kuralları kopyala" ile yenile.':e.message;if(UI.tab==='lb')S.dirty=true;}
}
const lbTimer=()=>{if(UI.tab==='lb'&&MP.ok&&Date.now()-LB.last>8000)lbPoll();};
ACT.lbSort=d=>{LB.sort=d.s;};
function tabLb(){
  const wk=LB.per==='wk';
  const keys=wk?{wm:['Servet artışı','wm'],wl:['Seviye artışı','wl'],wd:['Savaş hasarı','wd'],wt:['Ödenen vergi','wt']}
              :{lv:['Seviye','lv'],money:['Servet','money'],dmg:['Savaş hasarı','dmg'],tax:['Ödenen vergi','tax']};
  if(!keys[LB.sort])LB.sort=Object.keys(keys)[0];
  const cw=wkNo();
  let rows=LB.rows.filter(r=>!r.adm).map(r=>{const o=Object.assign({},r);if(wk&&r.w!==cw){o.wm=o.wl=o.wd=o.wt=0;}return o;});
  const me=rows.find(r=>r.id===(MP.uid&&MP.uid()));
  const g=wkGain();
  if(me){me.lv=S.me.level;me.money=Math.round(S.me.money);me.dmg=Math.round(S.me.dmg||0);me.rank=rankName();me.tax=Math.round(S.me.taxPaid||0);Object.assign(me,g);}
  else if(!S.me.admin)rows.push(Object.assign({id:'me',name:S.me.name,lv:S.me.level,money:Math.round(S.me.money),dmg:Math.round(S.me.dmg||0),rank:rankName(),tax:Math.round(S.me.taxPaid||0)},g));
  if(!wk&&S.me.admin&&typeof botRows==='function')botRows(50).forEach(b=>rows.push({id:b.id,name:'🤖 '+b.name,lv:b.lv,money:b.money,dmg:0,rank:'—',tax:b.tax}));
  const k=keys[LB.sort][1];rows.sort((a,b)=>(b[k]||0)-(a[k]||0));
  const myId=MP.ok?MP.uid():'me';
  let h=`<div class="panel"><h2>🏆 Sıralama</h2><div class="btns" style="margin-bottom:6px">${btn('Genel','data-a="lbPer" data-p="all"',!wk?'gold':'sm')}${btn('📅 Bu hafta','data-a="lbPer" data-p="wk"',wk?'gold':'sm')}</div>
  <div class="btns">${Object.keys(keys).map(s=>btn(keys[s][0],`data-a="lbSort" data-s="${s}"`,LB.sort===s?'gold sm':'sm')).join('')}</div>`;
  if(wk)h+=`<p class="hint">Haftalık sıralama Pazartesi sıfırlanır. Bitişine <b>${fmtDur(wkEnd()-Date.now())}</b> var. Değerler bu hafta başladığından beri olan artıştır.</p>`;
  if(!MP.ok)h+='<div class="al warn" style="margin-top:8px">Diğer oyuncuları görmek için Profil › Hesap bölümünden giriş yap. Şimdilik sadece sen görünüyorsun.</div>';
  if(LB.err)h+=`<div class="al bad">${esc(LB.err)}</div>`;
  const pos=rows.findIndex(r=>r.id===myId||r.id==='me');
  if(pos>=0)h+=`<p class="hint">Senin sıran: <b>${pos+1}</b> / ${rows.length}</p>`;
  h+='<table style="margin-top:6px"><tr><th>#</th><th align=left>Oyuncu</th><th>Rütbe</th><th>Sv</th><th>'+keys[LB.sort][0]+'</th></tr>';
  const medal=['🥇','🥈','🥉'];
  rows.slice(0,50).forEach((r,i)=>{const mine=r.id===myId||r.id==='me';
    h+=`<tr style="${mine?'background:#1a2330':''}"><td>${medal[i]||i+1}</td><td>${esc(r.name)}${mine?' (sen)':''}</td><td class="dim">${esc(r.rank||'')}</td><td class="num">${r.lv}</td><td class="num"><b>${wk&&(r[k]||0)>0?'+':''}${fmt(r[k]||0)}</b></td></tr>`;});
  return h+'</table></div>';
}
