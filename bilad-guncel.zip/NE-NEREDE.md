# Bilâd-ı Mütenâfise — Ne nerede, ne işe yarar

Oyun 7 sekmeden oluşur. Her özelliğin tek bir evi var (oyunda: Profil › Rehber › "Ne nerede?").

## 🏠 Ana Sayfa
- Ana Sayfa: bugün ne yapmalıyım, hızlı eylemler, bölgen, kısayollar
- Görevler: günlük giriş ödülü, günlük/haftalık görevler, başarımlar, etkinlikler
- Günlük: son olayların kaydı

## 🗺️ Harita
- Harita: dünya haritası, kim nereye hâkim; nüfus/altın/petrol/endeks katmanları
- Şehirler: devletlere göre şehir listesi, şehir bilgisi ve geliştirme

## ⛏️ Ekonomi
- Çalış (kaynak üret) · Otomatik (sen yokken çalışma/savaş) · Fabrika/Holding · Açık artırma
- Depo (al-sat, yatırım) · Pazar (oyuncu pazarı) · Üretim (ara mamul) · Banka · Bağış

## 🏛️ Devlet
- Devlet: bütçe, vergi, yasalar, ad/renk/bayrak, **Savaş ilanı** (önce hedef devlet, sonra o devletin bölgesi)
- Parti · Seçim · Başkan (+darbe) · Vali

## ⚔️ Savaş
- Savaş (vur, antrenman) · Ortak (gerçek oyuncular arası) · Casus · Diplomasi

## 👥 Topluluk
- Makaleler · Gazete · Sohbet · İttifak · Sıralama

## 👤 Profil
- Profil (karakter, yetenek) · Mesajlarım · Yardımcılar (Vekil + Danışman) · Ayarlar · Rehber · Hesap

## 👑 Yönetim (yalnız yönetici)
- Yönetim (tek kapı) → Panel, Yapay Zekâ, Güvenlik, Yönetim Merkezi, Kodlar

## Yükleme
GitHub'da `index.html`, `sw.js` ve `js/` klasörünün içindeki 10 dosyayı değiştir (eskileri sil, yenilerini yükle).
harita.js, takvim.js, simgeler ve manifest değişmedi.
